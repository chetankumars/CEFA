#customlog.py

__all__ = ['CustomLog']
class CustomLog:

    """
    Custom Log class to define common dimensions

    """
    asset_guid = "Asset_GUID"
    start_time = "start_time"
    sprequest_time = "sprequest_time"
    sprequestend_time = "sprequestend_time"
    sp_req_param = "sp_req_param"
    user_preferences =  "user_preferences"
    user_pref_val = "func:fnUserPreference"
    add_defect_tracker_details ="add_defect_or_add_row_to_defect"
    add_defect_tracker_details_val = "func:defectTracker"
    get_asset_details = "getAssetDetails"
    get_asset_details_val = "func:getAssetDetails"
    end_time = "end_time"
    error_messsage = "error_messsage"
    defect_details = "defect_details"
    defect_detail_val = "func:fnDefectDetails"
    defect_tracker_asset = "defect_tracker_assets"
    defect_tracker_asset_val = "func:fnDefectTrackerAssets"
    search_lookup ="searchLookup"
    search_lookup_val ="func:getSearchLookup"
    get_assets = "getAssets"
    get_assets_val = "func:fnGetAssets"
    get_user_info = "get_user_info"
    get_user_info_supplier_val = "func:fnGetUserInfo - SupplierDetails"
    get_user_info_geo_val = "func:fnGetUserInfo - UserGeoDetails"
    get_user_info_role_val = "func:fnGetUserInfo - UserRoleDetails"
    schema_errors = "schema_errors"
    Input_JSON = "Input_Json"
    status = "status"
