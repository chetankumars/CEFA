#test_defect_details_init.py

import sys
import os
import unittest
from unittest import mock
from unittest import IsolatedAsyncioTestCase
from unittest.mock import patch, Mock, MagicMock, create_autospec
from test.support import EnvironmentVarGuard
import azure.functions as func
sys.path.insert(0, os.getcwd())
from tests.load_environment_variables import EnvironmentVariable
load = EnvironmentVariable()
from getDefectDetails import main

class DefectDetailsInitTest(unittest.TestCase):
    
    @patch('getDefectDetails.businesslogic.get_defect_details.DefectDetails')
    async def test_defect_details_init_return_ok(self, mocked):
        mocked_value = '{"searchdatacount": {"totalcount": 1}, "assetdtls": [{"Asset_GUID": "3978559C3D9D45D9E04400306E4AD01A", "region": "Southern", "route": "Kent", "area": "Orpington", "elr": "TTH", "railway_id": "113A", "asset_grp": "Bridge", "asset_type": "Culvert", "owning_party": "Network Rail (Other)"}], "searchresult": [{"defect_id": "18107", "description": "PNE : Dense vegetation prevents locating.", "location": "Ends of culvert", "loc_major": null, "loc_minor": null, "details": [{"exam_id": "11033774", "exam_actual_date": "2019-12-12", "exam_type": "Visual", "deterioration": "NV", "risk_score": "8", "access_granted": "N", "access_required": "Y", "repaired": "N", "closure_flg": "N"}, {"exam_id": "9031972", "exam_actual_date": "2017-05-14", "exam_type": "Visual", "deterioration": "Baseline", "risk_score": "6", "access_granted": "Y", "access_required": "Y", "repaired": "N/A", "closure_flg": "N"}]}]}'
        mocked.return_value.get_defect_details_info.return_value = mocked_value, 200
        http_request = func.HttpRequest(
            method='GET',
            body='',
            url='', 
            headers= {'X-Defect-Filters': '{"assetGuid":"3978559C3D9D45D9E04400306E4AD01A","isOpenDefect":"Y"}'}
        )

        response = await main(http_request)

        self.assertEqual(response.status_code, 200)
        self.assertEqual(
            response.get_body(),
            b'{"searchdatacount": {"totalcount": 1}, "assetdtls": [{"Asset_GUID": "3978559C3D9D45D9E04400306E4AD01A", "region": "Southern", "route": "Kent", "area": "Orpington", "elr": "TTH", "railway_id": "113A", "asset_grp": "Bridge", "asset_type": "Culvert", "owning_party": "Network Rail (Other)"}], "searchresult": [{"defect_id": "18107", "description": "PNE : Dense vegetation prevents locating.", "location": "Ends of culvert", "loc_major": null, "loc_minor": null, "details": [{"exam_id": "11033774", "exam_actual_date": "2019-12-12", "exam_type": "Visual", "deterioration": "NV", "risk_score": "8", "access_granted": "N", "access_required": "Y", "repaired": "N", "closure_flg": "N"}, {"exam_id": "9031972", "exam_actual_date": "2017-05-14", "exam_type": "Visual", "deterioration": "Baseline", "risk_score": "6", "access_granted": "Y", "access_required": "Y", "repaired": "N/A", "closure_flg": "N"}]}]}'
        )

    async def test_defect_detail_init_bad_request_invalid_header(self):
        http_request = func.HttpRequest(
            method='GET',
            body=None,
            url='/getDefectDetails', 
            headers= {'X-Defect-Filters': None}
        )

        response =await main(http_request)

        self.assertEqual(response.status_code, 400)
        self.assertEqual(
            response.get_body(),
            b'{"error": {"types": "Invalid Request", "title": "Header/Param validation failure", "status": 400, "detail": "", "instance": "DefectDetails"}}'
        )    

    async def test_defect_init_bad_request_without_header(self):
        http_request = func.HttpRequest(
            method='GET',
            body=None,
            url='/getDefectDetails', 
        )

        response = await main(http_request)

        self.assertEqual(response.status_code, 400)
        self.assertEqual(
            response.get_body(),
            b'{"error": {"types": "Invalid Request", "title": "Header/Param validation failure", "status": 400, "detail": "", "instance": "DefectDetails"}}'
        )     


    async def test_defect_detail_bad_request_invalid_input(self):
        http_request = func.HttpRequest(
            method='GET',
            body=None,
            url='/getDefectDetails', 
            headers= {'X-Defect-Filters': '{"assetGuid1":"3978559C3D9D45D9E04400306E4AD01A","isOpenDefect":"Y"}'}
        )

        response =await main(http_request)
        self.assertEqual(response.status_code, 400)