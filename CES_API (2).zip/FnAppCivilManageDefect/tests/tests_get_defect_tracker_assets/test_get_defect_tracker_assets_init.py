#test_get_defect_tracker_assets_init.py

import sys
import os
import unittest
from unittest.mock import patch
from unittest import IsolatedAsyncioTestCase
import azure.functions as func
from tests.load_environment_variables import EnvironmentVariable
EnvironmentVariable()
from getDefectTrackerAssets import main

class DefectTrackerAssetsSearchInitTest(unittest.TestCase):
    
    @patch('getDefectTrackerAssets.businesslogic.get_defect_tracker_assets.DefectTracker')
    async def test_defect_tracker_init_return_ok(self, mocked):
        mocked_value = '{"searchdatacount": {"currentpage": 1, "totalcount": 4, "totalpages": 1}, "searchresult": [{"asset_guid": "3978559C2E6E45D9E04400306E4AD01A", "region": "Southern", "route": "Kent", "area": "London Bridge", "elr": "XTD", "struct_no": "90A", "start_mileage": "4.000000", "struct_type": "Underline Bridge", "mat_type": " RBE - Brick", "owner": "Network Rail (CE-Struct)", "hce_flag": "No", "total_defects": "14", "open_defects": "5", "highest_open_risk_score": "0"}, {"asset_guid": "3978559C2F7345D9E04400306E4AD01A", "region": "Southern", "route": "Kent", "area": "London Bridge", "elr": "XTD", "struct_no": "90", "start_mileage": "4.000000", "struct_type": "Underline Bridge", "mat_type": " RBE - Brick", "owner": "Network Rail (CE-Struct)", "hce_flag": "No", "total_defects": "10", "open_defects": "3", "highest_open_risk_score": "0"}, {"asset_guid": "3978559C2F8845D9E04400306E4AD01A", "region": "Southern", "route": "Kent", "area": "London Bridge", "elr": "XTD", "struct_no": "90B", "start_mileage": "4.000000", "struct_type": "Underline Bridge", "mat_type": " RBE - Brick", "owner": "Network Rail (CE-Struct)", "hce_flag": "No", "total_defects": "0", "open_defects": "0", "highest_open_risk_score": "0"}, {"asset_guid": "3978559C3A9545D9E04400306E4AD01A", "region": "Southern", "route": "Kent", "area": "Orpington", "elr": "VIR", "struct_no": "27C", "start_mileage": "4.000000", "struct_type": "Underline Bridge", "mat_type": " RBE - Cast in-situ reinforced Concrete", "owner": "Network Rail (CE-Struct)", "hce_flag": "No", "total_defects": "8", "open_defects": "6", "highest_open_risk_score": "0"}]}'
        mocked.return_value.get_defect_tracker_assets.return_value = mocked_value, 200
        http_request = func.HttpRequest(
            method='GET',
            body='',
            url='', 
            headers= {'X-Defect-Filters': '{"region_name": "Southern","route_id": 0,"area_id": 0,"elr_id":0,"start_mileage_from": 3.5,"start_mileage_to": 4,"railway_id": null,"ast_grp_id": 0,"ast_typ_id": [0],"ownparty_name": null,"mattyp_id": 0,"hceflg_name": "All","open_defect_from": -1,"open_defect_to" : 99999,"open_defect_score_from": -1,"open_defect_score_to": 99999,"is_export_to_doc": "N","sort_column": "ELR","sort_order": "asc","page_no": 1,"rows_per_page": 5}'}
        )

        response =await main(http_request)
        self.assertEqual(response.status_code, 200)
        self.assertEqual(
            response.get_body(),
            b'{"searchdatacount": {"currentpage": 1, "totalcount": 4, "totalpages": 1}, "searchresult": [{"asset_guid": "3978559C2E6E45D9E04400306E4AD01A", "region": "Southern", "route": "Kent", "area": "London Bridge", "elr": "XTD", "struct_no": "90A", "start_mileage": "4.000000", "struct_type": "Underline Bridge", "mat_type": " RBE - Brick", "owner": "Network Rail (CE-Struct)", "hce_flag": "No", "total_defects": "14", "open_defects": "5", "highest_open_risk_score": "0"}, {"asset_guid": "3978559C2F7345D9E04400306E4AD01A", "region": "Southern", "route": "Kent", "area": "London Bridge", "elr": "XTD", "struct_no": "90", "start_mileage": "4.000000", "struct_type": "Underline Bridge", "mat_type": " RBE - Brick", "owner": "Network Rail (CE-Struct)", "hce_flag": "No", "total_defects": "10", "open_defects": "3", "highest_open_risk_score": "0"}, {"asset_guid": "3978559C2F8845D9E04400306E4AD01A", "region": "Southern", "route": "Kent", "area": "London Bridge", "elr": "XTD", "struct_no": "90B", "start_mileage": "4.000000", "struct_type": "Underline Bridge", "mat_type": " RBE - Brick", "owner": "Network Rail (CE-Struct)", "hce_flag": "No", "total_defects": "0", "open_defects": "0", "highest_open_risk_score": "0"}, {"asset_guid": "3978559C3A9545D9E04400306E4AD01A", "region": "Southern", "route": "Kent", "area": "Orpington", "elr": "VIR", "struct_no": "27C", "start_mileage": "4.000000", "struct_type": "Underline Bridge", "mat_type": " RBE - Cast in-situ reinforced Concrete", "owner": "Network Rail (CE-Struct)", "hce_flag": "No", "total_defects": "8", "open_defects": "6", "highest_open_risk_score": "0"}]}'
        )

    async def test_defect_tracker_bad_request_without_header(self):
        http_request = func.HttpRequest(
            method='GET',
            body=None,
            url='/getDefectTrackerAssets', 
            headers= {}
        )

        response = await main(http_request)
        self.assertEqual(response.status_code, 400)
        self.assertEqual(
            response.get_body(),
            b'{"error": {"types": "Invalid Request", "title": "Header/Param validation failure", "status": 400, "detail": "Bad Request", "instance": "DefectTracker"}}'
        ) 

    async def test_defect_tracker_bad_request_invalid_header(self):
        http_request = func.HttpRequest(
            method='GET',
            body=None,
            url='/getDefectTrackerAssets', 
            headers= {'X-Defect-Filters': ""}
        )

        response = await main(http_request)
        self.assertEqual(response.status_code, 400)
        self.assertEqual(
            response.get_body(),
             b'{"error": {"types": "Invalid Request", "title": "Header/Param validation failure", "status": 400, "detail": "Bad Request", "instance": "DefectTracker"}}'
        ) 

    async def test_defect_tracker_bad_request_invalid_input(self):
        http_request = func.HttpRequest(
            method='GET',
            body=None,
            url='/getDefectTrackerAssets', 
            headers= {'X-Defect-Filters': '{"region_name1": "Southern","route_id": 0,"area_id": 0,"elr_id":0,"start_mileage_from": 3.5,"start_mileage_to": 4,"railway_id": null,"ast_grp_id": 0,"ast_typ_id": [0],"ownparty_name": null,"mattyp_id": 0,"hceflg_name": "All","open_defect_from": -1,"open_defect_to" : 99999,"open_defect_score_from": -1,"open_defect_score_to": 99999,"isexporttodoc": "N","sortcolumn": "ELR","sortorder": "asc","pageno": 1,"rowsperpage": 5}'}
        )

        response = await main(http_request)
        self.assertEqual(response.status_code, 400)
    