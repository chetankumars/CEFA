# test_close_defect_business_logic.py

import unittest
from unittest.mock import patch
from tests.load_environment_variables import EnvironmentVariable
EnvironmentVariable()
from closeDefect.business_logic.close_defect import CloseDefect

class CloseDefectTest(unittest.TestCase):
    
    @patch('closeDefect.business_logic.close_defect.SqlOperation')
    async def test_close_defect_return_ok(self, mocked):
        defect_details_mock = '{"save_status": 1,"error_msg": "error details on the message" }'
        mocked.return_value.fetch_one.return_value = defect_details_mock, 200
        response, status_code = await CloseDefect().defect_closing_details('120', 'abc123ef5678werg')
        self.assertEqual(status_code, 200)
        
    @patch('closeDefect.business_logic.close_defect.SqlOperation')
    async def test_close_defect_return_nocontent(self, mocked):
        mocked.return_value.fetch_one.return_value = None
        response, status_code = await CloseDefect().defect_closing_details('120', 'abc123ef5678werg')
        self.assertEqual(status_code, 204)
        self.assertEqual(response, '{}')

    @patch('closeDefect.business_logic.close_defect.SqlOperation')
    async def test_close_defect_return_nocontent_invalidJson(self, mocked):
        mocked.return_value.fetch_one.return_value = '{"save_status": 1,}'
        response, status_code = await CloseDefect().defect_closing_details('120', 'abc123ef5678werg')
        self.assertEqual(status_code, 204)
        self.assertEqual(response, '{}')

    @patch('closeDefect.business_logic.close_defect.SqlOperation.fetch_one')
    async def test_close_defect_return_Internalservererror(self, mocked):
        mocked.side_effect = ConnectionError
        response,status_code = await CloseDefect().defect_closing_details('120', 'abc123ef5678werg')
        self.assertEqual(status_code, 500)
        self.assertEqual(response, '{}')
