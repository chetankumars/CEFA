# test_close_defect_init.py

import unittest
from unittest.mock import patch
import azure.functions as func
from tests.load_environment_variables import EnvironmentVariable
EnvironmentVariable()
from closeDefect import main

class CloseDefectInitTest(unittest.TestCase):

    @patch('closeDefect.CloseDefect')
    async def test_init_return_ok(self, mocked):
        defect_details_mock = '{"save_status": 1,"error_msg": "error details on the message" }'
        mocked.return_value.defect_closing_details.return_value = defect_details_mock, 200
        req = func.HttpRequest(
        method='delete',
        body=None,
        url='/closeDefect',
        params={'defectId': '120',
        'userKey' : 'abc123ef5678werg'})

        resp = await main(req)
        self.assertEqual(resp.status_code, 200)
        self.assertEqual(resp.get_body(),
        b'{"save_status": 1,"error_msg": "error details on the message" }'
        )

    @patch('closeDefect.ErrorResponse')
    async def test_init_return_badrequest(self, mocked):
        mocked.return_value.__str__.return_value = "defectId or userKey query parameter is missing."
        req = func.HttpRequest(
        method='delete',
        body=None,
        url='/closeDefect',
        params={'userKey' : 'abc123ef5678werg'})

        resp = await main(req)
        self.assertEqual(resp.status_code, 400)
