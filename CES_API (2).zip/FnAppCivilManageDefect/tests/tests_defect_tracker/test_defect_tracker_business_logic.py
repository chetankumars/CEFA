#test_defect_tracker_business_logic.py

import sys
import os
import unittest
from unittest.mock import patch
import azure.functions as func
from tests.load_environment_variables import EnvironmentVariable
EnvironmentVariable()
from defectTracker.businesslogic.defect_tracker_details import DefectTrackerDetails
import json

class DefectTrackerBusinessLogic(unittest.TestCase):

    @patch('defectTracker.businesslogic.defect_tracker_details.SqlOperation')
    def test_get_defect_tracker_bl_return_ok_y(self,mocked):
        get_defect_tracker_details = ['{"exam_type":[{"exam_type_id":1,"exam_type_val":"Visual"},{"exam_type_id":2,"exam_type_val":"Detailed"},{"exam_type_id":3,"exam_type_val":"Underwater"},{"exam_type_id":4,"exam_type_val":"Additional"},{"exam_type_id":5,"exam_type_val":"One-off - Additional"},{"exam_type_id":6,"exam_type_val":"One-off - Additional Assess."},{"exam_type_id":7,"exam_type_val":"Additional - Assessment"},{"exam_type_id":8,"exam_type_val":"Line Of Route"},{"exam_type_id":9,"exam_type_val":"Rapid response - Bridge strike"},{"exam_type_id":10,"exam_type_val":"Rapid response - Other"},{"exam_type_id":11,"exam_type_val":"Reconnaissance"},{"exam_type_id":12,"exam_type_val":"Prelim. Advice Notification"},{"exam_type_id":13,"exam_type_val":"Additional - Tenanted Arch"},{"exam_type_id":14,"exam_type_val":"Enhanced"},{"exam_type_id":15,"exam_type_val":"Miscellaneous"}],"defect_id":23778}']
        mocked.return_value.fetch_one.return_value = get_defect_tracker_details
        response, status_code = DefectTrackerDetails().get_defect_tracker_info('Y')
        self.assertEqual(status_code, 200)
    
    @patch('defectTracker.businesslogic.defect_tracker_details.SqlOperation')
    def test_get_defect_tracker_bl_return_ok_n(self,mocked):
        get_defect_tracker_details = ['{"exam_type":[{"exam_type_id":1,"exam_type_val":"Visual"},{"exam_type_id":2,"exam_type_val":"Detailed"},{"exam_type_id":3,"exam_type_val":"Underwater"},{"exam_type_id":4,"exam_type_val":"Additional"},{"exam_type_id":5,"exam_type_val":"One-off - Additional"},{"exam_type_id":6,"exam_type_val":"One-off - Additional Assess."},{"exam_type_id":7,"exam_type_val":"Additional - Assessment"},{"exam_type_id":8,"exam_type_val":"Line Of Route"},{"exam_type_id":9,"exam_type_val":"Rapid response - Bridge strike"},{"exam_type_id":10,"exam_type_val":"Rapid response - Other"},{"exam_type_id":11,"exam_type_val":"Reconnaissance"},{"exam_type_id":12,"exam_type_val":"Prelim. Advice Notification"},{"exam_type_id":13,"exam_type_val":"Additional - Tenanted Arch"},{"exam_type_id":14,"exam_type_val":"Enhanced"},{"exam_type_id":15,"exam_type_val":"Miscellaneous"}],"defect_id":23778}']
        mocked.return_value.fetch_one.return_value = get_defect_tracker_details
        response, status_code = DefectTrackerDetails().get_defect_tracker_info('N')
        self.assertEqual(status_code, 200)

    @patch('defectTracker.businesslogic.defect_tracker_details.SqlOperation')
    def test_post_defect_tracker_bl_return_created(self,mocked):
        save_defect_tracker_details ='{"defect_id":1,"user_key":"abc123ef5678werg","supplier_id":1,"asset_guid":"xyv123ef5678werg","description":"cvbn","location":"sfsffff","loc_major":"sssss","loc_minor":"dddd","exam_dt":"11\/12\/2020","exam_id":1001,"access_req":"Y","exam_type_id":2,"recomm_no":"12346","risk_score":1,"deterioration_flg":"Y","repaired_flg":"Y","closure_flg":"N","accs_grant_flg":"N","comments":"ddwadwdwdwqdqwdqdw","isnewdefect":"Y"}'
        mocked.return_value.fetch_one.return_value = True, ''
        response, status_code = DefectTrackerDetails().post_defect_tracker_info(json.loads(save_defect_tracker_details))
        self.assertEqual(status_code, 201)
    
    @patch('defectTracker.businesslogic.defect_tracker_details.SqlOperation')
    def test_post_defect_tracker_bl_return_internal_server_error(self,mocked):
        save_defect_tracker_details ='{"user_key":"abc123ef5678werg","supplier_id":1,"asset_guid":"xyv123ef5678werg","description":"cvbn","location":"sfsffff","loc_major":"sssss","loc_minor":"dddd","exam_dt":"11\/12\/2020","exam_id":1001,"access_req":"Y","exam_type_id":2,"recomm_no":"12346","risk_score":1,"deterioration_flg":"Y","repaired_flg":"Y","closure_flg":"N","accs_grant_flg":"N","comments":"ddwadwdwdwqdqwdqdw","isnewdefect":"Y"}'
        mocked.return_value.fetch_one.return_value = ''
        try:
            response, status_code = DefectTrackerDetails().post_defect_tracker_info(save_defect_tracker_details)
        except:
            pass
            


        
