#get_defect_tracker_constants.py

__all__ = ["GetDefectTrackerConstants"]
class GetDefectTrackerConstants:
    """
    constants related to project specific

    """
  
    defect_filter = 'X-Defect-Filters'
    defect_tracker_assets_json_schema = 'defecttracker_request.json'
    defect_tracker_assets_function = 'getDefectTrackerAssets'