# Get Defect Tracker Assets

## Description
    Service to get all defect tracker assets from the CES db.
    
    APIM URL: https://apim-uks-dev-ces-0001.azure-api.net/II/CESAPI/assets/defects/search
    FUNCTION URL: https://fnp-uks-dev-ces-funcedst0001.azurewebsites.net/api/getDefectTrackerAssets
    
  ## Request header for defect tracker assets
    Method Type: GET
    Header Name : X-Defect-Filters
    Sample Value : {"region_name": "Southern","route_id": 0,"area_id": 0,"elr_id": [0],"start_mileage_from": 2,"start_mileage_to": 4,"railway_id": null,"ast_grp_id": 0,"ast_typ_id": [0],"ownparty_name": [null],"mattyp_id": [0],"hceflg_name": "All","open_defect_from": -1,"open_defect_to": 99999,"open_defect_score_from": -1,"open_defect_score_to": 99999,"is_export_to_doc": "N","sort_column": "ELR","sort_order": "asc","page_no": 1,"rows_per_page": 5}