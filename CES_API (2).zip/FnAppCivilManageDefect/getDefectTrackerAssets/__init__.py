#__init__.py

"""main method."""
import azure.functions as func
from getDefectTrackerAssets.businesslogic import get_defect_tracker_assets as bu
from .businesslogic.get_defect_tracker_assets import DefectTracker
from common import AppStatus,SharedConstants,ErrorResponse, CustomMessage
from .constants.get_defect_tracker_constants import GetDefectTrackerConstants

def main(req: func.HttpRequest) -> func.HttpResponse:
    """calling business logic inside main."""
  
    defect_filter = GetDefectTrackerConstants.defect_filter
    if defect_filter in req.headers and req.headers[defect_filter]:
       asset_filter = req.headers[defect_filter]
       obj = bu.DefectTracker()
       message, status_code = obj.get_defect_tracker_assets(asset_filter)
    else:
       message = ErrorResponse(SharedConstants.request_val_failure,SharedConstants.request_header_failure,
                                              AppStatus.bad_Request.value,CustomMessage.bad_request, DefectTracker.__name__).__str__()
       status_code = AppStatus.bad_Request.value[0]
         
    return func.HttpResponse(body=message, status_code= status_code, mimetype=SharedConstants.json_mime_type)

if __name__ == SharedConstants.main:
    main(func.HttpRequest)
