#get_defect_tracker_assets.py

"""Business Logic class"""
import sys
import os
import logging
import azure.functions as func
import json
from common import Logger
from common.utilities.json_helper import JsonHelper 
from common.validate.validation_helper import ValidationHelper
from datetime import datetime, timezone
from getDefectTrackerAssets.model.defecttracker_filter_req import DefectTrackerFilterRequest
from common import CustomLog, AppStatus, SharedConstants,ErrorResponse,SqlOperation
from ..constants.get_defect_tracker_constants import GetDefectTrackerConstants

FunctionApp = GetDefectTrackerConstants.defect_tracker_assets_function
Schema = SharedConstants.schema
JsonSchemaFile = GetDefectTrackerConstants.defect_tracker_assets_json_schema
istraceenabled = os.environ[SharedConstants.trace_enabled]


class DefectTracker:
    """ defect tracker class to get all defect tracker assets json response """ 
    def __init__(self):
        self.response = str({})
        self.status_code = AppStatus.ok.value[0]
        self.properties = {CustomLog.defect_tracker_asset : CustomLog.defect_tracker_asset_val}
        self.properties[CustomLog.start_time] = datetime.now(timezone.utc).isoformat()
        self.properties[CustomLog.status] = True
        Logger.__init__(self, name = self.__class__.__name__, start_time = datetime.now(timezone.utc))
        self.json_helper = JsonHelper()
        self.defecttracker_default =  DefectTrackerFilterRequest()
        self.sql_query = """
                          EXEC [CES].[sp_Get_DefectTrackerSearch_SearchResult]
                          @Input_JSON = ?
                          """

        self.data_mapper = {'region_name':'region_name',
                            'route_id':'route_id',
                            'area_id':'area_id',
                            'elr_id':'elr_id',
                            'start_mileage_from':'start_mileage_from',
                            'start_mileage_to':'start_mileage_to',
                            'railway_id':'railway_id',
                            'ast_grp_id':'ast_grp_id',
                            'ast_typ_id':'ast_typ_id',
                            'ownparty_name':'ownparty_name',
                            'mattyp_id':'mattyp_id',
                            'hceflg_name':'hceflg_name',
                            "open_defect_from":'open_defect_from',
                            "open_defect_to":'open_defect_to',
                            "open_defect_score_from":'open_defect_score_from',
                            "open_defect_score_to":'open_defect_score_to',
                            'is_export_to_doc':'isexporttodoc',
                            'sort_column':'sortcolumn',
                            'sort_order':'sortorder',
                            'page_no':'pageno',
                            'rows_per_page': 'rowsperpage'
                        }

        

    def validate_json(self, req):
        with open(os.path.join(os.getcwd(),FunctionApp,Schema,JsonSchemaFile), SharedConstants.file_read_mode) as _json_file:
            schema = self.json_helper.parse_json(_json_file.read())
        is_invalid_schema, errors = ValidationHelper().validate_json(req,schema[1])
        if is_invalid_schema:
            self.status_code = AppStatus.bad_Request.value[0]
            self.response = ErrorResponse(SharedConstants.request_val_failure,SharedConstants.invalid_input_value_msg,
                                              AppStatus.bad_Request.value, self.json_helper.stringify_json(errors)[1],
                                              DefectTracker.__name__).__str__()
        
             
    def map_dictionary(self, json_req):
        """ this method map the request column to the db column

        Args:
            json_req(json)

        Returns:
            json(str) 

        """

        return self.json_helper.stringify_json(dict((self.data_mapper.get(k,k), v) for(k,v) in json_req.items()))[1]


    def populate_default(self, defecttracker_request):
        """
        Function to populate default value for defect tracker asset filters
       
        Args:
            defecttracker_request (json)

        Returns:
            defecttracker_request (json)    
        """
        
        return {key: defecttracker_request.get(key, self.defecttracker_default.defecttracker_req_default[key]) for key in self.defecttracker_default.defecttracker_req_default}
       
    def get_all_defect_tracker_assets_json(self, req):
        """
        Function to  call the database to get all defect tracker assets json based on filter condition
       
        Args:
            req (str)
        """
        if self.status_code == AppStatus.ok.value[0]:
            dtasset_filter_param = self.map_dictionary(req)
            data =  json.loads(dtasset_filter_param)
            if(str(data['region_name']).replace(' ','') == str("North, West and Central").replace(' ','')):
                data['region_name']= ("North, West and Central")
                dtasset_filter_param = json.dumps(data)
                self.properties["asset_filter-param"] = dtasset_filter_param
            self.properties[CustomLog.sp_req_param] = CustomLog.Input_JSON + SharedConstants.colon + str(dtasset_filter_param)
            self.properties[CustomLog.sprequest_time] = datetime.now(timezone.utc).isoformat()
            response = SqlOperation().fetch_one(self.sql_query, dtasset_filter_param)
            self.properties[CustomLog.sprequestend_time] = datetime.now(timezone.utc).isoformat()
            is_valid_response,json_res = self.json_helper.parse_json(response[0] if response else None)
            if is_valid_response:
                #self.response = self.json_helper.stringify_json(json_res)[1]
                self.response = response[0]
            else:   
                self.status_code = AppStatus.no_content.value

    
    def get_defect_tracker_assets(self, defecttracker_filter):
        """
        Function to get all defect tracker assets json based on filter condition
       
        Args:
            defecttracker_filter (str)

        Returns:
            json(str) 
            statuscode(int)     - 204 No Content
                                - 200 Success
                                - 500 Internal Server Error 
                                - 400 Bad Request
        """
        try:
            self.properties[CustomLog.sp_req_param] = CustomLog.Input_JSON + SharedConstants.colon + str(defecttracker_filter)
            is_parse_json_sucess, req = self.json_helper.parse_json(defecttracker_filter)
            if is_parse_json_sucess:
               req_default = self.populate_default(req)
               self.validate_json(req_default)

               self.get_all_defect_tracker_assets_json(req_default)
            else:
               self.status_code = AppStatus.bad_Request.value[0]   
               self.response = ErrorResponse(SharedConstants.request_val_failure,SharedConstants.error_type_store_procedure,
                                              AppStatus.bad_Request.value, SharedConstants.bad_json_request_msg,
                                              DefectTracker.__name__).__str__()  
               self.properties[CustomLog.error_messsage] =  req
        except:
            self.properties[CustomLog.error_messsage] =  str(sys.exc_info())
            self.properties[CustomLog.status] = False
            self.status_code = AppStatus.internal_server_error.value[0]
            self.response = ErrorResponse(str(sys.exc_info()[0]), DefectTracker.__name__,
                                 AppStatus.internal_server_error.value, str(sys.exc_info()),DefectTracker.__name__).__str__()
            Logger.exception(self,type=sys.exc_info()[0], value = sys.exc_info()[1], tb =sys.exc_info()[2], properties = self.properties)
        finally:
            if istraceenabled:
                self.properties[CustomLog.end_time] = datetime.now(timezone.utc).isoformat()
                Logger.request(self,properties= self.properties)
            return self.response, self.status_code    
  