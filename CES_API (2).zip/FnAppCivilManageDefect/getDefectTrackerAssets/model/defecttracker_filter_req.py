#defecttracker_filter_req.py
"""Business Logic Class"""
import sys
import os

class DefectTrackerFilterRequest:

    """ Defect tracker class to get all defect tracker assets json response """

    def __init__(self):
        self.defecttracker_req_default = {
                                    "region_name": None,
                                    "route_id":0,
                                    "area_id":0,
                                    "elr_id":[0],
                                    "start_mileage_from":-1,
                                    "start_mileage_to":99999,
                                    "railway_id": None,
                                    "ast_grp_id":0,
                                    "ast_typ_id":[0],
                                    "ownparty_name":[None],
                                    "mattyp_id":[0],
                                    "hceflg_name":"All",
                                    "open_defect_from": -1,
	                                "open_defect_to": 99999,			
	                                "open_defect_score_from": -1,	
	                                "open_defect_score_to": 99999,
                                    "is_export_to_doc":"N",
                                    "sort_column":"StartMileage",
                                    "sort_order":"asc",
                                    "page_no":1,
                                    "rows_per_page":25
        }