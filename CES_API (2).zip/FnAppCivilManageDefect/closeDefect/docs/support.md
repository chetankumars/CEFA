# Close Defect Details

## Description
    Service to close defect details from the CES db.
    
    APIM URL: https://apim-uks-dev-ces-0001.azure-api.net/II/CESAPI/assets/defects/close
    FUNCTION URL: https://fnp-uks-dev-ces-funcedst0001.azurewebsites.net/api/closeDefect
    
  ## Request params for defect details
    Method Type: Delete
    params: defectId = 120
            userKey = abc123ef5678werg