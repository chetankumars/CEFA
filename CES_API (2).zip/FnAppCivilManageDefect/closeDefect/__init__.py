# __init__.py

import azure.functions as func
from common import SharedConstants, ErrorResponse, AppStatus
import azure.functions as func
from .business_logic.close_defect import CloseDefect
from .constants.close_defect_constants import CloseDefectConstants

def main(req: func.HttpRequest) -> func.HttpResponse:

    """ 
    Function calls Close Defect class to delete the existing defect.

    Args:
        req (func.HttpRequest)

    Returns:
        func.HttpResponse: closing defect details status json from CES DB
    """
    defect_id = req.params.get(CloseDefectConstants.defect_id)
    user_key =req.params.get(CloseDefectConstants.user_key)
    if defect_id is not None and user_key is not None:
        message, statuscode = CloseDefect().defect_closing_details(defect_id, user_key)
    else:
        message = ErrorResponse(SharedConstants.request_val_failure, SharedConstants.request_header_failure, AppStatus.bad_Request.value[0], CloseDefectConstants.param_failure, CloseDefect().__class__.__name__).__str__()
        statuscode = AppStatus.bad_Request.value[0]
    return func.HttpResponse(body=message, status_code= statuscode, mimetype= SharedConstants.json_mime_type)

if __name__ == SharedConstants.main:
    main(func.HttpRequest)