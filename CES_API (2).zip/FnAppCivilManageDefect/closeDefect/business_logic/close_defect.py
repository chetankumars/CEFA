# close_defect.py

import sys
import os
from ..constants.close_defect_constants import CloseDefectConstants
from common import SqlOperation,Logger,JsonHelper,CustomLog,SharedConstants,AppStatus,ErrorResponse
from datetime import datetime, timezone 
import traceback

istraceenabled = os.environ[SharedConstants.trace_enabled]

class CloseDefect:

    """ CloseDefect class to close information about defect in CES db."""

    def __init__(self):
        self.response = str({})
        self.statusCode = AppStatus.ok.value[0]
        self.properties = {CloseDefectConstants.close_defect_details : CloseDefectConstants.close_defect_details_val}
        self.properties[CustomLog.start_time] = datetime.now(timezone.utc).isoformat()
        Logger.__init__(self, name = self.__class__.__name__, start_time = datetime.now(timezone.utc))
        self.properties[CustomLog.status] = True
        self.json_helper = JsonHelper()

    def defect_closing_details(self, defect_id, user_key):
        """
        Method to call CES database to close defect details.

        Args:
          defect_id(int),user_key(str)

        Returns:
            json(str) 
            statuscode(int)   - 204 No Content
                              - 200 Success
                              - 400 Bad Request
                              - 500 Internal Server Error
        """
        try:
            input_json = {CloseDefectConstants.input_json_id : int(defect_id),CloseDefectConstants.input_json_key : user_key}
            params = self.json_helper.stringify_json(input_json)
            self.properties[CustomLog.sp_req_param] = CloseDefectConstants.input_json + SharedConstants.colon + params[1]
            self.properties[CustomLog.sprequest_time] = datetime.now(timezone.utc).isoformat()
            defect = SqlOperation().fetch_one(CloseDefectConstants.sql_query, params[1])
            self.properties[CustomLog.sprequestend_time] = datetime.now(timezone.utc).isoformat()
            if defect is not None:
                is_valid_response,json_obj = self.json_helper.parse_json(defect[0])
                if is_valid_response:
                    self.response = self.json_helper.stringify_json(json_obj)[1]
                else:
                    self.statusCode = AppStatus.no_content.value[0]  
            else:
                self.statusCode = AppStatus.no_content.value[0]

        except:
            self.properties[CustomLog.error_messsage] = str(traceback.format_exc())
            self.properties[CustomLog.status] = False
            self.statusCode = AppStatus.internal_server_error.value[0]
            self.response = ErrorResponse(str(sys.exc_info()[0]), CloseDefect.__name__,
                                 AppStatus.internal_server_error.value[0], str(sys.exc_info()),CloseDefect.__name__).__str__()
            Logger.exception(self,type= sys.exc_info()[0], value = sys.exc_info()[1], tb =sys.exc_info()[2], properties = self.properties )
        
        finally:
            if istraceenabled:
                self.properties[CustomLog.end_time] = datetime.now(timezone.utc).isoformat()
                Logger.request(self,properties= self.properties)
            return self.response, self.statusCode