# __init__.py

from .close_defect import *