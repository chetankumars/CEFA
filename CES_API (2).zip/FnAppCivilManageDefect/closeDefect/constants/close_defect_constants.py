# close_defect_constants.py

class CloseDefectConstants:

    """ Constants related to CloseDefectConstants """
    
    defect_id = "defectId"
    user_key = "userKey"
    input_json_id = "defect_id"
    input_json_key = "current_user_key"
    input_json = "Input_JSON"
    sql_query = """
                EXEC [CES].sp_Close_Defect
                @Input_JSON = ?
                """
    close_defect_details = "closeDefect"
    close_defect_details_val = "func:closeDefect"
    param_failure = "defectId or userKey query parameter is missing."