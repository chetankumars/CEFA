# __init__.py

from .close_defect_constants import *