# Get Defect Details

## Description
    Service to get all defect details from the CES db.
    
    APIM URL: https://apim-uks-dev-ces-0001.azure-api.net/II/CESAPI/assets/defects/assetId
    FUNCTION URL: https://fnp-uks-dev-ces-funcedst0001.azurewebsites.net/api/getDefectDetails
    
  ## Request header for defect details
    Method Type: GET
    Header Name : X-Defect-Filters
    Sample Value : {"assetGuid":"3978559C3D9D45D9E04400306E4AD01A","isOpenDefect":"Y"}