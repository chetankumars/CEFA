#get_defect_details.py

__all__ = ["GetDefectDetailsConstants"]
class GetDefectDetailsConstants:
    """
    constants related to project specific

    """
  
    defect_filter = 'X-Defect-Filters'     
    defect_details_class_name = 'DefectDetails'
    validate_request_class = 'ValidateRequest'
    defect_details_get_schema_class='DefectDetailsGetSchema'
    asset_guid = 'assetGuid'
    is_open_defect = 'isOpenDefect'