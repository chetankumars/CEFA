#defect_details.py

class DefectDetails:
    def __init__(self, assetGuid, isOpenDefect, *args, **kwargs):
        self.assetGuid = assetGuid
        self.isOpenDefect = isOpenDefect