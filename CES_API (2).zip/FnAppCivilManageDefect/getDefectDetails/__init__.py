"""main method."""
import logging
import common
import json
import sys
import azure.functions as func
from .businesslogic import get_defect_details as dt,validate_request as val
from .schema import defect_detail_get_schema as sc
from collections import namedtuple
from common import AppStatus, SharedConstants, ErrorResponse
from .constants.get_defect_details import GetDefectDetailsConstants

def main(req: func.HttpRequest) -> func.HttpResponse:
    """calling business logic inside main to get response based on filters."""
    try:
        filter_name = GetDefectDetailsConstants.defect_filter
        if filter_name in req.headers and req.headers[filter_name]:
           defect_detail_Filter = req.headers[filter_name]
           defect_details_collection=json.loads(defect_detail_Filter, object_hook=lambda d: namedtuple('X', d.keys())(*d.values()))
           is_valid_req, return_object =  val.ValidateRequest(defect_detail_Filter, sc.DefectDetailsGetSchema()).is_valid_request()
           get_defect_details = lambda is_valid, return_object: dt.DefectDetails(defect_details_collection.assetGuid,defect_details_collection.isOpenDefect).get_defect_details_info() if is_valid == True else (return_object.messages, 400)
           if is_valid_req:
              message, statuscode = get_defect_details(is_valid_req, return_object)
           else: 
              statuscode = AppStatus.bad_Request.value[0] 
              message = ErrorResponse(SharedConstants.request_val_failure, GetDefectDetailsConstants.defect_details_class_name,
                                              AppStatus.bad_Request.value,SharedConstants.invalid_input_value_msg, GetDefectDetailsConstants.defect_details_class_name).__str__()
        else :
              statuscode = AppStatus.bad_Request.value[0] 
              message = ErrorResponse(SharedConstants.request_val_failure,SharedConstants.request_header_failure,
                                              AppStatus.bad_Request.value,SharedConstants.request_header_failure, GetDefectDetailsConstants.defect_details_class_name).__str__()
    except:
          statuscode = AppStatus.bad_Request.value[0] 
          message = ErrorResponse(str(sys.exc_info()[0]), GetDefectDetailsConstants.defect_details_class_name,
                                 AppStatus.bad_Request.value, str(sys.exc_info()), GetDefectDetailsConstants.defect_details_class_name).__str__()
    finally:

      return func.HttpResponse(body=message,status_code= statuscode, mimetype=SharedConstants.json_mime_type) 


if __name__ == SharedConstants.main:
    main(func.HttpRequest)
