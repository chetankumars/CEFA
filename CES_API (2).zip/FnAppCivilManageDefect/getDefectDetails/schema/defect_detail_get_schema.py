#defect_detail_get_schema.py

from marshmallow import fields, Schema,post_load
from ..model  import defect_details
from ..constants.get_defect_details import GetDefectDetailsConstants

__all__ =[GetDefectDetailsConstants.defect_details_get_schema_class]

class DefectDetailsGetSchema(Schema):
    assetGuid = fields.String(required=True)
    isOpenDefect = fields.String(required=True)