#get_defect_details.py

import sys
import os
import logging
import azure.functions as func
from common import Logger, SqlOperation, ValidationHelper,CustomLog, AppStatus, SharedConstants, ErrorResponse, CustomMessage
from common.utilities.json_helper import JsonHelper
from datetime import datetime, timezone 
from ..constants.get_defect_details import GetDefectDetailsConstants

istraceenabled = os.environ[SharedConstants.trace_enabled]

__all__ = [GetDefectDetailsConstants.defect_details_class_name]

class DefectDetails:
  
    """ Defect Details class to get defect information as json response """ 
    def __init__(self, assetGuid, isOpenDefect):
        self.sql_query = """
                           EXEC [CES].sp_Get_DefectDetails_SearchResult
                           @Asset_GUID = ?, @IsOpenDefect = ?
                           """
        self.response = str([])
        self.status_code = AppStatus.ok.value[0]
        self.properties = {CustomLog.defect_details: CustomLog.defect_detail_val}
        self.assetGuid=assetGuid
        self.isOpenDefect = isOpenDefect
        self.properties[CustomLog.start_time] = datetime.now(timezone.utc).isoformat()
        self.properties[CustomLog.status] = True
        Logger.__init__(self, name = self.__class__.__name__, start_time = datetime.now(timezone.utc))
        
    def get_defect_details_info(self) ->(str, int) :
        """
        Function to call Ces database to get defect information json based on asset guid and isOpenDefect attribute
       
        Args:

        Returns:
            json(str) 
            statuscode(int)     - 204 No Content
                                - 200 Success
                                - 500 Internal Server Error 
                                - 406 Not Acceptable 
        """
        try:
            if self.assetGuid is not None and self.isOpenDefect is not None:
                self._sp_req_param = GetDefectDetailsConstants.asset_guid + SharedConstants.colon + self.assetGuid, GetDefectDetailsConstants.is_open_defect + SharedConstants.colon + self.isOpenDefect
                self._params = self.assetGuid, self.isOpenDefect
                self.properties[CustomLog.sp_req_param] = str(self._sp_req_param)
                self.properties[CustomLog.sprequest_time] = datetime.now(timezone.utc).isoformat()
                _json_string = SqlOperation().fetch_one(self.sql_query,self._params)
                self.properties[CustomLog.sprequestend_time] = datetime.now(timezone.utc).isoformat()
                _json_helper = JsonHelper()
                _isparsejson_sucess,_json_obj = _json_helper.parse_json(_json_string[0])
                if _isparsejson_sucess:
                   self.response = _json_helper.stringify_json(_json_obj)[1]
                else:
                   self.status_code = AppStatus.no_content.value[0] 
                   self.response = ErrorResponse(SharedConstants.request_val_failure, GetDefectDetailsConstants.defect_details_class_name,
                                              AppStatus.no_content.value, CustomMessage.no_content,
                                              GetDefectDetailsConstants.defect_details_class_name).__str__()   
            else:
                self.status_code = AppStatus.bad_Request.value[0]
                self.response = ErrorResponse(SharedConstants.request_val_failure,SharedConstants.request_header_failure,
                                              AppStatus.bad_Request.value, SharedConstants.bad_json_request_msg,
                                              GetDefectDetailsConstants.defect_details_class_name).__str__()  
        except:
            self.properties[CustomLog.error_messsage] =  str(sys.exc_info())
            self.properties[CustomLog.status] = False
            self.status_code = AppStatus.internal_server_error.value[0]
            self.response = ErrorResponse(str(sys.exc_info()[0]), GetDefectDetailsConstants.defect_details_class_name,
                                 AppStatus.internal_server_error.value, str(sys.exc_info()), GetDefectDetailsConstants.defect_details_class_name).__str__()
            Logger.exception(self,type=sys.exc_info()[0], value = str(sys.exc_info()[1]), tb = str(sys.exc_info()[2]), properties = self.properties )
        finally:
             if istraceenabled:
                self.properties[CustomLog.end_time] = datetime.now(timezone.utc).isoformat()
                Logger.request(self,properties= self.properties)

             return self.response, self.status_code   
