#validate_request.py
import sys
import os
from ..model import defect_details
from common import SharedConstants
import json
from ..constants.get_defect_details import GetDefectDetailsConstants


__all__ = [GetDefectDetailsConstants.validate_request_class]
class ValidateRequest:

    def __init__(self, defect_details, defect_schema):
        self.defect_details = defect_details
        self.defect_schema = defect_schema

    def is_valid_request(self, operation = SharedConstants.method_type_get)-> (bool, dict):
        """To validate incoming request

        Args:
            self ([ValidateRequest]): [self instance]

        Returns:
            [tuple]: [boo represent the schema validation was successful or not and error message for validation failure scenario]
        """

        try:
            
            output = self.defect_schema.loads(self.defect_details )
            return True, output
        except:
            return False, str(sys.exc_info())


    def is_valid_payload(self, payload)-> (bool, dict):
        try:
            is_valid_header, return_object =  self.is_valid_request()
            if is_valid_header and payload is not None:
                return (True, "")
            else:
                return False, return_object
        except:
            (excepclass, errormessage, trackback) = sys.exc_info()
            return False, errormessage

        



