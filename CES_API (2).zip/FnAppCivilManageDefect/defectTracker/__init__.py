#__init__.py

import sys
import azure.functions as func
from .businesslogic import DefectTrackerDetails, ValidateRequest
from .schema import DefectTrackerPostSchema
import json
import common
from common import SharedConstants, ErrorResponse
from .constants import DefectTrackerConstants

def main(req: func.HttpRequest) -> func.HttpResponse:
    """[summary]

    Args:
        req (func.HttpRequest): To Get/Post defect tracker details from/to CES DB

    Returns:
        func.HttpResponse: defect tracker json for get operation and save defect tracker details to CES DB
    """
    try:
        if req.method == SharedConstants.method_type_get:

            is_new_defect = req.params.get(DefectTrackerConstants.is_new_defect)
            if (is_new_defect is not None) and (is_new_defect == DefectTrackerConstants.y_new_defect or is_new_defect == DefectTrackerConstants.n_new_defect):
                message, statuscode = DefectTrackerDetails().get_defect_tracker_info(is_new_defect)
            else:
                message = common.ErrorResponse(common.SharedConstants.request_val_failure, common.SharedConstants.request_header_failure,common.AppStatus.bad_Request.value[0], DefectTrackerConstants.is_new_defect_validation_fail,DefectTrackerDetails().__class__.__name__).__str__()
                statuscode = common.AppStatus.bad_Request.value[0]
        else:

            is_valid_payload, return_object =  ValidateRequest(DefectTrackerPostSchema()).is_valid_payload(json.dumps(req.get_json()))
            if is_valid_payload:
                message, statuscode  = DefectTrackerDetails().post_defect_tracker_info(req.get_json())
            else:
                message = common.ErrorResponse(common.SharedConstants.request_val_failure, common.SharedConstants.request_header_failure,common.AppStatus.bad_Request.value[0], return_object.messages,DefectTrackerDetails().__class__.__name__).__str__()
                statuscode = common.AppStatus.bad_Request.value[0]
                         
    except:
        message = common.ErrorResponse(str(sys.exc_info()[0]), DefectTrackerDetails().__class__.__name__,common.AppStatus.internal_server_error.value, str(sys.exc_info()[1]), DefectTrackerDetails().__class__.__name__).__str__()
        statuscode = common.AppStatus.internal_server_error.value[0]

    finally:
        return func.HttpResponse(body=message, status_code= statuscode, mimetype= SharedConstants.json_mime_type)

if __name__ == SharedConstants.main:
    main(func.HttpRequest)
