#defect_tracker_constants.py

class DefectTrackerConstants:
    
    # Constants related to the project specific

    is_new_defect = "isNewDefect"
    y_new_defect = "Y"
    n_new_defect = "N"
    is_new_defect_validation_fail = "isNewDefect query param is missing or the provided value should be Y or N"
    stored_procedure_type = "Stored Procedure"