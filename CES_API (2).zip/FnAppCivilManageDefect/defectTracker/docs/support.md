# Add defect or add a row to existing defect for UI

## Description
    Service to get defect tracker details and post the defect tracker details to the CSE db.

## Get Request for Add defect if isNewDefect is Y and if isNewDefect is N

    APIM URL: https://apim-uks-dev-ces-0001.azure-api.net/II/CESAPI/assets/defects/{isNewDefect}
    Method Type: GET

    FUNCTION URL: https://fnp-uks-dev-ces-funcedst0001.azurewebsites.net/api/defectTracker
    Method Type: GET
    Request Param:

        isNewDefect (str)

## Post Request for Add defect if isNewDefect is Y and if isNewDefect is N

    APIM URL: https://apim-uks-dev-ces-0001.azure-api.net/II/CESAPI/assets/defects/setDefect
    Method Type:  POST
    
    FUNCTION URL: https://fnp-uks-sit-ces-funcedst0001.azurewebsites.net/api/defectTracker
    Method Type:  POST
    
    Sample Json:
            
                {
                    "defect_id": 1,
                    "user_key": "abc123ef5678werg",
                    "supplier_id": 1,
                    "asset_guid": "xyv123ef5678wergqwz",
                    "description": "cvbn",
                    "location": "sfsffff",
                    "loc_major": "sssss",
                    "loc_minor": "dddd",
                    "exam_dt": "2009-05-18",
                    "exam_id": 2052535,
                    "access_req": "Y",
                    "exam_type_id": 1,
                    "recomm_no": "12346",
                    "risk_score": 1,
                    "deterioration_flg": "Y",
                    "repaired_flg": "Y",
                    "closure_flg": "N",
                    "accs_grant_flg": "N",
                    "comments": "ddwadwdwdwqdqwdqdw",
                    "isnewdefect": "Y"
                }
                