#defect_tracker_post_schema.py

from marshmallow import fields, Schema

__all__ =['DefectTrackerPostSchema']
class DefectTrackerPostSchema(Schema):
    
    defect_id = fields.Integer(required=True)
    user_key = fields.Str(required=True)
    supplier_id = fields.Integer(required=True)
    description = fields.Str(required=True)
    location = fields.Str(required=True)
    exam_dt = fields.Str(required=True)
    access_req = fields.Str(required=True)
    exam_type_id = fields.Integer(required=True)
    risk_score = fields.Integer(required=True)
    deterioration_flg = fields.Str(required=True)
    repaired_flg = fields.Str(required=True)
    closure_flg = fields.Str(required=True)
    accs_grant_flg = fields.Str(required=True)
    asset_guid = fields.Str(allow_none=True, missing=True)
    comments = fields.Str(allow_none=True, missing=True)
    exam_id = fields.Integer(allow_none=True, missing=True)
    isnewdefect = fields.Str(allow_none=True, missing=True)
    loc_major = fields.Str(allow_none=True, missing=True)
    loc_minor = fields.Str(allow_none=True, missing=True)
    recomm_no = fields.Str(allow_none=True, missing=True)