#__init__.py

from .defect_tracker_post_schema import DefectTrackerPostSchema