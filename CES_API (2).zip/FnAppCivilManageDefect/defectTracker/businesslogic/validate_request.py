#validate_request.py
import sys
import os
sys.path.insert(0, os.getcwd()) 
import json


#validate_request.py

__all__ = ['ValidateRequest']
class ValidateRequest:

    def __init__(self, defect_tracker_schema):
        self.defect_tracker_schema = defect_tracker_schema

    def is_valid_payload(self, payload)-> (bool, dict):
        try:
            return_object =  self.defect_tracker_schema.loads(payload)
            return True, return_object
        except:
            (excepclass, errormessage, trackback) = sys.exc_info()
            return False, errormessage

        



