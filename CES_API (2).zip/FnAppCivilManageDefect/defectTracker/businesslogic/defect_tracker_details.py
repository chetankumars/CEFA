#defect_tracker_details.py

import sys
import os
import logging
import azure.functions as func
sys.path.insert(0, os.getcwd())
from common.utilities.json_helper import JsonHelper
import common
from common import SqlOperation, Logger, JsonHelper,ValidationHelper,CustomLog, AppStatus, SharedConstants,ErrorResponse
from datetime import datetime, timezone
from ..constants.defect_tracker_constants import DefectTrackerConstants
import traceback

istraceenabled = os.environ[SharedConstants.trace_enabled]

__all__ = ['DefectTrackerDetails']
class DefectTrackerDetails:
  
    """ DefectTrackerDetails class to get and post defect tracker information """ 
    def __init__(self):
        self.get_sql_query = """
                           EXEC [CES].sp_Get_NewDefect_DisplayDtls
                           @isnewdefect = ?
                           """

        self.post_sql_query = """
                           EXEC [CES].sp_Save_NewDefect_Dtls
                           @Input_JSON = ?
                           """
        self.data_mapper = {
                            'defect_id':'defect_id',
                            'user_key':'user_key',
                            'supplier_id':'supplier_id',
                            'asset_guid':'asset_guid',
                            'description':'description',
                            'location':'location',
                            'loc_major':'loc_major',
                            'loc_minor':'loc_minor',
                            'exam_dt':'exam_dt',
                            'exam_id':'exam_id',
                            'access_req':'access_req',
                            'exam_type_id':'exam_type_id',
                            'recomm_no':'recomm_no',
                            'risk_score':'risk_score',
                            'deterioration_flg':'deterioration_flg',
                            'repaired_flg':'repaired_flg',
                            'closure_flg':'closure_flg',
                            'accs_grant_flg':'accs_grant_flg',
                            'comments':'comments',
                            'isnewdefect':'isnewdefect'           
                           }

        self.response = str({})
        self.statusCode = AppStatus.ok.value[0]
        self.properties = {CustomLog.add_defect_tracker_details : CustomLog.add_defect_tracker_details_val}
        self.properties[CustomLog.start_time] = datetime.now(timezone.utc).isoformat()
        self.properties[CustomLog.status] = True
        Logger.__init__( self,name = self.__class__.__name__, start_time = datetime.now(timezone.utc))
        
    def get_defect_tracker_info(self, is_new_defect:str)->(str, int, bool):
        """
        Function to call Ces database to get defect tracker information.
       
        Args:
            is_new_defect (str)

        Returns:
            json(str) 
            statuscode(int)     - 204 No Content
                                - 200 Success
                                - 400 Bad Request
                                - 500 Internal Server Error 
                                
        """
        try:  
            self.properties[CustomLog.sp_req_param] = DefectTrackerConstants.is_new_defect + ":" + is_new_defect      
            self.properties[CustomLog.sprequest_time] = datetime.now(timezone.utc).isoformat()
            _json_string = SqlOperation().fetch_one(self.get_sql_query,is_new_defect)
            self.properties[CustomLog.sprequestend_time] = datetime.now(timezone.utc).isoformat()
            _json_helper = JsonHelper()
            _isparsejson_sucess,_json_obj = _json_helper.parse_json(_json_string[0])
            if _isparsejson_sucess:
               self.response = _json_helper.stringify_json(_json_obj)[1]
            else:
               self.statusCode = AppStatus.no_content.value[0]
            if istraceenabled:
                self.properties[CustomLog.end_time] = datetime.now(timezone.utc).isoformat()
                Logger.request(self,properties= self.properties)

            return self.response, self.statusCode   

        except:
            self.properties[CustomLog.error_messsage] =   str(traceback.format_exc())
            self.properties[CustomLog.status] =  False
            Logger.exception(self, type= sys.exc_info()[0], value = sys.exc_info()[1], tb =sys.exc_info()[2], properties = self.properties )
            raise 

    def map_dictionary(self, json_req)->str:
        """
        Method to map the request column to the db column

        Args:
            json_req(json)

        Returns:
            json(str) 
        
        """
       
        return  JsonHelper().stringify_json(dict((self.data_mapper.get(k, k), v) for (k, v) in json_req.items()))[1]

    def post_defect_tracker_info(self, defect_tracker_details_json)->(str, int, bool):
        """
        Function to call Ces database to set defect tracker information json.
       
        Args:
        Returns:
            json(str) 
            statuscode(int)     - 204 No Content
                                - 201 Created
                                - 500 Internal Server Error 
                                - 400 Bad Request
        """
        try:
            defect_tracker_details = self.map_dictionary(defect_tracker_details_json)
            self.properties[CustomLog.sp_req_param] = CustomLog.Input_JSON + ":" + str(defect_tracker_details)
            self.properties[CustomLog.sprequest_time] = datetime.now(timezone.utc).isoformat()
            _json_string =  SqlOperation().fetch_one(self.post_sql_query, defect_tracker_details)
            self.properties[CustomLog.sprequestend_time] = datetime.now(timezone.utc).isoformat()
            if _json_string is None:
                self.statusCode = AppStatus.no_content.value[0]
            if not _json_string[0]:
                self.response = common.ErrorResponse(DefectTrackerConstants.stored_procedure_type, DefectTrackerDetails().__class__.__name__,common.AppStatus.internal_server_error.value, _json_string[1],DefectTrackerDetails().__class__.__name__).__str__()
                self.statusCode = AppStatus.internal_server_error.value[0]
            else:
                self.response = ''
                self.statusCode = AppStatus.record_created.value[0]
            if istraceenabled:
                self.properties[CustomLog.end_time] = datetime.now(timezone.utc).isoformat()
                Logger.request(self,properties= self.properties)
                
            return self.response, self.statusCode          
        except:
            self.properties[CustomLog.error_messsage] =   str(traceback.format_exc())
            Logger.exception(self, type= sys.exc_info()[0], value = sys.exc_info()[1], tb =sys.exc_info()[2], properties = self.properties )
            raise
