#__init__.py

from .get_exam_data_status import ExamDataStatus