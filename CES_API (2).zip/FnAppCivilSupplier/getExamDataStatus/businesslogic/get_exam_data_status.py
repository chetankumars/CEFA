#get_exam_data_status.py

import sys
import os
import logging
import azure.functions as func
from common import SqlOperation, Logger, JsonHelper,CustomLog, AppStatus, SharedConstants,ErrorResponse,SetProperties,SuccessResponse
from datetime import datetime, timezone
from ..constants import ExamDataConstants
import traceback
istraceenabled = os.environ[SharedConstants.trace_enabled]

class ExamDataStatus(SetProperties):
    def __init__(self):
        self.sql_query = """
                           EXEC [CES].[sp_Get_FileProcessStatus]
                           @File_Name = ?
                           """
        self.response = str({})
        self.status_code = AppStatus.ok.value[0]
        SetProperties.__init__(self,CustomLog.get_exam_data_status,CustomLog.get_exam_data_status_val)
        Logger.__init__( self,name = ExamDataStatus.__name__, start_time = datetime.now(timezone.utc))
        self.json_helper = JsonHelper()
    
    def exam_data_status(self, req: func.HttpRequest)-> func.HttpResponse:
        """
        Function to call Ces database to get the exam data status
       
        Args:
            self ([ExamDataStatus]): [self instance]
            req: Http Request data (params Data)
        Returns:
            HttpResponse
            status_code(int)    - 200 Success
                                - 500 Internal Server Error
                                - 400 BadRequest 
                                - 204 No Content
        """
        try:
            file_name = req.params.get(ExamDataConstants.file_name)
            #supplier_name = req.params.get(ExamDataConstants.supplier_name)
            if file_name is not None: 
                SetProperties.sprequest_params(self,ExamDataConstants.file_name + SharedConstants.colon + file_name)
                #sp_param = file_name, supplier_name
                SetProperties.sprequest_time(self)
                json_string = SqlOperation().fetch_one(self.sql_query,file_name) 
                SetProperties.sprequestend_time(self)
                if json_string is not None:
                    _isparsejson_sucess,_json_obj = self.json_helper.parse_json(json_string[0])
                    if _isparsejson_sucess:
                        self.response = SuccessResponse(self.status_code,_json_obj).__str__()
                    else:
                        self.status_code = AppStatus.no_content.value[0]
                else:
                    self.status_code = AppStatus.no_content.value[0]
            else:
                self.status_code = AppStatus.bad_Request.value[0]
                self.response = ErrorResponse(SharedConstants.request_val_failure, SharedConstants.request_header_failure,self.status_code,ExamDataConstants.param_failure,ExamDataStatus.__name__).__str__() 
        except:
            SetProperties.error_messsage(self,str(traceback.format_exc()))
            SetProperties.status(self, False)
            self.status_code = AppStatus.internal_server_error.value[0]
            Logger.exception(self,type= sys.exc_info()[0], value = sys.exc_info()[1], tb =sys.exc_info()[2], properties = self._properties )
            self.response = ErrorResponse(sys.exc_info()[0],ExamDataStatus.__name__,self.status_code, str(sys.exc_info()[1]),ExamDataStatus.__name__).__str__()
        finally:
            if istraceenabled:
                SetProperties.end_time(self)  
                Logger.request(self,properties= self._properties)
            return  func.HttpResponse(body= self.response, status_code= self.status_code, mimetype= SharedConstants.json_mime_type) 