#__init__.py

from .exam_data import ExamDataConstants