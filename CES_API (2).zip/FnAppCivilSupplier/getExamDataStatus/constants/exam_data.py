#exam_data.py

class ExamDataConstants:
    
    # Constants related to the project specific

   file_name = "fileName"
   supplier_name = "supplierName"
   param_failure = "fileName/supplierName query parameter is missing."
   invalid_file_name = "Invalid File Name"