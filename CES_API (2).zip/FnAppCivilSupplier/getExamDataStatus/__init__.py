#__init__.py

import logging

import azure.functions as func
from .businesslogic import ExamDataStatus
from common import SharedConstants

def main(req: func.HttpRequest) -> func.HttpResponse:
    """[summary]

    Args:
        req (func.HttpRequest): Calling ExamDataStatus class to get the http response

    Returns:
        func.HttpResponse: status of exam data from CES DB
        
    """
    return  ExamDataStatus().exam_data_status(req)
 
if __name__ == SharedConstants.main:
    main(func.HttpRequest)
