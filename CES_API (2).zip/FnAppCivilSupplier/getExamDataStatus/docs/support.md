# Get the Examination Status

## Description
Services to get the examination data status from  CSE db.

   

    APIM URL:https://apim-uks-dev-ces-0001.azure-api.net/II/CESAPI/supplier/ExamData[?fileName]

## Request params for get exam data status
    Method Type:  GET
    Request params:
        fileName = CES_TaskListPlannedDateUpload_Amey Rail_1613620554742.xlsx
        supplierName=test
    Sample Response:
                {
                    "success": {
                        "status": 200,
                        "detail": {
                            "success": "Yes",
                            "message": ""
                        }
                    },
                   "success": {
                        "status": 200,
                        "detail": {
                            "success": "No",
                            "message": "Validation Failed in Task List Planned Dates."
                        }
                    },
                    "success": {
                        "status": 200,
                        "detail": {
                            "success": "N/A",
                            "message": "Different File formats submitted other than XML,PDF, JPG, PNG"
                        }
                    },
                     "success": {
                        "status": 200,
                        "detail": {
                            "success": "No",
                            "message": "PDF File names in XML does not match with the PDF submitted."
                        }
                    }
                }
        Bad Request:
                {
                    "error": {
                        "types": "Invalid Request",
                        "title": "Header/Param validation failure",
                        "status": 400,
                        "detail": "Invalid File Name",
                        "instance": "ExamDataStatus"
                    }
                  
                }

        Exception: 
                {
                    "error": {
                        "types": "<class 'UnboundLocalError'>",
                        "title": "ExamDataStatus",
                        "status": 500,
                        "detail": "local variable 'conn' referenced before assignment",
                        "instance": "ExamDataStatus"
                    }
                }    

