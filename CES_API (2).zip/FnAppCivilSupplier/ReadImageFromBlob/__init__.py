#__init__.py

import sys
import logging
import azure.functions as func
import requests
import base64
import json
from common import SharedConstants, Logger, ErrorResponse, AppStatus

def main(req: func.HttpRequest) -> func.HttpResponse:
    try:
        blob_url = req.params.get('blob_url')

        if blob_url:
            image_text = str(base64.b64encode(requests.get(blob_url).content))
            response = json.dumps({"image_text":image_text[2:image_text.__len__()-1]})
            status_code = 200
        else:
            response = json.dumps({"message":"Pass blob url in the query string."})
            status_code = 400
    except:
        response = ErrorResponse(str(sys.exc_info()[0]),"ReadImageFromBlob",
        AppStatus.internal_server_error.value[0], str(sys.exc_info()), "ReadImageFromBlob").__str__()
        status_code = AppStatus.internal_server_error.value[0]
        Logger.exception("ReadImageFromBlob", type= sys.exc_info()[0], value = sys.exc_info()[1], tb =sys.exc_info()[2], properties = {} )
    finally:
        return func.HttpResponse(body= response, status_code= status_code, mimetype=SharedConstants.json_mime_type)