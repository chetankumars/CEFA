#__init__.py

from .recommedation_details import RecommendationConstants