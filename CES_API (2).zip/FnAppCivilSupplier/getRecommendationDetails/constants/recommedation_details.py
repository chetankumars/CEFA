#recommendation_details.py

class RecommendationConstants:
    
    # Constants related to the project specific
   recommendation_filters = "X-Recommendation-Supplier-Filters"
   planned_exam_date = "plannedExamDate"
   supplier_id_header = "X-Supplier-Id"
   suppliers_mapper = "suppliersMapper"
   supplier_id = "supplierId"
   validate_request = "ValidateRequest"
   recommendation = "Recommendation"
   recommendation_details = "RecommendationDetails"
   sp_input_json = "Input_JSON"
   sp_supplier_id = "Supplier_ID"
   suppliers_dtls_mapper = "SUPPLIER_MAPPER"
   recommendation_details_schema = "RecommendationSchema"
   invalid_supplier = "Invalid supplier"
   id = "id"