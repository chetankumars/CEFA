#get_recommendation_details_sql.py

import sys
import os
import logging
import azure.functions as func
from common import SqlOperation, Logger, JsonHelper,ValidationHelper,CustomLog, AppStatus, SharedConstants,ErrorResponse,SuccessResponse
from datetime import datetime, timezone
from ..constants.recommedation_details import RecommendationConstants
istraceenabled = os.environ[SharedConstants.trace_enabled]
import traceback
import json

__all__ = [RecommendationConstants.recommendation_details]
class RecommendationDetails:
  
    """ RecommendationDetails class to get recommnedation details from CES DB """ 
    def __init__(self, json_req):
        self.sql_query = """
                           EXEC [CES]. sp_Get_RecommendationDtls_API
                           @Input_JSON = ?
                           """
        self.recommendation_details_req = json_req
        self.response = str({})                  
        self.status_code = AppStatus.ok.value[0]
        self.json_helper = JsonHelper()
        self.properties = {CustomLog.get_recommendation_details : CustomLog.get_recommendation_details_val}
        self.properties[CustomLog.start_time] = datetime.now(timezone.utc).isoformat()
        Logger.__init__( self,name = RecommendationDetails.__name__, start_time = datetime.now(timezone.utc))
        self.properties[CustomLog.status] = True

    def get_recommendation_details(self)-> func.HttpResponse:
        """
        Function to call Ces database to get recommendation details from CES DB.
       
        Args:
            self ([RecommendationDetails]): [self instance]
        Returns:
            HttpResponse
            statuscode(int)    - 204 No Content
                               - 200 Success
                               - 500 Internal Server Error 
                               - 400 Bad Request
        """
        try:
            data = json.loads(self.recommendation_details_req)
            if(str(data['region_name']).replace(' ','') == str("North, West and Central").replace(' ','')):
                data['region_name']= ("North, West and Central")
                self.recommendation_details_req = json.dumps(data)
                self.properties["req_param"] = self.recommendation_details_req
            self.properties[CustomLog.sp_req_param] = RecommendationConstants.sp_input_json + SharedConstants.colon + self.recommendation_details_req
            self.properties[CustomLog.sprequest_time] = datetime.now(timezone.utc).isoformat()
            json_string = SqlOperation().fetch_one(self.sql_query, self.recommendation_details_req)
            self.properties[CustomLog.sprequestend_time] = datetime.now(timezone.utc).isoformat()
            if json_string[1]:
               self.status_code = AppStatus.bad_Request.value[0]
               self.response =  ErrorResponse(SharedConstants.request_val_failure , RecommendationDetails.__name__,
                                self.status_code, str(json_string[1]),RecommendationDetails.__name__).__str__()
            else:                    
               isparsejson_sucess, json_obj = self.json_helper.parse_json(json_string[0] if json_string else None)
               if isparsejson_sucess: self.response =  json_string[0] 
               else: self.status_code = AppStatus.no_content.value[0] 
                             
        except:
            self.properties[CustomLog.error_messsage] =   str(traceback.format_exc())
            self.properties[CustomLog.status] = False
            Logger.exception(self,type= sys.exc_info()[0], value = sys.exc_info()[1], tb =sys.exc_info()[2], properties = self.properties )
            self.status_code = AppStatus.internal_server_error.value[0]
            self.response = ErrorResponse(str(sys.exc_info()[0]), RecommendationDetails.__name__,
                                 self.status_code, str(sys.exc_info()[1]),RecommendationDetails.__name__).__str__()
        finally:
            if istraceenabled:
                self.properties[CustomLog.end_time] = datetime.now(timezone.utc).isoformat()
                Logger.request(self,properties= self.properties)
            return func.HttpResponse(body=self.response,status_code= self.status_code, mimetype= SharedConstants.json_mime_type)