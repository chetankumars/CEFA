#validate_request.py

import sys
import os
import ast
import json
import pandas as pd
import numpy as np
import azure.functions as func
from common import JsonHelper
from ..constants import RecommendationConstants


__all__ = [RecommendationConstants.validate_request]
class ValidateRequest:

    """ ValidateRequest class to validate the request json """ 
    def __init__(self, recommendation_details_schema):
        self.recommendation_details_schema = recommendation_details_schema
        self.json_helper = JsonHelper()

    def is_valid_payload(self, recommendation_details_req):
        """ To validate incoming request

        Args:
            self ([ValidateRequest]): [self instance]
            recommendation_details_req: json

        """
        self.recommendation_details_schema.loads(recommendation_details_req)
           
       
       

        



