#get_recommendation_details_service.py

import sys
import os
import ast
import json
import pandas as pd
import numpy as np
import azure.functions as func
from common import AppStatus,SharedConstants,ErrorResponse,JsonHelper
from . import RecommendationDetails,ValidateRequest
from ..constants import RecommendationConstants
from ..schema import RecommendationSchema

__all__ = [RecommendationConstants.recommendation]
class Recommendation:

    def __init__(self):
        self.json_helper = JsonHelper()
        self.recommendation_filters_json = None

    def get_recommendation_details(self, req: func.HttpRequest)-> func.HttpResponse:
        """
        Function to get recommendation details from CES DB.
       
        Args:
            self ([RecommendationDetails]): [self instance]
            req :  func.HttpRequest
            
        Returns:
            HttpResponse
            statuscode(int)     - 200 OK
                                - 500 Internal Server Error
                                - 401 UnAuthorized 
        """
        try:
            self.recommendation_filters_json = req.headers[RecommendationConstants.recommendation_filters]
            ValidateRequest(RecommendationSchema()).is_valid_payload(self.recommendation_filters_json)
            response = RecommendationDetails(self.recommendation_filters_json).get_recommendation_details()
        except:
            error_response = ErrorResponse(SharedConstants.request_val_failure,SharedConstants.request_header_failure,
                                              AppStatus.bad_Request.value[0], str(sys.exc_info()[1]),
                                              Recommendation.__name__).__str__()
            response = func.HttpResponse(body= error_response, status_code= AppStatus.bad_Request.value[0], mimetype= SharedConstants.json_mime_type)
        finally:
            return response    
         



       

        



