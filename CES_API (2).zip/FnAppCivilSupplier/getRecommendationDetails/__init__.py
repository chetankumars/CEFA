#__init__.py

import sys
import json
import azure.functions as func
from .businesslogic import Recommendation 
from .constants import RecommendationConstants
from common import SharedConstants

def main(req: func.HttpRequest) -> func.HttpResponse:
    """[summary]

    Args:
        req (func.HttpRequest): json 

    Returns:
        func.HttpResponse: get recommendation details from CES DB
        
    """
    return  Recommendation().get_recommendation_details(req)
 
if __name__ == SharedConstants.main:
    main(func.HttpRequest)
