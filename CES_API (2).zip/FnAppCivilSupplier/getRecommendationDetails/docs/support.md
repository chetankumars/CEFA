# Save Planned, Baseline and Actual Exam Dates for Suppliers

## Description
    Service to get all recommendations from CES DB.
    Only valid Suppliers is able to access the Api.


## Post Request for Add Exam Dates

    APIM URL: https://apim-uks-dev-ces-0001.azure-api.net/II/CESAPI/supplier/recommendations
    Method Type:  GET
    
    FUNCTION URL: https://fnp-uks-dev-ces-funcedst0005.azurewebsites.net/api/getRecommendationDetails
    Method Type:  GET
    
    Header : x-recommendation-supplier-filters
    {"region_name":"Southern","route_name":"Kent","pageno":1,"rowsperpage":100}
