#recommendation_details_get_schema.py

from marshmallow import fields,validate, Schema
from ..constants.recommedation_details import RecommendationConstants
from common import SharedConstants

__all__ =[RecommendationConstants.recommendation_details_schema]
class RecommendationSchema(Schema):
    pageno = fields.Integer(required=True)
    region_name = fields.String(required=True)
    route_name = fields.String(required=False)
    rowsperpage = fields.Integer(required=True)

    
    


