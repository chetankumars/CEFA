#sharedlog.py

__all__ = ['SharedConstants']
class SharedConstants:

    """
    Common contants across packages and Web APIs

    """
    sql_connection_string = "SQL_CONNECTION_STRING"
    sql_copt_ss_access_token =1256
    request_val_failure = "Invalid Request"
    request_header_failure = "Header/Param validation failure"
    get_search_lookup = "getSearchLookup"
    search_lookup_response_schema = "searchlookup_response.json"
    get_assets = "getAssets"
    assets_req_schema = "assets_request.json"
    schema = "schema"
    search_lookup_bad_request_msg = "userId is missing"
    defect_tracker_assets_bad_request_msg = "Invalid input, expected value"
    assets_bad_request_msg = "Header X-Asset-Filters is missing"
    json_mime_type = "application/json"
    trace_enabled = "Trace_Enabled"
    asset_filter = 'X-Asset-Filters'
    response = "sp response"
    userId = "userId"
    main = '__main__'
    json_mime_type = "application/json"
    trace_enabled = "Trace_Enabled"
    colon = ":"
    comma =","
    date_format = "%d/%m/%Y"
    # _sql_copt_ss_access_token_value = 1256
   
