# get_defect_validate_request.py

import sys
import traceback
from common import JsonHelper
from ..schema import GetDefectDetailsSchema

class ValidationRequest:
    "Get Defect Details validation Request class to perform validation on input request"
    def __init__(self):
        self.get_defect_details_schema = GetDefectDetailsSchema()

    def is_valid_payload(self, payload)-> (bool, dict):
        """
        Method to validate the request against schema

        Args:
            json_req(json)

        Returns:
            json(bool,dict) 
        """
        try:
            return_object =  self.get_defect_details_schema.loads(payload)
            res = self.get_defect_details_schema.dump(return_object)
            return True, res
        except:
            return False, sys.exc_info()
    