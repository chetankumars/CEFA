#get_defects.py

import sys
import os
from common import SharedConstants,Logger,AppStatus,ErrorResponse,JsonHelper,CustomLog,SqlOperation
from datetime import datetime,timezone
from ..constants.get_defect_details_constants import DefectDetailsConstant
import traceback
import json
from getDefectDetails.business_logic.get_defect_validate_request  import ValidationRequest

istraceenabled = os.environ[SharedConstants.trace_enabled]

class Defects:
    """
    Defect class to get information about defect details from CES db.
    """ 
    def __init__(self):
       
        self.response = str({})
        self.statusCode = AppStatus.ok.value[0]
        self.properties = {DefectDetailsConstant.get_defect_details : DefectDetailsConstant.get_defect_details_value}
        self.properties[CustomLog.start_time] = datetime.now(timezone.utc).isoformat()
        Logger.__init__( self,name = Defects.__name__, start_time = datetime.now(timezone.utc))
        self.properties[CustomLog.status] = True
        self.json_helper = JsonHelper()
        self.validate_map = ValidationRequest()

    def get_defect_details_json(self, defect_details_req):
        """
        Function to  call the database to get all defect details json based on filter condition
       
        Args:
            defect_details_req(str)
        """
        req_param = self.json_helper.stringify_json(defect_details_req)[1]
        data = json.loads(req_param)
        if(str(data['region_name']).replace(' ','') == str("North, West and Central").replace(' ','')):
            data['region_name']= ("North, West and Central")
            req_param = json.dumps(data)
            self.properties["req_param"] = req_param
        self.properties[CustomLog.sp_req_param] = DefectDetailsConstant.input_json + SharedConstants.colon + req_param
        self.properties[CustomLog.sprequest_time] = datetime.now(timezone.utc).isoformat()
        defects = SqlOperation().fetch_one(DefectDetailsConstant.get_sql_query, req_param)
        self.properties[CustomLog.sprequestend_time] = datetime.now(timezone.utc).isoformat()
        if defects[1]:
            self.statusCode = AppStatus.bad_Request.value[0]
            self.response = ErrorResponse(SharedConstants.request_val_failure,Defects.__name__,self.statusCode,str(defects[1]),Defects.__name__).__str__()
        else:
            is_valid_response,json_obj = self.json_helper.parse_json(defects[0] if defects else None)        
            if is_valid_response:
                defect_search_result_output = []
                for defect_search_result in json_obj["defectsearchresult"]:
                    defect_result_output = []
                    for defect_result in defect_search_result["defectresult"]:
                        defect_dtls_output = []
                        for defect_dtls in defect_result["defectdtls"]:
                            defect_dtls["exam_date"] = (datetime.strptime(defect_dtls["exam_date"],'%Y-%m-%d')).strftime('%d-%m-%Y') if defect_dtls["exam_date"] else None
                            defect_dtls_output.append(defect_dtls)
                        defect_result["defectdtls"] = defect_dtls_output
                        defect_result_output.append(defect_result)
                    defect_search_result["defectresult"] = defect_result_output
                    defect_search_result_output.append(defect_search_result)
            
                json_obj["defectsearchresult"] = defect_search_result_output
                self.response = self.json_helper.stringify_json(json_obj)[1]
            else:
                self.statusCode = AppStatus.no_content.value[0]

    def get_defects_details(self, defect_details_filter):
        """
        Method to validate the request and to get defect details response.

        Args:
          defect_details_filter(string)

        Returns:
            json(str) 
            statuscode(int)     - 204 No Content
                                - 200 Success
                                - 400 Bad Request
                                - 500 Internal Server Error                          
        """
        try:
            is_valid,res = self.validate_map.is_valid_payload(defect_details_filter)
            if is_valid:
               self.get_defect_details_json(res)
            else: 
               self.statusCode = AppStatus.bad_Request.value[0]   
               self.response = ErrorResponse(SharedConstants.request_val_failure,SharedConstants.request_header_failure,
                                              AppStatus.bad_Request.value[0], str(res),
                                              Defects.__name__).__str__()  
               self.properties[CustomLog.error_messsage] =  str(res)
        except:
            self.properties[CustomLog.error_messsage] = str(sys.exc_info())
            self.properties[CustomLog.status] = False
            self.statusCode = AppStatus.internal_server_error.value[0]
            self.response = ErrorResponse(str(sys.exc_info()[0]), Defects.__name__,
                                 AppStatus.internal_server_error.value[0], str(sys.exc_info()),Defects.__name__).__str__()
            Logger.exception(self,type= sys.exc_info()[0], value = sys.exc_info()[1], tb =sys.exc_info()[2], properties = self.properties )
        finally:
            if istraceenabled:
                self.properties[CustomLog.end_time] = datetime.now(timezone.utc).isoformat()
                Logger.request(self,properties= self.properties)
            return self.response, self.statusCode