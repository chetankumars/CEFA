#__init__.py

from .get_defects import *