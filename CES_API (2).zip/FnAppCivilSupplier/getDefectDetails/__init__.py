#__init__.py

import azure.functions as func
import sys
from .business_logic.get_defects import Defects
from common import SharedConstants,ErrorResponse,AppStatus
from .constants.get_defect_details_constants import DefectDetailsConstant
import traceback

def main(req: func.HttpRequest) -> func.HttpResponse:
    """
    calling business logic inside main.
    
    Args:
        req (func.HttpRequest)

    Returns:
        func.HttpResponse:  defect details json from CES DB
    """
    if DefectDetailsConstant.defect_filter in req.headers and req.headers[DefectDetailsConstant.defect_filter]:
        response, statusCode = Defects().get_defects_details(req.headers[DefectDetailsConstant.defect_filter])
    else:
        statusCode = AppStatus.bad_Request.value[0]
        response = ErrorResponse(SharedConstants.request_val_failure, SharedConstants.request_header_failure, statusCode, DefectDetailsConstant.param_failure, Defects().__class__.__name__).__str__()
    return func.HttpResponse(body = response,status_code = statusCode, mimetype= SharedConstants.json_mime_type)

if __name__ == SharedConstants.main:
    main(func.HttpRequest)