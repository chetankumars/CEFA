#__init__.py

from .get_defect_details_constants import *