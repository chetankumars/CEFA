#defect_details_constants.py

class DefectDetailsConstant:

    """ Constants related to the project specific """

    is_new_defect = 'isNewDefect'
    get_sql_query = """
                        EXEC [CES].[sp_Get_DefectDetails_API]
                        @Input_JSON = ?
                    """ 
    get_defect_details = "getDefectDetails"
    get_defect_details_value = "func:getDefectDetails"
    param_failure = "Header X-Defect-Supplier-Filters is missing"
    defect_filter = 'X-Defect-Supplier-Filters'
    input_json = "Input_JSON"

    