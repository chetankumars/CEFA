# __init__.py

from .get_defect_details_schema import *