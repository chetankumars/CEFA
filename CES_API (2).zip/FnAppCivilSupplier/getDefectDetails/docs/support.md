# get defect details

## Description
    Get Information about defect details from CES DB.

## Post Request for Add Exam Dates

    APIM URL: https://apim-uks-dev-ces-0001.azure-api.net/II/CESAPI/supplier/defectDetails
    Method Type:  GET
    
    FUNCTION URL: https://fnp-uks-dev-ces-funcedst0005.azurewebsites.net/api/getDefectDetails?clientId=apim-apim-uks-dev-ces-0001
    Method Type:  GET
    
    Sample Json:
            
                [
                    {
                        "region_name": "Southern",
                        "route_name": "Kent",
                        "pageno": 1,
                        "rowsperpage": 100
                    }
                ]

   Sample Response:

   Success:
           {
                "searchdatacount": {
                    "currentpage": 1,
                    "totalcount": 2768,
                    "totalpages": 28
                },
                "defectsearchresult": [
                    {
                    "elr": "ATH",
                    "asset_guid": "3978559C2DE145D9E04400306E4AD01A",
                    "railway_id": "1812",
                    "open_defects": 0,
                    "total_defects": 1,
                    "highest_open_defect_score": 0,
                    "defectresult": [
                        {
                        "defect_id": 838,
                        "description": "PNE Vegetation",
                        "location": "Wingwalls and roadside parapets",
                        "loc_major": null,
                        "loc_minor": null,
                        "defectdtls": [
                            {
                            "exam_date": "2013-08-20",
                            "exam_id": 5015197,
                            "access_gained": "N/A",
                            "exam_type": "Visual",
                            "recommendation_number": null,
                            "risk_score": "N/A",
                            "access_required": "N/A",
                            "deterioration": "N/A",
                            "repaired": "N",
                            "closure_flg": "Y",
                            "recommendation_comments": null
                            }
                        ]
                        }
                    ]
                    }
                ]
            }
   Bad Request:
            {
                "error": {
                "types": "Invalid Request",
                "title": "Header/Param validation failure",
                "status": 400,
                "detail": "Header X-Defect-Supplier-Filters is missing",
                "instance": "Defects"
                }
            }

   Exception: 
            {
                "error": {
                "types": "<class 'UnboundLocalError'>",
                "title": "Defects",
                "status": 500,
                "detail": "(<class 'UnboundLocalError'>, UnboundLocalError(\"local variable  'conn' referenced before assignment\"), <traceback object at 0x7fca0be799b0>)",
                "instance": "Defects"
                }
            }
       