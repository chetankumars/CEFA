# get_asset_validate_request.py

import sys
import traceback
from common import JsonHelper
from ..schema import GetAssetDetailsSchema

class ValidationRequest:
    "Get Asset Details validation Request class to perform validation on input request"
    def __init__(self):
        self.get_asset_details_schema = GetAssetDetailsSchema()

    def is_valid_payload(self, payload)-> (bool, dict):
        """
        Method to validate the request against schema

        Args:
            json_req(json)

        Returns:
            json(bool,dict) 
        """
        try:
            return_object =  self.get_asset_details_schema.loads(payload)
            res = self.get_asset_details_schema.dump(return_object)
            return True, res
        except:
            return False, sys.exc_info()
    