#get_asset.py

import sys
import os
from common import SharedConstants,Logger,AppStatus,ErrorResponse,JsonHelper,CustomLog,SqlOperation
from datetime import datetime,timezone
from ..constants.get_asset_details_constants import AssetDetailsConstant
import traceback
import json 
from getAssetDetails.business_logic.get_asset_validate_request  import ValidationRequest
import json

istraceenabled = os.environ[SharedConstants.trace_enabled]

class Asset:
    """
    Asset class to get information about Asset details from CES db.
    """ 
    def __init__(self):
       
        self.response = str({})
        self.statusCode = AppStatus.ok.value[0]
        self.properties = {AssetDetailsConstant.get_asset_details : AssetDetailsConstant.get_asset_details_value}
        self.properties[CustomLog.start_time] = datetime.now(timezone.utc).isoformat()
        Logger.__init__( self,name = Asset.__name__, start_time = datetime.now(timezone.utc))
        self.properties[CustomLog.status] = True
        self.json_helper = JsonHelper()
        self.validate_map = ValidationRequest()

    def get_asset_details_json(self, asset_details_req):
        """
        Function to  call the database to get all asset details json based on filter condition
       
        Args:
            asset_details_req(str)
        """
        req_param = self.json_helper.stringify_json(asset_details_req)[1]
        data = json.loads(req_param)
        if(str(data['region_name']).replace(' ','') == str("North, West and Central").replace(' ','')):
            data['region_name']= ("North, West and Central")
            req_param = json.dumps(data)
            self.properties["req_param"] = req_param
        self.properties[CustomLog.sp_req_param] = AssetDetailsConstant.input_json + SharedConstants.colon + req_param
        self.properties[CustomLog.sprequest_time] = datetime.now(timezone.utc).isoformat()
        asset = SqlOperation().fetch_one(AssetDetailsConstant.get_sql_query, req_param)
        self.properties[CustomLog.sprequestend_time] = datetime.now(timezone.utc).isoformat()
        if asset[1]:
            self.statusCode = AppStatus.bad_Request.value[0]
            self.response = ErrorResponse(SharedConstants.request_val_failure,Asset.__name__,self.statusCode,str(asset[1]),Asset.__name__).__str__()
        else:
            is_valid_response,json_obj = self.json_helper.parse_json(asset[0] if asset else None)
            if is_valid_response:
                self.response = self.json_helper.stringify_json(json_obj)[1]
            else:
                self.statusCode = AppStatus.no_content.value[0]

    def get_asset_details(self, asset_details_filter):
        """
        Method to validate the request and to get asset details response.

        Args:
          asset_details_filter(string)

        Returns:
            json(str) 
            statuscode(int)     - 204 No Content
                                - 200 Success
                                - 400 Bad Request
                                - 500 Internal Server Error                          
        """
        try:
            is_valid,res = self.validate_map.is_valid_payload(asset_details_filter)
            if is_valid:
               self.get_asset_details_json(res)
            else: 
               self.statusCode = AppStatus.bad_Request.value[0]   
               self.response = ErrorResponse(SharedConstants.request_val_failure,SharedConstants.request_header_failure,
                                              AppStatus.bad_Request.value[0], str(res),
                                              Asset.__name__).__str__()  
               self.properties[CustomLog.error_messsage] =  str(res)
        except:
            self.properties[CustomLog.error_messsage] = str(sys.exc_info())
            self.properties[CustomLog.status] = False
            self.statusCode = AppStatus.internal_server_error.value[0]
            self.response = ErrorResponse(str(sys.exc_info()[0]), Asset.__name__,
                                 AppStatus.internal_server_error.value[0], str(sys.exc_info()),Asset.__name__).__str__()
            Logger.exception(self,type= sys.exc_info()[0], value = sys.exc_info()[1], tb =sys.exc_info()[2], properties = self.properties )
        finally:
            if istraceenabled:
                self.properties[CustomLog.end_time] = datetime.now(timezone.utc).isoformat()
                Logger.request(self,properties= self.properties)
            return self.response, self.statusCode