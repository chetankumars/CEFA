#get_asset_details_constants.py

class AssetDetailsConstant:

    """ Constants related to the project specific """

    get_sql_query = """
                        EXEC [CES].[sp_Get_AssetDtls_API]
                        @Input_JSON = ?
                    """ 
    get_asset_details = "getAssetDetails"
    get_asset_details_value = "func:getAssetDetails"
    param_failure = "Header X-Asset-Supplier-Filters is missing"
    asset_filter = 'X-Asset-Supplier-Filters'
    input_json = "Input_JSON"