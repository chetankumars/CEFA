# get_asset_details_schema.py

from marshmallow import fields, Schema

class GetAssetDetailsSchema(Schema):
    region_name = fields.Str(required=True)
    route_name = fields.Str(required=False)
    pageno = fields.Int(required=True)
    rowsperpage = fields.Int(required=True)