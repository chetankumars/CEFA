#__init__.py

import azure.functions as func
import sys
from .business_logic.get_asset import Asset
from common import SharedConstants,ErrorResponse,AppStatus
from .constants.get_asset_details_constants import AssetDetailsConstant
import traceback

def main(req: func.HttpRequest) -> func.HttpResponse:
    """
    calling business logic inside main.
    
    Args:
        req (func.HttpRequest)

    Returns:
        func.HttpResponse:  asset details json from CES DB
    """
    if AssetDetailsConstant.asset_filter in req.headers and req.headers[AssetDetailsConstant.asset_filter]:
        response, statusCode = Asset().get_asset_details(req.headers[AssetDetailsConstant.asset_filter])
    else:
        statusCode = AppStatus.bad_Request.value[0]
        response = ErrorResponse(SharedConstants.request_val_failure, SharedConstants.request_header_failure, statusCode, AssetDetailsConstant.param_failure, Asset().__class__.__name__).__str__()
    return func.HttpResponse(body = response,status_code = statusCode, mimetype= SharedConstants.json_mime_type)

if __name__ == SharedConstants.main:
    main(func.HttpRequest)