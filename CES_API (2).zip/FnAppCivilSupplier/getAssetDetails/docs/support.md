# get asset details

## Description
    Get Information about assset details from CES DB.

## Get Request for get Asset Details

    APIM URL: https://apim-uks-nprd-ces-0001.azure-api.net/II/CESAPI/supplier/assetData
    Method Type:  GET
    
    FUNCTION URL: https://fnp-uks-nprd-ii-fncesdev0005.azurewebsites.net/api/getAssetDetails?clientId=apim-apim-uks-nprd-ces-0001
    Method Type:  GET
    
    Sample Json:
            
                    [
                        {
                            "region_name": "Southern",
                            "route_name": "Kent",
                            "pageno": 1,
                            "rowsperpage": 100
                        }
                    ]

   Sample Response:

   Success:
           {
                "searchdatacount": {
                    "currentpage": 1,
                    "totalcount": 30,
                    "totalpages": 3
                },
                "searchresult": [
                    {
                    "region": "Southern",
                    "route": "Kent",
                    "area": "London Bridge",
                    "elr": "HHH",
                    "asset_guid": "3978559C2D8145D9E04400306E4AD01A",
                    "railway_id": "W97",
                    "asset_group": "Bridge",
                    "asset_type": "Viaduct",
                    "start_mileage": 2.475,
                    "end_mileage": null,
                    "primary_material": " RBE - Brick",
                    "owning_party": "Network Rail (CE-Struct)",
                    "gps_start": null,
                    "gps_end": null,
                    "structure_carries": "Rail",
                    "structure_over": "Tenant",
                    "hce_flag": "No",
                    "cmi_score": 63,
                    "tenanted_flg": "Yes",
                    "exam_type": "Detailed",
                    "comp_status": "Compliant",
                    "possession": null,
                    "rrv": null,
                    "ladder": null,
                    "confined_space": null,
                    "3rd_party": null,
                    "line_block": null,
                    "mewp": null,
                    "scaffold": null,
                    "water_permit": null,
                    "traffic_mngt": null,
                    "rope_access": null,
                    "cctv": null,
                    "safety_boat": null
                    }
                ]
            }
   Bad Request:
            {
                "error": {
                    "types": "Invalid Request",
                    "title": "Header/Param validation failure",
                    "status": 400,
                    "detail": "Header X-Asset-Supplier-Filters is missing",
                    "instance": "Asset"
                }
            }

   Exception: 
            {
                "error": {
                    "types": "<class 'UnboundLocalError'>",
                    "title": "Asset",
                    "status": 500,
                    "detail": "(<class 'UnboundLocalError'>, UnboundLocalError(\"local variable 'conn' referenced before assignment\"), <traceback object at 0x0000024627C54740>)",
                    "instance": "Asset"
                }
            }
       