#__init__.py

import azure.functions as func
from .business_logic.examdata_validation import ExamDataValidation
from common import SharedConstants

def main(req: func.HttpRequest) -> func.HttpResponse:
   
    """[summary]

    Args:
        req (func.HttpRequest): json 

    Returns:
        func.HttpResponse: returns http status code
        
    """
    files = req.get_json()
    response,statusCode = ExamDataValidation().validate(files,req)
    return func.HttpResponse(body=response, status_code=statusCode)

if __name__ == SharedConstants.main:
    main(func.HttpRequest)