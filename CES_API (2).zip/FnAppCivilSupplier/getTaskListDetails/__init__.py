# __init__.py

import sys
import azure.functions as func
import traceback
from .constants.get_tasklist_details_constants import TaskListDetailsConstants
from .business_logic.task_list_details import TaskListDetails
from common import AppStatus, SharedConstants, ErrorResponse


def main(req: func.HttpRequest) -> func.HttpResponse:
    """ 
    Function calls  TaskListDetails class to get tasklist details for supplier.

    Args:
        req (func.HttpRequest)

    Returns:
        func.HttpResponse:  tasklist details json from CES DB
    """
    
    if  req.headers[TaskListDetailsConstants.taskList_filter] and req.headers[TaskListDetailsConstants.taskList_suppliername_filter]:
        response, statusCode = TaskListDetails().get_task_list(req.headers[TaskListDetailsConstants.taskList_filter],req.headers[TaskListDetailsConstants.taskList_suppliername_filter])
    else:
        statusCode = AppStatus.bad_Request.value[0]
        response = ErrorResponse(SharedConstants.request_val_failure, SharedConstants.request_header_failure, statusCode, TaskListDetailsConstants.param_failure, TaskListDetails().__class__.__name__).__str__()
    return func.HttpResponse(body = response,status_code = statusCode, mimetype= SharedConstants.json_mime_type)

if __name__ == SharedConstants.main:
    main(func.HttpRequest)