# get tasklist details

## Description
    Get Information about tasklist details from CES DB.

## Get Request for tasklist details

    APIM URL: https://apim-uks-dev-ces-0001.azure-api.net/II/CESAPI/supplier/taskListDetails
    Method Type:  GET
    
    FUNCTION URL: https://fnp-uks-dev-ces-funcedst0005.azurewebsites.net/api/getTaskListDetails?clientId=apim-apim-uks-dev-ces-0001
    Method Type:  GET
    
    Sample Header: {"region":"Eastern","route":"Anglia","financialyear":"2021/2022","suppliername":"Amey Rail","pageNo":2,"rowsCount":100}

   Sample Response:

   Success:
            {
                "searchdatacount": {
                "currentpage": 2,
                "totalcount": 1,
                "totalpages": 1
            },
            "data": [
                      {
                        "region": "Eastern",
                        "route": "Anglia",
                        "area": "Ipswich",
                        "elr": "ESK",
                        "startMileage": 82.1,
                        "endMileage": null,
                        "railwayId": "431",
                        "assetDescription": "RIVER DEBEN & OCCUPATION ROAD (UFFORD)",
                        "assetGroup": "Bridge",
                        "assetType": "Underline Bridge",
                        "assetGuid": "3978559D1EC045D9E04400306E4AD01A",
                        "taskListStatus": "281",
                        "examinationType": "Visual",
                        "examId": 13265563,
                        "examFrequency": "1y 0m 0d",
                        "requiredDate": "2021-10-09",
                        "earliestRequiredDate": "2021-07-03",
                        "latestRequiredDate": "2022-01-15",
                        "maxToleranceDate": "2022-01-29",
                        "plannedDate": null,
                        "cRID": null,
                        "jobNumber": null,
                        "specificRequirement": null,
                        "commentsToSec": null,
                        "examGroupId": null,
                        "hce": "No",
                        "bcmiRequired": null,
                        "nrComment": null,
                        "tenantedArches": "No",
                        "examRequestStatus": "Planned",
                        "examReportStatus": null,
                        "examDate": null
                    }
                ]
            }
           
   Bad Request:
            {
                "error": {
                "types": "Invalid Request",
                "title": "Header/Param validation failure",
                "status": 400,
                "detail": "Header X-TaskList-Supplier-Filters is missing",
                "instance": "TaskListDetails"
                    }
            }

   Exception: 
            {
                "error": {
                "types": "<class 'UnboundLocalError'>",
                "title": "TaskListDetails",
                "status": 500,
                "detail": "(<class 'UnboundLocalError'>, UnboundLocalError(\"local variable 'conn' referenced before assignment\"), <traceback object at 0x0000026374632940>)",
                "instance": "TaskListDetails"
                    }
            }