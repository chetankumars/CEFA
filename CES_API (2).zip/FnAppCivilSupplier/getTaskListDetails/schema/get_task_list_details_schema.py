# get_task_list_details_schema.py

from marshmallow import fields, Schema, validate, ValidationError
import re

class GetTaskListDetailsSchema(Schema):
    region = fields.Str(required=True, validate=validate.Length(min=1, error="region should not be blank"))
    route = fields.Str(required=False, default=None)
    financialyear = fields.Str(required=True, validate=validate.Length(min=1, error="financialyear should not be blank"))
    suppliername = fields.Str(required=True,validate=validate.Length(min=1, error="suppliername should not be blank"))
    pageNo = fields.Int(required=True)
    rowsCount = fields.Int(required=True, validate=validate.Range(max=100),error="rowscount should be less than or equal to 100")