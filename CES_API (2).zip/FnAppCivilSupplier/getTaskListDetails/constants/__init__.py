# __init__.py

from .get_tasklist_details_constants import *