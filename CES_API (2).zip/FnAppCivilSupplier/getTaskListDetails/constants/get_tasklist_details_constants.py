# get_tasklist_details_constants.py

class TaskListDetailsConstants:

    """ Constants related to the project specific """

    sql_query = """
                EXEC [CES].[sp_Get_TaskListDtls_API]
                @Input_JSON = ?
                """ 
    get_taskList_details = "getTaskListDetails"
    get_taskList_details_value = "func:getTaskListDetails"
    param_failure = "Header X-TaskLists-Supplier-Filters is missing"
    taskList_filter = 'X-TaskLists-Supplier-Filters'
    taskList_suppliername_filter = 'X-TaskLists-Supplier-Name'
    input_json = "Input_JSON"
    suppliers_mapper = "suppliersMapper" 
    suppliers_metadata = "suppliersMetaData" 
    suppliers_dtls_mapper = "SUPPLIER_MAPPER"
    suppliers_metadata_mapper = "SUPPLIER_METADATA"
    id = "id"   
    name = "name"
    supplier_id = "supplierId"
    invalid_suppplier_name = 'Invalid supplier name.'