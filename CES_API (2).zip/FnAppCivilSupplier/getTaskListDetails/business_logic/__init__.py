# __init__.py

from .task_list_details import *