# task_list_details.py

import sys
import os
import logging
from datetime import datetime, timezone 
from common import Logger, AppStatus, JsonHelper, CustomLog, SharedConstants, SqlOperation, ErrorResponse
from ..constants.get_tasklist_details_constants import TaskListDetailsConstants
from getTaskListDetails.business_logic.task_list_validate_request import ValidateRequest
import json
import traceback

istraceenabled = os.environ[SharedConstants.trace_enabled]

class TaskListDetails:
    """ TaskListDetails class to get information about tasklist details from CES db."""
    
    def __init__(self):
        self.response = str({})
        self.statusCode = AppStatus.ok.value[0]
        self.properties = {TaskListDetailsConstants.get_taskList_details : TaskListDetailsConstants.get_taskList_details_value}
        self.properties[CustomLog.start_time] = datetime.now(timezone.utc).isoformat()
        Logger.__init__(self,name = TaskListDetails.__name__, start_time = datetime.now(timezone.utc))
        self.properties[CustomLog.status] = True
        self.json_helper = JsonHelper()
        self.validation = ValidateRequest()
        
    def get_task_list_json(self, task_list_req,supp_id):
        """
        Function to  call the database to get all tasklist details json based on filter condition
       
        Args:
            req (str)
        """
        supplier_name = self.get_supplier_name(supp_id)
        if(" " in supplier_name):
            supplier_name = supplier_name.replace(" ", "")
        req_supplier_name = task_list_req['suppliername']
        if(" " in req_supplier_name):
            req_supplier_name = req_supplier_name.replace(" ", "")

        if req_supplier_name == supplier_name:
            task_list_req['suppliername']=self.supplier_name
            req_param = self.json_helper.stringify_json(task_list_req)[1]
            data = json.loads(req_param)
            if(str(data['region']).replace(' ','') == str("North, West and Central").replace(' ','')):
                data['region']= ("North, West and Central")
                req_param = json.dumps(data)
                self.properties["task_list_filter"] = req_param
            self.properties[CustomLog.sp_req_param] = TaskListDetailsConstants.input_json + SharedConstants.colon + req_param
            self.properties[CustomLog.sprequest_time] = datetime.now(timezone.utc).isoformat()
            task_list = SqlOperation().fetch_one(TaskListDetailsConstants.sql_query, req_param)
            self.properties[CustomLog.sprequestend_time] = datetime.now(timezone.utc).isoformat()
            if task_list[1]:
                self.statusCode = AppStatus.bad_Request.value[0]
                self.response = ErrorResponse(SharedConstants.request_val_failure,TaskListDetails.__name__,self.statusCode,str(task_list[1]),TaskListDetails.__name__).__str__()
            else:
                is_valid_response,json_obj = self.json_helper.parse_json(task_list[0] if task_list else None)
                if is_valid_response:
                    data_output = []
                    for data in json_obj["data"]:
                        data["requiredDate"] = (datetime.strptime(data["requiredDate"],'%Y-%m-%d')).strftime('%d-%m-%Y') if data["requiredDate"] else None
                        data["earliestRequiredDate"] = (datetime.strptime(data["earliestRequiredDate"],'%Y-%m-%d')).strftime('%d-%m-%Y') if data["earliestRequiredDate"] else None
                        data["latestRequiredDate"] = (datetime.strptime(data["latestRequiredDate"],'%Y-%m-%d')).strftime('%d-%m-%Y') if data["latestRequiredDate"] else None
                        data["maxToleranceDate"] = (datetime.strptime(data["maxToleranceDate"],'%Y-%m-%d')).strftime('%d-%m-%Y') if data["maxToleranceDate"] else None
                        data["plannedDate"] = (datetime.strptime(data["plannedDate"],'%Y-%m-%d')).strftime('%d-%m-%Y') if data["plannedDate"] else None
                        data["examDate"] = (datetime.strptime(data["examDate"],'%Y-%m-%d')).strftime('%d-%m-%Y') if data["examDate"] else None    
                        data_output.append(data)
                    json_obj["data"] = data_output
                    self.response = self.json_helper.stringify_json(json_obj)[1]
                else:
                    self.statusCode = AppStatus.no_content.value[0]
        else:
            self.statusCode = AppStatus.bad_Request.value[0] 
            self.response = ErrorResponse(SharedConstants.request_val_failure,SharedConstants.request_header_failure,
                                              self.statusCode, str(TaskListDetailsConstants.invalid_suppplier_name),
                                              TaskListDetails.__name__).__str__()  

    def get_task_list(self, task_list_filter, supp_id):
        """
        Method to validate the request and to get tasklist response.

        Args:
          task_list_filter(string)

        Returns:
            json(str) 
            statuscode(int)   - 204 No Content
                              - 200 Success
                              - 400 Bad Request
                              - 500 Internal Server Error
        """
        try:
            is_valid,res = self.validation.is_valid_payload(task_list_filter)
            if is_valid:
               self.get_task_list_json(res,supp_id)
            else:
               self.statusCode = AppStatus.bad_Request.value[0]   
               self.response = ErrorResponse(SharedConstants.request_val_failure,SharedConstants.request_header_failure,
                                              AppStatus.bad_Request.value[0], str(res),
                                              TaskListDetails.__name__).__str__()  
               self.properties[CustomLog.error_messsage] =  str(res)
        except:
            self.properties[CustomLog.error_messsage] =   str(traceback.format_exc())
            self.properties[CustomLog.status] = False
            self.statusCode = AppStatus.internal_server_error.value[0]
            self.response = ErrorResponse(str(sys.exc_info()[0]), TaskListDetails.__name__,
                                 AppStatus.internal_server_error.value[0], str(sys.exc_info()),TaskListDetails.__name__).__str__()
            Logger.exception(self,type= sys.exc_info()[0], value = sys.exc_info()[1], tb =sys.exc_info()[2], properties = self.properties )
        finally:
            if istraceenabled:
                self.properties[CustomLog.end_time] = datetime.now(timezone.utc).isoformat()
                Logger.request(self,properties= self.properties)
            return self.response, self.statusCode
    
    def get_supplier_name(self,supp_id):
        """
        To get the database supplier id 
       
        Args:
            self ([TaskListData]): [self instance]
            Supplier Active directory Id : supp_id        """
        suppliers = self.json_helper.parse_json(os.environ[TaskListDetailsConstants.suppliers_dtls_mapper])[1]
        #use below value for local testing
        #suppliers = self.json_helper.parse_json('{"suppliersMapper":[{"id":"8e728a17-5b08-4ea0-be5a-5e53ba77ef9e","supplierId":"6"},{"id":"03e844f2-a687-4112-ab44-59088f964625","supplierId":"4"},{"id":"b7789d1f-defb-4f49-9681-bbea38b8a5e4","supplierId":"5"}]}')[1]
        self.properties['suppliers'] = str(suppliers)
        self.properties['x-supplier-id'] = str(supp_id)
        supplier = next((x for x in suppliers[TaskListDetailsConstants.suppliers_mapper] if x[TaskListDetailsConstants.id] == supp_id), '')
        self.properties['supplier'] = str(supplier)
        self.supplier_id = supplier[TaskListDetailsConstants.supplier_id] if supplier else ''

        suppliersnames = self.json_helper.parse_json(os.environ[TaskListDetailsConstants.suppliers_metadata_mapper])[1]
        #suppliersnames = self.json_helper.parse_json('{"suppliersMetaData":[{"id":"1","name":"Atkins Rail"},{"id":"2","name":"Mouchel Parkman Rail"},{"id":"3","name":"Owen Williams Rail"},{"id":"4","name":"Amey Rail"},{"id":"5","name":"Network Rail"},{"id":"6","name":"XEIAD"},{"id":"7","name":"Pell Frischmann"},{"id":"8","name":"AECOM"},{"id":"9","name":"Jacobs"},{"id":"10","name":"QTS"},{"id":"11","name":"Kraven"},{"id":"12","name":"CML"},{"id":"13","name":"AMCO"},{"id":"14","name":"Amey (CAFA)"},{"id":"15","name":"AECOM (CAFA)"},{"id":"16","name":"Other (CAFA)"},{"id":"17","name":"SAS Rope and Rail"},{"id":"18","name":"Inspire"},{"id":"19","name":"GW Marine"},{"id":"20","name":"AK Rates"},{"id":"21","name":"Coombes"},{"id":"22","name":"WSP"}]}')[1]
        suppliername = next((x for x in suppliersnames[TaskListDetailsConstants.suppliers_metadata] if x[TaskListDetailsConstants.id] == self.supplier_id), '')
        self.supplier_name=suppliername[TaskListDetailsConstants.name] if suppliername else ''
        self.properties['X-TaskLists-Supplier-Name'] = str(self.supplier_name)
        return (self.supplier_name)