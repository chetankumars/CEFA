# task_list_validate_request.py

import sys
import traceback
from ..schema import GetTaskListDetailsSchema

class ValidateRequest:
    "ValidateRequest class to perform validation on input request"
    def __init__(self):
        self.task_list_schema = GetTaskListDetailsSchema()

    def is_valid_payload(self, payload)-> (bool, dict):
        """
        Method to validate the request against schema

        Args:
            json_req(json)

        Returns:
            bool:represents validation is successful or not | dict:validated json response 
        """
        try:
            return_object =  self.task_list_schema.loads(payload)
            res = self.task_list_schema.dump(return_object)
            return True, res
        except:
            return False, sys.exc_info()