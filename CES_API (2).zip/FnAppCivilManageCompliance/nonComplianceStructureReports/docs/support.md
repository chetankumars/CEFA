# search non compliant structure reports

## Description
Services to get non compliant structure reports details from CES db.

    APIM URL: https://apim-uks-dev-ces-0001.azure-api.net/II/CESAPI/compliances/report
    Method Type: GET

    FUNCTION URL: https://fnp-uks-dev-ces-funcedst0007.azurewebsites.net/api/nonComplianceStructureReports
    Method Type: GET

## Request headers for nonComplianceStructureReports
    
    Request headers:
        Header Name : X-Report-Compliance-Filters
        Sample Value : {"route_id":1,"period_id":1}