# __init__.py

from .structures_report_constants import StructuresReportConstants