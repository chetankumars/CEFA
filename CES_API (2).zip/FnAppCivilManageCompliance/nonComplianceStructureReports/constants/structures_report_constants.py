# structures_report_constants.py

class StructuresReportConstants:
    """ Constants related to nonComplianceStructureReports"""
    sql_query = """
                EXEC [CES].[sp_Get_Structures_Report]
                @Input_JSON = ?
                """
    get_non_complaince_reports = "nonComplianceStructureReports"
    get_non_complaince_reports_val = "func:nonComplianceStructureReports"
    param_failure = "Header X-Report-Compliance-Filters is missing"
    report_filter = 'X-Report-Compliance-Filters'
    input_json = "Input_JSON"