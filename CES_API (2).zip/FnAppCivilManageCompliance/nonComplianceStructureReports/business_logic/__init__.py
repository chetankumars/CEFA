# __init__.py

from .structure_reports import *