# __init__.py

import azure.functions as func
from common import AppStatus, SharedConstants, ErrorResponse
from .business_logic.structure_reports import StructureReports
from .constants.structures_report_constants import StructuresReportConstants


def main(req: func.HttpRequest) -> func.HttpResponse:
    """ 
    Function calls  StructureReports class to get non compliance structures report details.

    Args:
        req (func.HttpRequest)

    Returns:
        func.HttpResponse:  non compliance structures report details json from CES DB
    """
    if StructuresReportConstants.report_filter in req.headers and req.headers[StructuresReportConstants.report_filter]:
        response, statusCode = StructureReports().view_non_compliance_reports(req.headers[StructuresReportConstants.report_filter])
    else:
        statusCode = AppStatus.bad_Request.value[0]
        response = ErrorResponse(SharedConstants.request_val_failure, SharedConstants.request_header_failure, statusCode, StructuresReportConstants.param_failure, StructureReports().__class__.__name__).__str__()
    return func.HttpResponse(body = response,status_code = statusCode, mimetype= SharedConstants.json_mime_type)

if __name__ == SharedConstants.main:
    main(func.HttpRequest)