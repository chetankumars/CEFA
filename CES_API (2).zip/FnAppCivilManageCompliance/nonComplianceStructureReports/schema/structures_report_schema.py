# structures_report_schema.py

from marshmallow import fields, Schema, validate, ValidationError

class StructuresReportSchema(Schema):
    route_id = fields.Int(required = True)
    period_id = fields.Int(required = True)
    