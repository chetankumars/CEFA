# Risk Assessment Under Water

## Description
    Service to get and update the risk assessment details to CES DB.

## Get Request for risk assessment

    APIM URL: https://apim-uks-nprd-ces-0001.azure-api.net/II/CESAPI/compliances/riskassessment
    Method Type: GET

    FUNCTION URL: https://fnp-uks-dev-ces-funcedst0007.azurewebsites.net/api/riskassessment
    Method Type: GET
    Request Param:
        1)assetGuid = 3978559C2FDC45D9E04400306E4AD01A
        2)examTypeId = 3
    
## Post Request for risk assessment

    APIM URL: https://apim-uks-nprd-ces-0001.azure-api.net/II/CESAPI/compliances/riskassessment
    Method Type: Post

    FUNCTION URL: https://fnp-uks-dev-ces-funcedst0007.azurewebsites.net/api/riskassessment
    Method Type: post

    Body:
        {
	"asset_guid":"3978559c2d8145d9e04400306e4ad01a",
	"exam_type_id":2,
	"assessment_date": "12/12/2020",
	"review_date":"12/12/2020",
	"expiry_date":"12/10/2021",
	"risk_score":"High",
	"mitigation_comment": "abcd",
	"risk_user_key":"fdfdfdfdf",
	"question_01":"q1",
	"question_01_ans":"Y",
	"question_01_cmt":"c1",
	"question_02":"q2",
	"question_02_ans":"Y",
	"question_02_cmt":"c2",
	"question_03":"q3",
	"question_03_ans":"Y",
	"question_03_cmt":"c3",
	"question_04":"q4",
	"question_04_ans":"Y",
	"question_04_cmt":"c4",
	"mitigation_action_01": "m1", 
	"mitigation_action_01_selection": "Y",
	"mitigation_action_02": "m2",
	"mitigation_action_02_selection": "N",
	"mitigation_action_03": "m3",
	"mitigation_action_03_selection": "N", 
	"mitigation_action_04": "m4",
	"mitigation_action_04_selection": "Y", 
	"mitigation_action_05": "m5",
	"mitigation_action_05_selection": "N", 
	"mitigation_action_06": "m6",
	"mitigation_action_06_selection": "Y", 
	"mitigation_action_07": "m7", 
	"mitigation_action_07_selection": "N",
	"mitigation_date": "12/10/2021"
	
}