from common.utilities.json_helper import JsonHelper

class RiskAssessmentMapper:

    def __init__(self):
        
        self.data_mapper = {
                            'asset_guid':'asset_guid',
                            'exam_type_id':'exam_type_id',
                            'assessment_date':'assessment_date',
                            'review_date':'review_date',
                            'expiry_date':'expiry_date',
                            'risk_score':'risk_score',
                            'mitigation_comment':'mitigation_comment',
                            'question_01':'question_01',
                            'question_01_ans':'question_01_ans',
                            'question_01_cmt':'question_01_cmt',
                            'question_02':'question_02',
                            'question_02_ans':'question_02_ans',
                            'question_02_cmt':'question_02_cmt',
                            'question_03':'question_03',
                            'question_03_ans':'question_03_ans',
                            'question_03_cmt':'question_03_cmt',
                            'question_04':'question_04',
                            'question_04_ans':'question_04_ans',
                            'question_04_cmt':'question_04_cmt'         
                           }


    def map_dictionary(self, json_req)->str:
        """
        Method to map the request column to the db column

        Args:
            json_req(json)

        Returns:
            json(str) 
        
        """
       
        return  JsonHelper().stringify_json(dict((self.data_mapper.get(k, k), v) for (k, v) in json_req.items()))[1]
