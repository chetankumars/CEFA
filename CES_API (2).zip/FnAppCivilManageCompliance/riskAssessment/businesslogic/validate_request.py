#validate_request.py
import sys
import os
import json


#validate_request.py

__all__ = ['ValidateRequest']
class ValidateRequest:

    def __init__(self, risk_assessment_schema):
        self.risk_assessment_schema = risk_assessment_schema

    def is_valid_payload(self, payload)-> (bool, dict):
        try: 
            return True, self.risk_assessment_schema.dump(self.risk_assessment_schema.loads(payload))
        except:
            return False, sys.exc_info()[1]

        



