#risk_assessment.py

import sys
import os
import logging
import azure.functions as func
import traceback
import common
import json
from common.utilities.json_helper import JsonHelper
from common import SqlOperation, Logger, JsonHelper,ValidationHelper,CustomLog, AppStatus, SharedConstants, SuccessResponse
from datetime import datetime, timezone
from ..constants.risk_assessment_constants import RiskAssessmentConstants
from .validate_request import ValidateRequest
from ..schema.risk_assessment_post_schema import RiskAssessmentPostSchema
from .risk_assessment_mapper import RiskAssessmentMapper

istraceenabled = os.environ[SharedConstants.trace_enabled]

__all__ = ['RiskAssessment']
class RiskAssessment:
  
    """ RiskAssessment class to get risk assessment form details and save the risk assessment form details into ces database """ 
    def __init__(self):

        self.get_sql_query = """
                           [CES].[sp_Get_RiskAssessment_Form_Dtls]
                           @Asset_GUID = ?, @Exam_Type_ID = ?
                           """
        self.save_sql_query = """
                           [CES].[sp_Save_RiskAssessment_Dtls]
                           @Input_JSON = ?
                           """
        self.response =  SuccessResponse(AppStatus.record_created.value[0],
                                         SharedConstants.save_success_msg).__str__()
        self.status_code = AppStatus.ok.value[0]
        self.properties = {RiskAssessmentConstants.risk_assessment : RiskAssessmentConstants.risk_assessment_val}
        self.properties[CustomLog.start_time] = datetime.now(timezone.utc).isoformat()
        Logger.__init__( self,name = RiskAssessment.__name__, start_time = datetime.now(timezone.utc))
        self.properties[CustomLog.status] = True
    
    def get_risk_assessment_info(self, req:func.HttpRequest)->(func.HttpResponse):
        """
        Function to call Ces database to get risk assessment information.
       
        Args:
            req (HttpRequest)

        Returns:
            response(HttpResponse) 
            statuscode(int)     - 204 No Content
                                - 200 Success
                                - 400 Bad Request
                                - 500 Internal Server Error 
                                
        """
        try:
            asset_guid = req.params.get(SharedConstants.asset_guid_query_param)
            exam_type_id = req.params.get(SharedConstants.exam_type_id_query_param)
            if(asset_guid is not None and exam_type_id is not None):
                self.properties[CustomLog.sp_req_param] = SharedConstants.asset_guid + SharedConstants.colon + asset_guid + SharedConstants.comma + SharedConstants.exam_type_id + SharedConstants.colon + str(exam_type_id)      
                self.properties[CustomLog.sprequest_time] = datetime.now(timezone.utc).isoformat()
                sp_param = asset_guid, exam_type_id
                _json_string = SqlOperation().fetch_one(self.get_sql_query,sp_param)
                self.properties[CustomLog.sprequestend_time] = datetime.now(timezone.utc).isoformat()
                _json_helper = JsonHelper()
                _isparsejson_sucess,_json_obj = _json_helper.parse_json(_json_string[0])
                if _isparsejson_sucess:
                    self.response = _json_helper.stringify_json(_json_obj)[1]
                else:
                    self.status_code = AppStatus.no_content.value[0]
            else:
                self.response = common.ErrorResponse(common.SharedConstants.request_val_failure, common.SharedConstants.request_header_failure,common.AppStatus.bad_Request.value[0], RiskAssessmentConstants.asset_guid_or_exam_type_id_invaild, RiskAssessment().__class__.__name__).__str__()
                self.status_code = AppStatus.bad_Request.value[0]
            if istraceenabled:
                self.properties[CustomLog.end_time] = datetime.now(timezone.utc).isoformat()
                Logger.request(self,properties= self.properties)

        except:
            self.properties[CustomLog.error_messsage] =   str(traceback.format_exc())
            self.properties[CustomLog.status] =  False
            Logger.exception( self,type= sys.exc_info()[0], value = sys.exc_info()[1], tb =sys.exc_info()[2], properties = self.properties )
            self.response = common.ErrorResponse(str(sys.exc_info()[0]), self.__class__.__name__,common.AppStatus.internal_server_error.value, str(sys.exc_info()[1]), self.__class__.__name__).__str__()
            self.status_code = common.AppStatus.internal_server_error.value[0]
        finally:
            return func.HttpResponse(body=self.response, status_code= self.status_code, mimetype= SharedConstants.json_mime_type)
        
    def post_risk_assessment_Info(self, req:func.HttpRequest)->(func.HttpResponse):
        """
        Function to call Ces database to save risk assessment information.
       
        Args:
            req (HttpRequest)

        Returns:
            response (HttpResponse)
            statuscode(int)     - 204 No Content
                                - 200 Success
                                - 400 Bad Request
                                - 500 Internal Server Error 
                                
        """
        try:
            risk_assessment_info = req.get_json()
            is_valid_payload, return_object =  ValidateRequest(RiskAssessmentPostSchema()).is_valid_payload(json.dumps(risk_assessment_info))
            if(is_valid_payload):
                risk_assessment_info_sp = RiskAssessmentMapper().map_dictionary(return_object)
                self.properties[CustomLog.sp_req_param] = SharedConstants.input_json + SharedConstants.colon + risk_assessment_info_sp
                self.properties[CustomLog.sprequest_time] = datetime.now(timezone.utc).isoformat()
                _json_string = SqlOperation().fetch_one(self.save_sql_query,risk_assessment_info_sp)
                self.properties[CustomLog.sprequestend_time] = datetime.now(timezone.utc).isoformat()
                if _json_string is None:
                    self.status_code = AppStatus.no_content.value[0]
                if not _json_string[0]:
                    self.response = common.ErrorResponse(sys.exc_info()[0], self.__class__.__name__,common.AppStatus.internal_server_error.value, _json_string[1], self.__class__.__name__).__str__()
                    self.status_code = AppStatus.internal_server_error.value[0]
                else:
                    self.status_code = AppStatus.record_created.value[0]
            else:
                self.response = common.ErrorResponse(common.SharedConstants.request_val_failure, common.SharedConstants.request_header_failure,common.AppStatus.bad_Request.value[0], return_object.messages, self.__class__.__name__).__str__()
                self.status_code = common.AppStatus.bad_Request.value[0]

            if istraceenabled:
                self.properties[CustomLog.end_time] = datetime.now(timezone.utc).isoformat()
                Logger.request(self,properties= self.properties)
        except:
            self.properties[CustomLog.error_messsage] =   str(traceback.format_exc())
            self.properties[CustomLog.status] = False
            Logger.exception(self,type= sys.exc_info()[0], value = sys.exc_info()[1], tb =sys.exc_info()[2], properties = self.properties )
            self.response = common.ErrorResponse(str(sys.exc_info()[0]), self.__class__.__name__,common.AppStatus.internal_server_error.value, str(sys.exc_info()[1]), self.__class__.__name__).__str__()
            self.status_code = common.AppStatus.internal_server_error.value[0]

        finally:
            return func.HttpResponse(body=self.response, status_code=self.status_code, mimetype= SharedConstants.json_mime_type)