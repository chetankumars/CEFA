#display_task_list_constants.py

class RiskAssessmentConstants:
    
    # Constants related to the project specific

    asset_guid_or_exam_type_id_invaild = "asset guid or exam type id is missing"
    risk_assessment = "risk assessment"
    risk_assessment_val = "func:riskAssessment"