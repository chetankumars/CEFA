#__init__.py

import sys
import azure.functions as func
from .businesslogic.risk_assessment import RiskAssessment
import json
import common
from common import SharedConstants, ErrorResponse, SharedConstants
from .constants.risk_assessment_constants import RiskAssessmentConstants
import traceback

def main(req: func.HttpRequest) -> func.HttpResponse:
    """[summary]

    Args:
        req (func.HttpRequest): risk assessment request for get and post operations.

    Returns:
        func.HttpResponse: risk assessment response
    """

    if req.method == SharedConstants.method_type_get:
        return RiskAssessment().get_risk_assessment_info(req)
    else:
        return RiskAssessment().post_risk_assessment_Info(req)

if __name__ == SharedConstants.main:
    main(func.HttpRequest)