# test_risk_assessment_historic_records.py

import sys
import os
import unittest
from unittest.mock import patch
import azure.functions as func
from tests.load_environment_variables import EnvironmentVariable
EnvironmentVariable()
from riskAssessmentHistoricRecords import RiskAssessmentHistoricRecords


class RiskAssessmentHistoricRecordsTest(unittest.TestCase):
    
    @patch('riskAssessmentHistoricRecords.business_logic.risk_assessment_historic_records.SqlOperation')
    async def test_actions_return_ok(self, mocked):
        action_details_mock = '{"searchdatacount":1,"risk_history":[{"rowrank":1,"assessment_date":"2012-10-08","review_date":"2013-01-11","expiry_date":"2013-01-18","risk_score":"Low","mitigation_comment":"Bulk Upload: Q1 - Q16 generically filled in to allow upload: no UDRs reported from site so low risk to extend review date.","risk_user":null,"question_01":null,"question_01_ans":null,"question_01_cmt":null,"question_02":null,"question_02_ans":null,"question_02_cmt":null,"question_03":null,"question_03_ans":null,"question_03_cmt":null,"question_04":null,"question_04_ans":null,"question_04_cmt":null,"mitigation_date":null,"mitigation_action_01":null,"mitigation_action_01_selection":null,"mitigation_action_02":null,"mitigation_action_02_selection":null,"mitigation_action_03":null,"mitigation_action_03_selection":null,"mitigation_action_04":null,"mitigation_action_04_selection":null,"mitigation_action_05":null,"mitigation_action_05_selection":null,"mitigation_action_06":null,"mitigation_action_06_selection":null,"mitigation_action_07":null,"mitigation_action_07_selection":null}]}'
        mocked.return_value.fetch_one.return_value = action_details_mock, 200
        response, status_code = await RiskAssessmentHistoricRecords().get_risk_assessment('1', '3978559C2D9F45D9E04400306E4AD01A')
        self.assertEqual(status_code, 200)
        
    @patch('riskAssessmentHistoricReco+rds.business_logic.risk_assessment_historic_records.SqlOperation')
    async def test_actions_return_nocontent(self, mocked):
        mocked.return_value.fetch_one.return_value = None
        response, status_code = await RiskAssessmentHistoricRecords().get_risk_assessment('1', '3978559C2D9F45D9E04400306E4AD01A')
        self.assertEqual(status_code, 204)
        self.assertEqual(response, '{}')

    @patch('riskAssessmentHistoricRecords.business_logic.risk_assessment_historic_records.SqlOperation')
    async def test_actions_return_internalservererrror_invalidJson(self, mocked):
        mocked.return_value.fetch_one.return_value = '{"searchdatacount":1,"risk_history":[{"rowrank":1"assessment_date":"2012-10-08","review_date":"2013-01-11","expiry_date":"2013-01-18","risk_score":"Low","mitigation_comment":"Bulk Upload: Q1 - Q16 generically filled in to allow upload: no UDRs reported from site so low risk to extend review date.","risk_user":null,"question_01":null,"question_01_ans":null,"question_01_cmt":null,"question_02":null,"question_02_ans":null,"question_02_cmt":null,"question_03":null,"question_03_ans":null,"question_03_cmt":null,"question_04":null,"question_04_ans":null,"question_04_cmt":null,"mitigation_date":null,"mitigation_action_01":null,"mitigation_action_01_selection":null,"mitigation_action_02":null,"mitigation_action_02_selection":null,"mitigation_action_03":null,"mitigation_action_03_selection":null,"mitigation_action_04":null,"mitigation_action_04_selection":null,"mitigation_action_05":null,"mitigation_action_05_selection":null,"mitigation_action_06":null,"mitigation_action_06_selection":null,"mitigation_action_07":null,"mitigation_action_07_selection":null}]}'
        response, status_code = await RiskAssessmentHistoricRecords().get_risk_assessment('1', '3978559C2D9F45D9E04400306E4AD01A')
        self.assertEqual(status_code, 500)
        self.assertEqual(response, '{}')

    @patch('riskAssessmentHistoricRecords.business_logic.risk_assessment_historic_records.SqlOperation')
    async def test_actions_return_Internalservererror(self, mocked):
        mocked.side_effect = ConnectionError
        try:
           await RiskAssessmentHistoricRecords().get_risk_assessment('1', '3978559C2D9F45D9E04400306E4AD01A')
        except ConnectionError:
            pass
        except Exception:
            self.fail('unexpected exception raised')
        else:
            self.fail('ExpectedException not raised')