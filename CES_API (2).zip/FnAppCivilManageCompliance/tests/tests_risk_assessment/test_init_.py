#test_init_.py

import sys
import os
import unittest
from unittest.mock import patch
import azure.functions as func
from tests.load_environment_variables import EnvironmentVariable
EnvironmentVariable()
from riskAssessment import main

class RiskAssessmentInitTest(unittest.TestCase):

    @patch('riskAssessment.RiskAssessment')
    def test_init_get_return_ok(self, mocked):
        get_risk_assessment_details ='{"assessment_date" : "2021-02-16", "review_date" : "2021-05-16", "expiry_date" : "2022-04-16"}'
        http_response = func.HttpResponse(body=get_risk_assessment_details,status_code=200)
        mocked.return_value.get_risk_assessment_info.return_value = http_response
        http_request = func.HttpRequest(
            method='GET',
            body='',
            url = '',
            params={'assetGuid': '3978559C2FDC45D9E04400306E4AD01A', 'examTypeId' : 1}
        )

        response = main(http_request)

        self.assertEqual(response.status_code, 200)
        self.assertEqual(
            response.get_body(),
            b'{"assessment_date" : "2021-02-16", "review_date" : "2021-05-16", "expiry_date" : "2022-04-16"}'
        )
    
    @patch('riskAssessment.RiskAssessment')
    def test_init_post_return_ok(self, mocked):
        save_risk_assessment_info = '{"asset_guid":"3978559c2d8145d9e04400306e4ad01a","exam_type_id":1,"assessment_date":"12/12/2020","review_date":"12/12/2020","expiry_date":"12/10/2021","risk_score":"low","mitigation_comment":"abcd","risk_user_key":"fdfdfdfdf","question_01":"q1","question_01_ans":"a1","question_01_cmt":"c1","question_02":"q2","question_02_ans":"a2","question_02_cmt":"c2","question_03":"q3","question_03_ans":"a3","question_03_cmt":"c3","question_04":"q4","question_04_ans":"a4","question_04_cmt":"c4"}'
        http_response = func.HttpResponse(body='',status_code=201)
        mocked.return_value.post_risk_assessment_Info.return_value = http_response
        http_request = func.HttpRequest(
            method='POST',
            body=save_risk_assessment_info.encode('utf8'),
            url = ''
        )

        response = main(http_request)

        self.assertEqual(response.status_code, 201)
        self.assertEqual(
            response.get_body(),
            b''
        )