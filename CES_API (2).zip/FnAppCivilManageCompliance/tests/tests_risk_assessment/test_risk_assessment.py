#test_defect_tracker_business_logic.py

import sys
import os
import unittest
from unittest.mock import patch
import azure.functions as func
from tests.load_environment_variables import EnvironmentVariable
EnvironmentVariable()
from riskAssessment.businesslogic.risk_assessment import RiskAssessment
import json

class RiskAssessmentBusinessLogic(unittest.TestCase):

    @patch('riskAssessment.businesslogic.risk_assessment.SqlOperation')
    def test_get_risk_assessment_bl_return_ok(self,mocked):
        get_risk_assessment_details = ['{"assessment_date" : "2021-02-16", "review_date" : "2021-05-16", "expiry_date" : "2022-04-16"}']
        http_request = func.HttpRequest(
            method='GET',
            body='',
            url = '',
            params={'assetGuid': '3978559C2FDC45D9E04400306E4AD01A', 'examTypeId' : 1}
        )
        mocked.return_value.fetch_one.return_value = get_risk_assessment_details
        response = RiskAssessment().get_risk_assessment_info(http_request)
        self.assertEqual(response.status_code, 200)

    @patch('riskAssessment.businesslogic.risk_assessment.SqlOperation')
    def test_get_risk_assessment_bl_return_bad_requset(self,mocked):
        get_risk_assessment_details = ['{"assessment_date" : "2021-02-16", "review_date" : "2021-05-16", "expiry_date" : "2022-04-16"}']
        http_request = func.HttpRequest(
            method='GET',
            body='',
            url = '',
            params={'assetGuid': '3978559C2FDC45D9E04400306E4AD01A'}
        )
        mocked.return_value.fetch_one.return_value = get_risk_assessment_details
        response = RiskAssessment().get_risk_assessment_info(http_request)
        self.assertEqual(response.status_code, 400)

    @patch('riskAssessment.businesslogic.risk_assessment.SqlOperation')
    def test_post_risk_assessment_bl_return_created(self,mocked):
        save_risk_assessment_details = '{"asset_guid":"3978559c2d8145d9e04400306e4ad01a","exam_type_id":1,"assessment_date":"12/12/2020","review_date":"12/12/2020","expiry_date":"12/10/2021","risk_score":"Low","mitigation_comment":"abcd","risk_user_key":"fdfdfdfdf","question_01":"q1","question_01_ans":"Y","question_01_cmt":"c1","question_02":"q2","question_02_ans":"Y","question_02_cmt":"c2","question_03":"q3","question_03_ans":"Y","question_03_cmt":"c3","question_04":"q4","question_04_ans":"Y","question_04_cmt":"c4"}'
        mocked.return_value.fetch_one.return_value = True, ''
        http_request = func.HttpRequest(
            method='POST',
            body=save_risk_assessment_details.encode('utf8'),
            url = ''
        )
        response = RiskAssessment().post_risk_assessment_Info(http_request)
        self.assertEqual(response.status_code, 201)

    @patch('riskAssessment.businesslogic.risk_assessment.SqlOperation')
    def test_post_risk_assessment_bl_invalid_request(self,mocked):
        save_risk_assessment_details = '{"asset":"3978559c2d8145d9e04400306e4ad01a","exam_type_id":1,"assessment_date":"12/12/2020","review_date":"12/12/2020","expiry_date":"12/10/2021","risk_score":"low","mitigation_comment":"abcd","risk_user_key":"fdfdfdfdf","question_01":"q1","question_01_ans":"a1","question_01_cmt":"c1","question_02":"q2","question_02_ans":"a2","question_02_cmt":"c2","question_03":"q3","question_03_ans":"a3","question_03_cmt":"c3","question_04":"q4","question_04_ans":"a4","question_04_cmt":"c4"}'
        mocked.return_value.fetch_one.return_value = True, ''
        http_request = func.HttpRequest(
            method='POST',
            body=save_risk_assessment_details.encode('utf8'),
            url = ''
        )
        response = RiskAssessment().post_risk_assessment_Info(http_request)
        self.assertEqual(response.status_code, 400)
    
    @patch('riskAssessment.businesslogic.risk_assessment.SqlOperation')
    def test_post_risk_assessment_bl_return_internal_server_error(self,mocked):
        save_risk_assessment_details = '{"asset_guid":"3978559c2d8145d9e04400306e4ad01a","exam_type_id":1,"assessment_date":"12/12/2020","review_date":"12/12/2020","expiry_date":"12/10/2021","risk_score":"low","mitigation_comment":"abcd","risk_user_key":"fdfdfdfdf","question_01":"q1","question_01_ans":"a1","question_01_cmt":"c1","question_02":"q2","question_02_ans":"a2","question_02_cmt":"c2","question_03":"q3","question_03_ans":"a3","question_03_cmt":"c3","question_04":"q4","question_04_ans":"a4","question_04_cmt":"c4"}'
        mocked.return_value.fetch_one.return_value = ''
        http_request = func.HttpRequest(
            method='POST',
            body=save_risk_assessment_details.encode('utf8'),
            url = ''
        )
        try:
            response = RiskAssessment().post_risk_assessment_Info(http_request)
        except:
            pass
            


        
