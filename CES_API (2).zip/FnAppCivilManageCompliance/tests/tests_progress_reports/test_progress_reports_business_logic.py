# test_progress_reports_business_logic.py

import sys
import os
import unittest
from unittest.mock import patch
from tests.load_environment_variables import EnvironmentVariable
EnvironmentVariable()
from progressReport.business_logic.progress_reports import ProgressReports

class ProgressReportsBusinessTest(unittest.TestCase):

    @patch('progressReport.business_logic.progress_reports.SqlOperation')
    def test_progressReport_return_ok(self, mocked):
        report_details_mock = ['{"section_1_report":null,"section_2_report":[{"kpi":"< 1 Month Passed Site Tolerance","period_1":0,"period_2":0,"period_3":0,"period_4":0,"period_5":0,"period_6":0,"period_7":0,"period_8":0,"period_9":0,"period_10":0,"period_11":0,"period_12":0,"period_13":0},{"kpi":"1 - 3 Months Passed Site Tolerance","period_1":0,"period_2":0,"period_3":0,"period_4":0,"period_5":0,"period_6":0,"period_7":0,"period_8":0,"period_9":0,"period_10":0,"period_11":0,"period_12":0,"period_13":0},{"kpi":"3 - 6 Months Passed Site Tolerance","period_1":0,"period_2":0,"period_3":0,"period_4":0,"period_5":0,"period_6":0,"period_7":0,"period_8":0,"period_9":0,"period_10":0,"period_11":0,"period_12":0,"period_13":0},{"kpi":"6 - 12 Months Passed Site Tolerance","period_1":0,"period_2":0,"period_3":0,"period_4":0,"period_5":0,"period_6":0,"period_7":0,"period_8":0,"period_9":0,"period_10":0,"period_11":0,"period_12":0,"period_13":0},{"kpi":"> 12 Months Passed Site Tolerance","period_1":0,"period_2":0,"period_3":0,"period_4":0,"period_5":0,"period_6":0,"period_7":0,"period_8":0,"period_9":0,"period_10":0,"period_11":0,"period_12":0,"period_13":0}],"section_3_report":null,"section_4_report":null,"section_5_report":null,"section_6_report":null,"section_7_report":null,"section_8_report":null,"section_9_report":null,"section_10_report":null,"section_11_report":null}']
        mocked.return_value.fetch_one.return_value = report_details_mock
        response, status_code = ProgressReports().view_progress_reports('{"period_id": 0,"exam_type_id": 2}')
        self.assertEqual(status_code, 200)
        
    @patch('progressReport.business_logic.progress_reports.SqlOperation')
    def test_progressReport_return_nocontent(self, mocked):
        mocked.return_value.fetch_one.return_value = None
        response, status_code = ProgressReports().view_progress_reports('{"period_id": 0,"exam_type_id": 2}')
        self.assertEqual(status_code, 204)
        self.assertEqual(response, '{}')

    @patch('progressReport.business_logic.progress_reports.SqlOperation')
    def test_progressReport_return_badrequest_invalidJson(self, mocked):
        mocked.return_value.fetch_one.return_value = ['{"section_1_report":[{"dim_value":"2017/2018","dtl_exams":4,"ve_exams":0,"uw_exams":0,"total_row_exams":4},{"dim_value":"2018/2019","dtl_exams":15,"ve_exams":1,"uw_exams":3,"total_row_exams":19},{"dim_value":"2019/2020","dtl_exams":55,"ve_exams":133,"uw_exams":3,"total_row_exams":191},{"dim_value":"2020/2021","dtl_exams":150,"ve_exams":1107,"uw_exams":75,"total_row_exams":1332},{"dim_value":"2021/2022","dtl_exams":0,"ve_exams":0,"uw_exams":13,"total_row_exams":13},{"dim_value":"Total","dtl_exams":224,"ve_exams":1241,"uw_exams":94,"total_row_exams":1559}],"section_2_report":[{"dim_value":"> 3 years","dtl_exams":0,"ve_exams":0,"uw_exams":0,"total_row_exams":0},{"dim_value":"0 - 6 months","dtl_exams":0,"ve_exams":0,"uw_exams":0,"total_row_exams":0},{"dim_value":"1 - 2 years","dtl_exams":0,"ve_exams":0,"uw_exams":0,"total_row_exams":0},{"dim_value":"2 - 3 years","dtl_exams":0,"ve_exams":0,"uw_exams":0,"total_row_exams":0},{"dim_value":"6 - 12 months","dtl_exams":0,"ve_exams":0,"uw_exams":0,"total_row_exams":0},{"dim_value":"Total","dtl_exams":0,"ve_exams":0,"uw_exams":0,"total_row_exams":0}],"section_3_report":[{"dim_value":"> 3 years","dtl_exams":0,"ve_exams":0,"uw_exams":0,"total_row_exams":0},{"dim_value":"0 - 6 months","dtl_exams":0,"ve_exams":0,"uw_exams":0,"total_row_exams":0},{"dim_value":"1 - 2 years","dtl_exams":0,"ve_exams":0,"uw_exams":0,"total_row_exams":0},{"dim_value":"2 - 3 years","dtl_exams":0,"ve_exams":0,"uw_exams":0,"total_row_exams":0},{"dim_value":"6 - 12 months","dtl_exams":0,"ve_exams":0,"uw_exams":0,"total_row_exams":0},{"dim_value":"Total","dtl_exams":0,"ve_exams":0,"uw_exams":0,"total_row_exams":0}],"Total_non_compliant":{"dim_value":"Total no. of non-compliant exams (ORR Reportable)","dtl_exams":224,"ve_exams":1241,"uw_exams":94,"total_row_exams":1559}}']
        response, status_code = ProgressReports().view_progress_reports('{"period_id": 0,"examtypeid": 2}')
        self.assertEqual(status_code, 400)

    @patch('progressReport.business_logic.progress_reports.SqlOperation')
    def test_progressReport_return_Internalservererror(self, mocked):
        mocked.side_effect = ConnectionError
        resonse,status_code = ProgressReports().view_progress_reports('{"period_id": 0,"exam_type_id": 2}')
        self.assertEqual(status_code , 500)
    
    