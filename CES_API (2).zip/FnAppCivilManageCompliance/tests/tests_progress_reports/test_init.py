# test_init.py

import sys
import os
import unittest
from unittest import mock
from unittest import IsolatedAsyncioTestCase
from unittest.mock import patch, Mock, MagicMock, create_autospec
import azure.functions as func
from tests.load_environment_variables import EnvironmentVariable
EnvironmentVariable()
from progressReport import main

class progressReportInitTest(unittest.TestCase):

    @patch('progressReport.ProgressReports')
    async def test_init_return_ok(self, mocked):
          report_details_mock = '{"section_1_report":null,"section_2_report":[{"kpi":"< 1 Month Passed Site Tolerance","period_1":0,"period_2":0,"period_3":0,"period_4":0,"period_5":0,"period_6":0,"period_7":0,"period_8":0,"period_9":0,"period_10":0,"period_11":0,"period_12":0,"period_13":0},{"kpi":"1 - 3 Months Passed Site Tolerance","period_1":0,"period_2":0,"period_3":0,"period_4":0,"period_5":0,"period_6":0,"period_7":0,"period_8":0,"period_9":0,"period_10":0,"period_11":0,"period_12":0,"period_13":0},{"kpi":"3 - 6 Months Passed Site Tolerance","period_1":0,"period_2":0,"period_3":0,"period_4":0,"period_5":0,"period_6":0,"period_7":0,"period_8":0,"period_9":0,"period_10":0,"period_11":0,"period_12":0,"period_13":0},{"kpi":"6 - 12 Months Passed Site Tolerance","period_1":0,"period_2":0,"period_3":0,"period_4":0,"period_5":0,"period_6":0,"period_7":0,"period_8":0,"period_9":0,"period_10":0,"period_11":0,"period_12":0,"period_13":0},{"kpi":"> 12 Months Passed Site Tolerance","period_1":0,"period_2":0,"period_3":0,"period_4":0,"period_5":0,"period_6":0,"period_7":0,"period_8":0,"period_9":0,"period_10":0,"period_11":0,"period_12":0,"period_13":0}],"section_3_report":null,"section_4_report":null,"section_5_report":null,"section_6_report":null,"section_7_report":null,"section_8_report":null,"section_9_report":null,"section_10_report":null,"section_11_report":null}'
          mocked.return_value.view_progress_reports.return_value = report_details_mock, 200
          req = func.HttpRequest(
          method='GET',
          body=None,
          url='/progressReport',
          headers={'X-Progress-Report-Filters':'{"period_id": 0,"exam_type_id": 2}'
          })

          resp = await main(req)
          self.assertEqual(resp.status_code, 200)
         
    
    @patch('progressReport.ProgressReports')
    async def test_init_return_badrequest(self, mocked):
          mocked.return_value.__str__.return_value = "Header X-Progress-Report-Filters is missing"
          req = func.HttpRequest(
          method='GET',
          body=None,
          url='/progressReport',
          headers={})

          resp = await main(req)
          self.assertEqual(resp.status_code, 400)