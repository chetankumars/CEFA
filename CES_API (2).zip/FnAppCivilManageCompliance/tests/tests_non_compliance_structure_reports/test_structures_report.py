# test_structure_report.py

import sys
import os
import unittest
from unittest.mock import patch
from tests.load_environment_variables import EnvironmentVariable
EnvironmentVariable()
from nonComplianceStructureReports.business_logic.structure_reports import StructureReports

class StructureReportsTest(unittest.TestCase):

    @patch('nonComplianceStructureReports.business_logic.structure_reports.SqlOperation')
    def test_non_compliance_reports_return_ok(self, mocked):
        report_details_mock = ['{"section_1_report":[{"dim_value":"2017/2018","dtl_exams":4,"ve_exams":0,"uw_exams":0,"total_row_exams":4},{"dim_value":"2018/2019","dtl_exams":15,"ve_exams":1,"uw_exams":3,"total_row_exams":19},{"dim_value":"2019/2020","dtl_exams":55,"ve_exams":133,"uw_exams":3,"total_row_exams":191},{"dim_value":"2020/2021","dtl_exams":150,"ve_exams":1107,"uw_exams":75,"total_row_exams":1332},{"dim_value":"2021/2022","dtl_exams":0,"ve_exams":0,"uw_exams":13,"total_row_exams":13},{"dim_value":"Total","dtl_exams":224,"ve_exams":1241,"uw_exams":94,"total_row_exams":1559}],"section_2_report":[{"dim_value":"> 3 years","dtl_exams":0,"ve_exams":0,"uw_exams":0,"total_row_exams":0},{"dim_value":"0 - 6 months","dtl_exams":0,"ve_exams":0,"uw_exams":0,"total_row_exams":0},{"dim_value":"1 - 2 years","dtl_exams":0,"ve_exams":0,"uw_exams":0,"total_row_exams":0},{"dim_value":"2 - 3 years","dtl_exams":0,"ve_exams":0,"uw_exams":0,"total_row_exams":0},{"dim_value":"6 - 12 months","dtl_exams":0,"ve_exams":0,"uw_exams":0,"total_row_exams":0},{"dim_value":"Total","dtl_exams":0,"ve_exams":0,"uw_exams":0,"total_row_exams":0}],"section_3_report":[{"dim_value":"> 3 years","dtl_exams":0,"ve_exams":0,"uw_exams":0,"total_row_exams":0},{"dim_value":"0 - 6 months","dtl_exams":0,"ve_exams":0,"uw_exams":0,"total_row_exams":0},{"dim_value":"1 - 2 years","dtl_exams":0,"ve_exams":0,"uw_exams":0,"total_row_exams":0},{"dim_value":"2 - 3 years","dtl_exams":0,"ve_exams":0,"uw_exams":0,"total_row_exams":0},{"dim_value":"6 - 12 months","dtl_exams":0,"ve_exams":0,"uw_exams":0,"total_row_exams":0},{"dim_value":"Total","dtl_exams":0,"ve_exams":0,"uw_exams":0,"total_row_exams":0}],"Total_non_compliant":{"dim_value":"Total no. of non-compliant exams (ORR Reportable)","dtl_exams":224,"ve_exams":1241,"uw_exams":94,"total_row_exams":1559}}']
        mocked.return_value.fetch_one.return_value = report_details_mock
        response, status_code = StructureReports().view_non_compliance_reports('{"route_id": 1,"period_id": 1 }')
        self.assertEqual(status_code, 200)
        
    @patch('nonComplianceStructureReports.business_logic.structure_reports.SqlOperation')
    def test_non_compliance_reports_return_nocontent(self, mocked):
        mocked.return_value.fetch_one.return_value = None
        response, status_code = StructureReports().view_non_compliance_reports('{"route_id": 1,"period_id": 1 }')
        self.assertEqual(status_code, 204)
        self.assertEqual(response, '{}')

    @patch('nonComplianceStructureReports.business_logic.structure_reports.SqlOperation')
    def test_non_compliance_reports_return_badrequest_invalidJson(self, mocked):
        mocked.return_value.fetch_one.return_value = ['{"section_1_report":[{"dim_value":"2017/2018","dtl_exams":4,"ve_exams":0,"uw_exams":0,"total_row_exams":4},{"dim_value":"2018/2019","dtl_exams":15,"ve_exams":1,"uw_exams":3,"total_row_exams":19},{"dim_value":"2019/2020","dtl_exams":55,"ve_exams":133,"uw_exams":3,"total_row_exams":191},{"dim_value":"2020/2021","dtl_exams":150,"ve_exams":1107,"uw_exams":75,"total_row_exams":1332},{"dim_value":"2021/2022","dtl_exams":0,"ve_exams":0,"uw_exams":13,"total_row_exams":13},{"dim_value":"Total","dtl_exams":224,"ve_exams":1241,"uw_exams":94,"total_row_exams":1559}],"section_2_report":[{"dim_value":"> 3 years","dtl_exams":0,"ve_exams":0,"uw_exams":0,"total_row_exams":0},{"dim_value":"0 - 6 months","dtl_exams":0,"ve_exams":0,"uw_exams":0,"total_row_exams":0},{"dim_value":"1 - 2 years","dtl_exams":0,"ve_exams":0,"uw_exams":0,"total_row_exams":0},{"dim_value":"2 - 3 years","dtl_exams":0,"ve_exams":0,"uw_exams":0,"total_row_exams":0},{"dim_value":"6 - 12 months","dtl_exams":0,"ve_exams":0,"uw_exams":0,"total_row_exams":0},{"dim_value":"Total","dtl_exams":0,"ve_exams":0,"uw_exams":0,"total_row_exams":0}],"section_3_report":[{"dim_value":"> 3 years","dtl_exams":0,"ve_exams":0,"uw_exams":0,"total_row_exams":0},{"dim_value":"0 - 6 months","dtl_exams":0,"ve_exams":0,"uw_exams":0,"total_row_exams":0},{"dim_value":"1 - 2 years","dtl_exams":0,"ve_exams":0,"uw_exams":0,"total_row_exams":0},{"dim_value":"2 - 3 years","dtl_exams":0,"ve_exams":0,"uw_exams":0,"total_row_exams":0},{"dim_value":"6 - 12 months","dtl_exams":0,"ve_exams":0,"uw_exams":0,"total_row_exams":0},{"dim_value":"Total","dtl_exams":0,"ve_exams":0,"uw_exams":0,"total_row_exams":0}],"Total_non_compliant":{"dim_value":"Total no. of non-compliant exams (ORR Reportable)","dtl_exams":224,"ve_exams":1241,"uw_exams":94,"total_row_exams":1559}']
        response, status_code = StructureReports().view_non_compliance_reports('{"route_id": 1,"periodid": 1 }')
        self.assertEqual(status_code, 400)

    @patch('nonComplianceStructureReports.business_logic.structure_reports.SqlOperation')
    def test_non_compliance_reports_return_Internalservererror(self, mocked):
        mocked.side_effect = ConnectionError
        resonse,status_code = StructureReports().view_non_compliance_reports('{"route_id": 1,"period_id": 1 }')
        self.assertEqual(status_code , 500)
    
    @patch('nonComplianceStructureReports.business_logic.structure_reports.SqlOperation')
    def test_non_compliance_assets_return_nocontent_invalid_response(self, mocked):
        mocked.return_value.fetch_one.return_value = ['{"section_1_report":[{"dim_value":"2017/2018""dtl_exams":4,"ve_exams":0,"uw_exams":0,"total_row_exams":4},{"dim_value":"2018/2019","dtl_exams":15,"ve_exams":1,"uw_exams":3,"total_row_exams":19},{"dim_value":"2019/2020","dtl_exams":55,"ve_exams":133,"uw_exams":3,"total_row_exams":191},{"dim_value":"2020/2021","dtl_exams":150,"ve_exams":1107,"uw_exams":75,"total_row_exams":1332},{"dim_value":"2021/2022","dtl_exams":0,"ve_exams":0,"uw_exams":13,"total_row_exams":13},{"dim_value":"Total","dtl_exams":224,"ve_exams":1241,"uw_exams":94,"total_row_exams":1559}],"section_2_report":[{"dim_value":"> 3 years","dtl_exams":0,"ve_exams":0,"uw_exams":0,"total_row_exams":0},{"dim_value":"0 - 6 months","dtl_exams":0,"ve_exams":0,"uw_exams":0,"total_row_exams":0},{"dim_value":"1 - 2 years","dtl_exams":0,"ve_exams":0,"uw_exams":0,"total_row_exams":0},{"dim_value":"2 - 3 years","dtl_exams":0,"ve_exams":0,"uw_exams":0,"total_row_exams":0},{"dim_value":"6 - 12 months","dtl_exams":0,"ve_exams":0,"uw_exams":0,"total_row_exams":0},{"dim_value":"Total","dtl_exams":0,"ve_exams":0,"uw_exams":0,"total_row_exams":0}],"section_3_report":[{"dim_value":"> 3 years","dtl_exams":0,"ve_exams":0,"uw_exams":0,"total_row_exams":0},{"dim_value":"0 - 6 months","dtl_exams":0,"ve_exams":0,"uw_exams":0,"total_row_exams":0},{"dim_value":"1 - 2 years","dtl_exams":0,"ve_exams":0,"uw_exams":0,"total_row_exams":0},{"dim_value":"2 - 3 years","dtl_exams":0,"ve_exams":0,"uw_exams":0,"total_row_exams":0},{"dim_value":"6 - 12 months","dtl_exams":0,"ve_exams":0,"uw_exams":0,"total_row_exams":0},{"dim_value":"Total","dtl_exams":0,"ve_exams":0,"uw_exams":0,"total_row_exams":0}],"Total_non_compliant":{"dim_value":"Total no. of non-compliant exams (ORR Reportable)""dtl_exams":224,"ve_exams":1241,"uw_exams":94,"total_row_exams":1559}']
        response, status_code = StructureReports().view_non_compliance_reports('{"route_id": 1,"period_id": 1 }')
        self.assertEqual(status_code, 204)
        self.assertEqual(response, '{}')