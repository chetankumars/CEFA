# test_init.py

import sys
import os
import unittest
from unittest.mock import patch
import azure.functions as func
from tests.load_environment_variables import EnvironmentVariable
EnvironmentVariable()
from nonComplianceStructureReports import main

class nonComplianceStructureReportsInitTest(unittest.TestCase):

    @patch('nonComplianceStructureReports.StructureReports')
    def test_init_return_ok(self, mocked):
          report_details_mock = '{"section_1_report":[{"dim_value":"2017\/2018","dtl_exams":4,"ve_exams":0,"uw_exams":0,"total_row_exams":4},{"dim_value":"2018\/2019","dtl_exams":15,"ve_exams":1,"uw_exams":3,"total_row_exams":19},{"dim_value":"2019\/2020","dtl_exams":55,"ve_exams":133,"uw_exams":3,"total_row_exams":191},{"dim_value":"2020\/2021","dtl_exams":150,"ve_exams":1107,"uw_exams":75,"total_row_exams":1332},{"dim_value":"2021\/2022","dtl_exams":0,"ve_exams":0,"uw_exams":13,"total_row_exams":13},{"dim_value":"Total","dtl_exams":224,"ve_exams":1241,"uw_exams":94,"total_row_exams":1559}],"section_2_report":[{"dim_value":"> 3 years","dtl_exams":0,"ve_exams":0,"uw_exams":0,"total_row_exams":0},{"dim_value":"0 - 6 months","dtl_exams":0,"ve_exams":0,"uw_exams":0,"total_row_exams":0},{"dim_value":"1 - 2 years","dtl_exams":0,"ve_exams":0,"uw_exams":0,"total_row_exams":0},{"dim_value":"2 - 3 years","dtl_exams":0,"ve_exams":0,"uw_exams":0,"total_row_exams":0},{"dim_value":"6 - 12 months","dtl_exams":0,"ve_exams":0,"uw_exams":0,"total_row_exams":0},{"dim_value":"Total","dtl_exams":0,"ve_exams":0,"uw_exams":0,"total_row_exams":0}],"section_3_report":[{"dim_value":"> 3 years","dtl_exams":0,"ve_exams":0,"uw_exams":0,"total_row_exams":0},{"dim_value":"0 - 6 months","dtl_exams":0,"ve_exams":0,"uw_exams":0,"total_row_exams":0},{"dim_value":"1 - 2 years","dtl_exams":0,"ve_exams":0,"uw_exams":0,"total_row_exams":0},{"dim_value":"2 - 3 years","dtl_exams":0,"ve_exams":0,"uw_exams":0,"total_row_exams":0},{"dim_value":"6 - 12 months","dtl_exams":0,"ve_exams":0,"uw_exams":0,"total_row_exams":0},{"dim_value":"Total","dtl_exams":0,"ve_exams":0,"uw_exams":0,"total_row_exams":0}],"Total_non_compliant":{"dim_value":"Total no. of non-compliant exams (ORR Reportable)","dtl_exams":224,"ve_exams":1241,"uw_exams":94,"total_row_exams":1559}'
          mocked.return_value.view_non_compliance_reports.return_value = report_details_mock, 200
          req = func.HttpRequest(
          method='GET',
          body=None,
          url='/nonComplianceStructureReports',
          headers={'X-Report-Compliance-Filters':'{"route_id": 1,"period_id": 1 }'
          })

          resp = main(req)
          self.assertEqual(resp.status_code, 200)
          self.assertEqual(resp.get_body(),
          b'{"section_1_report":[{"dim_value":"2017\/2018","dtl_exams":4,"ve_exams":0,"uw_exams":0,"total_row_exams":4},{"dim_value":"2018\/2019","dtl_exams":15,"ve_exams":1,"uw_exams":3,"total_row_exams":19},{"dim_value":"2019\/2020","dtl_exams":55,"ve_exams":133,"uw_exams":3,"total_row_exams":191},{"dim_value":"2020\/2021","dtl_exams":150,"ve_exams":1107,"uw_exams":75,"total_row_exams":1332},{"dim_value":"2021\/2022","dtl_exams":0,"ve_exams":0,"uw_exams":13,"total_row_exams":13},{"dim_value":"Total","dtl_exams":224,"ve_exams":1241,"uw_exams":94,"total_row_exams":1559}],"section_2_report":[{"dim_value":"> 3 years","dtl_exams":0,"ve_exams":0,"uw_exams":0,"total_row_exams":0},{"dim_value":"0 - 6 months","dtl_exams":0,"ve_exams":0,"uw_exams":0,"total_row_exams":0},{"dim_value":"1 - 2 years","dtl_exams":0,"ve_exams":0,"uw_exams":0,"total_row_exams":0},{"dim_value":"2 - 3 years","dtl_exams":0,"ve_exams":0,"uw_exams":0,"total_row_exams":0},{"dim_value":"6 - 12 months","dtl_exams":0,"ve_exams":0,"uw_exams":0,"total_row_exams":0},{"dim_value":"Total","dtl_exams":0,"ve_exams":0,"uw_exams":0,"total_row_exams":0}],"section_3_report":[{"dim_value":"> 3 years","dtl_exams":0,"ve_exams":0,"uw_exams":0,"total_row_exams":0},{"dim_value":"0 - 6 months","dtl_exams":0,"ve_exams":0,"uw_exams":0,"total_row_exams":0},{"dim_value":"1 - 2 years","dtl_exams":0,"ve_exams":0,"uw_exams":0,"total_row_exams":0},{"dim_value":"2 - 3 years","dtl_exams":0,"ve_exams":0,"uw_exams":0,"total_row_exams":0},{"dim_value":"6 - 12 months","dtl_exams":0,"ve_exams":0,"uw_exams":0,"total_row_exams":0},{"dim_value":"Total","dtl_exams":0,"ve_exams":0,"uw_exams":0,"total_row_exams":0}],"Total_non_compliant":{"dim_value":"Total no. of non-compliant exams (ORR Reportable)","dtl_exams":224,"ve_exams":1241,"uw_exams":94,"total_row_exams":1559}'
          )
    
    @patch('nonComplianceStructureReports.ErrorResponse')
    def test_init_return_badrequest(self, mocked):
          mocked.return_value.__str__.return_value = "Header X-Report-Compliance-Filters is missing"
          req = func.HttpRequest(
          method='GET',
          body=None,
          url='/nonComplianceStructureReports',
          headers={})

          resp = main(req)
          self.assertEqual(resp.status_code, 400)