# test_search_non_complaint_assets_business_logic.py

import sys
import os
import unittest
from unittest.mock import patch
from tests.load_environment_variables import EnvironmentVariable
EnvironmentVariable()
from searchNonCompliantAsset.business_logic.non_compliant_assets import NonCompliantAssets

class NonComplianceAssetsTest(unittest.TestCase):

    @patch('searchNonCompliantAsset.business_logic.non_compliant_assets.SqlOperation')
    def test_non_compliance_assets_return_ok(self, mocked):
        asset_details_mock = ['{"searchdatacount":{"currentpage":1,"totalcount":0,"totalpages":0},"searchresult":[]}']
        mocked.return_value.fetch_one.return_value = asset_details_mock
        response, status_code = NonCompliantAssets().view_non_compliance_assets('{"region_name":"abc"}')
        self.assertEqual(status_code, 200)
        
    @patch('searchNonCompliantAsset.business_logic.non_compliant_assets.SqlOperation')
    def test_non_compliance_assets_return_nocontent(self, mocked):
        mocked.return_value.fetch_one.return_value = None
        response, status_code = NonCompliantAssets().view_non_compliance_assets('{"region_name":"abc"}')
        self.assertEqual(status_code, 204)
        self.assertEqual(response, '{}')

    @patch('searchNonCompliantAsset.business_logic.non_compliant_assets.SqlOperation')
    def test_non_compliance_assets_return_badrequest_invalidJson(self, mocked):
        mocked.return_value.fetch_one.return_value = ['{"searchdatacount":{"currentpage":1,"totalcount":0,"totalpages":0},"searchresult":[]}']
        response, status_code = NonCompliantAssets().view_non_compliance_assets('{"region_name":"abc",}')
        self.assertEqual(status_code, 400)

    @patch('searchNonCompliantAsset.business_logic.non_compliant_assets.SqlOperation.fetch_one')
    def test_non_compliance_assets_return_Internalservererror(self, mocked):
        mocked.side_effect = ConnectionError
        resonse,status_code = NonCompliantAssets().view_non_compliance_assets('{"region_name":"abc"}')
        self.assertEqual(status_code , 500)
    
    @patch('searchNonCompliantAsset.business_logic.non_compliant_assets.SqlOperation')
    def test_non_compliance_assets_return_nocontent_invalid_response(self, mocked):
        mocked.return_value.fetch_one.return_value = ['{"searchdatacount:{"currentpage":1,"totalcount":0,"totalpages":0}"searchresult":[]}']
        response, status_code = NonCompliantAssets().view_non_compliance_assets('{"region_name":"abc"}')
        self.assertEqual(status_code, 204)
        self.assertEqual(response, '{}')
    
    @patch('searchNonCompliantAsset.business_logic.non_compliant_assets.SqlOperation')
    def test_non_compliance_assets_return_badrequest_when_sortorderpassedwrongly(self, mocked):
        mocked.return_value.fetch_one.return_value = ['{"searchdatacount":{"currentpage":1,"totalcount":0,"totalpages":0}"searchresult":[]}']
        response, status_code = NonCompliantAssets().view_non_compliance_assets('{"region_name":"abc","sortorder":"noorder"}')
        self.assertEqual(status_code, 400)

    @patch('searchNonCompliantAsset.business_logic.non_compliant_assets.SqlOperation')
    def test_non_compliance_assets_return_badrequest_when_sortcolumnpassedwrongly(self, mocked):
        mocked.return_value.fetch_one.return_value = ['{"searchdatacount":{"currentpage":1,"totalcount":0,"totalpages":0}"searchresult":[]}']
        response, status_code = NonCompliantAssets().view_non_compliance_assets('{"region_name":"abc","sortcolumn":"noorder"}')
        self.assertEqual(status_code, 400)

    @patch('searchNonCompliantAsset.business_logic.non_compliant_assets.SqlOperation')
    def test_non_compliance_assets_return_badrequest_when_regionnameisnotpassed(self, mocked):
        mocked.return_value.fetch_one.return_value = ['{"searchdatacount":{"currentpage":1,"totalcount":0,"totalpages":0}"searchresult":[]}']
        response, status_code = NonCompliantAssets().view_non_compliance_assets('{"sortorder":"asc"}')
        self.assertEqual(status_code, 400)

    @patch('searchNonCompliantAsset.business_logic.non_compliant_assets.SqlOperation')
    def test_non_compliance_assets_return_badrequest_when_referencedateformatiswrong(self, mocked):
        mocked.return_value.fetch_one.return_value = ['{"searchdatacount":{"currentpage":1,"totalcount":0,"totalpages":0}"searchresult":[]}']
        response, status_code = NonCompliantAssets().view_non_compliance_assets('{"region_name":"abc","reference_date":"2001/07/11"}')
        self.assertEqual(status_code, 400)

    @patch('searchNonCompliantAsset.business_logic.non_compliant_assets.SqlOperation')
    def test_non_compliance_assets_return_badrequest_when_isexporttodocispassedwrongly(self, mocked):
        mocked.return_value.fetch_one.return_value = ['{"searchdatacount":{"currentpage":1,"totalcount":0,"totalpages":0}"searchresult":[]}']
        response, status_code = NonCompliantAssets().view_non_compliance_assets('{"region_name":"abc","isexporttodoc":"S"}')
        self.assertEqual(status_code, 400)