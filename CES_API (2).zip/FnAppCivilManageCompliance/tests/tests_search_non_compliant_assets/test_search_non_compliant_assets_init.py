# test_search_non_compliant_assets_init.py

import sys
import os
import unittest
from unittest.mock import patch
import azure.functions as func
from tests.load_environment_variables import EnvironmentVariable
EnvironmentVariable()
from searchNonCompliantAsset import main

class viewNonComplianceAssetsInitTest(unittest.TestCase):

    @patch('searchNonCompliantAsset.NonCompliantAssets')
    def test_init_return_ok(self, mocked):
          asset_details_mock = '{"searchdatacount":{"currentpage":1,"totalcount":0,"totalpages":0},"searchresult":[]}'
          mocked.return_value.view_non_compliance_assets.return_value = asset_details_mock, 200
          req = func.HttpRequest(
          method='GET',
          body=None,
          url='/searchNonCompliantAsset',
          headers={'X-Asset-Compliance-Filters':'{"region_name":"abc"}'})

          resp = main(req)
          self.assertEqual(resp.status_code, 200)
          self.assertEqual(resp.get_body(),
          b'{"searchdatacount":{"currentpage":1,"totalcount":0,"totalpages":0},"searchresult":[]}'
          )
    
    @patch('searchNonCompliantAsset.ErrorResponse')
    def test_init_return_badrequest(self, mocked):
          mocked.return_value.__str__.return_value = "Header X-Asset-Compliance-Filters is missing"
          req = func.HttpRequest(
          method='GET',
          body=None,
          url='/searchNonCompliantAsset',
          headers={})

          resp = main(req)
          self.assertEqual(resp.status_code, 400)