# search progress/performance rports

## Description
Services to get progress/performance reports details from CES db.

    APIM URL: https://apim-uks-dev-ces-0001.azure-api.net/II/CESAPI/compliances/progressreport
    Method Type: GET

    FUNCTION URL: https://fnp-uks-dev-ces-funcedst0007.azurewebsites.net/api/progressReports
    Method Type: GET

## Request headers for progressReports
    
    Request headers:
        Header Name : X-Progress-Report-Filters
        Sample Value : {"period_id":0,"exam_type_id":2}