# reports_validate_request.py

import sys
from ..schema import ProgressReportSchema

class ValidateRequest:

    "Progress reports validation and mapping class to perform validation and mapping on input request"
    
    def __init__(self):
        self.progress_reports_schema = ProgressReportSchema()

    def is_valid_payload(self, payload):
        """
        Method to validate the request against schema

        Args:
            json_req(json)

        Returns:
            bool:represents validation is successful or not | dict:validated json response 
        """
        try:
            return_object =  self.progress_reports_schema.loads(payload)
            res = self.progress_reports_schema.dump(return_object)
            return True, res
        except:
            return False, sys.exc_info()