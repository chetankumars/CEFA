# __init__.py

import azure.functions as func
from common import AppStatus, SharedConstants, ErrorResponse
from .business_logic.progress_reports import ProgressReports
from .constants.progress_report_constants import ProgressReportConstants


def main(req: func.HttpRequest) -> func.HttpResponse:
    """ 
    Function calls  ProgressReports class to get progress report details.

    Args:
        req (func.HttpRequest)

    Returns:
        func.HttpResponse:  progress report details json from CES DB
    """
    if ProgressReportConstants.report_filter in req.headers and req.headers[ProgressReportConstants.report_filter]:
        response, statusCode = ProgressReports().view_progress_reports(req.headers[ProgressReportConstants.report_filter])
    else:
        statusCode = AppStatus.bad_Request.value[0]
        response = ErrorResponse(SharedConstants.request_val_failure, SharedConstants.request_header_failure, statusCode, ProgressReportConstants.param_failure, ProgressReports().__class__.__name__).__str__()
    return func.HttpResponse(body = response,status_code = statusCode, mimetype= SharedConstants.json_mime_type)

if __name__ == SharedConstants.main:
    main(func.HttpRequest)