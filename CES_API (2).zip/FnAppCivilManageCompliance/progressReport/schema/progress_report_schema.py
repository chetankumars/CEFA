# progress_report_schema.py

from marshmallow import fields, Schema, validate, ValidationError

class ProgressReportSchema(Schema):
    period_id = fields.Int(required = True)
    exam_type_id = fields.Int(required = True )