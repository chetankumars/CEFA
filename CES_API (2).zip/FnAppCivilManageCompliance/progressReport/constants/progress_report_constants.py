# progress_report_constants.py

class ProgressReportConstants:
    """ Constants related to progressReports"""
    sql_query = """
                EXEC [CES].[sp_Get_Progress_Report]
                @Input_JSON = ?
                """
    get_progress_reports = "progressReports"
    get_progress_reports_val = "func:progressReports"
    param_failure = "Header X-Progress-Report-Filters is missing"
    report_filter = 'X-Progress-Report-Filters'
    input_json = "Input_JSON"