#customlog.py

__all__ = ['CustomLog']
class CustomLog:

    """
    Custom Log class to define common dimensions

    """
    start_time = "start_time"
    sprequest_time = "sprequest_time"
    sprequestend_time = "sprequestend_time"
    user_preferences =  "user_preferences"
    user_pref_val = "func:fnUserPreference"
    end_time = "end_time"
    error_messsage = "error_messsage"
    defect_details = "defect_details"
    defect_detail_val = "func:fnDefectDetails"
    defect_tracker_asset = "defect_tracker_assets"
    defect_tracker_asset_val = "func:fnDefectTrackerAssets"
    search_lookup ="searchLookup"
    search_lookup_val ="func:getSearchLookup"
    get_assets = "getAssets"
    get_assets_val = "func:fnGetAssets"
    get_user_info = "get_user_info"
    get_user_info_supplier_val = "func:fnGetUserInfo - SupplierDetails"
    get_user_info_geo_val = "func:fnGetUserInfo - UserGeoDetails"
    get_user_info_role_val = "func:fnGetUserInfo - UserRoleDetails"
    schema_errors = "schema_errors"
    sp_req_param = "sp_req_param"
    status = "status"
