#sharedlog.py

__all__ = ['SharedConstants']
class SharedConstants:

    """
    Common contants across packages and Web APIs

    """
    sql_connection_string = "SQL_CONNECTION_STRING"
    sql_copt_ss_access_token =1256
    request_val_failure = "Invalid Request"
    request_header_failure = "Header/Param validation failure"
    get_search_lookup = "getSearchLookup"
    search_lookup_response_schema = "searchlookup_response.json"
    get_assets = "getAssets"
    assets_req_schema = "assets_request.json"
    schema = "schema"
    search_lookup_bad_request_msg = "userId is missing"
    bad_json_request_msg = "Invalid input, expected value"
    assets_bad_request_msg = "Header X-Asset-Filters is missing"
    json_mime_type = "application/json"
    trace_enabled = "Trace_Enabled"
    asset_filter = 'X-Asset-Filters'
    response = "sp response"
    userId = "userId"
    main = '__main__'
    json_mime_type = "application/json"
    trace_enabled = "Trace_Enabled"
    colon = ":"
    method_type_get = "GET"
    asset_guid = "Asset_GUID"
    exam_type_id = "Exam_Type_ID"
    asset_guid_query_param = "assetGuid"
    exam_type_id_query_param = "examTypeId"
    input_json = "Input_Json"
    comma = ","
    save_success_msg = "Data submitted successfully"
    # _sql_copt_ss_access_token_value = 1256
   
