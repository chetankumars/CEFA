# non_compliant_assets_schema.py

from marshmallow import fields, Schema, validate

class NonCompliantAssetsSchema(Schema):
    region_name = fields.Str(required=True)
    route_id = fields.Int(required=False,default=0)
    area_id = fields.Int(required=False,default=0)
    elr_id = fields.List(fields.Int(required=False),default=[0])
    start_mileage_from = fields.Decimal(required=False,default=-1)
    start_mileage_to = fields.Decimal(required=False,default=99999)
    railway_id = fields.Str(required=False,allow_none=True,default=None)
    ast_grp_id = fields.Int(required=False,default=0)
    ast_typ_id = fields.List(fields.Int(required=False),default=[0])
    reference_date = fields.Date(required=False,allow_none=True,default=None,format='%d/%m/%Y')
    owning_party = fields.Str(required=False, allow_none=True,default=None)
    dtl_risk_assessment_id = fields.List(fields.Int(required=False),default=[0])
    ve_risk_assessment_id = fields.List(fields.Int(required=False),default=[0])
    uw_risk_assessment_id = fields.List(fields.Int(required=False),default=[0])
    dtl_compliance_id = fields.List(fields.Int(required=False),default=[0])
    ve_compliance_id = fields.List(fields.Int(required=False),default=[0])
    uw_compliance_id = fields.List(fields.Int(required=False),default=[0])
    isexporttodoc = fields.Str(required=False,validate=validate.OneOf(['Y', 'N']),default='N')
    sortcolumn = fields.Str(required=False,default='StartMileage',validate=validate.OneOf(['StartMileage','AssetGUID','Region', 'ELR','Route','RailwayID', 'AssetDescription','AssetGroup','AssetType','OperationalStat','OwningParty','Material','DtlCompliance','DtlRiskStatus','VECompliance','VERiskStatus','UWCompliance','UWRiskStatus','DtlComplianceDate','DtlPlannedDate','DtlActualExamDate','DtlSupplier','VEComplianceDate','VEPlannedDate','VEActualExamDate','VESupplier','UWComplianceDate','UWPlannedDate','UWActualExamDate','UWSupplier']))
    sortorder = fields.Str(required=False,validate=validate.OneOf(['asc', 'desc']),default='asc')
    pageno = fields.Int(required=False,default=1)
    rowsperpage = fields.Int(required=False,default=25)

    