# search non compliant asset details

## Description
Services to get non compliant asset details from CES db.

    APIM URL: https://apim-uks-dev-ces-0001.azure-api.net/II/CESAPI/compliances/search
    Method Type: GET

    FUNCTION URL: https://fnp-uks-dev-ces-funcedst0007.azurewebsites.net/api/searchNonCompliantAsset
    Method Type: GET

## Request headers for searchNonCompliantAssets
    
    Request headers:
        Header Name : X-Asset-Compliance-Filters
        Sample Value : {"region_name":"Southern","route_id":0,"area_id":0,"elr_id":[0],"start_mileage_from":-1,"start_mileage_to":99999,"railway_id":null,"ast_grp_id":0,"ast_typ_id":[0],"reference_date":null,"owning_party": "Network Rail (CE-Struct)","dtl_risk_assessment_id":[0],"ve_risk_assessment_id":[0],"uw_risk_assessment_id":[0],"dtl_compliance_id":[0],"ve_compliance_id":[0],"uw_compliance_id":[1],"isexporttodoc":"N","sortcolumn":"StartMileage","sortorder":"asc","pageno":1,"rowsperpage":25}