# __init__.py

import sys
import azure.functions as func
import traceback
from .constants.non_compliant_assets_constants import NonCompliantAssetsConstants
from .business_logic.non_compliant_assets import NonCompliantAssets
from common import AppStatus, SharedConstants, ErrorResponse


def main(req: func.HttpRequest) -> func.HttpResponse:
    """ 
    Function calls  NonCompliantAssets class to get non compliance asset details.

    Args:
        req (func.HttpRequest)

    Returns:
        func.HttpResponse:  non compliance asset details json from CES DB
    """
    if NonCompliantAssetsConstants.asset_filter in req.headers and req.headers[NonCompliantAssetsConstants.asset_filter]:
        response, statusCode = NonCompliantAssets().view_non_compliance_assets(req.headers[NonCompliantAssetsConstants.asset_filter])
    else:
        statusCode = AppStatus.bad_Request.value[0]
        response = ErrorResponse(SharedConstants.request_val_failure, SharedConstants.request_header_failure, statusCode, NonCompliantAssetsConstants.param_failure, NonCompliantAssets().__class__.__name__).__str__()
    return func.HttpResponse(body = response,status_code = statusCode, mimetype= SharedConstants.json_mime_type)

if __name__ == SharedConstants.main:
    main(func.HttpRequest)