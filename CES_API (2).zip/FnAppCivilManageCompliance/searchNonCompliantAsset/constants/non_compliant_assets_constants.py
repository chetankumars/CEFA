# non_compliant_assets_constants.py

class NonCompliantAssetsConstants:
    """ Constants related to project"""
    sql_query = """
                EXEC [CES].[sp_Get_ComplianceAssetSearch_SearchResult]
                @Input_JSON = ?
                """
    get_non_complaince_assets = "searchNonCompliantAsset"
    get_non_complaince_assets_val = "func:searchNonCompliantAsset"
    param_failure = "Header X-Asset-Compliance-Filters is missing"
    asset_filter = 'X-Asset-Compliance-Filters'
    input_json = "Input_JSON"