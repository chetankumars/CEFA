# __init__.py

from .non_compliant_assets_constants import NonCompliantAssetsConstants