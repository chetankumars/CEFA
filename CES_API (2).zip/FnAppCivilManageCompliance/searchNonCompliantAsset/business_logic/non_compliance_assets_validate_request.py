# non_compliance_assets_validate_request.py

import sys
import traceback
from ..schema import NonCompliantAssetsSchema

class ValidateRequest:
    "Non Compliance Assets validation and mapping class to perform validation and mapping on input request"
    def __init__(self):
        self.non_compliance_asset_schema = NonCompliantAssetsSchema()

    def is_valid_payload(self, payload):
        """
        Method to validate the request against schema

        Args:
            json_req(json)

        Returns:
            bool:represents validation is successful or not | dict:validated json response 
        """
        try:
            return_object =  self.non_compliance_asset_schema.loads(payload)
            res = self.non_compliance_asset_schema.dump(return_object)
            return True, res
        except:
            return False, sys.exc_info()