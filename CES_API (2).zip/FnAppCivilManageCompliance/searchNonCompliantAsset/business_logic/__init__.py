# __init__.py

from .non_compliant_assets import *