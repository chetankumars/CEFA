# risk_assessment_constants.py

class RiskAssessmentConstants:

    """ Constants related to RiskAssessment Historic Records """
    
    exam_type_id = "examTypeId"
    sql_query = """
                EXEC [CES].sp_Get_RiskAssessment_History
                @Exam_Type_Id = ?, @ASSET_GUID = ?
                """
    risk_assessment = "riskAssessmentHistoricRecords"
    risk_assessment_val = "func:riskAssessmentHistoricRecords"
    param_failure = "examTypeId or assetGuid query parameter is missing."