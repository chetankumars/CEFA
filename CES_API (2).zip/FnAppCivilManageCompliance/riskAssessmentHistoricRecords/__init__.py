# __init__.py

import sys
import azure.functions as func
import traceback
from common import SharedConstants, ErrorResponse, AppStatus
from .business_logic.risk_assessment_historic_records import RiskAssessmentHistoricRecords
from .constants.risk_assessment_constants import RiskAssessmentConstants


def main(req: func.HttpRequest) -> func.HttpResponse:
    """ 
    Function calls RiskAssessmentHistoricRecords class to get historic records of risk assessment.

    Args:
        req (func.HttpRequest)

    Returns:
        func.HttpResponse: historic records of risk assessment details json from CES DB
    """

    try:
        exam_type_id = req.params.get(SharedConstants.exam_type_id_query_param)
        asset_guid =req.params.get(SharedConstants.asset_guid_query_param)
        if exam_type_id is not None and asset_guid is not None:
            message, statuscode = RiskAssessmentHistoricRecords().get_risk_assessment(exam_type_id, asset_guid)
        else:
            message = ErrorResponse(SharedConstants.request_val_failure, SharedConstants.request_header_failure, AppStatus.bad_Request.value[0], RiskAssessmentConstants.param_failure, RiskAssessmentHistoricRecords().__class__.__name__).__str__()
            statuscode = AppStatus.bad_Request.value[0]
    except:
        message = ErrorResponse(str(sys.exc_info()[0]), RiskAssessmentHistoricRecords().__class__.__name__, AppStatus.internal_server_error.value[0], str(traceback.format_exc()),RiskAssessmentHistoricRecords().__class__.__name__).__str__()
        statuscode = AppStatus.internal_server_error.value[0]
    finally:
        return func.HttpResponse(body=message, status_code= statuscode, mimetype= SharedConstants.json_mime_type)

if __name__ == SharedConstants.main:
    main(func.HttpRequest)