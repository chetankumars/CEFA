# risk assessment historic records

## Description
Services to get risk assessment historic record details from CES db.

    APIM URL: https://apim-uks-dev-ces-0001.azure-api.net/II/CESAPI/compliances/actions[?examTypeId][&assetGuid]
    Method Type: GET

    FUNCTION URL: https://fnp-uks-dev-ces-funcedst0007.azurewebsites.net/api/riskAssessmentHistoricRecords
    Method Type: GET

## Request params for risk assessment historic records
    
    Request params:(APIM URL)
        assetGuid = 3978559C2D9F45D9E04400306E4AD01A
        examTypeId = 1
        
    Request params: (FUNCTION URL)
        assetGuid = 3978559C2D9F45D9E04400306E4AD01A
        examTypeId = 1