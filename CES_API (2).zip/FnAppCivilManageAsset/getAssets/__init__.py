#__init__.py

import azure.functions as func
from getAssets.businesslogic.get_assets import Assets 
from common import AppStatus,SharedConstants,ErrorResponse
from .constants.get_assets import GetAssetsConstants

def main(req: func.HttpRequest) -> func.HttpResponse:
    """[summary]

    Args:
        req (func.HttpRequest): calling Assets class to get the assets response

    Returns:
        func.HttpResponse: assets json from CES DB
    """
    if GetAssetsConstants.asset_filter in req.headers and req.headers[GetAssetsConstants.asset_filter]:
       asset_filter = req.headers[GetAssetsConstants.asset_filter]
       response = Assets(asset_filter).get_assets()
    else:
       error_response = ErrorResponse(SharedConstants.request_val_failure,SharedConstants.request_header_failure,
                                              AppStatus.bad_Request.value[0], GetAssetsConstants.assets_bad_request_msg,
                                              Assets.__name__).__str__()
       response = func.HttpResponse(body= error_response, status_code= AppStatus.bad_Request.value[0], mimetype= SharedConstants.json_mime_type)  

    return response

if __name__ == SharedConstants.main:
    main(func.HttpRequest)
