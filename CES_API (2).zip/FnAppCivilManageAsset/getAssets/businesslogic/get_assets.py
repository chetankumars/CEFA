#get_assets.py

import sys
import os
import logging
import azure.functions as func
sys.path.insert(0, os.getcwd())
from common import SqlOperation,Logger,JsonHelper,ValidationHelper,CustomLog,SharedConstants,AppStatus,ErrorResponse
from datetime import datetime, timezone
from getAssets.model.assets_filter_req import AssetFilterRequest
from getAssets.constants.get_assets import GetAssetsConstants
import traceback
import json

istraceenabled = os.environ[SharedConstants.trace_enabled]

class Assets:
  
    """ Assets class to get all assets json response """ 
    def __init__(self, asset_filter):
        self.sql_query = """
                           Exec [CES].[sp_Get_AssetSearch_SearchResult]
                           @Input_JSON = ?
                           """
        self.data_mapper = {
                            'region_name':'region_name',
                            'route_id':'route_id',
                            'area_id':'area_id',
                            'elr_id':'elr_id',
                            'start_mileage_from':'start_mileage_from',
                            'start_mileage_to':'start_mileage_to',
                            'railway_id':'railway_id',
                            'ast_grp_id':'ast_grp_id',
                            'ast_typ_id':'ast_typ_id',
                            'opstat_id':'opstat_id',
                            'ownparty_name':'ownparty_name',
                            'asset_desc':'asset_desc',
                            'mattyp_id':'mattyp_id',
                            'hceflg_name':'hceflg_name',
                            'cmi_score_from':'cmi_score_from',
                            'cmi_score_to':'cmi_score_to',
                            'strccarries_name':'strccarries_name',
                            'strcover_name':'strcover_name',
                            'outsideparty_name':'outsideparty_name',
                            'is_export_to_doc':'isexporttodoc',
                            'sort_column':'sortcolumn',
                            'sort_order':'sortorder',
                            'page_no':'pageno',
                            'rows_per_page': 'rowsperpage'
                           }
        self.response = str({})
        self.status_code = AppStatus.ok.value[0]
        self.properties = {CustomLog.get_assets:CustomLog.get_assets_val}
        self.properties[CustomLog.start_time] = datetime.now(timezone.utc).isoformat()
        Logger.__init__(self, name = self.__class__.__name__, start_time = datetime.now(timezone.utc))
        self.json_helper = JsonHelper()
        self.asset_default =  AssetFilterRequest()
        self.asset_filter = asset_filter
        self.properties[CustomLog.status] = True

    def validate_json(self, req):
        """
        Function to validate the response recieved from database
       
        Args:
            req
        """
        with open(os.path.join(os.getcwd(),GetAssetsConstants.get_assets,SharedConstants.schema,GetAssetsConstants.assets_req_schema),SharedConstants.file_read_mode) as _json_file:
            schema = self.json_helper.parse_json(_json_file.read())
        is_invalid_schema, errors = ValidationHelper().validate_json(req,schema[1])
        if is_invalid_schema:
            self.status_code = AppStatus.bad_Request.value[0]
            schema_errors = self.json_helper.stringify_json(errors)[1]
            self.properties[CustomLog.schema_errors] =  schema_errors
            self.response = ErrorResponse(SharedConstants.request_val_failure,SharedConstants.request_header_failure,
                                              AppStatus.bad_Request.value[0], schema_errors,
                                              Assets.__name__).__str__() 


    def populate_default(self, assets_request)-> dict:
        """
        Function to  populate default value for asset filters
       
        Args:
            assets_request 
        Returns:
            asset_param (dict)   
        """
        asset_param = {key: assets_request.get(key, self.asset_default.asset_req_default[key]) 
                         for key in self.asset_default.asset_req_default} if isinstance(assets_request, dict) else assets_request

        return asset_param

                
    def map_dictionary(self, json_req) -> str:
        """
        Method to map the request column to the db column

        Args:
            json_req(json)

        Returns:
            json(str) 
        
        """
       
        return  self.json_helper.stringify_json(dict((self.data_mapper.get(k, k), v) for (k, v) in json_req.items()))[1]


    def get_all_assets_json(self, req):
        """
        Function to  call the database class to get all assets json based on filter condtion
       
        Args:
            req (str)
        """
        if self.status_code == AppStatus.ok.value[0]:
           self.properties["req"] = str(req)
           asset_filter_param = self.map_dictionary(req)
           data = json.loads(asset_filter_param)
           if(str(data['region_name']).replace(' ','') == str("North, West and Central").replace(' ','')):
                data['region_name']= ("North, West and Central")
                asset_filter_param = json.dumps(data)
                self.properties["asset_filter-param"] = asset_filter_param
           self.properties[CustomLog.sp_req_param] = GetAssetsConstants.input_json + SharedConstants.colon + asset_filter_param
           self.properties[CustomLog.sprequest_time] = datetime.now(timezone.utc).isoformat()
           response = SqlOperation().fetch_one(self.sql_query, asset_filter_param)
           self.properties[CustomLog.sprequestend_time] = datetime.now(timezone.utc).isoformat()
           is_valid_response,json_res = self.json_helper.parse_json(response[0] if response else None)
           if is_valid_response:
                self.response = response[0]
                #self.response = self.json_helper.stringify_json(json_res)[1]
           else:
                self.status_code = AppStatus.no_content.value[0]

     


    def get_assets(self)-> func.HttpResponse:
        """
        Function to get all assets json based on filter condtion
       
        Args:

        Returns:
            HttpResponse
            status_code(int)    - 204 No Content
                                - 200 Success
                                - 500 Internal Server Error 
                                - 400 Bad Request
        """
        try:
            is_parse_json_sucess, req = self.json_helper.parse_json(self.asset_filter)
            if is_parse_json_sucess:
               req_default = self.populate_default(req)
               self.validate_json(req_default)
               self.get_all_assets_json(req_default)
            else:
               self.status_code = AppStatus.bad_Request.value[0] 
               self.response = ErrorResponse(SharedConstants.request_val_failure,SharedConstants.request_header_failure,
                                              AppStatus.bad_Request.value[0], GetAssetsConstants.assets_bad_request_msg,
                                              Assets.__name__).__str__()   
        except:
            self.properties[CustomLog.error_messsage] =  str(sys.exc_info())
            self.status_code = AppStatus.internal_server_error.value[0]
            self.properties[CustomLog.status] = False
            Logger.exception(self, type= sys.exc_info()[0], value = sys.exc_info()[1], tb =sys.exc_info()[2], properties = self.properties )
            self.response = ErrorResponse(str(sys.exc_info()[0]), Assets.__name__,
                                 self.status_code, str(traceback.format_exc()),Assets.__name__).__str__()
        finally:
            if istraceenabled:
                self.properties[CustomLog.end_time] = datetime.now(timezone.utc).isoformat()
                Logger.request(self,properties= self.properties)
            return func.HttpResponse(body=self.response,status_code= self.status_code, mimetype= SharedConstants.json_mime_type)     
  