#assets_filter_req.py

"""Business Logic class"""
import sys

class AssetFilterRequest:
  
    """ AssetFilterRequest class to get default  json response """ 
    def __init__(self):
        self.asset_req_default = { "region_name": None,
                                    "route_id":0,
                                    "area_id":0,
                                    "elr_id":[0],
                                    "start_mileage_from":-1,
                                    "start_mileage_to":99999,
                                    "railway_id": None,
                                    "ast_grp_id":0,
                                    "ast_typ_id":[0],
                                    "opstat_id":[0],
                                    "ownparty_name":[None],
                                    "asset_desc":None,
                                    "mattyp_id":[0],
                                    "hceflg_name":"All",
                                    "cmi_score_from":-1,
                                    "cmi_score_to":99999,
                                    "strccarries_name":[None],
                                    "strcover_name":[None],
                                    "outsideparty_name":[None],
                                    "is_export_to_doc":"N",
                                    "sort_column":"StartMileage",
                                    "sort_order":"asc",
                                    "page_no":1,
                                    "rows_per_page":25
                                 }
