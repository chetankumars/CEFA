#get_assets.py

__all__ = ["GetAssetsConstants"]
class GetAssetsConstants:
    """
    constants related to project specific

    """
    get_assets = "getAssets"
    assets_req_schema = "assets_request.json"
    assets_bad_request_msg = "Header X-Asset-Filters is missing"  
    asset_filter = 'X-Asset-Filters' 
    input_json = "Input_JSON"    