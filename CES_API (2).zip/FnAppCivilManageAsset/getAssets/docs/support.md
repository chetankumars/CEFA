# Get assets

## Description
    Service to get allassets from the CES db.
    APIM URL: https://apim-uks-dev-ces-0001.azure-api.net/II/CESAPI/assets/search
    FUNCTION URL: https://fnp-uks-dev-ces-funcedst0001.azurewebsites.net/api/getAssets
    
  ## Request params for search lookup
    Method Type: GET
    Header Name : X-Asset-Filters
    Sample Value : {"region_name":"Southern","route_id":0,"area_id":0,"elr_id":[0],"start_mileage_from":-1,"start_mileage_to":99999,"railway_id":null,"ast_grp_id":0,"ast_typ_id":[0],"opstat_id":[0],"ownparty_name":[null],"asset_desc":null,"mattyp_id":[0],"hceflg_name":"All","cmi_score_from":-1,"cmi_score_to":99999,"strccarries_name":[null],"strcover_name":[null],"outsideparty_name":[null],"is_export_to_doc":"N","sort_column":"StartMileage","sort_order":"asc","page_no":1,"rows_per_page":25}