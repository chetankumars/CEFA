
|Item       |Category         |Passed                          |Notes                         |
|----------------|--------------|-----------------|-----------------------------|
|Is custom dimension Application Insights is working |`Development`|Yes| 
|There shall be no useless code|`Development`|Yes|  
|No Hardcoded values in code. All should be in config file.|`Development`|NYeso|
|No nested try/expect unless there is a good reason|`Development`|Yes|
|The application only logs one entry in the custom event log at the end|`Logging`|Yes|
|Followed (snake) case naming convention|`Development`|Yes|
|Function name should follow camel case with meaningfull name.|`Development`|Yes|
|Class name should follow Pascal case|`Development`|Yes|
|Header should follow Hypen Pascal case|`Development`|Yes|
|Proper description to be provided for methods |`Development`|Yes|
|Function folder structure should comply to User Preference|`Development`|Yes|
|All query param should follow camel case|`Development`|Yes|
|Is unit testing completed|`Development`|Yes|
