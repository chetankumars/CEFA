# save_asset_comment.py

import sys
import os
import logging
import azure.functions as func
from common import SqlOperation, Logger, JsonHelper,CustomLog, AppStatus, SharedConstants,ErrorResponse
from datetime import datetime, timezone
from .validate_request import ValidateRequest
from ..constants import AssetCommentConstants
from ..schema import AssetCommentSchema
import traceback
from datetime import date 
import json
istraceenabled = os.environ[SharedConstants.trace_enabled]


class SaveAssetComment:
    """ SaveAssetComment class to add the asset data  """
    def __init__(self):
        
        self.sql_query = """
                           EXEC [CES].[sp_Save_AssetDtls_AccessData]
                           @Input_JSON = ?
                           """
        self.response = str({})
        self.status_code = AppStatus.ok.value[0]
        self.properties = {CustomLog.add_asset_data : CustomLog.add_asset_data_val}
        self.properties[CustomLog.start_time] = datetime.now(timezone.utc).isoformat()
        self.properties[CustomLog.status] = True
        Logger.__init__( self,name = self.__class__.__name__, start_time = datetime.now(timezone.utc))

        self.json_helper = JsonHelper()
    
    def save_asset_comment(self,req: func.HttpRequest)-> func.HttpResponse:
        """
        Function to call Ces database to add the asset data
       
        Args:
            self ([SaveAssetComment]): [self instance]
            req: Http Request data (Json Data)
        Returns:
            HttpResponse
            status_code(int)     - 201 Created
                                - 500 Internal Server Error
                                - 400 BadRequest 
        """
        try:
            self.asset_comment_req = req.get_json()
            is_valid_payload, return_object =  ValidateRequest(AssetCommentSchema()).is_valid_payload(json.dumps(self.asset_comment_req))
            if is_valid_payload:
                self.asset_comment_json = self.json_helper.stringify_json(return_object)[1]
                sp_req_params = AssetCommentConstants.sp_input_json + SharedConstants.colon + self.asset_comment_json
                self.properties[CustomLog.sp_req_param] = sp_req_params
                self.properties[CustomLog.sprequest_time] = datetime.now(timezone.utc).isoformat()
                json_string = SqlOperation().fetch_one(self.sql_query, self.asset_comment_json)
                self.properties[CustomLog.sprequestend_time] = datetime.now(timezone.utc).isoformat()
                _isparsejson_sucess,_json_obj = self.json_helper.parse_json(json_string[0])
                if _isparsejson_sucess:
                    self.response = self.json_helper.stringify_json(_json_obj)[1]
                    response = func.HttpResponse(body= self.response, status_code= self.status_code, mimetype= SharedConstants.json_mime_type)
                else:
                    self.status_code = AppStatus.no_content.value[0]
                    response = func.HttpResponse(body= self.response, status_code= self.status_code, mimetype= SharedConstants.json_mime_type)
            else:
                self.status_code = AppStatus.bad_Request.value[0]
                self.response = ErrorResponse(SharedConstants.request_val_failure,SharedConstants.request_header_failure,self.status_code, str(return_object),SaveAssetComment.__name__).__str__()
                response = func.HttpResponse(body= self.response, status_code= self.status_code, mimetype= SharedConstants.json_mime_type)
        except:
            self.properties[CustomLog.error_messsage] =  str(traceback.format_exc())
            self.properties[CustomLog.status] = False
            Logger.exception(self,type= sys.exc_info()[0], value = sys.exc_info()[1], tb =sys.exc_info()[2], properties = self.properties )
            self.status_code = AppStatus.internal_server_error.value[0]
            error_response = ErrorResponse(SharedConstants.request_val_failure,SaveAssetComment.__name__,
                                              self.status_code, str(sys.exc_info()[1]),
                                              SaveAssetComment.__name__,).__str__()
            response = func.HttpResponse(body= error_response, status_code= self.status_code, mimetype= SharedConstants.json_mime_type)
        finally:
            if istraceenabled:
                self.properties[CustomLog.end_time] = datetime.now(timezone.utc).isoformat()
                Logger.request(self,properties= self.properties)
            return response