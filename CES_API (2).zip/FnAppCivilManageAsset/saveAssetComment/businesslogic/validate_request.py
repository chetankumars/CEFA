# validate_request.py

import sys
import os
sys.path.insert(0, os.getcwd()) 
import json



__all__ = ['ValidateRequest']
class ValidateRequest:

    def __init__(self, asset_schema):
        self.asset_schema = asset_schema

    def is_valid_payload(self, payload):
        try:
            load_schema =  self.asset_schema.loads(payload, partial=True)
            return_object =  self.asset_schema.dump(load_schema)
            return True, return_object
        except:
            (excepclass, errormessage, trackback) = sys.exc_info()
            return False, errormessage