# asset_comment_constants.py

__all__ = ["AssetCommentConstants"]
class AssetCommentConstants:
    """
    constants related to project specific

    """
    sp_input_json = "Input_JSON"
    validate_request = "ValidateRequest"
    