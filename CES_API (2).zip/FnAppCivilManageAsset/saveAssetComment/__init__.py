import logging

import azure.functions as func
from .businesslogic import SaveAssetComment

def main(req: func.HttpRequest) -> func.HttpResponse:
    """[summary]

    Args:
        req (func.HttpRequest): request parameter to add asset data to CES DB

    Returns:
        func.HttpResponse: status returned from CES DB
        
    """
    
    return SaveAssetComment().save_asset_comment(req)
