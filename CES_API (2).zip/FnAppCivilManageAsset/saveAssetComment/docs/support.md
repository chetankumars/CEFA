# add comment

## Description
    To Add Asset comment to  CES DB.

## Get Request for tasklist details

    APIM URL: https://apim-uks-dev-ces-0001.azure-api.net/II/CESAPI/assets/addComment
    Method Type:  POST
    
    FUNCTION URL: https://fnp-uks-dev-ces-funcedst0003.azurewebsites.net/api/saveAssetComment
    Method Type:  POST
    
    Sample Json:
    {
        "asset_guid": "3978559C379545D9E04400306E4AD01A",
        "exam_type_id": 2,
        "comments": "comments to test",
        "current_user_key":  "9725949A-1EB7-497E-B397-A511422AFAFE"
    }

   Sample Response:
   {
    "save_status": 1,
    "error_msg": null
    }