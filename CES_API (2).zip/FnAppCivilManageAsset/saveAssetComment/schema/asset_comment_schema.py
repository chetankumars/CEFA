# asset_comment_schema.py

from marshmallow import fields,Schema

__all__ =['AssetCommentSchema']
class AssetCommentSchema(Schema):
    asset_guid = fields.String(required=False,allow_none=True,default=None, missing=True)
    exam_type_id = fields.Integer(required=True)  
    comments = fields.String(required=False, allow_none=True,default=None, missing=True)  
    current_user_key = fields.String(required=True)

