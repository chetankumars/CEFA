# __init__.py

from .asset_comment_schema import AssetCommentSchema