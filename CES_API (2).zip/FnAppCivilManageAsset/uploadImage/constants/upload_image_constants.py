# upload_image_constants.py

class UploadImageConstants:

    """
        constants related to project specific
    """

    asset_guid = "asset_guid"
    asset_img_name = "asset_img_name"
    asset_img_path = "asset_img_path"
    block_blob = "BlockBlob"
    user_id = "user_id"
    upload_image = "uploadimage"
    upload_image_val = "func:uploadimage"
    container_path = "container_path"
    storage_account_url = "storage_account_url"
    x_file_meta_data = "X-File-Metadata"
    file_meta_data_empty = "X-File-Metadata header is missing"
    blob_exists = "Blob already exists."