# upload image

## Description
Services to uploading the asset image to the azure blob storage and inserting asset image metadata to the CES db.