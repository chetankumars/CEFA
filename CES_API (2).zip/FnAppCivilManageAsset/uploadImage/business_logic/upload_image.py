#upload_image.py

import sys
import os
import logging
import azure.functions as func
import common
import json
import traceback
from common import Logger, SqlOperation, ValidationHelper,CustomLog, AppStatus, SharedConstants, ErrorResponse, CustomMessage
from common.utilities.json_helper import JsonHelper
from datetime import datetime, timezone
from azure.storage.blob import BlobClient
from datetime import datetime
from azure.identity import ChainedTokenCredential, DefaultAzureCredential, ManagedIdentityCredential
from ..constants.upload_image_constants import UploadImageConstants
from azure.core.exceptions import ResourceExistsError

istraceenabled = os.environ[SharedConstants.trace_enabled]

class  UploadImage:

    """ UploadImage to the blob and store the metadata in the CES database""" 
    def __init__(self):
        self.post_sql_query = """
                           [CES].[sp_Save_AssetImg_Dtls]
                           @asset_guid = ?, @asset_img_name = ?,
                           @asset_img_path = ?, @user_id = ?
                           """
        self.response = str([])
        self.container_path =  os.environ[UploadImageConstants.container_path].format(str(datetime.now().year), str(datetime.now().month), str(datetime.now().day), str(datetime.now().hour), str(datetime.now().minute), str(datetime.now().second))
        self.storage_account_url = os.environ[UploadImageConstants.storage_account_url]
        self.status_code = AppStatus.ok.value[0]
        self.properties = {UploadImageConstants.upload_image:UploadImageConstants.upload_image_val}
        self.properties[CustomLog.start_time] = datetime.now(timezone.utc).isoformat()
        self.properties[CustomLog.status] = True
        Logger.__init__(self, name = self.__class__.__name__, start_time = datetime.now(timezone.utc))
        
    def upload_blob(self, file_meta_data, file_data, file_name):

        """
        Function to upload the asset image to the blob storage.
       
        Args:
        file_meta_data(str)
        file_data(str)
        """
        managed_identity = ManagedIdentityCredential()
        service_principal = DefaultAzureCredential()
        credential_chain = ChainedTokenCredential(managed_identity, service_principal)
        
        if file_meta_data[UploadImageConstants.asset_img_path] is not None and file_meta_data[UploadImageConstants.asset_img_path] !='':
            blob_container_path = str(file_meta_data[UploadImageConstants.asset_img_path]).replace(self.storage_account_url+"/","").replace("/"+file_meta_data[UploadImageConstants.asset_img_name],"")
            blob = BlobClient(self.storage_account_url, container_name= blob_container_path, blob_name = file_meta_data[UploadImageConstants.asset_img_name], credential=credential_chain)
            blob.delete_blob()
        
        blob = BlobClient(self.storage_account_url, container_name= self.container_path, blob_name = str(file_name), credential=credential_chain)
        blob.upload_blob(file_data, blob_type = UploadImageConstants.block_blob)

    def insert_file_meta_data(self, file_meta_data, file_data, file_name) ->(str, int) :
        """
        Function to upload the asset image to the blob storage.
       
        Args:
        file_meta_data(str)     
        file_data(str)

        Returns:
            response (str) 
            statuscode(int)     - 204 No Content
                                - 200 Success
                                - 500 Internal Server Error 
                                - 406 Not Acceptable 
        """
        try:

            self.properties[CustomLog.sp_req_param] =  UploadImageConstants.asset_guid + SharedConstants.colon + file_meta_data[UploadImageConstants.asset_guid] + UploadImageConstants.asset_img_name + SharedConstants.colon + str(file_name) + UploadImageConstants.asset_img_path + SharedConstants.colon + file_meta_data[UploadImageConstants.asset_img_path] + UploadImageConstants.user_id + SharedConstants.colon + file_meta_data[UploadImageConstants.user_id]

            self.upload_blob(file_meta_data, file_data, file_name)

            file_meta_data[UploadImageConstants.asset_img_path] = self.storage_account_url + '/' + self.container_path + '/' + str(file_name)
            
            self._params = file_meta_data[UploadImageConstants.asset_guid], str(file_name), file_meta_data[UploadImageConstants.asset_img_path], file_meta_data[UploadImageConstants.user_id]
            _json_string =  SqlOperation().fetch_one(self.post_sql_query, self._params )
            self.properties[CustomLog.sprequestend_time] = datetime.now(timezone.utc).isoformat()
            if _json_string is None:
                self.status_code = AppStatus.no_content.value[0]
            elif not _json_string[0]:
                self.response = common.ErrorResponse(UploadImage().__class__.__name__, UploadImage().__class__.__name__,common.AppStatus.internal_server_error.value, _json_string[1],UploadImage().__class__.__name__).__str__()
                self.status_code = AppStatus.internal_server_error.value[0]
            else:
                result = {}
                result['asset_img_name'] = str(file_name)
                result['asset_img_path'] = file_meta_data[UploadImageConstants.asset_img_path]
                self.response = json.dumps(result)
                self.status_code = AppStatus.record_created.value[0]
        except ResourceExistsError:
            self.properties[CustomLog.error_messsage] =  str(traceback.format_exc())
            self.properties[CustomLog.status] = False
            self.status_code = AppStatus.bad_Request.value[0]
            self.response = ErrorResponse(str(sys.exc_info()[0]), UploadImage().__class__.__name__,
                                 AppStatus.bad_Request.value, UploadImageConstants.blob_exists, UploadImage().__class__.__name__).__str__()
            Logger.exception(self,type=sys.exc_info()[0], value = str(sys.exc_info()[1]), tb = str(sys.exc_info()[2]), properties = self.properties )
        except:
            self.properties[CustomLog.error_messsage] =  str(traceback.format_exc())
            self.properties[CustomLog.status] = False
            self.status_code = AppStatus.internal_server_error.value[0]
            self.response = ErrorResponse(str(sys.exc_info()[0]), UploadImage().__class__.__name__,
                                 AppStatus.internal_server_error.value, str(sys.exc_info()), UploadImage().__class__.__name__).__str__()
            Logger.exception(self,type=sys.exc_info()[0], value = str(sys.exc_info()[1]), tb = str(sys.exc_info()[2]), properties = self.properties )
        finally:
             if istraceenabled:
                self.properties[CustomLog.end_time] = datetime.now(timezone.utc).isoformat()
                Logger.request(self,properties= self.properties)

                return self.response, self.status_code