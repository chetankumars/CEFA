import logging
import azure.functions as func
import base64
import json
import requests
import json
import common
from common import SharedConstants, AppStatus
from .business_logic import UploadImage
from .constants.upload_image_constants import UploadImageConstants

def main(req: func.HttpRequest) -> func.HttpResponse:

    try:
        file_meta_data = json.loads(req.headers[UploadImageConstants.x_file_meta_data])
        if(file_meta_data is None or file_meta_data ==''):
            raise UploadImageConstants.file_meta_data_empty
    except:
        status_code = AppStatus.bad_Request.value[0]
        response = common.ErrorResponse(common.SharedConstants.request_val_failure, common.SharedConstants.request_header_failure,common.AppStatus.bad_Request.value[0], UploadImageConstants.file_meta_data_empty, UploadImageConstants.upload_image).__str__()
        return func.HttpResponse(body= response, status_code= status_code, mimetype= SharedConstants.json_mime_type)

    file_data = ''
    file_name = ''

    for files in req.files.listvalues():
        for file in files:
            file_data = file.read()
            file_name = file.filename

    response, status_code = UploadImage().insert_file_meta_data(file_meta_data, file_data, file_name)

    return func.HttpResponse(body= response, status_code= status_code, mimetype= SharedConstants.json_mime_type)
