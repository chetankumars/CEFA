#get_display_recommendation_details_constants.py

class GetDisplayRecommendationDetailsConstants:
    """
    constants related to project specific

    """
    
    asset_guid = "assetGuid"
    exam_key  = "examKey"
    sql_query = """
                EXEC [CES].sp_Get_RecommendationDtls_SearchResult
                @Asset_GUID = ?,
                @Exam_Key = ?

                """
   