# Get display recommendation details

## Description
Services to get display recommendation details from the CSE db.

    <!-- APIM URL: https://apim-uks-dev-ces-0001.azure-api.net/II/CESAPI/assets/{assetId}[?requestType] -->

    FUNCTION URL: https://fnp-uks-dev-ces-funcedst0001.azurewebsites.net/api/getDisplayRecommendation

## Request params for display recommendation details
    
    Request params:(APIM URL)
        assetId = 3978559C2D8345D9E04400306E4AD01A       
        
    Request params: (FUNCTION URL)
        assetGuid = 3978559C2D8345D9E04400306E4AD01A
       

