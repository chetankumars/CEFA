#__init__.py

import sys
import common
import json
import traceback
from common import SharedConstants
import azure.functions as func
from .business_logic import get_display_recommendation_details as bu
from .constants.get_display_recommendation_details_constants import GetDisplayRecommendationDetailsConstants

def main(req: func.HttpRequest) -> func.HttpResponse:

    """[summary]

    Args:
        req (func.HttpRequest): To Get display recommendation details from CES DB

    Returns:
        func.HttpResponse: display recommendation details json for get operation as response from CES DB
    """
    # return func.HttpResponse(status_code=200)
    try:       
        asset_guid = req.params.get(GetDisplayRecommendationDetailsConstants.asset_guid)
        exam_key = req.params.get(GetDisplayRecommendationDetailsConstants.exam_key)
        recommendationdetails = bu.GetDisplayRecommendationDetails()        
        response,status_code = recommendationdetails.get_display_recommendation(asset_guid,exam_key)        
    except:
        response = common.ErrorResponse(str(sys.exc_info()[0]), bu.GetDisplayRecommendationDetails().__class__.__name__,common.AppStatus.internal_server_error.value, str(traceback.format_exc()),bu.GetDisplayRecommendationDetails().__class__.__name__).__str__()
        status_code = common.AppStatus.internal_server_error.value[0]
    finally:       
        return func.HttpResponse(body=response,status_code=status_code,mimetype=SharedConstants.json_mime_type)

if __name__ == SharedConstants.main:
    main(func.HttpRequest)
