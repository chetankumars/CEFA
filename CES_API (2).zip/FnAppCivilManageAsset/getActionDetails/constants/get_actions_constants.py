# get_actions_constants.py

class GetActionsConstants:

    """ Constants related to GetActionDetails """
    
    rcmn_key = "rcmnKey"
    sql_query = """
                EXEC [CES].sp_Get_RcmdnActionDtls
                @rcmn_key = ?, @ASSET_GUID = ?
                """
    get_action_details = "getActionDetails"
    get_action_details_val = "func:getActionDetails"
    param_failure = "rcmnKey or assetGuid query parameter is missing."