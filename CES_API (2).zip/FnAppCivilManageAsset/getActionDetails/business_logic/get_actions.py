# get_actions.py

import sys
import os
import logging
import json
import azure.functions as func
from ..constants.get_actions_constants import GetActionsConstants
from common import SqlOperation,Logger,JsonHelper,CustomLog,SharedConstants,AppStatus
from datetime import datetime, timezone 

istraceenabled = os.environ[SharedConstants.trace_enabled]

class Actions:

    """ Actions class to get information about actions from CES db."""

    def __init__(self):
        self.response = str({})
        self.statusCode = AppStatus.ok.value[0]
        self.properties = {GetActionsConstants.get_action_details : GetActionsConstants.get_action_details_val}
        self.properties[CustomLog.start_time] = datetime.now(timezone.utc).isoformat()
        Logger.__init__(self, name = self.__class__.__name__, start_time = datetime.now(timezone.utc))
        self.properties[CustomLog.status] = True
        self.json_helper = JsonHelper()

    def get_asset_actions(self, rcmn_key, asset_guid) -> (str,int):
        """
        Method to call CES database to get action details.

        Args:
          rcmn_key(int)

        Returns:
            json(str) 
            statuscode(int)   - 204 No Content
                              - 200 Success
                              - 400 Bad Request
                              - 500 Internal Server Error
        """
        try:
          self.properties[CustomLog.sp_req_param] = GetActionsConstants.rcmn_key + SharedConstants.colon + rcmn_key, SharedConstants.asset_guid + SharedConstants.colon + asset_guid
          param = rcmn_key, asset_guid
          self.properties[CustomLog.sprequest_time] = datetime.now(timezone.utc).isoformat()
          actions = SqlOperation().fetch_one(GetActionsConstants.sql_query, param)
          self.properties[CustomLog.sprequestend_time] = datetime.now(timezone.utc).isoformat()
          if actions is not None:
             is_valid_response,json_obj = self.json_helper.parse_json(actions[0])
             if is_valid_response:
                 self.response = self.json_helper.stringify_json(json_obj)[1]
             else:
                 self.statusCode = AppStatus.internal_server_error.value[0]  
          else:
             self.statusCode = AppStatus.no_content.value[0]
          if istraceenabled:
             self.properties[CustomLog.end_time] = datetime.now(timezone.utc).isoformat()
             Logger.request(self,properties= self.properties)
          return self.response, self.statusCode
        except:
            self.properties[CustomLog.error_messsage] = str(sys.exc_info())
            self.properties[CustomLog.status] = False
            Logger.exception(self, type= sys.exc_info()[0], value = sys.exc_info()[1], tb =sys.exc_info()[2], properties = self.properties )
            raise