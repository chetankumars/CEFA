# __init__.py

import sys
import azure.functions as func
import traceback
from common import SharedConstants, ErrorResponse, AppStatus
from .business_logic.get_actions import Actions
from .constants.get_actions_constants import GetActionsConstants


def main(req: func.HttpRequest) -> func.HttpResponse:
    """ 
    Function calls Actions class to get action details.

    Args:
        req (func.HttpRequest)

    Returns:
        func.HttpResponse: action details json from CES DB
    """

    try:
        recommendation_key = req.params.get(GetActionsConstants.rcmn_key)
        asset_guid =req.params.get(SharedConstants.asset_guid)
        if recommendation_key is not None and asset_guid is not None:
            message, statuscode = Actions().get_asset_actions(recommendation_key, asset_guid)
        else:
            message = ErrorResponse(SharedConstants.request_val_failure, SharedConstants.request_header_failure, AppStatus.bad_Request.value[0], GetActionsConstants.param_failure, Actions().__class__.__name__).__str__()
            statuscode = AppStatus.bad_Request.value[0]
    except:
        message = ErrorResponse(str(sys.exc_info()[0]), Actions().__class__.__name__, AppStatus.internal_server_error.value[0], str(traceback.format_exc()),Actions().__class__.__name__).__str__()
        statuscode = AppStatus.internal_server_error.value[0]
    finally:
        return func.HttpResponse(body=message, status_code= statuscode, mimetype= SharedConstants.json_mime_type)

if __name__ == SharedConstants.main:
    main(func.HttpRequest)