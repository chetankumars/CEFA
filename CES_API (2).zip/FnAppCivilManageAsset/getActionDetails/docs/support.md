# Get action details

## Description
Services to get action details from CES db.

    APIM URL: https://apim-uks-dev-ces-0001.azure-api.net/II/CESAPI//assets/actions[?rcmnKey][&assetGuid]
    Method Type: GET

    FUNCTION URL: https://fnp-uks-dev-ces-funcedst0003.azurewebsites.net/api/getActionDetails
    Method Type: GET

## Request params for actiondetails
    
    Request params:(APIM URL)
        assetGuid = 3978559C2D9F45D9E04400306E4AD01A
        rcmnKey = 152719
        
    Request params: (FUNCTION URL)
        assetGuid = 3978559C2D9F45D9E04400306E4AD01A
        rcmnKey = 152719