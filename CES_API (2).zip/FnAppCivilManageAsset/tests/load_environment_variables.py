import os
import sys
sys.path.insert(0, os.getcwd())

class EnvironmentVariable:

    def __init__(self):
        os.environ['IDENTITY_ENDPOINT'] =''
        os.environ['IDENTITY_HEADER'] =''
        os.environ['Trace_Enabled'] = 'True'
        os.environ['SQL_DB'] =''
        os.environ['SQL_CONNECTION_STRING'] = ''
        os.environ['SQL_RESOURCE_URI'] =''
        os.environ['MANAGED_IDENTITY_CLIENT_ID'] =''
        os.environ['SQL_DRIVER'] =''
        os.environ['SQL_SERVER'] =''
        os.environ['APPINSIGHTS_INSTRUMENTATIONKEY'] ='b4c9a07a-d78f-43cd-ad26-b1426011edc7'
        os.environ['container_path'] ='ces-adls/Raw/Asset_Image/{0}/{1}/{2}'
        os.environ['storage_account_url'] ='https://sacuksnprdiicesdev0001.blob.core.windows.net'
        os.environ['AZURE_CLIENT_ID'] ='1220d9bf-91ec-4298-92d8-d099ced4e7ca'
        os.environ['AZURE_TENANT_ID'] ='c22cc3e1-5d7f-4f4d-be03-d5a158cc9409'
        os.environ['AZURE_CLIENT_SECRET'] ='-NRpY2~__O2GcGJj57SE-33_8whl8rsA.~'
    