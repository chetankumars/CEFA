#test_get_assests_init.py

import sys
import os
import unittest
from unittest import mock
from unittest.mock import patch, Mock, MagicMock, create_autospec
import azure.functions as func
sys.path.insert(0, os.getcwd())
from tests.load_environment_variables import EnvironmentVariable
load = EnvironmentVariable()
from getAssets import main

class GetAssetsInitTest(unittest.TestCase):
        
    @patch('getAssets.Assets')
    def test_init_return_ok(self, mocked):
        mocked_value = '{"searchdatacount":{"currentpage":1,"totalcount":2},"searchresult":[{"region":"abc","route":"abcd","elr":"abcdef","start_mileage":2.2,"end_mileage":3.3,"railway_id":"abc","asset_desc":"xyz","asset_grp":"asd","asset_type":"vbvb","operation_status":"ert","owning_party":"ert","primary_material":"asd","last_dtl_exam":"12/12/2020","dtl_exam_freq":2,"last_vis_exam":"12/10/2020"}]}'
        http_response = func.HttpResponse(status_code=200,body=mocked_value)
        mocked.return_value.get_assets.return_value = http_response
        http_request = func.HttpRequest(
            method='GET',
            body=None,
            url='/getAssets', 
            headers= {'X-Asset-Filters': '{"region_name":"Southern","route_id":0,"area_id":0,"elr_id":0,"start_mileage_from":-1,"start_mileage_to":99999,"railway_id":null,"ast_grp_id":0,"ast_typ_id":[0],"opstat_id":0,"ownparty_name":null,"asset_desc":null,"mattyp_id":0,"hceflg_name":"All","cmi_score_from":-1,"cmi_score_to":99999,"strccarries_name":null,"strcover_name":null,"is_export_to_doc":"N","sort_column":"StartMileage","sort_order":"asc","page_no":1,"rows_per_page":25}'}
        )

        response = main(http_request)

        self.assertEqual(response.status_code, 200)
        self.assertEqual(
            response.get_body(),
            b'{"searchdatacount":{"currentpage":1,"totalcount":2},"searchresult":[{"region":"abc","route":"abcd","elr":"abcdef","start_mileage":2.2,"end_mileage":3.3,"railway_id":"abc","asset_desc":"xyz","asset_grp":"asd","asset_type":"vbvb","operation_status":"ert","owning_party":"ert","primary_material":"asd","last_dtl_exam":"12/12/2020","dtl_exam_freq":2,"last_vis_exam":"12/10/2020"}]}'
        )

    def test_init_return_bad_request_invalid_header(self):
        http_request = func.HttpRequest(
            method='GET',
            body=None,
            url='/getAssets', 
            headers= {'assetfiltercondition': None}
        )

        response = main(http_request)

        self.assertEqual(response.status_code, 400)
        self.assertEqual(
            response.get_body(),
            b'{"error": {"types": "Invalid Request", "title": "Header/Param validation failure", "status": 400, "detail": "Header X-Asset-Filters is missing", "instance": "Assets"}}'
        )    

    def test_init_return_bad_request_without_header(self):
        http_request = func.HttpRequest(
            method='GET',
            body=None,
            url='/getAssets', 
        )

        response = main(http_request)

        self.assertEqual(response.status_code, 400)
        self.assertEqual(
            response.get_body(),
            b'{"error": {"types": "Invalid Request", "title": "Header/Param validation failure", "status": 400, "detail": "Header X-Asset-Filters is missing", "instance": "Assets"}}'
        )     

    