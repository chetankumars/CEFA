#test_get_assets_businesslogic.py

import sys
import os
import unittest
from unittest import mock
from unittest.mock import patch, Mock, MagicMock, create_autospec
import azure.functions as func
sys.path.insert(0, os.getcwd())
from tests.load_environment_variables import EnvironmentVariable
load = EnvironmentVariable()
from getAssets.businesslogic.get_assets import Assets

class GetAssetsTest(unittest.TestCase):

    @patch('getAssets.businesslogic.get_assets.SqlOperation')
    async def test_return_ok(self, mocked):
        req = '{"region_name":"Southern","route_id":0,"area_id":0,"elr_id":0,"start_mileage_from":-1,"start_mileage_to":99999,"railway_id":null,"ast_grp_id":0,"ast_typ_id":[0],"opstat_id":0,"ownparty_name":null,"asset_desc":null,"mattyp_id":0,"hceflg_name":"All","cmi_score_from":-1,"cmi_score_to":99999,"strccarries_name":null,"strcover_name":null,"is_export_to_doc":"N","sort_column":"StartMileage","sort_order":"asc","page_no":1,"rows_per_page":25}'
        mocked.return_value.fetch_one.return_value  = ['{"searchdatacount":{"currentpage":1,"totalcount":4871,"totalpages":195},"searchresult":[{"asset_guid":"3978559C2EF045D9E04400306E4AD01A","region":"Southern","route":"Kent","elr":"XTD","start_mileage":"0.000000","end_mileage":null,"railway_id":"W251","asset_desc":"BREWERS LANE ARCHES 184 - 180","asset_grp":"Bridge","asset_type":"Viaduct","operation_status":"Functionary","owning_party":"Network Rail (CE-Op Prop)","primary_material":" RBE - Brick","last_Dtl_Exam":null,"dtl_exam_freq":null,"last_vis_exam":null}]}']
        actualResponse = await Assets(req).get_assets()
        self.assertEqual(
            actualResponse.get_body(),
            b'{"searchdatacount": {"currentpage": 1, "totalcount": 4871, "totalpages": 195}, "searchresult": [{"asset_guid": "3978559C2EF045D9E04400306E4AD01A", "region": "Southern", "route": "Kent", "elr": "XTD", "start_mileage": "0.000000", "end_mileage": null, "railway_id": "W251", "asset_desc": "BREWERS LANE ARCHES 184 - 180", "asset_grp": "Bridge", "asset_type": "Viaduct", "operation_status": "Functionary", "owning_party": "Network Rail (CE-Op Prop)", "primary_material": " RBE - Brick", "last_Dtl_Exam": null, "dtl_exam_freq": null, "last_vis_exam": null}]}')

    @patch('getAssets.businesslogic.get_assets.SqlOperation')
    async def test_return_no_content_When_null_response(self, mocked):
        req = '{"region_name":"Southern","route_id":0,"area_id":0,"elr_id":0,"start_mileage_from":-1,"start_mileage_to":99999,"railway_id":null,"ast_grp_id":0,"ast_typ_id":[0],"opstat_id":0,"ownparty_name":null,"asset_desc":null,"mattyp_id":0,"hceflg_name":"All","cmi_score_from":-1,"cmi_score_to":99999,"strccarries_name":null,"strcover_name":null,"is_export_to_doc":"N","sort_column":"StartMileage","sort_order":"asc","page_no":1,"rows_per_page":25}'
        mocked.return_value.fetch_one.return_value  = None
        response = await Assets(req).get_assets()
        self.assertEqual(
            response.get_body(),
            b'{}'
        )  

    async def test_return_bad_request(self):
        req = None
        response = await Assets(req).get_assets()
        self.assertEqual(response.status_code, 400)
        self.assertEqual(
            response.get_body(),
            b'{"error": {"types": "Invalid Request", "title": "Header/Param validation failure", "status": 400, "detail": "Header X-Asset-Filters is missing", "instance": "Assets"}}'
        )
    
    @patch('getAssets.businesslogic.get_assets.SqlOperation')
    async def test_return_no_content_when_invalid_json_response(self, mocked):
        req = '{"region_name":"Southern","route_id":0,"area_id":0,"elr_id":0,"start_mileage_from":-1,"start_mileage_to":99999,"railway_id":null,"ast_grp_id":0,"ast_typ_id":[0],"opstat_id":0,"ownparty_name":null,"asset_desc":null,"mattyp_id":0,"hceflg_name":"All","cmi_score_from":-1,"cmi_score_to":99999,"strccarries_name":null,"strcover_name":null,"is_export_to_doc":"N","sort_column":"StartMileage","sort_order":"asc","page_no":1,"rows_per_page":25}'
        mocked.return_value.fetch_one.return_value  = None
        response = await Assets(req).get_assets()
        self.assertEqual(
            response.get_body(),
            b'{}'
        )

    @patch('getAssets.businesslogic.get_assets.SqlOperation')
    async def test_return_internal_server_error_exception(self,mocked):
        req = '{"region_name":"Southern","route_id":0,"area_id":0,"elr_id":0,"start_mileage_from":-1,"start_mileage_to":99999,"railway_id":null,"ast_grp_id":0,"ast_typ_id":[0],"opstat_id":0,"ownparty_name":null,"asset_desc":null,"mattyp_id":0,"hceflg_name":"All","cmi_score_from":-1,"cmi_score_to":99999,"strccarries_name":null,"strcover_name":null,"is_export_to_doc":"N","sort_column":"StartMileage","sort_order":"asc","page_no":1,"rows_per_page":25}'
        mocked.return_value.fetch_one.return_value  = {'{"searchdatacount":{"currentpage":1,"totalcount":4871,"totalpages":195},"searchresult":[{"asset_guid":"3978559C2EF045D9E04400306E4AD01A","region":"Southern","route":"Kent","elr":"XTD","start_mileage":"0.000000","end_mileage":null,"railway_id":"W251","asset_desc":"BREWERS LANE ARCHES 184 - 180","asset_grp":"Bridge","asset_type":"Viaduct","operation_status":"Functionary","owning_party":"Network Rail (CE-Op Prop)","primary_material":" RBE - Brick","last_Dtl_Exam":null,"dtl_exam_freq":null,"last_vis_exam":null}]}'}
        actualResponse = await Assets(req).get_assets()
        self.assertEqual(actualResponse.status_code, 500) 