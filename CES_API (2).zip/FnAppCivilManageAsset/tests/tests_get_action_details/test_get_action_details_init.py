# test_get_action_details_init.py

import sys
import os
import unittest
from unittest.mock import patch
import azure.functions as func
from tests.load_environment_variables import EnvironmentVariable
EnvironmentVariable()
from getActionDetails import main

class GetActionsInitTest(unittest.TestCase):

      @patch('getActionDetails.Actions')
      def test_init_return_ok(self, mocked):
          action_details_mock = '{"struc_description": "DANES ROAD VIADUCT ARCHES 388 - 397", "act_num": 1234, "work_type": "Correspondence", "work_category": "Third Party Works", "location": "Cross girders DK3 XGE1", "problem_statement": "Epoxy grouting of fractures to cross girder encasement", "work_status": "Scheduled", "priority_year": "2021/2022", "quantity": "12.00 unit", "notes": "ABC"}'
          mocked.return_value.get_asset_actions.return_value = action_details_mock, 200
          req = func.HttpRequest(
          method='GET',
          body=None,
          url='/getActionDetails',
          params={'rcmnKey': '152719',
          'assetGuid' : '3978559C2D9F45D9E04400306E4AD01A'})

          resp = main(req)
          self.assertEqual(resp.status_code, 200)
          self.assertEqual(resp.get_body(),
          b'{"struc_description": "DANES ROAD VIADUCT ARCHES 388 - 397", "act_num": 1234, "work_type": "Correspondence", "work_category": "Third Party Works", "location": "Cross girders DK3 XGE1", "problem_statement": "Epoxy grouting of fractures to cross girder encasement", "work_status": "Scheduled", "priority_year": "2021/2022", "quantity": "12.00 unit", "notes": "ABC"}'
          )

      @patch('getActionDetails.ErrorResponse')
      def test_init_return_badrequest(self, mocked):
          mocked.return_value.__str__.return_value = "rcmnKey or assetGuid is Missing"
          req = func.HttpRequest(
          method='GET',
          body=None,
          url='/getActionDetails',
          params={'assetGuid' : '3978559C2D9F45D9E04400306E4AD01A'})

          resp = main(req)
          self.assertEqual(resp.status_code, 400)

      @patch('getActionDetails.ErrorResponse')
      def test_init_return_internalservererror(self, mocked):
          mocked.return_value.__str__.return_value = "Sql connection error"
          req = func.HttpRequest(
          method='GET',
          body=None,
          url='/getActionDetails',
          params={'rcmnKey': '152719',
          'assetGuid' : '3978559C2D9F45D9E04400306E4AD01A'})

          resp = main(req)
          self.assertEqual(resp.status_code, 500)
          
 