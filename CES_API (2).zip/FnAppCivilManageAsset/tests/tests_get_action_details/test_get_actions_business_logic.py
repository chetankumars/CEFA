# test_get_actions_business_logic.py

import sys
import os
import unittest
from unittest.mock import patch
import azure.functions as func
from tests.load_environment_variables import EnvironmentVariable
EnvironmentVariable()
from getActionDetails import Actions


class ActionsTest(unittest.TestCase):
    
    @patch('getActionDetails.business_logic.get_actions.SqlOperation')
    def test_actions_return_ok(self, mocked):
        action_details_mock = '{"struc_description": "DANES ROAD VIADUCT ARCHES 388 - 397", "act_num": 1234, "work_type": "Correspondence", "work_category": "Third Party Works", "location": "Cross girders DK3 XGE1", "problem_statement": "Epoxy grouting of fractures to cross girder encasement", "work_status": "Scheduled", "priority_year": "2021/2022", "quantity": "12.00 unit", "notes": "ABC"}'
        mocked.return_value.fetch_one.return_value = action_details_mock, 200
        response, status_code = Actions().get_asset_actions('152719', '3978559C2D9F45D9E04400306E4AD01A')
        self.assertEqual(status_code, 200)
        self.assertEqual(response, action_details_mock )
        
    @patch('getActionDetails.business_logic.get_actions.SqlOperation')
    def test_actions_return_nocontent(self, mocked):
        mocked.return_value.fetch_one.return_value = None
        response, status_code = Actions().get_asset_actions('152719', '3978559C2D9F45D9E04400306E4AD01A')
        self.assertEqual(status_code, 204)
        self.assertEqual(response, '{}')

    @patch('getActionDetails.business_logic.get_actions.SqlOperation')
    def test_actions_return_internalservererrror_invalidJson(self, mocked):
        mocked.return_value.fetch_one.return_value = '{"act_no" : "2",}'
        response, status_code = Actions().get_asset_actions('152719', '3978559C2D9F45D9E04400306E4AD01A')
        self.assertEqual(status_code, 500)
        self.assertEqual(response, '{}')

    @patch('getActionDetails.business_logic.get_actions.SqlOperation.fetch_one')
    def test_actions_return_Internalservererror(self, mocked):
        mocked.side_effect = ConnectionError
        try:
            Actions().get_asset_actions('152719','3978559C2D8345D9E04400306E4AD01A')
        except ConnectionError:
            pass
        except Exception:
            self.fail('unexpected exception raised')
        else:
            self.fail('ExpectedException not raised')