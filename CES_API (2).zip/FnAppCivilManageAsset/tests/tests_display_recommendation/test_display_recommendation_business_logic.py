#test_display_recommendation_business_logic.py

import sys
import os
import unittest
from unittest.mock import patch
import azure.functions as func
from tests.load_environment_variables import EnvironmentVariable
EnvironmentVariable()
from getDisplayRecommendation.business_logic.get_display_recommendation_details import GetDisplayRecommendationDetails
import json

class DisplayRecommendationBusinessLogic(unittest.TestCase):

    @patch('getDisplayRecommendation.business_logic.get_display_recommendation_details.SqlOperation')
    def test_get_display_recommendation_bl_return_ok(self,mocked):
        get_display_recommendation_details = ['{"searchdatacount": {"totalcount": 8},"assetdtls": [{"elr": "NKL","railway_id": "622","asset_grp": "Bridge","asset_type": "Culvert"}],"searchresult": [{"exam_id": 9020001,"exam_actual_date": "2018-01-04","exam_type": "Detailed","highest_risk_score": "3","details": [{"rcmn_desc": "Clearing accumulated rubbish to pits","location": null,"work_category": "Culvert Cleaning","quantity_units": "2.00 unit","risk_score": "10","status": "Duplicate","action_change": null,"rcmn_key": 158274}]}]}']
        mocked.return_value.fetch_one.return_value = get_display_recommendation_details
        response, status_code = GetDisplayRecommendationDetails().get_display_recommendation('3978559C328B45D9E04400306E4AD01A',14350)
        self.assertEqual(status_code, 200)    
   
    
    @patch('getDisplayRecommendation.business_logic.get_display_recommendation_details.SqlOperation')
    def test_get_display_recommendation_bl_return_bad_request(self,mocked):
        get_display_recommendation_details = ['{"searchdatacount": { "totalcount": null },"assetdtls": [{ "eng_line_ref": null,"railway_id": null,"asset_group_sr_key": null,"asset_type_sr_key": null}],earchresult": [{"exam_actual_date": null,"exam_type": null,"exam_id": null,"highest_risk_score": null,"details": [{"description": null,"location": null,"work_category": null,"quantity_unit": null,"risk_score": null,"rcmn_status": null,"action_change": null,"rcmn_key":null}]}]}']
        mocked.return_value.fetch_one.return_value = get_display_recommendation_details
        response, status_code = GetDisplayRecommendationDetails().get_display_recommendation(None,0)
        self.assertEqual(status_code, 400)    

    
    @patch('getDisplayRecommendation.business_logic.get_display_recommendation_details.SqlOperation')
    def  test_get_display_recommendation_bl_return_internal_server_error(self,mocked):
        get_display_recommendation_details = ['{"searchdatacount": { "totalcount": null },"assetdtls": [{ "eng_line_ref": null,"railway_id": null,"asset_group_sr_key": null,"asset_type_sr_key": null}],earchresult": [{"exam_actual_date": null,"exam_type": null,"exam_id": null,"highest_risk_score": null,"details": [{"description": null,"location": null,"work_category": null,"quantity_unit": null,"risk_score": null,"rcmn_status": null,"action_change": null,"rcmn_key":null}]}]}']
        mocked.return_value.fetch_one.return_value = ''
        try:
            response, status_code = GetDisplayRecommendationDetails().get_display_recommendation(None,0)
        except:
            pass
            


        
