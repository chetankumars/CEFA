#test_bl_common_asset_details.py

import sys
import os
import unittest
from unittest import mock
from unittest.mock import patch
from tests.load_environment_variables import EnvironmentVariable
import azure.functions as func
EnvironmentVariable()
from getAssetDetails.business_logic.get_asset_details_commondata_business_logic import AssetCommonDetails

class GetCommonAssetDetailsBusinessLogicTest(unittest.TestCase):

    @patch('getAssetDetails.bu.commondata.SqlOperation')
    def test_sql_common_asset_details(self, mocked):
        common_asset_details = ['{"region": "Southern", "assetdesc": "GREAT SUFFOLK STREET VIADUCT ARCHES 22 - 31A", "route": "Kent", "area": "London Bridge", "ralway_id": "W63", "asset_type": "Viaduct", "op_status": 252, "elr": "NTL", "start_mileage": 0.875, "end_mileage": null, "prim_material": 13, "owning_party": "Network Rail (CE-Struct)", "gps_start": null, "gps_end": null, "stuct_carry": null, "struct_over": null, "hce_flag": "No", "asset_guid": "3978559C2D8345D9E04400306E4AD01A", "total_defect_cnt": null, "open_defect_cnt": null, "picture_uri": null, "cmi_score": 71, "ve_comp_stat": null, "de_comp_stat": null, "uw_comp_stat": null}']
        mocked.return_value.fetch_one.return_value = common_asset_details
        response, status_code = AssetCommonDetails().get_asset_info('3978559C2D8345D9E04400306E4AD01A')
        self.assertEqual(status_code, 200)
        self.assertEqual(response, '{"region": "Southern", "assetdesc": "GREAT SUFFOLK STREET VIADUCT ARCHES 22 - 31A", "route": "Kent", "area": "London Bridge", "ralway_id": "W63", "asset_type": "Viaduct", "op_status": 252, "elr": "NTL", "start_mileage": 0.875, "end_mileage": null, "prim_material": 13, "owning_party": "Network Rail (CE-Struct)", "gps_start": null, "gps_end": null, "stuct_carry": null, "struct_over": null, "hce_flag": "No", "asset_guid": "3978559C2D8345D9E04400306E4AD01A", "total_defect_cnt": null, "open_defect_cnt": null, "picture_uri": null, "cmi_score": 71, "ve_comp_stat": null, "de_comp_stat": null, "uw_comp_stat": null}')

    @patch('getAssetDetails.bu.commondata.SqlOperation.fetch_one')
    def test_sql_common_asset_details_exception_case(self, mocked):
        mocked.side_effect = ConnectionError
        try:
            AssetCommonDetails().get_asset_info('3978559C2D8345D9E04400306E4AD01A')
        except ConnectionError:
            pass
        except Exception:
            self.fail('unexpected exception raised')
        else:
            self.fail('ExpectedException not raised')

    @patch('getAssetDetails.bu.commondata.SqlOperation.fetch_one')
    def test_sql_common_asset_details_json_parse_not_success(self, sql_mocked):
        common_asset_details = ['{"region": {"Southern", "assetdesc": "GREAT SUFFOLK STREET VIADUCT ARCHES 22 - 31A", "route": "Kent", "area": "London Bridge", "ralway_id": "W63", "asset_type": "Viaduct", "op_status": 252, "elr": "NTL", "start_mileage": 0.875, "end_mileage": null, "prim_material": 13, "owning_party": "Network Rail (CE-Struct)", "gps_start": null, "gps_end": null, "stuct_carry": null, "struct_over": null, "hce_flag": "No", "asset_guid": "3978559C2D8345D9E04400306E4AD01A", "total_defect_cnt": null, "open_defect_cnt": null, "picture_uri": null, "cmi_score": 71, "ve_comp_stat": null, "de_comp_stat": null, "uw_comp_stat": null}']
        sql_mocked.return_value = common_asset_details
        response, status_code = AssetCommonDetails().get_asset_info('3978559C2D8345D9E04400306E4AD01A')
        self.assertEqual(status_code, 204)
        self.assertEqual(response, '{}')

    def test_sql_common_asset_details_asset_guid_none(self):
        response, status_code = AssetCommonDetails().get_asset_info(None)
        self.assertEqual(status_code, 400)