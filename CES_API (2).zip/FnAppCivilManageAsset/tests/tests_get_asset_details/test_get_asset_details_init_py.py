#test_get_asset_details_init_py.py

import sys
import os
import unittest
from unittest import mock
from unittest.mock import patch, Mock, MagicMock, create_autospec
from test.support import EnvironmentVarGuard
import azure.functions as func
from tests.load_environment_variables import EnvironmentVariable
EnvironmentVariable()
from getAssetDetails import main

class GetAssetDetailsInitTest(unittest.TestCase):
        
    @patch('getAssetDetails.bu.GetAssetIndividualDetails')
    def test_init_return_ok(self, mocked):
        mocked_value = '{"region": "Southern", "assetdesc": "GREAT SUFFOLK STREET VIADUCT ARCHES 22 - 31A", "route": "Kent", "area": "London Bridge", "ralway_id": "W63", "asset_type": "Viaduct", "op_status": 252, "elr": "NTL", "start_mileage": 0.875, "end_mileage": null, "prim_material": 13, "owning_party": "Network Rail (CE-Struct)", "gps_start": null, "gps_end": null, "stuct_carry": null, "struct_over": null, "hce_flag": "No", "asset_guid": "3978559C2D8345D9E04400306E4AD01A", "total_defect_cnt": null, "open_defect_cnt": null, "picture_uri": null, "cmi_score": 71, "ve_comp_stat": null, "de_comp_stat": null, "uw_comp_stat": null}'
        mocked.return_value.get_asset_info_by_requestype.return_value = mocked_value, 200
        http_request = func.HttpRequest(
            method='GET',
            body=None,
            url='/my_function', 
            params={'requestType': 'getcommonassetdetails',
            'assetGuid':'3978559C2D8345D9E04400306E4AD01A'}
        )

        response = main(http_request)

        self.assertEqual(response.status_code, 200)
        self.assertEqual(
            response.get_body(),
            b'{"region": "Southern", "assetdesc": "GREAT SUFFOLK STREET VIADUCT ARCHES 22 - 31A", "route": "Kent", "area": "London Bridge", "ralway_id": "W63", "asset_type": "Viaduct", "op_status": 252, "elr": "NTL", "start_mileage": 0.875, "end_mileage": null, "prim_material": 13, "owning_party": "Network Rail (CE-Struct)", "gps_start": null, "gps_end": null, "stuct_carry": null, "struct_over": null, "hce_flag": "No", "asset_guid": "3978559C2D8345D9E04400306E4AD01A", "total_defect_cnt": null, "open_defect_cnt": null, "picture_uri": null, "cmi_score": 71, "ve_comp_stat": null, "de_comp_stat": null, "uw_comp_stat": null}',
        )

    