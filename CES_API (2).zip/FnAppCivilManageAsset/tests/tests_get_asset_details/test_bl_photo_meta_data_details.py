#test_bl_photo_meta_data_details.py

import sys
import os
import unittest
from unittest import mock
from unittest.mock import patch, Mock, MagicMock, create_autospec
import azure.functions as func
sys.path.insert(0,os.getcwd())
from tests.load_environment_variables import EnvironmentVariable
EnvironmentVariable()
from getAssetDetails.business_logic.get_asset_details_photometadata_business_logic import AssetPhotoMetaDataDetails

class GetPhotoMetaAssetDetailsBusinessLogicTest(unittest.TestCase):

    @patch('getAssetDetails.bu.photometadata.SqlOperation')
    def test_sql_photometadata_asset_details(self, mocked):
        photo_meta_data_asset_details = [['[{"defect":{"exam_date":"2011-06-10","exam_type":"Visual","exam_id":361831},"img":null},{"defect":{"exam_date":"2011-08-15","exam_type":"Detailed","exam_id":317671},"img":null},{"defect":{"exam_date":"2013-09-25","exam_type":"Visual","exam_id":2376690},"img":null},{"defect":{"exam_date":"2014-09-04","exam_type":"Visual","exam_id":6045906},"img":null},{"defect":{"exam_date":"2015-07-10","exam_type":"Visual","exam_id":7008775},"img":null},{"defect":{"exam_date":"2016-06-24","exam_type":"Visual","exam_id":8014339},"img":null},{"defect":{"exam_date":"2017-06-09","exam_type":"Detailed","exam_id":9019493},"img":null},{"defect":{"exam_date":"2019-05-31","exam_type":"Visual","exam_id":11031935},"img":null},{"defect":{"exam_date":"2020-01-11","exam_type":"Additional","exam_id":2964811},"img":null},{"defect":{"exam_date":"2020-06-21","exam_type":"Additional","exam_id":3013501},"img":null}]']]
        mocked.return_value.fetch_all.return_value = photo_meta_data_asset_details
        response, status_code = AssetPhotoMetaDataDetails().get_asset_info('3978559C2D8345D9E04400306E4AD01A')
        self.assertEqual(status_code, 200)
        self.assertEqual(response, '[{"defect":{"exam_date":"2011-06-10","exam_type":"Visual","exam_id":361831},"img":null},{"defect":{"exam_date":"2011-08-15","exam_type":"Detailed","exam_id":317671},"img":null},{"defect":{"exam_date":"2013-09-25","exam_type":"Visual","exam_id":2376690},"img":null},{"defect":{"exam_date":"2014-09-04","exam_type":"Visual","exam_id":6045906},"img":null},{"defect":{"exam_date":"2015-07-10","exam_type":"Visual","exam_id":7008775},"img":null},{"defect":{"exam_date":"2016-06-24","exam_type":"Visual","exam_id":8014339},"img":null},{"defect":{"exam_date":"2017-06-09","exam_type":"Detailed","exam_id":9019493},"img":null},{"defect":{"exam_date":"2019-05-31","exam_type":"Visual","exam_id":11031935},"img":null},{"defect":{"exam_date":"2020-01-11","exam_type":"Additional","exam_id":2964811},"img":null},{"defect":{"exam_date":"2020-06-21","exam_type":"Additional","exam_id":3013501},"img":null}]')

    @patch('getAssetDetails.bu.photometadata.SqlOperation.fetch_all')
    def test_sql_photometadataasset_details_exception_case(self, mocked):
        mocked.side_effect = ConnectionError
        try:
            AssetPhotoMetaDataDetails().get_asset_info('3978559C2D8345D9E04400306E4AD01A')
        except ConnectionError:
            pass
        except Exception:
            self.fail('unexpected exception raised')
        else:
            self.fail('ExpectedException not raised')

    @patch('getAssetDetails.bu.photometadata.SqlOperation.fetch_all')
    def test_sql_photometadata_asset_details_json_parse_not_succes(self, sql_mocked):
        photo_meta_data_asset_details = None
        sql_mocked.return_value = photo_meta_data_asset_details
        response, status_code = AssetPhotoMetaDataDetails().get_asset_info('3978559C2D8345D9E04400306E4AD01A')
        self.assertEqual(status_code, 204)
        self.assertEqual(response, '{}')

    def test_sql_photo_meta_data_asset_details_asset_guid_none(self):
        response, status_code = AssetPhotoMetaDataDetails().get_asset_info(None)
        self.assertEqual(status_code, 400)