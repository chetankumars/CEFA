#test_bl_access_assest_details.py

import sys
import os
import unittest
from unittest import mock
from unittest.mock import patch
from test.support import EnvironmentVarGuard
import azure.functions as func
import json
from tests.load_environment_variables import EnvironmentVariable
EnvironmentVariable()
from getAssetDetails.business_logic.get_asset_details_accessddata_business_logic import AssetAccessDetails

class GetAccessAssetDetailsBusinessLogicTest(unittest.TestCase):

    @patch('getAssetDetails.bu.accessdata.SqlOperation')
    def test_sql_access_asset_details(self, mocked):
        access_asset_details = ['{"possession": null, "rrv": null, "ladder": null, "confined_space": null, "3rd_party": null, "line_block": null, "mewp": null, "scaffold": null, "water_permit": null, "traffic_mngt": null, "rope_access": null, "cctv": null, "saftey_boat": null}']
        mocked.return_value.fetch_one.return_value = access_asset_details
        response, status_code = AssetAccessDetails().get_asset_info('3978559C2D8345D9E04400306E4AD01A')
        self.assertEqual(status_code, 200)
        self.assertEqual(response, '{"possession": null, "rrv": null, "ladder": null, "confined_space": null, "3rd_party": null, "line_block": null, "mewp": null, "scaffold": null, "water_permit": null, "traffic_mngt": null, "rope_access": null, "cctv": null, "saftey_boat": null}')

    @patch('getAssetDetails.bu.accessdata.SqlOperation.fetch_one')
    def test_sql_access_asset_details_exception_case(self, mocked):
        mocked.side_effect = ConnectionError
        try:
            AssetAccessDetails().get_asset_info('3978559C2D8345D9E04400306E4AD01A')
        except ConnectionError:
            pass
        except Exception:
            self.fail('unexpected exception raised')
        else:
            self.fail('ExpectedException not raised')

    @patch('getAssetDetails.bu.accessdata.SqlOperation.fetch_one')
    def test_sql_access_asset_details_json_parse_not_success(self, sql_mocked):
        access_asset_details = ['{"possession": {null, "rrv": null, "ladder": null, "confined_space": null, "3rd_party": null, "line_block": null, "mewp": null, "scaffold": null, "water_permit": null, "traffic_mngt": null, "rope_access": null, "cctv": null, "saftey_boat": null}']
        sql_mocked.return_value = access_asset_details
        response, status_code = AssetAccessDetails().get_asset_info('3978559C2D8345D9E04400306E4AD01A')
        self.assertEqual(status_code, 204)
        self.assertEqual(response, '{}')

    def test_sql_access_asset_details_asset_guid_none(self):
        response, status_code = AssetAccessDetails().get_asset_info(None)
        self.assertEqual(status_code, 400)