# test_asset_history_cleansing_details.py

import sys
import os
import unittest
from unittest import mock
from unittest.mock import patch
from test.support import EnvironmentVarGuard
import azure.functions as func
import json
from tests.load_environment_variables import EnvironmentVariable
EnvironmentVariable()

from getAssetDetails.business_logic.get_asset_history_cleansingdata_business_logic import AssetHistoryCleansing

class GetAsseHistoryCleansingBusinessLogicTest(unittest.TestCase):

    @patch('getAssetDetails.bu.cleansingdata.SqlOperation')
    def test_sql_asset_cleansing_details(self, mocked):
        asset_history_cleansing = ['{"carrs_data": {"asset_guid": "3978559C2D8E45D9E04400306E4AD01A", "railway_id": "388A", "start_mileage": 1.5506, "end_mileage": 1.5506, "asset_group": "Bridge", "asset_type": "Underline Bridge", "area": "London Bridge", "elr": "HHH", "asset_desc": "OSTEND PLACE (METS)  (Arch 120)", "primary_material": " RBE - Brick", "os_grid_ref": "TQ32097897", "hce_flag": "No"}, "bridge_data": {"asset_guid": null, "railway_id": null, "start_mileage": null, "end_mileage": null, "asset_group": null, "asset_type": null, "area": null, "elr": null, "asset_desc": null, "primary_material": null, "os_grid_ref": null, "hce_flag": null}, "discrepancy": {"asset_guid": "Yes", "railway_id": "Yes", "start_mileage": "Yes", "end_mileage": "Yes", "asset_group": "Yes", "asset_type": "Yes", "area": "Yes", "elr": "Yes", "asset_desc": "Yes", "primary_material": "Yes", "os_grid_ref": "Yes", "hce_flag": "Yes"}}']
        mocked.return_value.fetch_one.return_value = asset_history_cleansing
        response, status_code = AssetHistoryCleansing().get_asset_info('3978559C2D8345D9E04400306E4AD01A')
        self.assertEqual(status_code, 200)
    
    @patch('getAssetDetails.bu.cleansingdata.SqlOperation.fetch_one')
    def test_sql_asset_cleansing_details_exception_case(self, mocked):
        mocked.side_effect = ConnectionError
        try:
            AssetHistoryCleansing().get_asset_info('3978559C2D8345D9E04400306E4AD01A')
        except ConnectionError:
            pass
        except Exception:
            self.fail('unexpected exception raised')
        else:
            self.fail('ExpectedException not raised')


    @patch('getAssetDetails.bu.cleansingdata.SqlOperation.fetch_one')
    def test_sql_asset_cleansing_details_json_parse_not_success(self, sql_mocked):
        asset_history_cleansing = None
        sql_mocked.return_value = asset_history_cleansing
        response, status_code = AssetHistoryCleansing().get_asset_info('3978559C2D8345D9E04400306E4AD01A')
        self.assertEqual(status_code, 204)
        self.assertEqual(response, '{}')

    def test_sql_asset_cleansing_details_asset_guid_none(self):
        response, status_code = AssetHistoryCleansing().get_asset_info(None)
        self.assertEqual(status_code, 400)