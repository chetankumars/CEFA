#test_get_asset_details_bl_common.py

import sys
import os
import unittest
from unittest import mock
from unittest.mock import patch, Mock, MagicMock, create_autospec
from test.support import EnvironmentVarGuard
import azure.functions as func
sys.path.insert(0,os.getcwd())
from tests.load_environment_variables import EnvironmentVariable
EnvironmentVariable()
from getAssetDetails.business_logic.get_asset_details import GetAssetIndividualDetails

class GetAssetDetailsBusinessLogicCommonTest(unittest.TestCase):

    @patch('getAssetDetails.bu.commondata.AssetCommonDetails')
    def test_bl_common_asset_details(self, mocked):
        common_asset_details = '{"region": "Southern", "assetdesc": "GREAT SUFFOLK STREET VIADUCT ARCHES 22 - 31A", "route": "Kent", "area": "London Bridge", "ralway_id": "W63", "asset_type": "Viaduct", "op_status": 252, "elr": "NTL", "start_mileage": 0.875, "end_mileage": null, "prim_material": 13, "owning_party": "Network Rail (CE-Struct)", "gps_start": null, "gps_end": null, "stuct_carry": null, "struct_over": null, "hce_flag": "No", "asset_guid": "3978559C2D8345D9E04400306E4AD01A", "total_defect_cnt": null, "open_defect_cnt": null, "picture_uri": null, "cmi_score": 71, "ve_comp_stat": null, "de_comp_stat": null, "uw_comp_stat": null}'
        mocked.return_value.get_asset_info.return_value = common_asset_details, 200
        response, status_code = GetAssetIndividualDetails().get_asset_info_by_requestype('getcommonassetdetails', '3978559C2D8345D9E04400306E4AD01A')
        self.assertEqual(status_code, 200)
        self.assertEqual(
            response,
            '{"region": "Southern", "assetdesc": "GREAT SUFFOLK STREET VIADUCT ARCHES 22 - 31A", "route": "Kent", "area": "London Bridge", "ralway_id": "W63", "asset_type": "Viaduct", "op_status": 252, "elr": "NTL", "start_mileage": 0.875, "end_mileage": null, "prim_material": 13, "owning_party": "Network Rail (CE-Struct)", "gps_start": null, "gps_end": null, "stuct_carry": null, "struct_over": null, "hce_flag": "No", "asset_guid": "3978559C2D8345D9E04400306E4AD01A", "total_defect_cnt": null, "open_defect_cnt": null, "picture_uri": null, "cmi_score": 71, "ve_comp_stat": null, "de_comp_stat": null, "uw_comp_stat": null}',
        )

    @patch('getAssetDetails.bu.accessdata.AssetAccessDetails')
    def test_bl_access_asset_details(self, mocked):
        access_asset_details = '{"possession": null, "rrv": null, "ladder": null, "confined_space": null, "3rd_party": null, "line_block": null, "mewp": null, "scaffold": null, "water_permit": null, "traffic_mngt": null, "rope_access": null, "cctv": null, "saftey_boat": null}'
        mocked.return_value.get_asset_info.return_value = access_asset_details, 200
        response, status_code = GetAssetIndividualDetails().get_asset_info_by_requestype('getaccessassetdetails', '3978559C2D8345D9E04400306E4AD01A')
        self.assertEqual(status_code, 200)
        self.assertEqual(
            response,
            '{"possession": null, "rrv": null, "ladder": null, "confined_space": null, "3rd_party": null, "line_block": null, "mewp": null, "scaffold": null, "water_permit": null, "traffic_mngt": null, "rope_access": null, "cctv": null, "saftey_boat": null}',
        )

    @patch('getAssetDetails.bu.photometadata.AssetPhotoMetaDataDetails')
    def test_bl_photo_meta_data_asset_details(self, mocked):
        photo_meta_data_asset_details = '[{"defect": {"exam_date": "2020-12-20", "exam_type": "Visual", "exam_id": 1}, "img": [{"img_index": 1, "img_description": "ABC", "img_name": "IMG.JPG", "img_link": "IMG.JPG"}, {"img_index": 2, "img_description": "ABC", "img_name": "IMG1.JPG", "img_link": "IMG1.JPG"}]}, {"defect": {"exam_date": "2020-12-24", "exam_type": "Visual", "exam_id": 2}, "img": [{"img_index": 1, "img_description": "DEF", "img_name": "IMG1.JPG", "img_link": "IMG1.JPG"}, {"img_index": 2, "img_description": "DEF1", "img_name": "IMG2.JPG", "img_link": "IMG2.JPG"}]}]'
        mocked.return_value.get_asset_info.return_value = photo_meta_data_asset_details, 200
        response, status_code = GetAssetIndividualDetails().get_asset_info_by_requestype('getphotometadataassetdetails', '3978559C2D8345D9E04400306E4AD01A')
        self.assertEqual(status_code, 200)
        self.assertEqual(
            response,
            '[{"defect": {"exam_date": "2020-12-20", "exam_type": "Visual", "exam_id": 1}, "img": [{"img_index": 1, "img_description": "ABC", "img_name": "IMG.JPG", "img_link": "IMG.JPG"}, {"img_index": 2, "img_description": "ABC", "img_name": "IMG1.JPG", "img_link": "IMG1.JPG"}]}, {"defect": {"exam_date": "2020-12-24", "exam_type": "Visual", "exam_id": 2}, "img": [{"img_index": 1, "img_description": "DEF", "img_name": "IMG1.JPG", "img_link": "IMG1.JPG"}, {"img_index": 2, "img_description": "DEF1", "img_name": "IMG2.JPG", "img_link": "IMG2.JPG"}]}]',
        )
    
    @patch('getAssetDetails.bu.commondata.AssetCommonDetails')
    def test_bl_invalid_request_type(self, mocked):
        response, status_code = GetAssetIndividualDetails().get_asset_info_by_requestype('invalidrequesttype', '3978559C2D8345D9E04400306E4AD01A')
        self.assertEqual(status_code, 400)