import unittest
from unittest import mock
from unittest.mock import patch
import azure.functions as func
import json
from tests.load_environment_variables import EnvironmentVariable
EnvironmentVariable()
from uploadImage.business_logic.upload_image import UploadImage

class UploadImageBusinessLogic(unittest.TestCase):

    @patch('uploadImage.business_logic.upload_image.BlobClient')
    async def test_upload_image_success(self, mocked):
        mocked.return_value.upload_blob.return_value = True
        try:
            await UploadImage().upload_blob(json.loads('{"asset_guid":"170E5F89DD1A52EDE050E70A83865BE0","asset_img_name":"170E5F89DD1A52EDE050E70A84865BE0.PNG","asset_img_path":"","user_id":""}'),'file_data','file_name.png')
            pass
        except:
            self.fail('file was not uploaded')

    
    @patch('uploadImage.business_logic.upload_image.BlobClient')
    async def test_upload_image_fail(self, mocked):
        mocked.return_value.upload_blob.return_value = True
        try:
            await UploadImage().upload_blob(json.loads('{"asset_guid":"170E5F89DD1A52EDE050E70A83865BE0","asset_name":"170E5F89DD1A52EDE050E70A84865BE0.PNG","asset_img_path":"","user_id":""}'),'file_data','file_name.png')
            self.fail('')
        except:
            pass

    @patch('uploadImage.business_logic.upload_image.BlobClient')
    @patch('uploadImage.business_logic.upload_image.SqlOperation')
    async def test_insert_file_meta_data_success(self, sql_mocked, blob_client_mocked):
        sql_mocked.return_value.fetch_one.return_value = True, ''
        blob_client_mocked.return_value.upload_blob.return_value = True
        status_code = await UploadImage().insert_file_meta_data(json.loads('{"asset_guid":"170E5F89DD1A52EDE050E70A83865BE0","asset_img_name":"170E5F89DD1A52EDE050E70A84865BE0.PNG","asset_img_path":"","user_id":""}'),'file_data', 'file_name.png')[1]
        self.assertEqual(201, status_code)
    
    @patch('uploadImage.business_logic.upload_image.BlobClient')
    @patch('uploadImage.business_logic.upload_image.SqlOperation')
    async def test_insert_file_meta_data_internal_server_error(self, sql_mocked, blob_client_mocked):
        sql_mocked.return_value.fetch_one.return_value = False, 'sql error'
        blob_client_mocked.return_value.upload_blob.return_value = True
        response, status_code = await UploadImage().insert_file_meta_data(json.loads('{"asset_guid":"170E5F89DD1A52EDE050E70A83865BE0","asset_img_name":"170E5F89DD1A52EDE050E70A84865BE0.PNG","asset_img_path":"","user_id":""}'),'file_data','file_name.png')
        self.assertEqual(500, status_code)
        self.assertEqual(response, '{"error": {"types": "UploadImage", "title": "UploadImage", "status": [500, "Internal Server Error"], "detail": "sql error", "instance": "UploadImage"}}')

    @patch('uploadImage.business_logic.upload_image.BlobClient')
    @patch('uploadImage.business_logic.upload_image.SqlOperation')
    async def test_insert_file_meta_data_nocontent(self, sql_mocked, blob_client_mocked):
        sql_mocked.return_value.fetch_one.return_value = None
        blob_client_mocked.return_value.upload_blob.return_value = True
        response, status_code = await UploadImage().insert_file_meta_data(json.loads('{"asset_guid":"170E5F89DD1A52EDE050E70A83865BE0","asset_img_name":"170E5F89DD1A52EDE050E70A84865BE0.PNG","asset_img_path":"","user_id":""}'),'file_data','file_name.png')
        self.assertEqual(204, status_code)
        self.assertEqual(response, '[]')
