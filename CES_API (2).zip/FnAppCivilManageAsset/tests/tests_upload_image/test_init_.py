import unittest
from unittest import mock
from unittest.mock import patch
import azure.functions as func
import json
from tests.load_environment_variables import EnvironmentVariable
EnvironmentVariable()
from uploadImage.business_logic.upload_image import UploadImage
from uploadImage import main

class UploadImageTest(unittest.TestCase):

    @patch('uploadImage.UploadImage')
    def test_upload_image_success(self, mocked):
        self.x_file_meta_data = '{"asset_guid":"170E5F89DD1A52EDE050E70A83865BE0","asset_img_name":"170E5F89DD1A52EDE050E70A84865BE0.PNG","asset_img_path":"","user_id":""}'
        mocked.return_value.insert_file_meta_data.return_value = "", 201
        http_request = func.HttpRequest(
            method='post',
            body =bytes('','utf-8'),
            url='/my_function', 
            params={'requestType': 'getcommonassetdetails',
            'assetGuid':'3978559C2D8345D9E04400306E4AD01A'},
            headers= {'X-File-Metadata':'{"asset_guid":"170E5F89DD1A52EDE050E70A83865BE0","asset_img_name":"170E5F89DD1A52EDE050E70A84865BE0.PNG","asset_img_path":"","user_id":""}'},   
        )

        response = main(http_request)

        self.assertEqual(response.status_code, 201)