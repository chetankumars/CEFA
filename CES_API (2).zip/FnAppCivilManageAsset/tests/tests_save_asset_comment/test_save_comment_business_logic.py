# test_save_comment_business_logic.py

import sys
import os
import unittest
from unittest import mock
from unittest.mock import patch, Mock, MagicMock, create_autospec
from test.support import EnvironmentVarGuard
import azure.functions as func
from tests.load_environment_variables import EnvironmentVariable
EnvironmentVariable()
from saveAssetComment import SaveAssetComment

class SaveAssetCommentBusinessLogicTest(unittest.TestCase):

    @patch('saveAssetComment.businesslogic.save_asset_comment.SqlOperation')
    def test_return_return_updated(self, mocked):  
        mocked_dates ='{"asset_guid": "3978559C379545D9E04400306E4AD01A","exam_type_id": 2,"comments": "comments to test","current_user_key":  "9725949A-1EB7-497E-B397-A511422AFAFE"}'
        mocked_value = ('{"save_status":1,"error_msg":null}', )
        http_request = func.HttpRequest(
            method='POST',
            body=mocked_dates.encode('utf8'),
            url='/saveAssetComment'
        )
        mocked.return_value.fetch_one.return_value  = mocked_value
        instance = SaveAssetComment()
        response = instance.save_asset_comment(http_request)
        self.assertEqual(response.status_code, 200) 

    @patch('saveAssetComment.businesslogic.save_asset_comment.SqlOperation')
    def test_return_bad_request(self, mocked):  
        mocked_dates ='{"asset_guid": "3978559C379545D9E04400306E4AD01A","exam_type_id": "2a","comments": "comments to test","current_user_key":  "9725949A-1EB7-497E-B397-A511422AFAFE"}'
        mocked_value = '{"error": {"types": "Invalid Request", "title": "Header/Param validation failure", "status": 400, "detail": "", "instance": "SaveAssetComment"}'
        http_request = func.HttpRequest(
            method='POST',
            body=mocked_dates.encode('utf8'),
            url='/saveAssetComment'
        )
        mocked.return_value.fetch_one.return_value  = mocked_value
        instance = SaveAssetComment()
        response = instance.save_asset_comment(http_request)
        self.assertEqual(response.status_code, 400) 