# test_save_comment_init_.py

import sys
import os
import unittest
from unittest import mock
from unittest import IsolatedAsyncioTestCase
from unittest.mock import patch, Mock, MagicMock, create_autospec
import azure.functions as func
from tests.load_environment_variables import EnvironmentVariable
EnvironmentVariable()
from saveAssetComment import main

class saveAssetCommentInitTest(unittest.TestCase):

    @patch('saveAssetComment.SaveAssetComment')
    async def test_init_return_ok(self, mocked):
        mocked_dates ='{"asset_guid": "3978559C379545D9E04400306E4AD01A","exam_type_id": 2,"comments": "comments to test","current_user_key":  "9725949A-1EB7-497E-B397-A511422AFAFE"}'
        mocked_value = '{"save_status": 0,"error_msg": null}'
        http_response = func.HttpResponse(status_code=200,body=mocked_value)
        mocked.return_value.save_task_list_status.return_value = http_response
        req = func.HttpRequest(
        method='POST',
        body=mocked_dates.encode('utf8'),
        url='/saveAssetComment'
        )

        resp = await main(req)
        self.assertEqual(resp.status_code, 200)
         
    
    @patch('saveAssetComment.SaveAssetComment')
    async def test_init_return_badrequest(self, mocked):
        mocked_dates ='{"asset_guid": "3978559C379545D9E04400306E4AD01A","exam_type_id": "2a","comments": "comments to test","current_user_key":  "9725949A-1EB7-497E-B397-A511422AFAFE"}'
        mocked_value = '{"save_status": 0,"error_msg": null}'
        http_response = func.HttpResponse(status_code=200,body=mocked_value)
        mocked.return_value.save_task_list_status.return_value = http_response
        req = func.HttpRequest(
        method='POST',
        body=mocked_dates.encode('utf8'),
        url='/saveAssetComment'
        )

        resp = await main(req)
        self.assertEqual(resp.status_code, 400)