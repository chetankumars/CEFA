#get_asset_details.py

import os
import sys
sys.path.insert(0, os.getcwd())
import azure.functions as func
import common
from common import AppStatus
from . import get_asset_details_commondata_business_logic as commondata 
from . import get_asset_details_accessddata_business_logic as accessdata
from . import get_asset_details_photometadata_business_logic as photometadata
from . import get_asset_history_cleansingdata_business_logic as cleansingdata
from ..constants.get_asset_details_constants import GetAssetDetailsConstants

class GetAssetIndividualDetails: 
       
    def get_asset_info_by_requestype(self, request_type:str, asset_guid:str):
        
        """
        method to return the asset infomation based on GUID and request type.
        
        Args:
            request_type (str)
            asset_guid (str)

        Returns:
            HttpResponse: http response with the asset information
        """
         
        get_assetInfo = {
            GetAssetDetailsConstants.get_history_cleansingdata_detail: [cleansingdata.AssetHistoryCleansing, asset_guid], 
            GetAssetDetailsConstants.get_common_details: [commondata.AssetCommonDetails, asset_guid], 
            GetAssetDetailsConstants.get_access_details: [accessdata.AssetAccessDetails, asset_guid], 
            GetAssetDetailsConstants.get_photometadata_details: [photometadata.AssetPhotoMetaDataDetails, asset_guid] 
        } 
    
        if request_type is not None and request_type.lower() in get_assetInfo.keys(): 
            reqtype_sel = get_assetInfo[request_type.lower()]
            return reqtype_sel[0]().get_asset_info(reqtype_sel[1])
        else:
            self.statusCode = AppStatus.bad_Request.value[0]
            self.response = common.ErrorResponse(common.SharedConstants.request_val_failure, common.SharedConstants.request_header_failure,common.AppStatus.bad_Request.value[0], GetAssetDetailsConstants.invalida_request_type, self.__class__.__name__).__str__()
            
            return self.response, self.statusCode
         