#get_asset_details_accessdata_business_logic.py

import sys
import os
import logging
import azure.functions as func
import traceback
import common
from common import Logger,CustomLog,SharedConstants,AppStatus
from common import SqlOperation
from common.utilities.json_helper import JsonHelper
from datetime import datetime, timezone
from ..constants.get_asset_details_constants import GetAssetDetailsConstants

istraceenabled = os.environ[SharedConstants.trace_enabled]

class AssetAccessDetails:
  
    """ AssetAccessDetails class to get asset access information as json response """ 
    def __init__(self):
        self.sql_query = """
                           EXEC [CES].[sp_Get_AssetDtls_AccessData]
                           @Asset_GUID = ?
                           """
        self.response = str({})
        self.statusCode = AppStatus.ok.value[0]
        self.properties = {CustomLog.get_asset_details : CustomLog.get_asset_details_val}
        self.properties[CustomLog.status] =  True
        self.properties[CustomLog.start_time] = datetime.now(timezone.utc).isoformat()
        Logger.__init__(self, name = self.__class__.__name__, start_time = datetime.now(timezone.utc))

    def get_asset_info(self, asset_guid:str):
        """
        Function to call Ces database to get asset information json based on asset guid
       
        Args:
            asset_guid (str)

        Returns:
            json(str) 
            statuscode(int)     - 204 No Content
                                - 200 Success
                                - 500 Internal Server Error 
                                - 400 BadRequest 
        """
        try:
            if asset_guid is not None:
                self.properties[CustomLog.sp_req_param] = CustomLog.asset_guid + SharedConstants.colon + asset_guid
                self.properties[CustomLog.sprequest_time] = datetime.now(timezone.utc).isoformat()
                _json_string = SqlOperation().fetch_one(self.sql_query,asset_guid)
                self.properties[CustomLog.sprequestend_time] = datetime.now(timezone.utc).isoformat()
                _json_helper = JsonHelper()
                if _json_string is not None:
                    _isparsejson_sucess,_json_obj = _json_helper.parse_json(_json_string[0])
                    if _isparsejson_sucess:
                        self.response = _json_helper.stringify_json(_json_obj)[1]
                    else:
                        self.statusCode = AppStatus.no_content.value[0]
                else:
                    self.statusCode =AppStatus.no_content.value[0] 
            else:
                self.statusCode = AppStatus.bad_Request.value[0]
                self.response = common.ErrorResponse(common.SharedConstants.request_val_failure, common.SharedConstants.request_header_failure,common.AppStatus.bad_Request.value[0], GetAssetDetailsConstants.asset_guid_empty, self.__class__.__name__).__str__()
            if istraceenabled:
                self.properties[CustomLog.end_time] = datetime.now(timezone.utc).isoformat()
                Logger.request(self,properties= self.properties)
            return self.response, self.statusCode
        except:
            self.properties[CustomLog.error_messsage] =   str(traceback.format_exc())
            self.properties[CustomLog.status] =  False
            Logger.exception(self, type= sys.exc_info()[0], value = sys.exc_info()[1], tb =sys.exc_info()[2], properties = self.properties )
            raise
        
