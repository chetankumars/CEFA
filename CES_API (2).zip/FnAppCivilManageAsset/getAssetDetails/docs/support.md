# Get asset details

## Description
Services to get asset common details, asset access details and asset photometadata details from the CSE db.

    APIM URL: https://apim-uks-dev-ces-0001.azure-api.net/II/CESAPI/assets/{assetId}[?requestType]

    FUNCTION URL: https://fnp-uks-dev-ces-funcedst0001.azurewebsites.net/api/getAssetDetails

## Request params for asset common details
    
    Request params:(APIM URL)
        assetId = 3978559C2D8345D9E04400306E4AD01A
        requestType = getcommonassetdetails
        
    Request params: (FUNCTION URL)
        assetGuid = 3978559C2D8345D9E04400306E4AD01A
        requestType = getcommonassetdetails

## Get Request for asset access details

    Request params:(APIM URL)
        assetId = 3978559C2D8345D9E04400306E4AD01A
        requestType = getaccessassetdetails
        
    Request params: (FUNCTION URL)
        assetGuid = 3978559C2D8345D9E04400306E4AD01A
        requestType = getcommonassetdetails

## Get Request for asset photometadata details

    Request params:(APIM URL)
        assetId = 3978559C2D8345D9E04400306E4AD01A
        requestType = getphotometadataassetdetails
        
    Request params: (FUNCTION URL)
        assetGuid = 3978559C2D8345D9E04400306E4AD01A
        requestType = getphotometadataassetdetails