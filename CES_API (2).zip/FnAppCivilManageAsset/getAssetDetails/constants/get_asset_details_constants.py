#get_asset_details_constants.py

__all__ = ["GetAssetDetailsConstants"]
class GetAssetDetailsConstants:
    """
    constants related to project specific

    """
    request_type = "requestType"
    asset_guid = "assetGuid"
    get_common_details = "getcommonassetdetails"
    get_access_details = "getaccessassetdetails"
    get_photometadata_details = "getphotometadataassetdetails"
    get_history_cleansingdata_detail = "getassethistorycleansingdetails"
    asset_guid_empty = "asset_guid query param is missing"
    invalida_request_type = "invalid request type query param or request type missing"