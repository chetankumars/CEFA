#__init__.py

import sys
import common
from common import SharedConstants
import azure.functions as func
from .business_logic import get_asset_details as bu
from .constants.get_asset_details_constants import GetAssetDetailsConstants

def main(req: func.HttpRequest) -> func.HttpResponse:

    """[summary]

    Args:
        req (func.HttpRequest): To Get asset details from CES DB

    Returns:
        func.HttpResponse: asset details json for get operation as response from CES DB
    """

    try:
        request_type = req.params.get(GetAssetDetailsConstants.request_type)
        asset_guid = req.params.get(GetAssetDetailsConstants.asset_guid)
        assetdetails = bu.GetAssetIndividualDetails()
        response, status_code = assetdetails.get_asset_info_by_requestype(request_type, asset_guid)
    except:
        response = common.ErrorResponse(str(sys.exc_info()[0]), bu.GetAssetIndividualDetails().__class__.__name__,common.AppStatus.internal_server_error.value, str(sys.exc_info()[1]), bu.GetAssetIndividualDetails().__class__.__name__).__str__()
        status_code = common.AppStatus.internal_server_error.value[0]
    finally:
        return func.HttpResponse(body=response,status_code=status_code, mimetype= SharedConstants.json_mime_type)

if __name__ == SharedConstants.main:
    main(func.HttpRequest)
