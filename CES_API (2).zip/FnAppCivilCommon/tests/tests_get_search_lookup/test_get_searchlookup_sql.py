#test_get_searchlookup_sql.py

import sys
import os
import json
import unittest
from unittest import mock
from unittest.mock import patch, Mock, MagicMock
import pyodbc
import pandas
import simplejson
sys.path.insert(0, os.getcwd())
from tests.load_environment_variables import EnvironmentVariable
EnvironmentVariable()
from getSearchLookup.businesslogic.get_search_lookup import SearchLookup


class SearchLookupTest(unittest.TestCase):

    @patch('getSearchLookup.businesslogic.get_search_lookup.SqlOperation')
    async def test_return_ok(self, mocked):   
        mocked_value = ['{"regions":[{"region_id":1,"region_name":"Eastern","routes":[{"route_id":1,"route_name":"Anglia","areas":[{"area_id":null,"area_name":null,"elr":[{"elr_id":null,"elr_code":null}]}]}]}],"asset_groups":[{"asg_id":1,"asg_name":"Ancilliaries","ast":[{"ast_id":13,"ast_name":"Cable Structure"}]}],"oprstats":[{"opstat_id":66,"opstat_name":"Duplicate"}],"ownparty":[{"ownparty_id":1,"ownparty_name":"CTRL"}],"mattyps":[{"mattyp_id":50,"mattyp_name":" RBE - Aluminium"}],"hceflg":[{"hceflg_id":1,"hceflg_name":"Yes"}],"strccarries":[{"strccarries_id":1,"strccarries_name":null}],"strcover":[{"strcover_id":1,"strcover_name":null}]}']
        mocked.return_value.fetch_one.return_value  = mocked_value
        userId = 1
        instance = SearchLookup(userId)
        response = await instance.get_search_lookup()
        self.assertEqual(response.status_code, 200)
        self.assertEqual(
            response.get_body(),
            b'{"regions": [{"region_id": 1, "region_name": "Eastern", "routes": [{"route_id": 1, "route_name": "Anglia", "areas": [{"area_id": null, "area_name": null, "elr": [{"elr_id": null, "elr_code": null}]}]}]}], "asset_groups": [{"asg_id": 1, "asg_name": "Ancilliaries", "ast": [{"ast_id": 13, "ast_name": "Cable Structure"}]}], "oprstats": [{"opstat_id": 66, "opstat_name": "Duplicate"}], "ownparty": [{"ownparty_id": 1, "ownparty_name": "CTRL"}], "mattyps": [{"mattyp_id": 50, "mattyp_name": " RBE - Aluminium"}], "hceflg": [{"hceflg_id": 1, "hceflg_name": "Yes"}], "strccarries": [{"strccarries_id": 1, "strccarries_name": null}], "strcover": [{"strcover_id": 1, "strcover_name": null}]}'
        )  


    @patch('getSearchLookup.businesslogic.get_search_lookup.SqlOperation')
    async def test_return_partial_content(self, mocked):   
        mocked_value = ['{"regions":[{"region_id":1,"region_name":"Eastern","routes":[{"route_id":1,"route_name":"Anglia","areas":[{"area_id":null,"area_name":null,"elr":[{"elr_id":null,"elr_code":null}]}]}]}],"asset_groups":[{"asg_id":1,"asg_name":"Ancilliaries","ast":[{"ast_id":13,"ast_name":"Cable Structure"}]}],"oprstats":[{"opstat_id":66,"opstat_name":"Duplicate"}],"ownparty":[{"ownparty_id":1,"ownparty_name":"CTRL"}],"mattyps":[{"mattyp_id":50,"mattyp_name":" RBE - Aluminium"}],"hceflg":[{"hceflg_id":1,"hceflg_name":"Yes"}],"strccarries":[{"strccarries_id":1,"strccarries_name":null}]}']
        mocked.return_value.fetch_one.return_value  = mocked_value
        userId = 1
        instance = SearchLookup(userId)
        response = await instance.get_search_lookup()
        self.assertEqual(response.status_code, 206)
        self.assertEqual(
            response.get_body(),
            b'{"regions": [{"region_id": 1, "region_name": "Eastern", "routes": [{"route_id": 1, "route_name": "Anglia", "areas": [{"area_id": null, "area_name": null, "elr": [{"elr_id": null, "elr_code": null}]}]}]}], "asset_groups": [{"asg_id": 1, "asg_name": "Ancilliaries", "ast": [{"ast_id": 13, "ast_name": "Cable Structure"}]}], "oprstats": [{"opstat_id": 66, "opstat_name": "Duplicate"}], "ownparty": [{"ownparty_id": 1, "ownparty_name": "CTRL"}], "mattyps": [{"mattyp_id": 50, "mattyp_name": " RBE - Aluminium"}], "hceflg": [{"hceflg_id": 1, "hceflg_name": "Yes"}], "strccarries": [{"strccarries_id": 1, "strccarries_name": null}]}'
        )      
         


    @patch('getSearchLookup.businesslogic.get_search_lookup.SqlOperation')
    async def test_return_no_content_When_null_response(self, mocked):
        mocked_value = None
        mocked.return_value.fetch_one.return_value  = mocked_value
        userId = 1
        instance = SearchLookup(userId)
        response = await instance.get_search_lookup()
        self.assertEqual(response.status_code, 204)
        self.assertEqual(
            response.get_body(),
            b'{}'
        )  
   
    @patch('getSearchLookup.businesslogic.get_search_lookup.SqlOperation')
    async def test_return_no_content_when_invalid_json_response(self, mocked):
        mocked_value = None
        mocked.return_value.fetch_one.return_value  = mocked_value
        userId = 1
        instance = SearchLookup(userId)
        response = await instance.get_search_lookup()
        self.assertEqual(response.status_code, 204)
        self.assertEqual(
            response.get_body(),
            b'{}'
        )

    async def test_return_bad_request(self):
        userId = None
        instance = SearchLookup(userId)
        response = await instance.get_search_lookup()
        self.assertEqual(response.status_code, 400)
        self.assertEqual(
            response.get_body(),
            b'{"error": {"types": "Invalid Request", "title": "Header/Param validation failure", "status": 400, "detail": "userId is missing", "instance": "SearchLookup"}}'
        )      


    async def test_return_internal_server_error_exception(self):
        userId = 1
        instance = SearchLookup(userId)
        response = await instance.get_search_lookup()
        self.assertEqual(response.status_code, 500)        
        self.assertEqual(
            response.get_body(),
            b'{}'
        )   

if __name__ == '__main__':
    unittest.main()
