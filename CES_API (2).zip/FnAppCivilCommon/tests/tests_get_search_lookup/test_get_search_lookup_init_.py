#test_get_search_lookup_init_.py

import sys
import os
import unittest
from unittest import mock
from unittest.mock import patch, Mock, MagicMock, create_autospec
from test.support import EnvironmentVarGuard
import azure.functions as func
sys.path.insert(0, os.getcwd())
from tests.load_environment_variables import EnvironmentVariable
EnvironmentVariable()
from getSearchLookup import main

class SearchLookUpInitTest(unittest.TestCase):
    
    @patch('getSearchLookup.SearchLookup')
    def test_init_return_ok(self, mocked):
        mocked_value = '{"regions":[{"region_id":1,"region_name":"Eastern","routes":[{"route_id":1,"route_name":"Anglia","areas":[{"area_id":null,"area_name":null,"elr":[{"elr_id":null,"elr_code":null}]}]}]}],"asset_groups":[{"asg_id":1,"asg_name":"Ancilliaries","ast":[{"ast_id":13,"ast_name":"Cable Structure"}]}],"oprstats":[{"opstat_id":66,"opstat_name":"Duplicate"}],"ownparty":[{"ownparty_id":1,"ownparty_name":"CTRL"}],"mattyps":[{"mattyp_id":50,"mattyp_name":" RBE - Aluminium"}],"hceflg":[{"hceflg_id":1,"hceflg_name":"Yes"}],"strccarries":[{"strccarries_id":1,"strccarries_name":null}]}'
        http_response = func.HttpResponse(status_code=200,body=mocked_value)
        mocked.return_value.get_search_lookup.return_value = http_response
        http_request = func.HttpRequest(
            method='GET',
            body=None,
            url='/getSearchLookup', 
            params={'userId': '123'}
        )

        response = main(http_request)

        self.assertEqual(response.status_code, 200)
        self.assertEqual(
            response.get_body(),
            b'{"regions":[{"region_id":1,"region_name":"Eastern","routes":[{"route_id":1,"route_name":"Anglia","areas":[{"area_id":null,"area_name":null,"elr":[{"elr_id":null,"elr_code":null}]}]}]}],"asset_groups":[{"asg_id":1,"asg_name":"Ancilliaries","ast":[{"ast_id":13,"ast_name":"Cable Structure"}]}],"oprstats":[{"opstat_id":66,"opstat_name":"Duplicate"}],"ownparty":[{"ownparty_id":1,"ownparty_name":"CTRL"}],"mattyps":[{"mattyp_id":50,"mattyp_name":" RBE - Aluminium"}],"hceflg":[{"hceflg_id":1,"hceflg_name":"Yes"}],"strccarries":[{"strccarries_id":1,"strccarries_name":null}]}',
        )
    
    