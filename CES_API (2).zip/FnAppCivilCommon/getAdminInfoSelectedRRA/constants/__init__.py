#__init__.py

from .admin_info_constants import AdminInfoConstants