#admin_info_constants.py

__all__ = ["AdminInfoConstants"]
class AdminInfoConstants:
    """
    constants related to project specific

    """
    sp_input_json = "Input_JSON"
    invalid_request = "Invalid userID/currentUser"
    rra_filter = 'X-RRA-AdminUser-Filters'
    param_failure = "Header X-RRA-AdminUser-Filters is missing"
    