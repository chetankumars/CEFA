#search_request_schema.py

from marshmallow import fields,Schema

__all__ =['UserSchema']
class UserSchema(Schema):
    region_name = fields.String(required=True,default='abc')
    route_id = fields.Integer(required=True,default=1) 
    area_id = fields.Integer(required=True,default=1)
  


