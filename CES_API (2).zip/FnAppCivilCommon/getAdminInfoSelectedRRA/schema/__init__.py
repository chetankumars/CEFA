#__init__.py

from .search_request_schema import UserSchema
