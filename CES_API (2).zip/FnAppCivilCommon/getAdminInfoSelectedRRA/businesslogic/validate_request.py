#validate_request.py

import sys
import os
from common import JsonHelper
from ..constants import AdminInfoConstants

__all__ = ['ValidateRequest']
class ValidateRequest:

    """ ValidateRequest class to validate the request json """ 
    def __init__(self, admin_data_schema):
        self.admin_data_schema = admin_data_schema
        self.json_helper = JsonHelper()

    def is_valid_payload(self, admin_data_req):
        """ To validate incoming request

        Args:
            self ([ValidateRequest]): [self instance]
            admin_data_req: json
        Returns:
            [tuple]: [bool represent the schema validation was successful or not and error message for validation failure scenario]

        """
        try:
            return True, self.admin_data_schema.dump(self.admin_data_schema.loads(admin_data_req))
        except:
            (excepclass, errormessage, trackback) = sys.exc_info()
            return False, errormessage