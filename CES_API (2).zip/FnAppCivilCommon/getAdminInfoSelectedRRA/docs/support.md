# Search Admin Information for RRA search 

## Provides the information of users (user ID) for RRA search 
    APIM URL : https://apim-uks-dev-ces-0001.azure-api.net/II/CESAPI/lookups/search
    FUNCTION URL : https://fnp-uks-nprd-ii-fncesdev0002.azurewebsites.net/api/getAdminInfoSelectedRRA
    Method Type:  GET
    Request headers:
        Header Name : X-RRA-AdminUser-Filters
        Sample Value :{"region_name": "Wales and Western","route_id": 13,"area_id": 17}
    Sample Response:    
        {
            "searchdatacount": 18,
            "user_ids": [
                4,
                5,
                6,
                9,
                11,
                12,
                13,
                14,
                15,
                16,
                17,
                18,
                19,
                20,
                22,
                23,
                8,
                7
            ]
        }

        "error": {
            "types": "Invalid Request",
            "title": "Header/Param validation failure",
            "status": 400,
            "detail": "{'region_name': ['Missing data for required field.'], 'region_nme': ['Unknown field.']}",
            "instance": "AdminInfoForRRA"
    }