#tokengen.py
from .token_descriptor import TokenDescriptor

__all__ = ['GenToken']
class GenToken:
    validation_token = TokenDescriptor()