# Get search lookup

## Description
Services to get searchlookup data from the CSE db.

    APIM URL: https://apim-uks-dev-ces-0001.azure-api.net/II/CESAPI/lookups/basicandadvancesearch[?userId]

    FUNCTION URL: https://fnp-uks-dev-ces-funcedst0001.azurewebsites.net/api/getSearchLookup?userId=

## Request params for search lookup
    
    Request params:(APIM URL)
        userId = 123
        
    Request params:(APIM URL)
        userId = 123

