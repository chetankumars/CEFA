#get_search_lookup_constants.py

__all__ = ["GetSearchLookUpConstants"]
class GetSearchLookUpConstants:
    """
    constants related to project specific

    """
    user_id = "User_ID"
    get_search_lookup = "getSearchLookup"
    search_lookup_response_schema = "searchlookup_response.json"
    search_lookup_bad_request_msg = "userId is missing"
    req = "userId"