#__init__.py
import azure.functions as func
from .businesslogic import SearchLookup
from common import SharedConstants
from .constants.get_search_lookup_constants import GetSearchLookUpConstants

def main(req: func.HttpRequest) -> func.HttpResponse:
    """[summary]

    Args:
        req (func.HttpRequest): Calling SearchLookup class to get the http response

    Returns:
        func.HttpResponse: searchlookup json from CES DB
    """
    response  =  SearchLookup(req.params.get(GetSearchLookUpConstants.req)).get_search_lookup()
    return response

if __name__ == SharedConstants.main :
    main(func.HttpRequest)
