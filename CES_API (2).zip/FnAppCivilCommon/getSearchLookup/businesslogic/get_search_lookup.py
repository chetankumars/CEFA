#get_search_lookup.py

import sys
import os
import logging
import azure.functions as func
sys.path.insert(0, os.getcwd())
from common import SqlOperation,Logger,JsonHelper,ValidationHelper,CustomLog,SharedConstants,AppStatus,ErrorResponse
from getSearchLookup.constants.get_search_lookup_constants import GetSearchLookUpConstants
from datetime import datetime, timezone 

istraceenabled = os.environ[SharedConstants.trace_enabled]

__all__ = ['SearchLookup']

class SearchLookup:
  
    """ search lookup class to get basic and advance search json response """ 
    def __init__(self, user_id):
        self.user_id = user_id
        self.sql_query = """
                           EXEC [CES].[sp_Get_AssetSearch_UserFilterData]
                           @User_ID = ?
                           """
        self.response = str({})
        self.status_code = AppStatus.ok.value[0]
        self.properties = {CustomLog.search_lookup : CustomLog.search_lookup_val}
        self.properties[CustomLog.start_time] = datetime.now(timezone.utc).isoformat()
        Logger.__init__(self, name = SearchLookup.__name__, start_time = datetime.now(timezone.utc))
        self.properties[CustomLog.status] = True
        self.json_helper = JsonHelper()


    def validate_response(self,json_obj):
        """
        Function to validate the response recieved from database
       
        Args:
            json_obj
        """
        ispartialjson = False 
        with open(os.path.join(os.getcwd(), GetSearchLookUpConstants.get_search_lookup,
                  SharedConstants.schema, GetSearchLookUpConstants.search_lookup_response_schema), SharedConstants.file_read_mode) as json_file:
            _schema = self.json_helper.parse_json(json_file.read())
        ispartialjson, errors = ValidationHelper().validate_json(json_obj,_schema[1])
        if ispartialjson:
            self.properties[CustomLog.schema_errors] =  self.json_helper.stringify_json(errors)
            self.status_code = AppStatus.partial_content.value[0]
        self.response = self.json_helper.stringify_json(json_obj)[1]


    def get_search_lookup(self)-> func.HttpResponse:
        """
        Function to call Ces database to get basic and advance search json based on user
       
        Args:

        Returns:
            HttpResponse 
            status_code(int)    - 204 No Content
                                - 200 Success
                                - 206 Partial Content   
                                - 500 Internal Server Error 
        """
        try:
            if self.user_id is not None:
                self.properties[CustomLog.sprequest_time] = datetime.now(timezone.utc).isoformat()
                self.properties[CustomLog.sp_req_param] = GetSearchLookUpConstants.user_id + ":" + str(self.user_id)
                json_string = SqlOperation().fetch_one(self.sql_query,self.user_id)
                self.properties[CustomLog.sprequestend_time] = datetime.now(timezone.utc).isoformat()
                isparsejson_sucess, json_obj = self.json_helper.parse_json(json_string[0] if json_string else None)
                if isparsejson_sucess: self.validate_response(json_obj)
                else:  self.status_code = AppStatus.no_content.value[0] 
            else:
                self.status_code = AppStatus.bad_Request.value[0]
                self.response = ErrorResponse(SharedConstants.request_val_failure,SharedConstants.request_header_failure,
                                              AppStatus.bad_Request.value[0], GetSearchLookUpConstants.search_lookup_bad_request_msg,
                                              SearchLookup.__name__).__str__()        
        except:
            self.properties[CustomLog.error_messsage] =  str(sys.exc_info())
            self.status_code = AppStatus.internal_server_error.value[0]
            self.properties[CustomLog.status] = False
            Logger.exception(self, type= sys.exc_info()[0], value = sys.exc_info()[1], tb =sys.exc_info()[2], properties = self.properties )
            self.response = ErrorResponse(sys.exc_info()[0], SearchLookup.__name__,
                                 self.status_code, sys.exc_info()[2],SearchLookup.__name__).__str__()
        finally:
            if istraceenabled:
                self.properties[CustomLog.end_time] = datetime.now(timezone.utc).isoformat()
                Logger.request(self,properties= self.properties)
            return func.HttpResponse(body=self.response,status_code= self.status_code, mimetype= SharedConstants.json_mime_type)
 
  