#save_request_schema.py

from marshmallow import fields, validate,Schema

__all__ =['SaveRequestSchema']
class UserSchema(Schema):
    region_name = fields.String(required=False,default='abc')
    route_id = fields.Integer(required=False,default=1) 
    area_id = fields.Integer(required=False,default=1)
  
class SaveRequestSchema(Schema):
    user_id = fields.Int(required=True)
    supplier_id = fields.Int(required=False,default=1)
    is_new_user = fields.Str(required=True,validate=validate.OneOf(['Y','N']))
    current_user_key =  fields.String(required=False,default='BDFD2401-040F-4250-B506-444A7684C9AC')
    user_default_rra = fields.List(fields.Nested(UserSchema), required=True)
    user_selected_rra = fields.List(fields.Nested(UserSchema), required=True)

class UISchema(SaveRequestSchema):
    user_key = fields.String(required=True,default='BDFD2401-040F-4250-B506-444A7684C9AC')
    role_id = fields.Int(required=True,default=1)

