#admin_user_information.py

import sys
import os
import logging
import azure.functions as func
from common import SqlOperation, Logger, JsonHelper,CustomLog, AppStatus, SharedConstants,ErrorResponse
from datetime import datetime, timezone
import traceback
import json
from ..schema import SaveRequestSchema,UserSchema
from .validate_request import ValidateRequest
from ..constants import AdminInfoConstants

istraceenabled = os.environ[SharedConstants.trace_enabled]

class AdminInformation:
    """ AdminInformation class to  save/update/get/delete the admin user information"""
    def __init__(self):
        
        self.sql_query_get = """
                            EXEC [CES].sp_Get_Admin_UserRRAInfo
                            @User_ID = ?
                           """
        self.sql_query_post = """
                            EXEC [CES].sp_Save_Admin_UserRRA
                            @Input_JSON = ?
                           """
        self.sql_query_delete = """
                            EXEC [CES].sp_Delete_Admin_UserRRA
                            @User_Id = ?, @Current_User_Key = ?
                           """
        self.response_message = str({})
        self.status_code = AppStatus.ok.value[0]
        self.properties = {CustomLog.admin_information : CustomLog.admin_information_val}
        self.properties[CustomLog.start_time] = datetime.now(timezone.utc).isoformat()
        Logger.__init__(self, name = self.__class__.__name__, start_time = datetime.now(timezone.utc))
        self.properties[CustomLog.status] = True
        self._json_helper = JsonHelper()
        self.response = str({})
    
    def process_data(self,req: func.HttpRequest)-> func.HttpResponse:
        """
        Function to call Operation Method
       
        Args:
            self ([AdminInformation]): [self instance]
            req: Http Request data (Json data)
        Returns:
            HttpResponse
            status_code(int)    - 200 Success
                                - 204 No Content
                                - 201 Created
                                - 500 Internal Server Error
                                - 400 Bad Request 
        """
        try:
            if req.method == SharedConstants.method_type_get:
                return self.get_data(req)
            if req.method == SharedConstants.method_type_post:
                self.status_code = AppStatus.record_created.value[0]
                return self.save_data(req)
            if req.method == SharedConstants.method_type_delete:
                return self.delete_data(req)
        except:
            self.properties[CustomLog.error_messsage] =  str(traceback.format_exc())
            self.properties[CustomLog.status] = False
            Logger.exception( self,type= sys.exc_info()[0], value = sys.exc_info()[1], tb =sys.exc_info()[2], properties = self.properties )
            self.status_code = AppStatus.internal_server_error.value[0]
            error_response = ErrorResponse(SharedConstants.request_val_failure,AdminInformation.__name__,
                                            self.status_code, str(sys.exc_info()[1]),
                                            AdminInformation.__name__,).__str__()
            self.response = func.HttpResponse(body= error_response, status_code= self.status_code, mimetype= SharedConstants.json_mime_type)
        finally:
            if istraceenabled:
                self.properties[CustomLog.end_time] = datetime.now(timezone.utc).isoformat() 
                Logger.request(self,properties= self.properties) 
            return self.response

    

    def Operation_Data(self,sql_query,params):
        """
        Function to call Ces database to save/delete/get admin user information
       
        Args:
            self ([AdminInformation]): [self instance]
            sql_query: SQL SP
            params:parameter to pass into sql SP
        
        """
        self.properties[CustomLog.sprequest_time] = datetime.now(timezone.utc).isoformat()
        _json_string =  SqlOperation().fetch_one(sql_query,params)
        self.properties[CustomLog.sprequestend_time] = datetime.now(timezone.utc).isoformat()
        if _json_string is not None:
            _isparsejson_sucess,_json_obj = self._json_helper.parse_json(_json_string[0])
            if _isparsejson_sucess:
                self.response_message = self._json_helper.stringify_json(_json_obj)[1]
                self.response = func.HttpResponse(body= self.response_message, status_code= self.status_code, mimetype= SharedConstants.json_mime_type) 
            else:
                self.status_code = AppStatus.no_content.value[0]
                self.response = func.HttpResponse(body= self.response_message, status_code= self.status_code, mimetype= SharedConstants.json_mime_type) 
        else:
            self.status_code = AppStatus.no_content.value[0]
            self.response = func.HttpResponse(body= self.response_message, status_code= self.status_code, mimetype= SharedConstants.json_mime_type)

    def save_data(self, req):
        """
        Function to call Operation Data
       
        """
        admin_info_req = req.get_json()
        is_valid_payload, return_object =  ValidateRequest(SaveRequestSchema()).is_valid_payload(self._json_helper.stringify_json(admin_info_req)[1])
        if is_valid_payload:
            self.admin_data_json = self._json_helper.stringify_json(return_object)
            self.properties[CustomLog.sp_req_param] = AdminInfoConstants.sp_input_json + SharedConstants.colon + self.admin_data_json[1]
            self.Operation_Data(self.sql_query_post,self.admin_data_json[1])
        else:
            self.status_code = AppStatus.bad_Request.value[0]
            self.response_message = ErrorResponse(SharedConstants.request_val_failure,SharedConstants.request_header_failure,self.status_code, str(return_object),AdminInformation.__name__).__str__()
            self.response = func.HttpResponse(body= self.response_message, status_code= self.status_code, mimetype= SharedConstants.json_mime_type)

    def get_data(self,req: func.HttpRequest)-> func.HttpResponse:
        """
        Function to call Operation Data
        """
        user_id = req.params.get(AdminInfoConstants.user_id)
        if user_id is not None:
            self.properties[CustomLog.sp_req_param] = AdminInfoConstants.user_id + SharedConstants.colon + str(user_id)
            self.Operation_Data(self.sql_query_get,str(user_id))
        else:
            self.status_code = AppStatus.bad_Request.value[0]
            self.response_message = ErrorResponse(SharedConstants.request_val_failure,SharedConstants.request_header_failure,self.status_code,AdminInfoConstants.invalid_user_id,AdminInformation.__name__).__str__()
            self.response = func.HttpResponse(body= self.response_message, status_code=self.status_code, mimetype= SharedConstants.json_mime_type) 
    
    def delete_data(self,req: func.HttpRequest)-> func.HttpResponse:
        """
        Function to call Operation Data
        """
        user_id = req.params.get(AdminInfoConstants.user_id)
        current_user = req.params.get(AdminInfoConstants.current_user)
        if user_id is not None and current_user is not None:
            sp_param = str(user_id), str(current_user)
            self.properties[CustomLog.sp_req_param] = AdminInfoConstants.user_id + SharedConstants.colon + str(user_id) + SharedConstants.comma + AdminInfoConstants.current_user + SharedConstants.colon + str(current_user)
            self.Operation_Data(self.sql_query_delete,sp_param)
        else:
            self.status_code = AppStatus.bad_Request.value[0]
            self.response_message = ErrorResponse(SharedConstants.request_val_failure,SharedConstants.request_header_failure,self.status_code,AdminInfoConstants.invalid_request,AdminInformation.__name__).__str__()
            self.response = func.HttpResponse(body= self.response_message, status_code=self.status_code, mimetype= SharedConstants.json_mime_type) 
        