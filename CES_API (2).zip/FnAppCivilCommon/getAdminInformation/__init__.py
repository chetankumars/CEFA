#__init__.py

import azure.functions as func
from .businesslogic import AdminInformation
from common import SharedConstants


def main(req: func.HttpRequest) -> func.HttpResponse:
    """[summary]

    Args:
        req (func.HttpRequest): To Get/Post/Delete user information from/to CES DB

    Returns:
        func.HttpResponse: User information json for get operation and response code for successful save of user info to CES DB
    """
   
    return AdminInformation().process_data(req)

if __name__ == SharedConstants.main:
    main(func.HttpRequest)
