#admin_info_constants.py

__all__ = ["AdminInfoConstants"]
class AdminInfoConstants:
    """
    constants related to project specific

    """
    sp_input_json = "Input_JSON"
    user_id = "userID"
    invalid_user_id = "Invalid userID"
    invalid_request = "Invalid userID/currentUser"
    current_user = "currentUser"
    
    