# Save Admin Information

## Request params for Saving the RRA information for a new/existing user
    APIM URL :https://apim-uks-dev-ces-0001.azure-api.net/II/CESAPI/lookups/adminInfo
    FUNCTION URL : https://fnp-uks-nprd-ii-fncesdev0002.azurewebsites.net/api/getAdminInformation
    Method Type:  POST
    Request Body:
    Sample Json:{
                "user_id": 7,       
                "supplier_id": 4,
                "is_new_user": "Y",   
                "current_user_key":  "9725949A-1EB7-497E-B397-A511422AFAFE",
                "user_default_rra":[{       
                "region_name": "Eastern",
                    "route_id": 1,
                    "area_id": 12
                    }],
                "user_selected_rra": [{       
                        "region_name": "Wales and Western",
                        "route_id": 13,
                        "area_id": 17
                    },
                    {       
                        "region_name": "Southern",
                        "route_id": 9,
                        "area_id": 3   
                    }]   
                }
     Sample Response:
        
        Success:
                {
                    {
                        "save_status": 1,
                        "error_msg": null
                    }
                    {
                        "save_status": 0,
                        "error_msg": "The selected user RRA already exist in system"
                    }
                }
       
        Bad Request:
                {
                    "error": {
                        "types": "Invalid Request",
                        "title": "Header/Param validation failure",
                        "status": 400,
                        "detail": "{'user_id': ['Not a valid integer.']}",
                        "instance": "AdminInformation"
                    }

                    "error": {
                        "types": "Invalid Request",
                        "title": "Header/Param validation failure",
                        "status": 400,
                        "detail": "{'user_id': ['Missing data for required field.']}",
                        "instance": "AdminInformation"
                    }
                    
                }
        Exception: 
                {
                    "error": {
                        "types": "<class 'UnboundLocalError'>",
                        "title": "AdminInformation",
                        "status": 500,
                        "detail": "local variable 'conn' referenced before assignment",
                        "instance": "AdminInformation"
                    }
                    "error": {
                        "types": "Invalid Request",
                        "title": "AdminInformation",
                        "status": 500,
                        "detail": "HTTP request does not contain valid JSON data",
                        "instance": "AdminInformation"
                    }
                }   
## Request params for Provides RRA & default information for an user 
    APIM URL :https://apim-uks-dev-ces-0001.azure-api.net/II/CESAPI/lookups/adminInfo
    FUNCTION URL : https://fnp-uks-nprd-ii-fncesdev0002.azurewebsites.net/api/getAdminInformation
    Method Type:  GET
    Request params:
        userID:24
   
    Sample Response:
        {
            "supplier_id": null,
            "supplier_name": null,
            "user_default_rra": [
                {
                    "region_name": "",
                    "route_id": null,
                    "route_name": "",
                    "area_id": null,
                    "area_name": ""
                }
            ],
            "user_associated_rra": [
                {
                    "region_name": "",
                    "route_id": null,
                    "route_name": "",
                    "area_id": null,
                    "area_name": ""
                }
            ]
        }
       
        Bad Request:
                {
                    "error": {
                        "types": "Invalid Request",
                        "title": "Header/Param validation failure",
                        "status": 400,
                        "detail": "Invalid userID",
                        "instance": "AdminInformation"
                    }
                }
        Exception: 
                {
                    "error": {
                        "types": "<class 'UnboundLocalError'>",
                        "title": "AdminInformation",
                        "status": 500,
                        "detail": "local variable 'conn' referenced before assignment",
                        "instance": "AdminInformation"
                    }
                }    
## Request params for Deleting the user from RRA tables
    APIM URL :https://apim-uks-dev-ces-0001.azure-api.net/II/CESAPI/lookups/adminInfo
    FUNCTION URL : https://fnp-uks-nprd-ii-fncesdev0002.azurewebsites.net/api/getAdminInformation
    Method Type:  DELETE
    Request params:
        userID:24
        currentUser:asd
   
    Sample Response:
        {
            {
                "delete_status": 0,
                "error_msg": "The selected user does not have RRA in system"
            }
            {
                "delete_status": 1,
                "error_msg": null
            }
        }
       
        Bad Request:
                {
                    "error": {
                        "types": "Invalid Request",
                        "title": "Header/Param validation failure",
                        "status": 400,
                        "detail": "Invalid userID/currentUser",
                        "instance": "AdminInformation"
                    }
                }
        Exception: 
                {
                    "error": {
                        "types": "<class 'UnboundLocalError'>",
                        "title": "AdminInformation",
                        "status": 500,
                        "detail": "local variable 'conn' referenced before assignment",
                        "instance": "AdminInformation"
                    }
                } 