# Save Task List Status

## Description
Services to update task list status data into the CSE db.

    FUNCTION URL: https://fnp-uks-dev-ces-funcedst0006.azurewebsites.net/api/postTaskListStatus
    APIM URL : https://apim-uks-dev-ces-0001.azure-api.net/II/CESAPI/tasklist/setstatus[?userkey][&roleName]


## Request params for save task list status
    Method Type:  POST
    Request params:
        userKey = A22AF4A1-611E-4C65-B018-287A3B81F873
        roleName=CEFA PM/Asset Engineer or Super User/ Supplier Planner
    Request Body:
    Sample Json:
        
            [{
                "exam_sr_key": "45834",
                "task_list_id": "50",
                "task_list_stat": "1595"
                },
                {
                "exam_sr_key": "45833",
                "task_list_id": "186",
                "task_list_stat": "1595"
            }]
    Sample Response:
        
        Success:
                {
                    NOTE:For RoleName:Supplier Planner
                    "success": {
                        "status": 201,
                        "supplier_json":"null",
                        "pdf_json":"null",
                        "detail": "Data updated successfully"
                    }

                    NOTE:For RoleName:CEFA PM/Asset Engineer or Super User/
                    "success": {
                        "status": 201,
                        "supplier_json": [
                            {
                                "Supplier_Id": 4
                            }
                        ],
                        "pdf_json": [
                            {
                                "region": "Southern",
                                "route": "Kent",
                                "area": "London Bridge",
                                "elr": "HHH",
                                "railway_id": "W63",
                                "mileage_from": 0.875,
                                "mileage_to": null,
                                "asset_grp": "Bridge",
                                "asset_type": "Viaduct",
                                "asset_desc": "GREAT SUFFOLK STREET VIADUCT ARCHES 22 - 31A",
                                "asset_guid": "3978559C2D8345D9E04400306E4AD01A",
                                "exam_id": 3013501,
                                "job_number": null,
                                "hce_flg": "No",
                                "bcmi_required": null,
                                "specific_exam_req": "Monthly cyclical examination to monitor the concrete slab movement. The examiner has to take base reading during first inspection. The base readings are to be used against futures inspection/readings to monitor any lateral movements or deterioration. 4 No. monthly cyclical examinations are required, and I will let you know after the review of initial four monthly data that if we require an extension of the monitoring.",
                                "nr_internal_note": null,
                                "tenanted_arch": null,
                                "exam_frequency": "0y 1m 0d",
                                "due_date_earliest": null,
                                "due_dt": "2020-04-15",
                                "due_date_latest": null,
                                "max_tolerance_date": null,
                                "task_list_stat": "Agreed",
                                "exam_req_stat": "Scheduled",
                                "exam_rpt_stat": null,
                                "exam_planned_date": "2020-04-15",
                                "exam_actual_date": "2020-06-21",
                                "other_supplier_comment": null,
                                "change_req_id": null
                            }
                        ],
                        "detail": "Data updated successfully"
                    }

                }
       
        Bad Request:
                {
                    "error": {
                        "types": "Invalid Request",
                        "title": "Header/Param validation failure",
                        "status": 400,
                        "detail": "{'examData': {1: {'exam_sr_key': ['Not a valid integer.']}}}",
                        "instance": "TaskListStatus"
                    }

                    "error": {
                        "types": "Invalid Request",
                        "title": "Header/Param validation failure",
                        "status": 400,
                        "detail": "userkey or roleName query parameter is missing",
                        "instance": "TaskListStatus"
                    }
                    "error": {
                        "types": "Invalid Request",
                        "title": "TaskListStatus",
                        "status": 500,
                        "detail": "User does not have permission to save/submit for next level",
                        "instance": "TaskListStatus"
                    }
                }
        Exception: 
                {
                    "error": {
                        "types": "<class 'UnboundLocalError'>",
                        "title": "TaskListStatus",
                        "status": 500,
                        "detail": "local variable 'conn' referenced before assignment",
                        "instance": "TaskListStatus"
                    }
                }    

