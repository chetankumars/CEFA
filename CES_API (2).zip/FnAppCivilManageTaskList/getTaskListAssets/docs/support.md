# Get Task List Assets Record from CES db.

## Description
    Service to get all task list assets from the CES db based on filter criteria.
    Task List Basic/Advanced Search/Supplier Search/Export to Task list XL
    
    APIM URL: https://apim-uks-dev-ces-0001.azure-api.net/II/CESAPI/tasklist/taskListSearch
    FUNCTION URL: https://fnp-uks-dev-ces-funcedst0006.azurewebsites.net/api/getTaskListAssets
    
  ## Request header for get task list assets
    Method Type: GET
    Params : isSupplierSearch
    Sample Value : Y

    Header Name : X-TaskList-Filters
    Sample Value : {"region_name":"Southern","route_id":9,"area_id":2,"supplier_id":4,"exam_type_id":1,"exam_status_id":0, "elr_id":1076,"start_mileage_from":5.5,"start_mileage_to":99999,"railway_id":null,"ast_grp_id":0,"ast_typ_id":[0], "exam_id":0,"task_list_stat_id":0,"compliance_date_from":"1/1/1900","compliance_date_to":"31/12/9999", "tasklist_yr_id":1294,"due_date_from":"1/1/1999","due_date_to":"31/12/1988", "is_export_to_doc":"N", "sort_column":"StartMileage","sort_order":"asc","page_no":1,"rows_per_page":10}


    Method Type: GET
    Params : isSupplierSearch
    Sample Value : N

    Header Name : X-TaskList-Filters
    Sample Value : {"region_name":"Wales and Western","route_id":13,"area_id":17,"supplier_id":0,"exam_type_id":0,"exam_status_id":0, "elr_id":0,"start_mileage_from":-1,"start_mileage_to":99999,"railway_id":null,"ast_grp_id":0,"ast_typ_id":[0], "exam_id":0,"task_list_stat_id":0,"compliance_date_from":"1/1/1900","compliance_date_to":"31/12/9999",  
    "tasklist_yr_id":1642,"due_date_from":"1/1/1900","due_date_to":"31/12/9999", "is_export_to_doc":"N", "sort_column":"StartMileage","sort_order":"asc","page_no":1,"rows_per_page":10}

