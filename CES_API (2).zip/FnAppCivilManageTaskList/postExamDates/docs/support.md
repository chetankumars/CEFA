# Save Exam dates Details

## Description
Services to update task list details data into the CSE db.

    FUNCTION URL: https://fnp-uks-dev-ces-funcedst0001.azurewebsites.net/api/postExamDates[?userKey]

    APIM URL:https://apim-uks-dev-ces-0001.azure-api.net/II/CESAPI/tasklist/setexamdates[?userKey]

## Request params for save exam dates
    Method Type:  POST
    Request params:
        userKey = A22AF4A1-611E-4C65-B018-287A3B81F873
    Sample Json:
        
            [{
                    "examkey": 1,
                    "plannedExamDate": "28/02/2021",
                    "actualExamDate": "28/01/2021",
                    "otherSupplierComment": "1",
                    "crId": "123"
                },
                {
                    "examkey": 2,
                    "plannedExamDate": "28/02/2021",
                    "actualExamDate": "28/01/2021",
                    "otherSupplierComment": "1",
                    "crId": "123"

            }]
    Sample Response:

        Success:
                {
                    "success": {
                        "status": 201,
                        "detail": "Data updated successfully"
                    }
                }
        Bad Request:
                {
                    "error": {
                        "types": "Invalid Request",
                        "title": "Header/Param validation failure",
                        "status": 400,
                        "detail": "{'examData': {1: {'plannedExamDate': ['Not a valid date.']}}}",
                        "instance": "SaveExamDates"
                    }

                    "error": {
                        "types": "Invalid Request",
                        "title": "Header/Param validation failure",
                        "status": 400,
                        "detail": "The planned date cannot be in the past",
                        "instance": "SaveExamDates"
                    }
                }

        Exception: 
                {
                    "error": {
                        "types": "<class 'UnboundLocalError'>",
                        "title": "SaveExamDates",
                        "status": 500,
                        "detail": "local variable 'conn' referenced before assignment",
                        "instance": "SaveExamDates"
                    }
                }    

