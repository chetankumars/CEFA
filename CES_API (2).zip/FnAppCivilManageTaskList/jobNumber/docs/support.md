# Get and save job number Records in CES db.

## Description
    Service to get and save jobnumbers in the CES db.
    
## Get Request for joNumber

    APIM URL: https://apim-uks-dev-ces-0001.azure-api.net/II/CESAPI/tasklist/jobNumber/{examKey}
    Method Type: GET

    FUNCTION URL: https://fnp-uks-dev-ces-funcedst0001.azurewebsites.net/api/jobNumber
    Method Type: GET
    Request Param:examKey
    sample value:2

## Post Request for jobNumber

    APIM URL: https://apim-uks-dev-ces-0001.azure-api.net/II/CESAPI/tasklist/jobNumber
    Method Type:  POST
    
    FUNCTION URL: https://fnp-uks-sit-ces-funcedst0001.azurewebsites.net/api/jobNumber
    Method Type:  POST
    
    Sample Json:
            
                {
	                "examkey": 2,
	                "jobnumber": "B-2122-372;63ANG5788",
	                "current_user_key":  "9725949A-1EB7-497E-B397-A511422AFAFE"
                }