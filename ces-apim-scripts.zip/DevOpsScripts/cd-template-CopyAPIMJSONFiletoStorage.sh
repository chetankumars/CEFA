bloburl='https://'$(StorageAccountName)'.blob.core.windows.net/'$(StorageContainerName)'?'$(PlaceholderForWriteSASKey)

azcopy copy '$(System.DefaultWorkingDirectory)/_apimfiles/LinkedTemplate/manage-assetdetails-api.template.json' $bloburl
azcopy copy '$(System.DefaultWorkingDirectory)/_apimfiles/LinkedTemplate/manage-compliance-api.template.json' $bloburl
azcopy copy '$(System.DefaultWorkingDirectory)/_apimfiles/LinkedTemplate/manage-defects-api.template.json' $bloburl

azcopy copy '$(System.DefaultWorkingDirectory)/_apimfiles/LinkedTemplate/manage-lookups-api.template.json' $bloburl
azcopy copy '$(System.DefaultWorkingDirectory)/_apimfiles/LinkedTemplate/manage-suppliers-api.template.json' $bloburl
azcopy copy '$(System.DefaultWorkingDirectory)/_apimfiles/LinkedTemplate/manage-task-list-api.template.json' $bloburl
azcopy copy '$(System.DefaultWorkingDirectory)/_apimfiles/LinkedTemplate/manage-userroles-api.template.json' $bloburl
azcopy copy '$(System.DefaultWorkingDirectory)/_apimfiles/LinkedTemplate/globalServicePolicy.template.json' $bloburl
azcopy copy '$(System.DefaultWorkingDirectory)/_apimfiles/LinkedTemplate/products.template.json' $bloburl
