#Create SAS token for 8 minute validity
SASSTART=`date -u -d "-2 minutes" '+%Y-%m-%dT%H:%MZ'`
EXPIRY=`date -u -d "10 minutes" '+%Y-%m-%dT%H:%MZ'`

SANAME=$(StorageAccountName)
KEY=$(StorageAccountKey)
CONTAINERNAME=$(StorageContainerName)

SASKEY=`az storage container generate-sas --account-name $SANAME --account-key $KEY --name $CONTAINERNAME \
--permissions acrw --start $SASSTART --expiry $EXPIRY`

echo '##vso[task.setvariable variable=PlaceholderForWriteSASKey]'$SASKEY

echo 'https://'$SANAME'.blob.core.windows.net/'$CONTAINERNAME'?'$SASKEY 