f1='https://'$(StorageAccountName)'.blob.core.windows.net/'$(StorageContainerName)'/manage-assetdetails-api.template.json?'$(PlaceholderForWriteSASKey) 
f2='https://'$(StorageAccountName)'.blob.core.windows.net/'$(StorageContainerName)'/manage-compliance-api.template.json?'$(PlaceholderForWriteSASKey)
f3='https://'$(StorageAccountName)'.blob.core.windows.net/'$(StorageContainerName)'/manage-defects-api.template.json?'$(PlaceholderForWriteSASKey)
f4='https://'$(StorageAccountName)'.blob.core.windows.net/'$(StorageContainerName)'/manage-lookups-api.template.json?'$(PlaceholderForWriteSASKey)
f5='https://'$(StorageAccountName)'.blob.core.windows.net/'$(StorageContainerName)'/manage-suppliers-api.template.json?'$(PlaceholderForWriteSASKey)
f6='https://'$(StorageAccountName)'.blob.core.windows.net/'$(StorageContainerName)'/manage-task-list-api.template.json?'$(PlaceholderForWriteSASKey)
f7='https://'$(StorageAccountName)'.blob.core.windows.net/'$(StorageContainerName)'/manage-userroles-api.template.json?'$(PlaceholderForWriteSASKey)
f8='https://'$(StorageAccountName)'.blob.core.windows.net/'$(StorageContainerName)'/globalServicePolicy.template.json?'$(PlaceholderForWriteSASKey)
f9='https://'$(StorageAccountName)'.blob.core.windows.net/'$(StorageContainerName)'/products.template.json?'$(PlaceholderForWriteSASKey)

echo $f1
echo $f2
echo $f3
echo $f4
echo $f5
echo $f6
echo $f7
echo $f8
echo $f9

nameTemplateParamFile='$(System.DefaultWorkingDirectory)/_apimfiles/MainTemplate/Main-Cefa-APIM.Parameters.json'
echo $templatefile
updatednameTemplateParamFile='$(System.DefaultWorkingDirectory)/_apimfiles/MainTemplate/Updated_Main-Cefa-APIM.Parameters.json'

# update parameter file with SAS file Url and create a new file named parameters.json
jq ".parameters.assetdetailsLink.value = \"$f1\" |  \
.parameters.complianceLink.value = \"$f2\" |  \
.parameters.defectsLink.value = \"$f3\" |  \
.parameters.lookupsLink.value = \"$f4\" | \
.parameters.suppliersLink.value = \"$f5\" | \
.parameters.tasklistLink.value = \"$f6\" | \
.parameters.userrolesLink.value = \"$f7\" | \
.parameters.globalpolicyLink.value = \"$f8\" | \
.parameters.productdetailsLink.value = \"$f9\" | \
.parameters.ApimServiceName.value = \"$(ApimServiceName)\"" "$nameTemplateParamFile" > $updatednameTemplateParamFile

cat $updatednameTemplateParamFile

 
