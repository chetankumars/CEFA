nameTemplateParamFile='$(System.DefaultWorkingDirectory)/_apimfiles/MainTemplate/namedValues.Parameters.json'
updatednameTemplateParamFile='$(System.DefaultWorkingDirectory)/_apimfiles/MainTemplate/Updated_namedValues.Parameters.json'

# update parameter file with SAS file Url and create a new file named parameters.json

jq ".parameters.FnAppCivilCommon.value = \"$(FnAppCivilCommon)\" |  \
.parameters.FnAppCivilManageAsset.value = \"$(FnAppManageAsset)\" |  \
.parameters.FnAppCivilManageCompliance.value = \"$(FnAppManageCompliance)\" |  \
.parameters.FnAppCivilManageDefect.value = \"$(FnAppManageDefect)\" |  \
.parameters.FnAppCivilManageTaskList.value = \"$(FnAppManageTaskList)\" |  \
.parameters.FnAppCivilSupplier.value = \"$(FnAppCivilSupplier)\" |  \
.parameters.FnAppCivilUser.value = \"$(FnAppCivilUser)\" |  \
.parameters.ApimServiceName.value = \"$(ApimServiceName)\"" "$nameTemplateParamFile" > $updatednameTemplateParamFile

cat $nameTemplateParamFile
cat $updatednameTemplateParamFile
