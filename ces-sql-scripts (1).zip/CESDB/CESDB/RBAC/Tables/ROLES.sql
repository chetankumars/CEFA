﻿CREATE TABLE [RBAC].[ROLES]
(
	[ROLE_SR_KEY] decimal(18) NOT NULL IDENTITY (1, 1),	-- Role surrogate key (pk)
	[ROLE_NAME] varchar(50) NOT NULL,	-- Role Name
	[ROLE_DESCRIPTION] varchar(100) NOT NULL,	-- Role Description
	[ISACTIVE] bit NOT NULL DEFAULT 1,	-- Indicates if the Role is Active or Not
	[CREATED_USER] varchar(64) NOT NULL,	-- Created By User
	[CREATED_DATE] datetime NOT NULL,	-- Created Date
	[UPDATED_USER] varchar(64) NULL,	-- Updated By user
	[UPDATED_DATE] datetime NULL	-- Updated Date
)
GO

/* Create Primary Keys, Indexes, Uniques, Checks */

ALTER TABLE [RBAC].[ROLES] 
 ADD CONSTRAINT [PK_ROLES]
	PRIMARY KEY CLUSTERED ([ROLE_SR_KEY] ASC)
GO

/* Create Table Comments */

EXEC sp_addextendedproperty 'MS_Description', 'Role surrogate key (pk)', 'Schema', [RBAC], 'table', [ROLES], 'column', [ROLE_SR_KEY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Role Name', 'Schema', [RBAC], 'table', [ROLES], 'column', [ROLE_NAME]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Role Description', 'Schema', [RBAC], 'table', [ROLES], 'column', [ROLE_DESCRIPTION]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Indicates if the Role is Active or Not', 'Schema', [RBAC], 'table', [ROLES], 'column', [ISACTIVE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Created By User', 'Schema', [RBAC], 'table', [ROLES], 'column', [CREATED_USER]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Created Date', 'Schema', [RBAC], 'table', [ROLES], 'column', [CREATED_DATE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Updated By user', 'Schema', [RBAC], 'table', [ROLES], 'column', [UPDATED_USER]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Updated Date', 'Schema', [RBAC], 'table', [ROLES], 'column', [UPDATED_DATE]
GO