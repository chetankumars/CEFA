﻿CREATE TABLE [RBAC].[USER]
(
	[USER_SR_KEY] decimal(18) NOT NULL IDENTITY (1, 1),	-- User Surrogate Key (pk)
	[USER_ID] varchar(64) NOT NULL,	-- Active Directory GUID
	[ISACTIVE] bit NOT NULL DEFAULT 1,	-- Indicates if the user is Active or not - 1 for Active, 0 for Deleted/Inactive
	[CREATED_USER] varchar(64) NOT NULL,	-- Created By User
	[CREATED_DATE] datetime NOT NULL,	-- Created Date
	[UPDATED_USER] varchar(64) NULL,	-- Updated By User
	[UPDATED_DATE] datetime NULL	-- Updated Date
)
GO

/* Create Primary Keys, Indexes, Uniques, Checks */

ALTER TABLE [RBAC].[USER] 
 ADD CONSTRAINT [PK_USER]
	PRIMARY KEY CLUSTERED ([USER_SR_KEY] ASC)
GO

/* Create Table Comments */

EXEC sp_addextendedproperty 'MS_Description', 'User Surrogate Key (pk)', 'Schema', [RBAC], 'table', [USER], 'column', [USER_SR_KEY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Active Directory GUID', 'Schema', [RBAC], 'table', [USER], 'column', [USER_ID]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Indicates if the user is Active or not - 1 for Active, 0 for Deleted/Inactive', 'Schema', [RBAC], 'table', [USER], 'column', [ISACTIVE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Created By User', 'Schema', [RBAC], 'table', [USER], 'column', [CREATED_USER]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Created Date', 'Schema', [RBAC], 'table', [USER], 'column', [CREATED_DATE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Updated By User', 'Schema', [RBAC], 'table', [USER], 'column', [UPDATED_USER]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Updated Date', 'Schema', [RBAC], 'table', [USER], 'column', [UPDATED_DATE]
GO