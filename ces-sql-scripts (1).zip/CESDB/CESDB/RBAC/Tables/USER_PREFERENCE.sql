﻿CREATE TABLE [RBAC].[USER_PREFERENCE] (
    [USER_PREF_SR_KEY] DECIMAL (18)  IDENTITY (1, 1) NOT NULL,
    [USER_SR_KEY]      DECIMAL (18)  NOT NULL,
    [RESC_SR_KEY]      DECIMAL (18)  NOT NULL,
    [USER_PREF_DATA]   VARCHAR (MAX) NOT NULL,
    [CREATED_USER]     VARCHAR (64)  NOT NULL,
    [CREATED_DATE]     DATETIME      NOT NULL,
    [UPDATED_USER]     VARCHAR (64)  NULL,
    [UPDATED_DATE]     DATETIME      NULL,
    [ISACTIVE]         BIT           DEFAULT ((1)) NOT NULL,
    CONSTRAINT [PK_USER_PREFERENCE] PRIMARY KEY CLUSTERED ([USER_PREF_SR_KEY] ASC) WITH (FILLFACTOR = 80),
    CONSTRAINT [FK_USER_PREFERENCE_RESOURCES] FOREIGN KEY ([RESC_SR_KEY]) REFERENCES [RBAC].[RESOURCES] ([RESC_SR_KEY]),
    CONSTRAINT [FK_USER_PREFERENCE_USER] FOREIGN KEY ([USER_SR_KEY]) REFERENCES [RBAC].[USER] ([USER_SR_KEY])
);


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Updated Date', @level0type = N'SCHEMA', @level0name = N'RBAC', @level1type = N'TABLE', @level1name = N'USER_PREFERENCE', @level2type = N'COLUMN', @level2name = N'UPDATED_DATE';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Updated By User', @level0type = N'SCHEMA', @level0name = N'RBAC', @level1type = N'TABLE', @level1name = N'USER_PREFERENCE', @level2type = N'COLUMN', @level2name = N'UPDATED_USER';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Created Date', @level0type = N'SCHEMA', @level0name = N'RBAC', @level1type = N'TABLE', @level1name = N'USER_PREFERENCE', @level2type = N'COLUMN', @level2name = N'CREATED_DATE';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Created By User', @level0type = N'SCHEMA', @level0name = N'RBAC', @level1type = N'TABLE', @level1name = N'USER_PREFERENCE', @level2type = N'COLUMN', @level2name = N'CREATED_USER';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'User preference data (sent from UI in JSON format)', @level0type = N'SCHEMA', @level0name = N'RBAC', @level1type = N'TABLE', @level1name = N'USER_PREFERENCE', @level2type = N'COLUMN', @level2name = N'USER_PREF_DATA';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Screen for which user preference data is setup', @level0type = N'SCHEMA', @level0name = N'RBAC', @level1type = N'TABLE', @level1name = N'USER_PREFERENCE', @level2type = N'COLUMN', @level2name = N'RESC_SR_KEY';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'User ID', @level0type = N'SCHEMA', @level0name = N'RBAC', @level1type = N'TABLE', @level1name = N'USER_PREFERENCE', @level2type = N'COLUMN', @level2name = N'USER_SR_KEY';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'User Preference Surrogate Key', @level0type = N'SCHEMA', @level0name = N'RBAC', @level1type = N'TABLE', @level1name = N'USER_PREFERENCE', @level2type = N'COLUMN', @level2name = N'USER_PREF_SR_KEY';

