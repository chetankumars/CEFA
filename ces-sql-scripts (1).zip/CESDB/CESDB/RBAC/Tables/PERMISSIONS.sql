﻿CREATE TABLE [RBAC].[PERMISSIONS]
(
	[PERM_SR_KEY] decimal(18) NOT NULL IDENTITY (1, 1),	-- Permission Surrogate Key (pk)
	[PERM_NAME] varchar(50) NOT NULL,	-- Permission Name
	[PERM_DESC] varchar(100) NULL,	-- Permission Description
	[ISACTIVE] bit NOT NULL DEFAULT 1,	-- Indicates whether the record is active or not
	[CREATED_USER] varchar(64) NOT NULL,	-- Created By user
	[CREATED_DATE] datetime NOT NULL,	-- Created Date
	[UPDATED_USER] varchar(64) NULL,	-- Updated By user
	[UPDATED_DATE] datetime NULL	-- Updated Date
)
GO

/* Create Primary Keys, Indexes, Uniques, Checks */

ALTER TABLE [RBAC].[PERMISSIONS] 
 ADD CONSTRAINT [PK_PERMISSIONS]
	PRIMARY KEY CLUSTERED ([PERM_SR_KEY] ASC)
GO

/* Create Table Comments */

EXEC sp_addextendedproperty 'MS_Description', 'Permission Surrogate Key (pk)', 'Schema', [RBAC], 'table', [PERMISSIONS], 'column', [PERM_SR_KEY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Permission Name', 'Schema', [RBAC], 'table', [PERMISSIONS], 'column', [PERM_NAME]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Permission Description', 'Schema', [RBAC], 'table', [PERMISSIONS], 'column', [PERM_DESC]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Indicates whether the record is active or not', 'Schema', [RBAC], 'table', [PERMISSIONS], 'column', [ISACTIVE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Created By user', 'Schema', [RBAC], 'table', [PERMISSIONS], 'column', [CREATED_USER]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Created Date', 'Schema', [RBAC], 'table', [PERMISSIONS], 'column', [CREATED_DATE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Updated By user', 'Schema', [RBAC], 'table', [PERMISSIONS], 'column', [UPDATED_USER]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Updated Date', 'Schema', [RBAC], 'table', [PERMISSIONS], 'column', [UPDATED_DATE]
GO