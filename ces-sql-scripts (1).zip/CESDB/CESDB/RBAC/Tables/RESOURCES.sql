﻿CREATE TABLE [RBAC].[RESOURCES]
(
	[RESC_SR_KEY] decimal(18) NOT NULL IDENTITY (1, 1),	-- Resource Surrogate Key (pk)
	[RESC_NAME] varchar(50) NOT NULL,	-- Resource Name
	[RESC_DESC] varchar(100) NOT NULL,	-- Resource Description
	[ISACTIVE] bit NOT NULL DEFAULT 1,	-- Indicates if the record is Active or not
	[CREATED_USER] varchar(64) NOT NULL,	-- Created By user
	[CREATED_DATE] datetime NOT NULL,	-- Created Date
	[UPDATED_USER] varchar(64) NULL,	-- Updated by user
	[UPDATED_DATE] datetime NULL	-- Updated Date
)
GO

/* Create Primary Keys, Indexes, Uniques, Checks */

ALTER TABLE [RBAC].[RESOURCES] 
 ADD CONSTRAINT [PK_RESOURCES]
	PRIMARY KEY CLUSTERED ([RESC_SR_KEY] ASC)
GO

/* Create Table Comments */

EXEC sp_addextendedproperty 'MS_Description', 'Resource Surrogate Key (pk)', 'Schema', [RBAC], 'table', [RESOURCES], 'column', [RESC_SR_KEY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Resource Name', 'Schema', [RBAC], 'table', [RESOURCES], 'column', [RESC_NAME]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Resource Description', 'Schema', [RBAC], 'table', [RESOURCES], 'column', [RESC_DESC]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Indicates if the record is Active or not', 'Schema', [RBAC], 'table', [RESOURCES], 'column', [ISACTIVE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Created By user', 'Schema', [RBAC], 'table', [RESOURCES], 'column', [CREATED_USER]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Created Date', 'Schema', [RBAC], 'table', [RESOURCES], 'column', [CREATED_DATE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Updated by user', 'Schema', [RBAC], 'table', [RESOURCES], 'column', [UPDATED_USER]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Updated Date', 'Schema', [RBAC], 'table', [RESOURCES], 'column', [UPDATED_DATE]
GO