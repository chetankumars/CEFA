﻿CREATE TABLE [RBAC].[USER_ROLES]
(
	[USER_ROLE_SR_KEY] decimal(18) NOT NULL IDENTITY (1, 1),	-- User Role surrogate Key (pk)
	[USER_SR_KEY] decimal(18) NOT NULL,	-- User Surrogate Key (fk)
	[ROLE_SR_KEY] decimal(18) NOT NULL,	-- Role surrogate key (fk)
	[ISACTIVE] bit NOT NULL DEFAULT 1,	-- Indicates if the record is Active or not
	[CREATED_USER] varchar(64) NOT NULL,	-- Created By user
	[CREATED_DATE] datetime NOT NULL,	-- Created Date
	[UPDATED_USER] varchar(64) NULL,	-- Updated By User
	[UPDATED_DATE] datetime NULL	-- Updated Date
)
GO

/* Create Primary Keys, Indexes, Uniques, Checks */

ALTER TABLE [RBAC].[USER_ROLES] 
 ADD CONSTRAINT [PK_USER_ROLES]
	PRIMARY KEY CLUSTERED ([USER_ROLE_SR_KEY] ASC)
GO

/* Create Foreign Key Constraints */

ALTER TABLE [RBAC].[USER_ROLES] ADD CONSTRAINT [FK_USER_ROLES_ROLES]
	FOREIGN KEY ([ROLE_SR_KEY]) REFERENCES [RBAC].[ROLES] ([ROLE_SR_KEY]) ON DELETE No Action ON UPDATE No Action
GO

ALTER TABLE [RBAC].[USER_ROLES] ADD CONSTRAINT [FK_USER_ROLES_USER]
	FOREIGN KEY ([USER_SR_KEY]) REFERENCES [RBAC].[USER] ([USER_SR_KEY]) ON DELETE No Action ON UPDATE No Action
GO

/* Create Table Comments */

EXEC sp_addextendedproperty 'MS_Description', 'User Role surrogate Key (pk)', 'Schema', [RBAC], 'table', [USER_ROLES], 'column', [USER_ROLE_SR_KEY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'User Surrogate Key (fk)', 'Schema', [RBAC], 'table', [USER_ROLES], 'column', [USER_SR_KEY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Role surrogate key (fk)', 'Schema', [RBAC], 'table', [USER_ROLES], 'column', [ROLE_SR_KEY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Indicates if the record is Active or not', 'Schema', [RBAC], 'table', [USER_ROLES], 'column', [ISACTIVE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Created By user', 'Schema', [RBAC], 'table', [USER_ROLES], 'column', [CREATED_USER]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Created Date', 'Schema', [RBAC], 'table', [USER_ROLES], 'column', [CREATED_DATE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Updated By User', 'Schema', [RBAC], 'table', [USER_ROLES], 'column', [UPDATED_USER]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Updated Date', 'Schema', [RBAC], 'table', [USER_ROLES], 'column', [UPDATED_DATE]
GO