﻿CREATE TABLE [RBAC].[ROLE_RESC_PERM_RELATION]
(
	[ROLE_RESC_PERM_SR_KEY] decimal(18) NOT NULL IDENTITY (1, 1),	-- Surrogate Key (PK)
	[ROLE_SR_KEY] decimal(18) NOT NULL,	-- Role Surrogate Key (FK)
	[RESC_SR_KEY] decimal(18) NOT NULL,	-- Resource Surrogate Key (Fk)
	[PERM_SR_KEY] decimal(18) NOT NULL,	-- Permission Surrogate Key (Fk)
	[ISACTIVE] bit NOT NULL DEFAULT 1,	-- Indicates if the record is Active or not
	[CREATED_USER] varchar(64) NOT NULL,	-- Created By User
	[CREATED_DATE] datetime NOT NULL,	-- Created Date
	[UPDATED_USER] varchar(64) NULL,	-- Updated By user
	[UPDATED_DATE] datetime NULL	-- Updated Date
)
GO

/* Create Primary Keys, Indexes, Uniques, Checks */

ALTER TABLE [RBAC].[ROLE_RESC_PERM_RELATION] 
 ADD CONSTRAINT [PK_ROLE_RESC_PERM_RELATION]
	PRIMARY KEY CLUSTERED ([ROLE_RESC_PERM_SR_KEY] ASC)
GO

/* Create Foreign Key Constraints */

ALTER TABLE [RBAC].[ROLE_RESC_PERM_RELATION] ADD CONSTRAINT [FK_ROLE_RESC_PERM_RELATION_PERMISSIONS]
	FOREIGN KEY ([PERM_SR_KEY]) REFERENCES [RBAC].[PERMISSIONS] ([PERM_SR_KEY]) ON DELETE No Action ON UPDATE No Action
GO

ALTER TABLE [RBAC].[ROLE_RESC_PERM_RELATION] ADD CONSTRAINT [FK_ROLE_RESC_PERM_RELATION_RESOURCES]
	FOREIGN KEY ([RESC_SR_KEY]) REFERENCES [RBAC].[RESOURCES] ([RESC_SR_KEY]) ON DELETE No Action ON UPDATE No Action
GO

ALTER TABLE [RBAC].[ROLE_RESC_PERM_RELATION] ADD CONSTRAINT [FK_ROLE_RESC_PERM_RELATION_ROLES]
	FOREIGN KEY ([ROLE_SR_KEY]) REFERENCES [RBAC].[ROLES] ([ROLE_SR_KEY]) ON DELETE No Action ON UPDATE No Action
GO

/* Create Table Comments */

EXEC sp_addextendedproperty 'MS_Description', 'Surrogate Key (PK)', 'Schema', [RBAC], 'table', [ROLE_RESC_PERM_RELATION], 'column', [ROLE_RESC_PERM_SR_KEY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Role Surrogate Key (FK)', 'Schema', [RBAC], 'table', [ROLE_RESC_PERM_RELATION], 'column', [ROLE_SR_KEY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Resource Surrogate Key (Fk)', 'Schema', [RBAC], 'table', [ROLE_RESC_PERM_RELATION], 'column', [RESC_SR_KEY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Permission Surrogate Key (Fk)', 'Schema', [RBAC], 'table', [ROLE_RESC_PERM_RELATION], 'column', [PERM_SR_KEY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Indicates if the record is Active or not', 'Schema', [RBAC], 'table', [ROLE_RESC_PERM_RELATION], 'column', [ISACTIVE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Created By User', 'Schema', [RBAC], 'table', [ROLE_RESC_PERM_RELATION], 'column', [CREATED_USER]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Created Date', 'Schema', [RBAC], 'table', [ROLE_RESC_PERM_RELATION], 'column', [CREATED_DATE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Updated By user', 'Schema', [RBAC], 'table', [ROLE_RESC_PERM_RELATION], 'column', [UPDATED_USER]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Updated Date', 'Schema', [RBAC], 'table', [ROLE_RESC_PERM_RELATION], 'column', [UPDATED_DATE]
GO