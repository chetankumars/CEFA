﻿/***************************************************************************************************************************************            
* Name						: sp_Get_Search_UserPreference            
* Created By				: Cognizant            
* Date Created				: 17-Dec-2020           
* Description				: This stored procedure provides the user preference data saved for any screen  
* Input Parameters			: User ID, Screen Id      
* Output Parameters			: N/A            
* Return Value				: N/A            
* Assumptions				: None    
* Execution Statement		: Exec [CES].sp_Get_Search_UserPreference 6,3
*								
* Modified Date     Modified By   Revision Number  Modifications            

*******************************************************************************************************************************************/ 



CREATE PROCEDURE [RBAC].[sp_Get_Search_UserPreference]
	@User_ID	DECIMAL(18),
	@Screen_ID	DECIMAL(18)

AS
BEGIN
	SET NOCOUNT ON
	BEGIN TRY
		DECLARE
				@ErrorMsg	VARCHAR(250)

		
				SELECT 
					USER_PREF_DATA AS Pref_Data
										 
				FROM [RBAC].USER_PREFERENCE 
				WHERE USER_SR_KEY = @User_ID
				AND RESC_SR_KEY = @Screen_ID
				AND ISACTIVE = 1
				--FOR JSON AUTO
			
	END TRY
	BEGIN CATCH
		SET @ErrorMsg = ERROR_MESSAGE() + 
						' Line Num:' + CONVERT(VARCHAR(5), ERROR_LINE()) + 
						',ErrorNum:' + CONVERT(VARCHAR(5), ERROR_NUMBER()) + 
						',Severity:' + CONVERT(VARCHAR(5), ERROR_SEVERITY()) + 
						',State:' + CONVERT(VARCHAR(10), ERROR_STATE()) + 
						',Procedure:' + CONVERT(VARCHAR(25), OBJECT_NAME(@@procid)) +
						',Procedure:' + CONVERT(VARCHAR(25), ERROR_PROCEDURE());  

		THROW 50000,@ErrorMsg,1;
	END CATCH
	SET NOCOUNT OFF
END