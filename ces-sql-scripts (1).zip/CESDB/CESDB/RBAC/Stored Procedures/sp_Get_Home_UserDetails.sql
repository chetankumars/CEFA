﻿/***************************************************************************************************************************************            
* Name						: sp_Get_Home_UserDetails            
* Created By				: Cognizant            
* Date Created				: 15-Dec-2020           
* Description				: This stored procedure provides the user details (roles/permissions/screen access).  
* Input Parameters			: @User_Key      
* Output Parameters			: N/A            
* Return Value				: N/A            
* Assumptions				: None    
* Execution Statement		: Exec [RBAC].sp_Get_Home_UserDetails 'AA3DF15A-B72D-4A33-B21C-764BD17C3F64'
*								
* Modified Date     Modified By   Revision Number  Modifications            

*******************************************************************************************************************************************/ 



CREATE PROCEDURE [RBAC].[sp_Get_Home_UserDetails]
	@User_Key	VARCHAR(64)
AS
BEGIN
	BEGIN TRY
		SET NOCOUNT ON
		DECLARE
				@ErrorMsg	VARCHAR(250)
	
				SELECT 
					usr.USER_SR_KEY AS userid,
					usr.[USER_ID] AS userkey,
					role.ROLE_SR_KEY AS roleid,
					role.ROLE_DESCRIPTION AS rolename,
					permission.PERM_SR_KEY AS permid,
					permission.PERM_DESC AS permname,
					screen.RESC_SR_KEY AS screenid,
					screen.[RESC_DESC] AS screenname
				FROM		[RBAC].[user] usr
				INNER JOIN	[RBAC].USER_ROLES ur
				ON			usr.USER_SR_KEY = ur.USER_SR_KEY
				INNER JOIN	[RBAC].ROLES role
				ON			role.ROLE_SR_KEY = ur.ROLE_SR_KEY
				INNER JOIN	[RBAC].ROLE_RESC_PERM_RELATION rrpr
				ON			rrpr.ROLE_SR_KEY = role.ROLE_SR_KEY
				INNER JOIN	[RBAC].RESOURCES screen
				ON			screen.RESC_SR_KEY = rrpr.RESC_SR_KEY
				INNER JOIN	[RBAC].[PERMISSIONS] permission
				ON			permission.PERM_SR_KEY = rrpr.PERM_SR_KEY
				WHERE		usr.ISACTIVE = 1
				AND			ur.ISACTIVE = 1
				AND			role.ISACTIVE = 1
				AND			rrpr.ISACTIVE = 1
				AND			screen.ISACTIVE = 1
				AND			permission.ISACTIVE = 1
				AND			usr.[USER_ID] = @User_Key

				FOR JSON AUTO,INCLUDE_NULL_VALUES,WITHOUT_ARRAY_WRAPPER
	

	END TRY
	BEGIN CATCH
		SET @ErrorMsg = ERROR_MESSAGE() + 
						' Line Num:' + CONVERT(VARCHAR(5), ERROR_LINE()) + 
						',ErrorNum:' + CONVERT(VARCHAR(5), ERROR_NUMBER()) + 
						',Severity:' + CONVERT(VARCHAR(5), ERROR_SEVERITY()) + 
						',State:' + CONVERT(VARCHAR(10), ERROR_STATE()) + 
						',Procedure:' + CONVERT(VARCHAR(25), OBJECT_NAME(@@procid)) +
						',Procedure:' + CONVERT(VARCHAR(25), ERROR_PROCEDURE());  

		THROW 50000,@ErrorMsg,1;
	END CATCH

	SET NOCOUNT OFF
END