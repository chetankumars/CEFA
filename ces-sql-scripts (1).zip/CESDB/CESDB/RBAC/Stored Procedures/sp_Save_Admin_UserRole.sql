﻿/***************************************************************************************************************************************            
* Name						: sp_Save_Admin_UserRole            
* Created By				: Cognizant            
* Date Created				: 10-Mar-2021           
* Description				: This stored procedure provides the option to save new or existing user role they are assigned.  
* Input Parameters			: JSON      
* Output Parameters			: @OUT_ErrorNo            
* Return Value				: 1 - Success / 0 - Fail            
* Assumptions				: None    
* Execution Statement		: Exec [RBAC].sp_Save_Admin_UserRole '{
																	"user_key": "BDFD2401-040F-4250-B506-444A7684C9AC",	
																	"role_id": 1,	
																	"current_user_key":  "BDFD2401-040F-4250-B506-444A7684C9AC",
																	"is_new_user": "Y"
																  }'
*								
* Modified Date     Modified By   Revision Number  Modifications            

*******************************************************************************************************************************************/ 

CREATE PROCEDURE [RBAC].[sp_Save_Admin_UserRole]
	@Input_JSON		NVARCHAR(MAX)
AS 
BEGIN
	SET NOCOUNT ON
	
	
	BEGIN TRY
		DECLARE
				@ErrorMsg				VARCHAR(250),
				@ErrorDescription		VARCHAR(4000),
				@result					NVARCHAR(MAX),
				@user_key				VARCHAR(64),
				@current_user_key		VARCHAR(64),
				@current_date			DATETIME,
				@role_id                DECIMAL(18),				
				@user_count				DECIMAL(18),
				@user_sr_key			DECIMAL(18),
				@is_new_user			VARCHAR(1)							
				

				SELECT 
					@user_key = COALESCE(@user_key,CASE LOWER([key]) WHEN 'user_key' THEN [value] ELSE NULL END),
					@role_id = COALESCE(@role_id,CASE LOWER([key]) WHEN 'role_id' THEN [value] ELSE NULL END),
					@current_user_key = COALESCE(@current_user_key,CASE LOWER([key]) WHEN 'current_user_key' THEN [value] ELSE NULL END),
					@is_new_user = COALESCE(@is_new_user,CASE LOWER([key]) WHEN 'is_new_user' THEN [value] ELSE NULL END)
					
				FROM	OPENJSON(@Input_JSON);		

				IF (@user_key IS NULL or LTRIM(RTRIM(@user_key)) = '')
				BEGIN
					SET @ErrorMsg = 'User Key provided is blank';
					THROW 50000,@ErrorMsg,1;
				END

				IF (@role_id IS NULL)
				BEGIN
					SET @ErrorMsg = 'Role Id provided is blank';
					THROW 50000,@ErrorMsg,1;
				END
				ELSE
				BEGIN
					IF NOT EXISTS (SELECT * FROM RBAC.[ROLES] WHERE ROLE_SR_KEY = @role_id AND ISACTIVE=1)
					BEGIN
					SET @ErrorMsg = 'The selected Role Id is not valid';
					THROW 50000,@ErrorMsg,1;
					END
				END

				IF (@current_user_key IS NULL or LTRIM(RTRIM(@current_user_key)) = '')
				BEGIN
					SET @ErrorMsg = 'Current logged in user key is blank';
					THROW 50000,@ErrorMsg,1;
				END
		
			  SELECT @user_count=COUNT(USER_SR_KEY) FROM RBAC.[USER] WHERE USER_ID=@user_key AND ISACTIVE=1 

			  SET @current_date = GETDATE()

			  IF UPPER(@is_new_user) = 'Y'  
				  BEGIN				
					IF @user_count=0 
						BEGIN
							--PRINT 'NEW USER SAVE'
							BEGIN TRAN
								INSERT INTO RBAC.[USER] (USER_ID,ISACTIVE,CREATED_USER,CREATED_DATE,UPDATED_USER,UPDATED_DATE) 
								VALUES (@user_key,1,@current_user_key,@current_date,@current_user_key,@current_date)
								
								SELECT @user_sr_key=USER_SR_KEY FROM RBAC.[USER] WHERE USER_ID=@user_key and ISACTIVE=1
								
								INSERT INTO RBAC.[USER_ROLES] 
								(USER_SR_KEY,ROLE_SR_KEY,ISACTIVE,CREATED_USER,CREATED_DATE,UPDATED_USER,UPDATED_DATE)
								VALUES (@user_sr_key,@role_id,1,
								@current_user_key,@current_date,@current_user_key,@current_date)
								
								SET @result= (
									SELECT 1 AS save_status,NULL AS error_msg, @user_sr_key AS user_id
									FOR JSON PATH,WITHOUT_ARRAY_WRAPPER, INCLUDE_NULL_VALUES
								)
							COMMIT TRAN
						END
					ELSE
						BEGIN
							SET @ErrorMsg = 'The selected user already exist in system';
							SET @result= (
								SELECT 0 AS save_status,@ErrorMsg AS error_msg, NULL AS user_id
								FOR JSON PATH,WITHOUT_ARRAY_WRAPPER, INCLUDE_NULL_VALUES
							)
						END
				  END
			  ELSE
				  BEGIN
					IF @user_count>0 
						BEGIN
							--PRINT 'EXISTING USER SAVE'
							SELECT @user_sr_key=USER_SR_KEY FROM RBAC.[USER] WHERE USER_ID=@user_key AND ISACTIVE=1														
							IF EXISTS (SELECT 1 FROM RBAC.[USER_ROLES] WHERE USER_SR_KEY = @user_sr_key AND ISACTIVE=1)
								BEGIN
								BEGIN TRAN	
									UPDATE RBAC.[USER_ROLES] 
									SET ROLE_SR_KEY=@role_id,
									UPDATED_USER=@current_user_key,
									UPDATED_DATE=@current_date
									WHERE USER_SR_KEY = @user_sr_key AND ISACTIVE=1
									
									
									SET @result= (
													SELECT 1 AS save_status,NULL AS error_msg, @user_sr_key AS user_id
													FOR JSON PATH,WITHOUT_ARRAY_WRAPPER, INCLUDE_NULL_VALUES
												)
								COMMIT TRAN
								END
							ELSE
							BEGIN
							BEGIN TRAN	
									INSERT INTO RBAC.[USER_ROLES] 
									(USER_SR_KEY,ROLE_SR_KEY,ISACTIVE,CREATED_USER,CREATED_DATE,UPDATED_USER,UPDATED_DATE)
									VALUES (@user_sr_key,@role_id,1,
									@current_user_key,@current_date,@current_user_key,@current_date)
									
									SET @result= (
										SELECT 1 AS save_status,NULL AS error_msg, @user_sr_key AS user_id
										FOR JSON PATH,WITHOUT_ARRAY_WRAPPER, INCLUDE_NULL_VALUES
									)
								COMMIT TRAN
							END							
						END
					ELSE
						BEGIN
							SET @ErrorMsg = 'The selected user does not exist in system';	
							SET @result= (
								SELECT 0 AS save_status,@ErrorMsg AS error_msg, NULL AS user_id
								FOR JSON PATH,WITHOUT_ARRAY_WRAPPER, INCLUDE_NULL_VALUES
							)
						END
				  END

		 SELECT @result

	END TRY
	BEGIN CATCH
		IF (@@TRANCOUNT >0)
			ROLLBACK TRAN

		IF @ErrorMsg IS NULL
			SET @ErrorMsg = ERROR_MESSAGE() 
		
		SET @ErrorDescription = @ErrorMsg + 
							' Line Num:' + CONVERT(VARCHAR(5), ERROR_LINE()) + 
							',ErrorNum:' + CONVERT(VARCHAR(5), ERROR_NUMBER()) + 
							',Severity:' + CONVERT(VARCHAR(5), ERROR_SEVERITY()) + 
							',State:' + CONVERT(VARCHAR(10), ERROR_STATE()) + 
							',Procedure:' + CONVERT(VARCHAR(25), OBJECT_NAME(@@procid)) +
							',Procedure:' + CONVERT(VARCHAR(25), ERROR_PROCEDURE())

		SET @result= (
						SELECT 0 AS save_status,@ErrorMsg AS error_msg, NULL AS user_id
						FOR JSON PATH,WITHOUT_ARRAY_WRAPPER, INCLUDE_NULL_VALUES
					)
		SELECT @result;
		
		THROW 50000,@ErrorDescription,1;

		
	END CATCH

	
	SET NOCOUNT OFF
END