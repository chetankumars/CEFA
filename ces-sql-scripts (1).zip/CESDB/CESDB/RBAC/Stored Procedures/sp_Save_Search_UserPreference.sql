﻿/***************************************************************************************************************************************            
* Name						: sp_Save_Search_UserPreference            
* Created By				: Cognizant            
* Date Created				: 17-Dec-2020           
* Description				: This stored procedure saves the user preference data saved for any screen  
* Input Parameters			: User ID, Screen Id , User Preference data (JSON)     
* Output Parameters			: N/A            
* Return Value				: N/A            
* Assumptions				: None    
* Execution Statement		: 
	DECLARE @output BIT
	Exec [CES].sp_Save_Search_UserPreference 1,'827af35c-1346-4a40-9e1d-9aff6b141cb3',1,'"Pref_Data": "def"',@output OUTPUT
	SELECT @output
*								
* Modified Date     Modified By   Revision Number  Modifications            

*******************************************************************************************************************************************/ 



CREATE PROCEDURE [RBAC].[sp_Save_Search_UserPreference]
	@User_ID		DECIMAL(18),
	@User_Key		VARCHAR(64),
	@Screen_ID		DECIMAL(18),
	@User_Pref_Data	VARCHAR(MAX)
	--@Output			BIT OUTPUT 

AS
BEGIN

	SET NOCOUNT ON
	BEGIN TRY
		DECLARE
				@ErrorMsg	VARCHAR(250),
				@Output			BIT = 0

			--SET @Output = 0;
				
			IF (@User_ID IS NULL OR @Screen_ID IS NULL OR @User_Pref_Data IS NULL)
			BEGIN
				SET @ErrorMsg = 'Input parameter value is missing';
				THROW 50000,@ErrorMsg,1;
			END

			BEGIN TRAN

			IF EXISTS (SELECT 1 FROM [RBAC].USER_PREFERENCE
						WHERE USER_SR_KEY = @User_ID
						AND RESC_SR_KEY = @Screen_ID
						AND ISACTIVE = 1)
				UPDATE [RBAC].USER_PREFERENCE
				SET	USER_PREF_DATA = @User_Pref_Data,
					UPDATED_USER = @User_Key,
					UPDATED_DATE = GETDATE()
				WHERE USER_SR_KEY = @User_ID
				AND RESC_SR_KEY = @Screen_ID
				AND ISACTIVE = 1

			ELSE
				INSERT INTO [RBAC].USER_PREFERENCE
				(
					USER_SR_KEY,
					RESC_SR_KEY,
					USER_PREF_DATA,
					CREATED_USER,
					CREATED_DATE
				)
				SELECT
					@User_ID,
					@Screen_ID,
					@User_Pref_Data,
					@User_Key,
					GETDATE()
		
		IF @@ERROR = 0
			SET @Output = 1
				
		COMMIT TRAN
		

	END TRY
	BEGIN CATCH

		IF (@@TRANCOUNT >0)
			ROLLBACK TRAN
		SET @ErrorMsg = ERROR_MESSAGE() + 
						' Line Num:' + CONVERT(VARCHAR(5), ERROR_LINE()) + 
						',ErrorNum:' + CONVERT(VARCHAR(5), ERROR_NUMBER()) + 
						',Severity:' + CONVERT(VARCHAR(5), ERROR_SEVERITY()) + 
						',State:' + CONVERT(VARCHAR(10), ERROR_STATE()) + 
						',Procedure:' + CONVERT(VARCHAR(25), OBJECT_NAME(@@procid)) +
						',Procedure:' + CONVERT(VARCHAR(25), ERROR_PROCEDURE());  
		SET @Output = 0;
		THROW 50000,@ErrorMsg,1;
	END CATCH
	SELECT @Output AS [Output]
	SET NOCOUNT OFF
END