﻿/***************************************************************************************************************************************            
* Name						: sp_Get_Admin_UserRoleInfo            
* Created By				: Cognizant            
* Date Created				: 10-Mar-2021           
* Description				: This stored procedure used to get list of users for selected Region, Route, and Area.
* Input Parameters			: JSON      
* Output Parameters			: @OUT_ErrorNo            
* Return Value				: N/A            
* Assumptions				: None    
* Execution Statement		: Exec [RBAC].sp_Get_Admin_UserRoleInfo '{		
																	 "user_id": [1,2,3,4,5]
															         }'
*								
* Modified Date     Modified By   Revision Number  Modifications            

*******************************************************************************************************************************************/ 



CREATE PROCEDURE [RBAC].[sp_Get_Admin_UserRoleInfo]
	@Input_JSON		NVARCHAR(MAX)
AS 
BEGIN
	SET NOCOUNT ON
	
	
	BEGIN TRY
		DECLARE
				@ErrorMsg				VARCHAR(250),
				@result					NVARCHAR(MAX),
				@user_ids                NVARCHAR(MAX),
				@role_name              VARCHAR(50),
				@user_key               VARCHAR(64),
				@role_id                DECIMAL(18),
				@totalresultcnt         INT,
				@pageno					DECIMAL(18),
				@rowsperpage		    DECIMAL(18),
				@ast_typ_array			NVARCHAR(MAX),
				@ErrorDescription		VARCHAR(4000)				
				

     
		DECLARE  @tbl_Admin_UserRoleInfo TABLE
		(
				[user_id]              DECIMAL(18),
				user_key               VARCHAR(64),
				role_id                DECIMAL(18),
				role_name              VARCHAR(50)
				               
				
		)

		DECLARE  @UserId_Table TABLE
		(
			[user_id] DECIMAL(18)
		)

		  SELECT 
			@user_ids = COALESCE(@user_ids,CASE LOWER([key]) WHEN 'user_id' THEN [value] ELSE NULL END)
		

		FROM	OPENJSON(@Input_JSON);


		-- Validateion start

		IF (@user_ids IS NULL)
		BEGIN
			SET @ErrorMsg = 'Mandatory Input value is missing';
			DROP TABLE IF EXISTS #tbl_Admin_UserRoleInfo;
			THROW 50000,@ErrorMsg,1;
		END


	   -- Validation End
	    
		INSERT INTO @UserId_Table ([user_id])
		SELECT [value] FROM OPENJSON(@user_ids);


		INSERT INTO @tbl_Admin_UserRoleInfo
	   (
				[user_id],
				user_key,
				role_id,
				role_name
		)
		
			SELECT
				u.USER_SR_KEY AS user_id,
				u.USER_ID AS user_key,
				r.ROLE_SR_KEY AS role_id,
				r.ROLE_DESCRIPTION   AS role_name
			
			FROM [RBAC].[USER] AS u
			INNER JOIN [RBAC].[USER_ROLES] AS ur
			ON u.USER_SR_KEY = ur.USER_SR_KEY
			INNER JOIN [RBAC].[ROLES] AS r
			ON r.ROLE_SR_KEY = ur.ROLE_SR_KEY

			WHERE u.USER_SR_KEY IN (SELECT [user_id] FROM @UserId_Table)
			AND u.ISACTIVE= 1
			AND ur.ISACTIVE= 1
			AND r.ISACTIVE = 1
			

--select * from #tbl_Admin_UserRoleInfo
		SELECT  @totalresultcnt = count (1) FROM @tbl_Admin_UserRoleInfo

		--SELECT @totalresultcnt

		--If no records are returned in search result
		IF  @totalresultcnt=0 
		BEGIN
			SET @result=
					(
						SELECT 							
							@totalresultcnt AS searchdatacount,
							JSON_QUERY('[]') user_roleinfo
						
						FOR JSON PATH,WITHOUT_ARRAY_WRAPPER, INCLUDE_NULL_VALUES
				)
		END	

		--If alt least 1 record is returned in search result
		ELSE
		BEGIN
       --select getdate()
				SET @result=
				(
					SELECT 
							@totalresultcnt AS searchdatacount,
							(
								SELECT 									
									user_id,
									user_key,
									role_id,
									role_name
																
								FROM @tbl_Admin_UserRoleInfo AS sr
																
								FOR JSON PATH, INCLUDE_NULL_VALUES
							  ) user_roleinfo
							FOR JSON PATH, INCLUDE_NULL_VALUES, WITHOUT_ARRAY_WRAPPER
					    )
	
		END	

	--PRINT @result
		SELECT @result
		
	END TRY
	BEGIN CATCH
		SET @ErrorMsg = ERROR_MESSAGE() + 
						' Line Num:' + CONVERT(VARCHAR(5), ERROR_LINE()) + 
						',ErrorNum:' + CONVERT(VARCHAR(5), ERROR_NUMBER()) + 
						',Severity:' + CONVERT(VARCHAR(5), ERROR_SEVERITY()) + 
						',State:' + CONVERT(VARCHAR(10), ERROR_STATE()) + 
						',Procedure:' + CONVERT(VARCHAR(25), ERROR_PROCEDURE());  
		
		
		THROW 50000,@ErrorMsg,1;

		
	END CATCH

	SET NOCOUNT OFF
END