﻿/***************************************************************************************************************************************            
* Name						: vw_ADF_Reference_Type_Value            
* Created By				: Cognizant            
* Date Created				: 14-Dec-2020           
* Description				: This view will fetch all the reference type and value combinations. To be used in ADF ETL framework.
* Assumptions				: None    
* Execution Statement		: EXEC [ViewReferenceTypeValue]  
*								
* Modified Date     Modified By   Revision Number  Modifications            

*******************************************************************************************************************************************/ 


CREATE VIEW [CTL_CES_ADL_CONTROL].[vw_ADF_Reference_Type_Value]
AS
SELECT        
	RT.REF_TYP_SR_KEY, 
	RT.REF_TYP_NAME, 
	RT.REF_TYP_CODE, 
	RV.REF_VAL_SR_KEY, 
	RV.REF_VALUE
FROM            
	CES.REFERENCE_TYPE RT 
	INNER JOIN CES.REFERENCE_VALUE RV 
	ON RT.REF_TYP_SR_KEY = RV.REF_TYP_SR_KEY
