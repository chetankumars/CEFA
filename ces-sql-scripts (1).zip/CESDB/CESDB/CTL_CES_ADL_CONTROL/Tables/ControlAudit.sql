﻿CREATE TABLE [CTL_CES_ADL_CONTROL].[ControlAudit] (
    [AuditLogId]       INT           IDENTITY (1, 1) NOT NULL,
    [ADFName]          VARCHAR (500) NOT NULL,
    [PipeLineRunID]    VARCHAR (500) NOT NULL,
    [PipeLineName]     VARCHAR (500) NOT NULL,
    [ActivityName]     VARCHAR (500) NOT NULL,
    [Status]           VARCHAR (100) NOT NULL,
    [StartTime]        DATETIME      NULL,
    [EndTime]          DATETIME      NULL,
    [TargetTable]      VARCHAR (500) NULL,
    [Rows_Transferred] BIGINT        NULL,
    [Message]          VARCHAR (500) NULL,
    [TriggerType]      VARCHAR (100) NULL,
    [ISACTIVE]         BIT           DEFAULT ((1)) NOT NULL,
    [CREATED_USER]     VARCHAR (64)  NOT NULL,
    [CREATED_DATE]     DATETIME      NOT NULL,
    [UPDATED_USER]     VARCHAR (64)  NULL,
    [UPDATED_DATE]     DATETIME      NULL,
    CONSTRAINT [PK_ControlAudit_AuditLogId] PRIMARY KEY CLUSTERED ([AuditLogId] ASC) WITH (STATISTICS_NORECOMPUTE = ON)
);



