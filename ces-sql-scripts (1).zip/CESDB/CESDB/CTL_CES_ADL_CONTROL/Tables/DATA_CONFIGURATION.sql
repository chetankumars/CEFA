﻿CREATE TABLE [CTL_CES_ADL_CONTROL].[DATA_CONFIGURATION] (
    [CONFIG_SR_KEY]             DECIMAL (9)    IDENTITY (1, 1) NOT NULL,
    [ConfigGroupName]           VARCHAR (255)  NULL,
    [SourceTableName]           VARCHAR (255)  NULL,
    [OutboundDataLakeContainer] VARCHAR (255)  NULL,
    [OutboundDataLakePath]      VARCHAR (255)  NULL,
    [ConfigFunctionOperation]   VARCHAR (255)  NULL,
    [IncrementalColumnName]     VARCHAR (255)  NULL,
    [IncrementalDate]           DATETIME       NULL,
    [FlagColumnName]            VARCHAR (255)  NULL,
    [FlagColumnValue]           VARCHAR (50)   NULL,
    [FileName]                  VARCHAR (50)   NULL,
    [SqlQuery]                  VARCHAR (8000) NULL,
    [ISACTIVE]                  BIT            DEFAULT ((1)) NOT NULL,
    [CREATED_USER]              VARCHAR (64)   NOT NULL,
    [CREATED_DATE]              DATETIME       NOT NULL,
    [UPDATED_USER]              VARCHAR (64)   NULL,
    [UPDATED_DATE]              DATETIME       NULL,
    CONSTRAINT [PK_DATA_CONFIGURATION] PRIMARY KEY CLUSTERED ([CONFIG_SR_KEY] ASC)
);



