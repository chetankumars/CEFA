﻿CREATE TABLE [CTL_CES_ADL_CONTROL].[FileMetadata] (
    [FileLogId]               INT           IDENTITY (1, 1) NOT NULL,
    [PipeLineRunID]           VARCHAR (500) NOT NULL,
    [FileName]                VARCHAR (500) NOT NULL,
    [Description]             VARCHAR (500) NULL,
    [Owner]                   VARCHAR (500) NULL,
    [Security_Classification] VARCHAR (500) NULL,
    [Personal_Data]           VARCHAR (500) NULL,
    [Data_Type]               VARCHAR (500) NULL,
    [Data_Classification]     VARCHAR (500) NULL,
    [Encoding]                VARCHAR (100) NULL,
    [File_Extension]          VARCHAR (100) NULL,
    [Rows_Read]               BIGINT        NULL,
    [Rows_Transferred]        BIGINT        NULL,
    [Rows_Error]              BIGINT        NULL,
    [Storage_Layer]           VARCHAR (500) NULL,
    [ISACTIVE]                BIT           DEFAULT ((1)) NOT NULL,
    [CREATED_USER]            VARCHAR (500) NOT NULL,
    [CREATED_DATE]            DATETIME      NOT NULL,
    [UPDATED_USER]            VARCHAR (500) NULL,
    [UPDATED_DATE]            DATETIME      NULL,
    CONSTRAINT [PK_FileMetadata_FileLogId] PRIMARY KEY CLUSTERED ([FileLogId] ASC) WITH (STATISTICS_NORECOMPUTE = ON)
);



