﻿
/***************************************************************************************************************************************            
* Name						: sp_Insert_ADF_FileMetadata            
* Created By				: Cognizant            
* Date Created				: 04-Dec-2020           
* Description				: This stored procedure maintains the File Metadata.  
* Input Parameters			: 
								@FileName				VARCHAR(500)
								@PipeLineRunID			varchar(500) 
								,@Description			VARCHAR(500)
								,@Creator				VARCHAR(500)
								,@Owner					VARCHAR(500)
								,@Security_Classification VARCHAR(500)
								,@Personal_Data			VARCHAR(500)
								,@Data_Type				VARCHAR(500)
								,@Data_Classification	VARCHAR(500)								
								,@Encoding				VARCHAR(100)
								,@File_Extension		VARCHAR(100)
								,@Rows_Read				BIGINT
								,@Rows_Transferred		BIGINT
								,@Rows_Error			BIGINT
								,@Storage_Layer			VARCHAR(500)
								,@Creation_Date			DateTime   
* Output Parameters			: N/A            
* Return Value				: N/A            
* Assumptions				: None    
* Execution Statement		: Exec [CTL_CES_ADL_CONTROL].[sp_Insert_ADF_FileMetadata] '1'
*								
* Modified Date     Modified By   Revision Number  Modifications            

*******************************************************************************************************************************************/ 


CREATE PROCEDURE [CTL_CES_ADL_CONTROL].[sp_Insert_ADF_FileMetadata] 
(      
	@FileName				VARCHAR(500)
	,@PipeLineRunID			VARCHAR(500)
	,@Description			VARCHAR(500)
	,@Creator				VARCHAR(500)
	,@Owner					VARCHAR(500)
	,@Security_Classification VARCHAR(500)
	,@Personal_Data			VARCHAR(500)
	,@Data_Type				VARCHAR(500)
	,@Data_Classification	VARCHAR(500)
	,@Encoding				VARCHAR(100)
	,@File_Extension		VARCHAR(100)
	,@Rows_Read				BIGINT
	,@Rows_Transferred		BIGINT
	,@Rows_Error			BIGINT
	,@Storage_Layer			VARCHAR(500)
	,@Creation_Date			DateTime
 )      
AS      
SET NOCOUNT ON;     
BEGIN       
		INSERT INTO [CTL_CES_ADL_CONTROL].[FileMetadata] 
		(   
			[FileName]
			,[PipeLineRunID]
			,[Description]			
			,[Owner]
			,Security_Classification
			,Personal_Data
			,Data_Type	
			,Data_Classification
			,[Encoding]	
			,File_Extension
			,Rows_Read
			,Rows_Transferred
			,Rows_Error
			,Storage_Layer
			,[CREATED_USER]
			,[CREATED_DATE]
		 )      
		VALUES 
		(  
			@FileName
			,@PipeLineRunID
			,@Description		
			
			,@Owner
			,@Security_Classification	
			,@Personal_Data			
			,@Data_Type			
			,@Data_Classification
			,@Encoding				
			,@File_Extension
			,@Rows_Read
			,@Rows_Transferred
			,@Rows_Error
			,@Storage_Layer
			,@Creator
			,@Creation_Date		
		)   
END
