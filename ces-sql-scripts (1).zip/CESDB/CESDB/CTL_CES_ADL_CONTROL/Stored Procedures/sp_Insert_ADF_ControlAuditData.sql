﻿/***************************************************************************************************************************************            
* Name						: sp_Insert_ADF_ControlAuditData            
* Created By				: Cognizant            
* Date Created				: 04-Dec-2020           
* Description				: This stored procedure maintains the log of RCF pipeline activity.  
* Input Parameters			: 
								@ADFName					VARCHAR(500)
								,@PipeLineRunID				VARCHAR(500)
								,@PipeLineName				VARCHAR(500)
								,@ActivityName				VARCHAR(500)
								,@Status					VARCHAR(100)
								,@StartTime					DATETIME
								,@EndTime					DATETIME
								,@TargetTable				VARCHAR(500)
								,@Rows_Transferred			BIGINT
								,@SQLDBCopyStatus			VARCHAR(500)
								,@Message					VARCHAR(500)
								,@CreatedBy					VARCHAR(100)
								,@TriggerType				VARCHAR(100)    
* Output Parameters			: N/A            
* Return Value				: N/A            
* Assumptions				: None    
* Execution Statement		: Exec [CTL_CES_ADL_CONTROL].[sp_Insert_ADF_ControlAuditData] '1'
*								
* Modified Date     Modified By   Revision Number  Modifications            

*******************************************************************************************************************************************/ 



CREATE PROCEDURE [CTL_CES_ADL_CONTROL].[sp_Insert_ADF_ControlAuditData] 
(      
	 @ADFName					VARCHAR(500)
	,@PipeLineRunID				VARCHAR(500)
	,@PipeLineName				VARCHAR(500)
	,@ActivityName				VARCHAR(500)
	,@Status					VARCHAR(500)
	,@StartTime					DATETIME
	,@EndTime					DATETIME	
	,@TargetTable				VARCHAR(500)
	,@Rows_Transferred			BIGINT
	,@Message					VARCHAR(500)
	,@CreatedBy					VARCHAR(100)
	,@TriggerType				VARCHAR(100)
 )      
AS      
SET NOCOUNT ON;     
BEGIN       
		INSERT INTO [CTL_CES_ADL_CONTROL].[ControlAudit] 
		(      
			 ADFName
			,PipeLineRunID
			,PipeLineName
			,ActivityName
			,[Status]
			,StartTime
			,EndTime
			,TargetTable
			,Rows_Transferred
			,[Message]
			,CREATED_DATE
			,CREATED_USER
			,TriggerType
		 )      
		VALUES 
		(  
			@ADFName
			,@PipeLineRunID
			,@PipeLineName
			,@ActivityName
			,@Status
			,@StartTime
			,@EndTime
			,@TargetTable
			,@Rows_Transferred
			,@Message
			,getdate()
			,@CreatedBy 
			,@TriggerType
		)      
END
