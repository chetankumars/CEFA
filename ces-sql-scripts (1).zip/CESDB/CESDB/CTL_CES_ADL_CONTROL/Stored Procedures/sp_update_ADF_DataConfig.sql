﻿


/***************************************************************************************************************************************            
* Name						: sp_update_ADF_DataConfig            
* Created By				: Cognizant            
* Date Created				: 04-Jan-2021           
* Description				: This stored procedure maintains the dataConfiguration for updating max(IncrementalDate).  
* Input Parameters			: 
								@SourceTableName varchar(255),
                                @ConfigFunctionOperation varchar(255),
                                @IncrementalDate date  
* Output Parameters			: N/A            
* Return Value				: N/A            
* Assumptions				: None    
* Execution Statement		: Exec [CTL_CES_ADL_CONTROL].[sp_update_ADF_DataConfig]  'a,b'
*								
* Modified Date     Modified By   Revision Number  Modifications            

*******************************************************************************************************************************************/ 

CREATE PROCEDURE [CTL_CES_ADL_CONTROL].[sp_update_ADF_DataConfig] 
(      
	@SourceTableName			VARCHAR(255),
	@ConfigFunctionOperation	VARCHAR(255),
	@IncrementalDate			DATETIME
)
AS
BEGIN
SET NOCOUNT ON;
	UPDATE [CTL_CES_ADL_CONTROL].[DATA_CONFIGURATION] 
	SET 
	IncrementalDate= @IncrementalDate,
	UPDATED_USER = 'CES',
	UPDATED_DATE = getdate()
	WHERE SourceTableName IN(SELECT value FROM STRING_SPLIT(@SourceTableName,','))
	AND ConfigFunctionOperation=@ConfigFunctionOperation

SET NOCOUNT OFF;
END