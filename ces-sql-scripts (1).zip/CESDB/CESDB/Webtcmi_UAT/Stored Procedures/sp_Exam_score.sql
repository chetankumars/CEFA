/****** Object:  StoredProcedure [WEBTCMI].[sp_Exam_score]    Script Date: 7/21/2021 12:26:36 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [WEBTCMI].[sp_Exam_score]
	@Input_JSON		NVARCHAR(MAX)
	
AS 

BEGIN

drop table webtcmi.tmpexamscore;

create table webtcmi.tmpexamscore
(
Id INT not null,
LastScoreDate datetime2 null
)

Insert into webtcmi.tmpexamscore
(
Id,
LastScoreDate
)
Select Id,
LastScoreDate 
from OPENJSON(@Input_JSON,'$.value[0].value')
with
(
Id INT,
LastScoreDate datetime2
)
where LastScoreDate is not null

--select count(*) from webtcmi.tmpexamscore;

--select ExamId from webtcmi.tmpexamscore where LastScoreDate >= (select LAST_REQUEST_DATE from [WEBTCMI].[ctl_date] where table_name='SCORE')

delete from [WEBTCMI].[ExamMajorElementScores] 
where ExamId in (select Id from webtcmi.tmpexamscore where LastScoreDate >= (select LAST_REQUEST_DATE from [WEBTCMI].[ctl_date] where table_name='SCORE'));

--select * from webtcmi.tmpexamscore 

--(select LAST_REQUEST_DATE from [WEBTCMI].[ctl_date] where table_name='SCORE'));


delete from [WEBTCMI].[ExamMinorElementScores] 
where ExamId in (select Id from webtcmi.tmpexamscore where LastScoreDate >= (select LAST_REQUEST_DATE from [WEBTCMI].[ctl_date] where table_name='SCORE'));


delete from [WEBTCMI].[GroupedDefectScores] 
where ExamId in (select Id from webtcmi.tmpexamscore where LastScoreDate >= (select LAST_REQUEST_DATE from [WEBTCMI].[ctl_date] where table_name='SCORE'));

--select LAST_REQUEST_DATE from [WEBTCMI].[ctl_date] where table_name='SCORE'

--select count(*) from webtcmi.tmpexamscore;
drop table webtcmi.tmpexamscore;

end
GO

