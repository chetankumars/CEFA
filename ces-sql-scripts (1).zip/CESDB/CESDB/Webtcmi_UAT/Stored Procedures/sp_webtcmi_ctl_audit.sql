/****** Object:  StoredProcedure [WEBTCMI].[sp_webtcmi_ctl_audit]    Script Date: 7/21/2021 12:27:21 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/**************************************************************************************************************************************/           

CREATE PROCEDURE [WEBTCMI].[sp_webtcmi_ctl_audit] 
(      
	 @ADFName					VARCHAR(500)
	,@PipeLineRunID					VARCHAR(500)
	,@PipeLineName					VARCHAR(500)
	,@Status					VARCHAR(500)
	,@StartTime					DATETIME
	,@EndTime					DATETIME	
	,@Rows_Transferred				BIGINT
	,@CreatedBy					VARCHAR(100)
	,@TABLE_NAME				VARCHAR(100)
	 )      
AS      
SET NOCOUNT ON;     
BEGIN       
		INSERT INTO [WEBTCMI].[CTL_Webtcmi_audit] 
		(      
			 ADFName
			,PipeLineRunID
			,PipeLineName
			,[Status]
			,StartTime
			,EndTime
			,Rows_Transferred
			,CREATED_DATE
			,CREATED_USER
			,TABLE_NAME
			)     
		VALUES 
		(  
			@ADFName
			,@PipeLineRunID
			,@PipeLineName
			,@Status
			,@StartTime
			,@EndTime
			,@Rows_Transferred
			,getdate()
			,@CreatedBy
			,@TABLE_NAME 
	)		      

--declare @insertcount int;

--@insertcount = select max(createddate) from @TABLE_NAME;

---select @insertcount = count(*) from [WEBTCMI].[ASSETS] where createddate in (select max(createddate) from [WEBTCMI].[ASSETS])

---select @insertcount;

--update [WEBTCMI].[CTL_Webtcmi_audit] set CREATED_DATE = @insertcount where PipeLineRunID =@PipeLineRunID;

---update [WEBTCMI].[CTL_Webtcmi_audit] set Rows_Transferred = @insertcount where PipeLineRunID =@PipeLineRunID;

END
GO

