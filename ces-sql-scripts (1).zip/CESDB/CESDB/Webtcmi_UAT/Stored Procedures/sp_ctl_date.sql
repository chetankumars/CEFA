/****** Object:  StoredProcedure [WEBTCMI].[sp_ctl_date]    Script Date: 7/21/2021 12:25:34 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [WEBTCMI].[sp_ctl_date] 
(      
	 @TABLE_NAME					VARCHAR(500)
	,@CREATED_USER					VARCHAR(500)
	,@LAST_REQUEST_DATE				VARCHAR(500)
	 )      
AS      
SET NOCOUNT ON;     
begin       
/*
 --If @TABLE_NAME='TUNNELS'
update webtcmi.ctl_date
set CREATED_DATE = CURRENT_TIMESTAMP, LAST_REQUEST_DATE = a.lastRequestDate
from
(select max (LastModificationTime) as lastRequestDate from @TABLE_NAME) a
WHERE TABLE_NAME=@TABLE_NAME

*/

update webtcmi.ctl_date set CREATED_DATE = CURRENT_TIMESTAMP,LAST_REQUEST_DATE = (select convert( datetime2,@LAST_REQUEST_DATE,127) as LastRequestDate)
where TABLE_NAME=@TABLE_NAME


end
GO

