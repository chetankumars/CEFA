/****** Object:  Table [WEBTCMI].[CTL_Webtcmi_audit]    Script Date: 7/21/2021 12:17:26 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [WEBTCMI].[CTL_Webtcmi_audit](
	[ADFName] [varchar](500) NULL,
	[PipeLineRunID] [varchar](500) NULL,
	[PipeLineName] [varchar](500) NULL,
	[Status] [varchar](500) NULL,
	[StartTime] [datetime] NULL,
	[EndTime] [datetime] NULL,
	[Rows_Transferred] [bigint] NULL,
	[CREATED_DATE] [datetime] NULL,
	[CREATED_USER] [varchar](100) NULL,
	[TABLE_NAME] [varchar](100) NULL
) ON [PRIMARY]
GO

