/****** Object:  Table [WEBTCMI].[OtherFeatures]    Script Date: 7/21/2021 12:22:22 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [WEBTCMI].[OtherFeatures](
	[Id] [int] NOT NULL,
	[AssetId] [int] NULL,
	[MajorElementId] [int] NULL,
	[Type] [nvarchar](64) NULL,
	[SubType] [nvarchar](64) NULL,
	[IsDeleted] [bit] NOT NULL,
	[LastModificationTime] [datetime2](7) NULL,
	[CreatedDate] [datetime2](7) NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [WEBTCMI].[OtherFeatures]  WITH CHECK ADD FOREIGN KEY([AssetId])
REFERENCES [WEBTCMI].[ASSETS] ([Id])
GO

ALTER TABLE [WEBTCMI].[OtherFeatures]  WITH CHECK ADD FOREIGN KEY([MajorElementId])
REFERENCES [WEBTCMI].[MajorElements] ([Id])
GO

ALTER TABLE [WEBTCMI].[OtherFeatures]  WITH CHECK ADD CHECK  (([SubType]='Other' OR [SubType]='WaterManagementPipe' OR [SubType]='WaterManagement' OR [SubType]='CableHangers' OR [SubType]='GSMRMast' OR [SubType]='OHLEBracket' OR [SubType]='SignalSupport' OR [SubType]='LocationCabinet' OR [SubType]='WaterCatchmentStructure' OR [SubType]='ShaftCover' OR [SubType]='SteelworkSupportStructure' OR [SubType]='SteelChannels' OR [SubType]='ServiceBay' OR [SubType]='CastIronBeam' OR [SubType]='BoosterTransformer' OR [SubType]='ArchBeamRibs'))
GO

ALTER TABLE [WEBTCMI].[OtherFeatures]  WITH CHECK ADD CHECK  (([Type]='SuperStructure' OR [Type]='OtherStructure' OR [Type]='MultipleSimpleFixings' OR [Type]='EquipmentSupportStructure' OR [Type]='SubordinateStructure'))
GO

