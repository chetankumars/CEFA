/****** Object:  Table [WEBTCMI].[NotableItems]    Script Date: 7/21/2021 12:21:55 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [WEBTCMI].[NotableItems](
	[Id] [int] NOT NULL,
	[AssetId] [int] NULL,
	[MajorElementId] [int] NULL,
	[Flavour] [nvarchar](64) NULL,
	[IsDeleted] [bit] NOT NULL,
	[LastModificationTime] [datetime2](7) NULL,
	[CreatedDate] [date] NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [WEBTCMI].[NotableItems]  WITH CHECK ADD FOREIGN KEY([AssetId])
REFERENCES [WEBTCMI].[ASSETS] ([Id])
GO

ALTER TABLE [WEBTCMI].[NotableItems]  WITH CHECK ADD FOREIGN KEY([MajorElementId])
REFERENCES [WEBTCMI].[MajorElements] ([Id])
GO

ALTER TABLE [WEBTCMI].[NotableItems]  WITH CHECK ADD CHECK  (([Flavour]='SuspectedShaft' OR [Flavour]='OpenShaft' OR [Flavour]='HiddenShaft' OR [Flavour]='BlindShaft' OR [Flavour]='Measurements' OR [Flavour]='GroundLevelMeasurements' OR [Flavour]='GroundLevel' OR [Flavour]='VisualExam' OR [Flavour]='SkewedArea' OR [Flavour]='ConstructionJoint' OR [Flavour]='Discontinuity' OR [Flavour]='AccessArch' OR [Flavour]='Refuge' OR [Flavour]='Heading' OR [Flavour]='Adit' OR [Flavour]='CrossPassage' OR [Flavour]='Brickwork' OR [Flavour]='Rock' OR [Flavour]='SprayConcrete' OR [Flavour]='Label'))
GO

