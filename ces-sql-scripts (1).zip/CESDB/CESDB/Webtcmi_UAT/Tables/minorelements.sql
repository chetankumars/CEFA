/****** Object:  Table [WEBTCMI].[MinorElements]    Script Date: 7/21/2021 12:21:43 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [WEBTCMI].[MinorElements](
	[Id] [int] NOT NULL,
	[MajorElementId] [int] NOT NULL,
	[MinorCode] [nvarchar](16) NOT NULL,
	[MinorElementNumber] [int] NOT NULL,
	[Material] [nvarchar](64) NOT NULL,
	[IsDeleted] [bit] NOT NULL,
	[LastModificationTime] [datetime2](7) NULL,
	[Area] [decimal](6, 2) NOT NULL,
	[DimensionB] [decimal](6, 2) NULL,
	[CreatedDate] [datetime2](7) NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [WEBTCMI].[MinorElements]  WITH CHECK ADD FOREIGN KEY([MajorElementId])
REFERENCES [WEBTCMI].[MajorElements] ([Id])
GO

ALTER TABLE [WEBTCMI].[MinorElements]  WITH CHECK ADD CHECK  (([Material]='Dx' OR [Material]='Gp' OR [Material]='Ci' OR [Material]='Bi' OR [Material]='Ms' OR [Material]='Cs' OR [Material]='Ro' OR [Material]='Un' OR [Material]='Me' OR [Material]='Co' OR [Material]='St' OR [Material]='Br'))
GO

ALTER TABLE [WEBTCMI].[MinorElements]  WITH CHECK ADD CHECK  (([MinorCode]='HSW' OR [MinorCode]='SHX' OR [MinorCode]='SHS' OR [MinorCode]='CAP' OR [MinorCode]='EYR' OR [MinorCode]='EYU' OR [MinorCode]='WWL' OR [MinorCode]='FRV' OR [MinorCode]='HWL' OR [MinorCode]='PPT' OR [MinorCode]='PPR' OR [MinorCode]='INV' OR [MinorCode]='EWK' OR [MinorCode]='ESW' OR [MinorCode]='DSW' OR [MinorCode]='DPC' OR [MinorCode]='ESH' OR [MinorCode]='DSH' OR [MinorCode]='DDK' OR [MinorCode]='DMG' OR [MinorCode]='DAR' OR [MinorCode]='DSC' OR [MinorCode]='EWL' OR [MinorCode]='DCK' OR [MinorCode]='ARC' OR [MinorCode]='MGR' OR [MinorCode]='CRN' OR [MinorCode]='USC' OR [MinorCode]='UAR' OR [MinorCode]='UMG' OR [MinorCode]='UDK' OR [MinorCode]='USH' OR [MinorCode]='MSH' OR [MinorCode]='UPC' OR [MinorCode]='USW' OR [MinorCode]='MSW' OR [MinorCode]='MWK' OR [MinorCode]='LSW'))
GO

