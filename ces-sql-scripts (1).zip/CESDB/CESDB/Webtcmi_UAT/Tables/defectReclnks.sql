/****** Object:  Table [WEBTCMI].[DefectRecommendationLinks]    Script Date: 7/21/2021 12:18:05 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [WEBTCMI].[DefectRecommendationLinks](
	[DefectId] [int] NOT NULL,
	[RecommendationId] [int] NOT NULL,
	[IsDeleted] [bit] NOT NULL,
	[LastModificationTime] [datetime2](7) NULL,
	[CreatedDate] [datetime2](7) NULL
) ON [PRIMARY]
GO

ALTER TABLE [WEBTCMI].[DefectRecommendationLinks]  WITH CHECK ADD FOREIGN KEY([DefectId])
REFERENCES [WEBTCMI].[Defects] ([Id])
GO

ALTER TABLE [WEBTCMI].[DefectRecommendationLinks]  WITH CHECK ADD FOREIGN KEY([RecommendationId])
REFERENCES [WEBTCMI].[Recommendations] ([Id])
GO

