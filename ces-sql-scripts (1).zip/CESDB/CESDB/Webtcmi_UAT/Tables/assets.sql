/****** Object:  Table [WEBTCMI].[ASSETS]    Script Date: 7/21/2021 12:16:23 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [WEBTCMI].[ASSETS](
	[Id] [int] NOT NULL,
	[Name] [nvarchar](128) NOT NULL,
	[AssetType] [nvarchar](64) NOT NULL,
	[BoreCutAndCover] [bit] NULL,
	[Route] [nvarchar](64) NULL,
	[Region] [nvarchar](64) NULL,
	[ShaftType] [nvarchar](64) NULL,
	[Elr] [nvarchar](64) NULL,
	[RailwayId] [nvarchar](64) NOT NULL,
	[BoreId] [int] NULL,
	[TunnelId] [int] NOT NULL,
	[CarrsGuid] [nvarchar](32) NOT NULL,
	[IsDeleted] [bit] NOT NULL,
	[LastModificationTime] [datetime2](7) NULL,
	[SignificantWaterIngress] [bit] NULL,
	[DefectsGettingWorse] [bit] NULL,
	[PresenceOfWaterManagement] [bit] NULL,
	[MisalignedJoints] [bit] NULL,
	[SpalledConcrete] [bit] NULL,
	[LooseOrMissingSegmentBolts] [bit] NULL,
	[CastIronSectionLoss] [bit] NULL,
	[LowerSegmentalCriteria] [bit] NULL,
	[LowerCriteria] [bit] NOT NULL,
	[HasRBE] [bit] NOT NULL,
	[IsNRResponsibility] [bit] NULL,
	[OperationalStatus] [nvarchar](64) NULL,
	[CreatedDate] [datetime2](7) NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [WEBTCMI].[ASSETS]  WITH CHECK ADD FOREIGN KEY([TunnelId])
REFERENCES [WEBTCMI].[TUNNELS] ([Id])
GO

ALTER TABLE [WEBTCMI].[ASSETS]  WITH CHECK ADD CHECK  (([AssetType]='Shaft' OR [AssetType]='Bore'))
GO

ALTER TABLE [WEBTCMI].[ASSETS]  WITH CHECK ADD CHECK  (([Elr]='YRC' OR [Elr]='YKR' OR [Elr]='XTD' OR [Elr]='WYS' OR [Elr]='WYM' OR [Elr]='WSJ2' OR [Elr]='WPH1' OR [Elr]='WKL2' OR [Elr]='WJL4' OR [Elr]='WHL' OR [Elr]='WEY' OR [Elr]='WCM2' OR [Elr]='WBS1' OR [Elr]='WAH' OR [Elr]='VTB3' OR [Elr]='VTB2' OR [Elr]='VOG' OR [Elr]='VIR' OR [Elr]='TTH' OR [Elr]='TTA1' OR [Elr]='TSB' OR [Elr]='TLA' OR [Elr]='TJC3' OR [Elr]='TJC1' OR [Elr]='THO' OR [Elr]='TCC' OR [Elr]='TBH1' OR [Elr]='TAT' OR [Elr]='TAH1' OR [Elr]='SWM2' OR [Elr]='SWM1' OR [Elr]='SWB' OR [Elr]='SUB2' OR [Elr]='STR2' OR [Elr]='SSP' OR [Elr]='SPC8' OR [Elr]='SPC6' OR [Elr]='SPC4' OR [Elr]='SPC1' OR [Elr]='SMJ2' OR [Elr]='SKS1' OR [Elr]='SKN' OR [Elr]='SJO1' OR [Elr]='SJC' OR [Elr]='SIL' OR [Elr]='SHL' OR [Elr]='SHB' OR [Elr]='SGN' OR [Elr]='SDI2' OR [Elr]='SCU1' OR [Elr]='SCT2' OR [Elr]='SCT1' OR [Elr]='SCQ2' OR [Elr]='SCQ1' OR [Elr]='SCM4' OR [Elr]='SCM3' OR [Elr]='SBO' OR [Elr]='SBJ' OR [Elr]='SBH1' OR [Elr]='SAC' OR [Elr]='RTT' OR [Elr]='RJB' OR [Elr]='RHD2' OR [Elr]='RED2' OR [Elr]='RBS2' OR [Elr]='RBS1' OR [Elr]='RAC' OR [Elr]='PWS2' OR [Elr]='PSR2' OR [Elr]='PSE' OR [Elr]='PPH' OR [Elr]='POD' OR [Elr]='PEM' OR [Elr]='PEH' OR [Elr]='PED5' OR [Elr]='PED2' OR [Elr]='PDB' OR [Elr]='PBJ' OR [Elr]='PAA1' OR [Elr]='OXD' OR [Elr]='OWW' OR [Elr]='OME3' OR [Elr]='NWO' OR [Elr]='NSS' OR [Elr]='NOG1' OR [Elr]='NOC' OR [Elr]='NMC1' OR [Elr]='NKL' OR [Elr]='NEW' OR [Elr]='NEM7' OR [Elr]='NEM4' OR [Elr]='NEM3' OR [Elr]='NEM2' OR [Elr]='NEC2' OR [Elr]='NAJ3' OR [Elr]='NAJ2' OR [Elr]='NAJ1' OR [Elr]='MVN2' OR [Elr]='MVM' OR [Elr]='MVL3' OR [Elr]='MVL1' OR [Elr]='MVE2' OR [Elr]='MVE1' OR [Elr]='MRB' OR [Elr]='MLN4' OR [Elr]='MLN3' OR [Elr]='MLN2' OR [Elr]='MLN1' OR [Elr]='MLG2' OR [Elr]='MIR2' OR [Elr]='MIR1' OR [Elr]='MEB2' OR [Elr]='MEB1' OR [Elr]='MDL1' OR [Elr]='MCL2' OR [Elr]='MCL' OR [Elr]='MCJ1' OR [Elr]='MCH' OR [Elr]='MAS' OR [Elr]='MAC3' OR [Elr]='LTN1' OR [Elr]='LLI' OR [Elr]='LLA' OR [Elr]='LJT1' OR [Elr]='LGS2' OR [Elr]='LEN3' OR [Elr]='LEJ' OR [Elr]='LEH1' OR [Elr]='LEC2' OR [Elr]='LEC1' OR [Elr]='LCS' OR [Elr]='LBE4' OR [Elr]='LBE1' OR [Elr]='KSL' OR [Elr]='KJE1' OR [Elr]='KHL' OR [Elr]='JRT2' OR [Elr]='JRT1' OR [Elr]='IOW' OR [Elr]='ILK1' OR [Elr]='HXS2' OR [Elr]='HXS1' OR [Elr]='HSX2' OR [Elr]='HNR' OR [Elr]='HNL1' OR [Elr]='HMN2' OR [Elr]='HGL2' OR [Elr]='HDT' OR [Elr]='HDR' OR [Elr]='HDB' OR [Elr]='HCM2' OR [Elr]='HAY1' OR [Elr]='HAF' OR [Elr]='GUE2' OR [Elr]='GSW' OR [Elr]='GSM4' OR [Elr]='GSM2' OR [Elr]='GSM1' OR [Elr]='GSJ2' OR [Elr]='GSJ1' OR [Elr]='GRD' OR [Elr]='GOU2' OR [Elr]='GAE' OR [Elr]='FHR6' OR [Elr]='FHR5' OR [Elr]='FDM' OR [Elr]='FAL1' OR [Elr]='EWG' OR [Elr]='ETF' OR [Elr]='EHW' OR [Elr]='EGM3' OR [Elr]='EGM1' OR [Elr]='ECN2' OR [Elr]='ECM8' OR [Elr]='ECM1' OR [Elr]='DSE' OR [Elr]='DOL2' OR [Elr]='DJP' OR [Elr]='DJH' OR [Elr]='DCL' OR [Elr]='DAE2' OR [Elr]='CWR' OR [Elr]='CWL2' OR [Elr]='CWK2' OR [Elr]='CWK1' OR [Elr]='CWJ' OR [Elr]='CRL' OR [Elr]='CRC2' OR [Elr]='CNX' OR [Elr]='CNH3' OR [Elr]='CNH1' OR [Elr]='CNB3' OR [Elr]='CNB1' OR [Elr]='CMD1' OR [Elr]='CLY' OR [Elr]='CJC' OR [Elr]='CHW1' OR [Elr]='CGJ2' OR [Elr]='CFP' OR [Elr]='CCS2' OR [Elr]='CCL' OR [Elr]='CCH' OR [Elr]='CBC3' OR [Elr]='CBC1' OR [Elr]='CAT' OR [Elr]='CAR' OR [Elr]='CAM' OR [Elr]='BUX' OR [Elr]='BTL' OR [Elr]='BTH3' OR [Elr]='BTH1' OR [Elr]='BTC' OR [Elr]='BSW' OR [Elr]='BRY' OR [Elr]='BOK2' OR [Elr]='BML3' OR [Elr]='BML2' OR [Elr]='BML1' OR [Elr]='BME2' OR [Elr]='BLI1' OR [Elr]='BHI' OR [Elr]='BGL2' OR [Elr]='BGK' OR [Elr]='BFB' OR [Elr]='BEX' OR [Elr]='BEJ' OR [Elr]='BEC' OR [Elr]='BCG' OR [Elr]='BBJ' OR [Elr]='BBB' OR [Elr]='BAH2' OR [Elr]='BAG1' OR [Elr]='BAE2' OR [Elr]='BAE1' OR [Elr]='ATL' OR [Elr]='ATH' OR [Elr]='ARG2' OR [Elr]='ANI1' OR [Elr]='ALC2' OR [Elr]='AJM1' OR [Elr]='AFR' OR [Elr]='AAV' OR [Elr]='AAV'))
GO

ALTER TABLE [WEBTCMI].[ASSETS]  WITH CHECK ADD CHECK  (([OperationalStatus]='Unlocated' OR [OperationalStatus]='PartInfilled' OR [OperationalStatus]='Functionary' OR [OperationalStatus]='NonOperational' OR [OperationalStatus]='Operational'))
GO

ALTER TABLE [WEBTCMI].[ASSETS]  WITH CHECK ADD CHECK  (([Region]='WalesAndWestern' OR [Region]='Southern' OR [Region]='ScotlandsRailway' OR [Region]='NorthWestAndCentral' OR [Region]='Eastern'))
GO

ALTER TABLE [WEBTCMI].[ASSETS]  WITH CHECK ADD CHECK  (([Route]='Western' OR [Route]='WestCoastMainlineSouth' OR [Route]='Wessex' OR [Route]='WalesAndBorders' OR [Route]='Sussex' OR [Route]='Scotland' OR [Route]='NorthWest' OR [Route]='NorthAndEast' OR [Route]='NetworkRailHighSpeed' OR [Route]='Kent' OR [Route]='EastMidlands' OR [Route]='EastCoast' OR [Route]='Central' OR [Route]='Anglia'))
GO

ALTER TABLE [WEBTCMI].[ASSETS]  WITH CHECK ADD CHECK  (([ShaftType]='Suspected' OR [ShaftType]='Hidden' OR [ShaftType]='Blind' OR [ShaftType]='Open'))
GO

