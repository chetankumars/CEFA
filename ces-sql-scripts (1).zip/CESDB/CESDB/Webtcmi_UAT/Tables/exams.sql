/****** Object:  Table [WEBTCMI].[Exams]    Script Date: 7/21/2021 12:20:00 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [WEBTCMI].[Exams](
	[Id] [int] NOT NULL,
	[AssetId] [int] NULL,
	[DateCarriedOut] [datetime2](7) NULL,
	[Status] [nvarchar](64) NOT NULL,
	[AssetScore] [float] NULL,
	[IsDeleted] [bit] NOT NULL,
	[LastModificationTime] [datetime2](7) NULL,
	[LastScoreDate] [datetime2](7) NULL,
	[CreatedDate] [datetime2](7) NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [WEBTCMI].[Exams]  WITH CHECK ADD FOREIGN KEY([AssetId])
REFERENCES [WEBTCMI].[ASSETS] ([Id])
GO

ALTER TABLE [WEBTCMI].[Exams]  WITH CHECK ADD CHECK  (([Status]='Abandoned' OR [Status]='Complete' OR [Status]='DefectsCompleted' OR [Status]='ElementsVerified' OR [Status]='New'))
GO

