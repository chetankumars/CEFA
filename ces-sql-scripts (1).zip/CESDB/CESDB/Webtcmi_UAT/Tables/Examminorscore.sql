/****** Object:  Table [WEBTCMI].[ExamMinorElementScores]    Script Date: 7/21/2021 12:19:30 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [WEBTCMI].[ExamMinorElementScores](
	[ExamId] [int] NOT NULL,
	[MinorElementId] [int] NOT NULL,
	[Score] [float] NOT NULL,
	[LastScoreDate] [datetime2](7) NOT NULL,
	[CreatedDate] [datetime2](7) NULL
) ON [PRIMARY]
GO

ALTER TABLE [WEBTCMI].[ExamMinorElementScores]  WITH CHECK ADD FOREIGN KEY([ExamId])
REFERENCES [WEBTCMI].[Exams] ([Id])
GO

ALTER TABLE [WEBTCMI].[ExamMinorElementScores]  WITH CHECK ADD FOREIGN KEY([MinorElementId])
REFERENCES [WEBTCMI].[MinorElements] ([Id])
GO

