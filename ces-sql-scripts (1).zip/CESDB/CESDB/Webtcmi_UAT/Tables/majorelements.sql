/****** Object:  Table [WEBTCMI].[MajorElements]    Script Date: 7/21/2021 12:20:53 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [WEBTCMI].[MajorElements](
	[Id] [int] NOT NULL,
	[AssetId] [int] NOT NULL,
	[MajorElementCode] [nvarchar](32) NOT NULL,
	[MajorElementNumber] [int] NOT NULL,
	[ParapetSubjectToSurcharge] [bit] NULL,
	[PortalShowingSignsOfDeformation] [bit] NULL,
	[PortalRetainMoistureLadenSoil] [bit] NULL,
	[LowerCriteria] [bit] NOT NULL,
	[HasRBE] [bit] NOT NULL,
	[IsDeleted] [bit] NOT NULL,
	[LastModificationTime] [datetime2](7) NULL,
	[CreatedDate] [datetime2](7) NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [WEBTCMI].[MajorElements]  WITH CHECK ADD FOREIGN KEY([AssetId])
REFERENCES [WEBTCMI].[ASSETS] ([Id])
GO

ALTER TABLE [WEBTCMI].[MajorElements]  WITH CHECK ADD CHECK  (([MajorElementCode]='HG' OR [MajorElementCode]='AD' OR [MajorElementCode]='CP' OR [MajorElementCode]='SV' OR [MajorElementCode]='IP' OR [MajorElementCode]='TP' OR [MajorElementCode]='SH' OR [MajorElementCode]='EO' OR [MajorElementCode]='EB' OR [MajorElementCode]='FX' OR [MajorElementCode]='FS' OR [MajorElementCode]='JX' OR [MajorElementCode]='JS' OR [MajorElementCode]='TC' OR [MajorElementCode]='TX' OR [MajorElementCode]='TS'))
GO

