/****** Object:  Table [WEBTCMI].[Defects]    Script Date: 7/21/2021 12:18:53 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [WEBTCMI].[Defects](
	[Id] [int] NOT NULL,
	[AssetId] [int] NULL,
	[MajorElementId] [int] NULL,
	[ExamAddedId] [int] NOT NULL,
	[ExamRemovedId] [int] NULL,
	[DefectCode] [nvarchar](64) NOT NULL,
	[IsDeleted] [bit] NOT NULL,
	[LastModificationTime] [datetime2](7) NULL,
	[CreatedDate] [datetime2](7) NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [WEBTCMI].[Defects]  WITH CHECK ADD FOREIGN KEY([AssetId])
REFERENCES [WEBTCMI].[ASSETS] ([Id])
GO

ALTER TABLE [WEBTCMI].[Defects]  WITH CHECK ADD FOREIGN KEY([ExamAddedId])
REFERENCES [WEBTCMI].[Exams] ([Id])
GO

ALTER TABLE [WEBTCMI].[Defects]  WITH CHECK ADD FOREIGN KEY([ExamRemovedId])
REFERENCES [WEBTCMI].[Exams] ([Id])
GO

ALTER TABLE [WEBTCMI].[Defects]  WITH CHECK ADD FOREIGN KEY([MajorElementId])
REFERENCES [WEBTCMI].[MajorElements] ([Id])
GO

ALTER TABLE [WEBTCMI].[Defects]  WITH CHECK ADD CHECK  (([DefectCode]='RS3' OR [DefectCode]='RS2' OR [DefectCode]='RS1' OR [DefectCode]='R5' OR [DefectCode]='R4' OR [DefectCode]='R3' OR [DefectCode]='R2' OR [DefectCode]='R1' OR [DefectCode]='P5' OR [DefectCode]='P4' OR [DefectCode]='P3' OR [DefectCode]='P2' OR [DefectCode]='P1' OR [DefectCode]='RO' OR [DefectCode]='DC' OR [DefectCode]='SP3' OR [DefectCode]='SP2' OR [DefectCode]='SP1' OR [DefectCode]='SR3' OR [DefectCode]='SR2' OR [DefectCode]='SR1' OR [DefectCode]='SS3' OR [DefectCode]='SS2' OR [DefectCode]='SS1' OR [DefectCode]='W5' OR [DefectCode]='W4' OR [DefectCode]='W3' OR [DefectCode]='W2' OR [DefectCode]='W1' OR [DefectCode]='S3' OR [DefectCode]='S2' OR [DefectCode]='S1' OR [DefectCode]='NE' OR [DefectCode]='MC4' OR [DefectCode]='MC3' OR [DefectCode]='MC2' OR [DefectCode]='MC1' OR [DefectCode]='J3' OR [DefectCode]='J2' OR [DefectCode]='J1' OR [DefectCode]='HS' OR [DefectCode]='HN' OR [DefectCode]='DN' OR [DefectCode]='DM' OR [DefectCode]='DL' OR [DefectCode]='CV4' OR [DefectCode]='CV3' OR [DefectCode]='CV2' OR [DefectCode]='CV1' OR [DefectCode]='CU4' OR [DefectCode]='CU3' OR [DefectCode]='CU2' OR [DefectCode]='CU1' OR [DefectCode]='CS4' OR [DefectCode]='CS3' OR [DefectCode]='CS2' OR [DefectCode]='CS1' OR [DefectCode]='CL4' OR [DefectCode]='CL3' OR [DefectCode]='CL2' OR [DefectCode]='CL1' OR [DefectCode]='CH4' OR [DefectCode]='CH3' OR [DefectCode]='CH2' OR [DefectCode]='CH1' OR [DefectCode]='CD4' OR [DefectCode]='CD3' OR [DefectCode]='CD2' OR [DefectCode]='CD1' OR [DefectCode]='CC4' OR [DefectCode]='CC3' OR [DefectCode]='CC2' OR [DefectCode]='CC1' OR [DefectCode]='BS' OR [DefectCode]='BH' OR [DefectCode]='BC' OR [DefectCode]='SR2' OR [DefectCode]='SR1' OR [DefectCode]='SS3' OR [DefectCode]='SS2' OR [DefectCode]='SS1' OR [DefectCode]='W5' OR [DefectCode]='W4' OR [DefectCode]='W3' OR [DefectCode]='W2' OR [DefectCode]='W1' OR [DefectCode]='S3' OR [DefectCode]='S2' OR [DefectCode]='S1' OR [DefectCode]='NE' OR [DefectCode]='MC4' OR [DefectCode]='MC3' OR [DefectCode]='MC2' OR [DefectCode]='MC1' OR [DefectCode]='J3' OR [DefectCode]='J2' OR [DefectCode]='J1' OR [DefectCode]='HS' OR [DefectCode]='HN' OR [DefectCode]='DN' OR [DefectCode]='DM' OR [DefectCode]='DL' OR [DefectCode]='CV4' OR [DefectCode]='CV3' OR [DefectCode]='CV2' OR [DefectCode]='CV1' OR [DefectCode]='CU4' OR [DefectCode]='CU3' OR [DefectCode]='CU2' OR [DefectCode]='CU1' OR [DefectCode]='CS4' OR [DefectCode]='CS3' OR [DefectCode]='CS2' OR [DefectCode]='CS1' OR [DefectCode]='CL4' OR [DefectCode]='CL3' OR [DefectCode]='CL2' OR [DefectCode]='CL1' OR [DefectCode]='CH4' OR [DefectCode]='CH3' OR [DefectCode]='CH2' OR [DefectCode]='CH1' OR [DefectCode]='CD4' OR [DefectCode]='CD3' OR [DefectCode]='CD2' OR [DefectCode]='CD1' OR [DefectCode]='CC4' OR [DefectCode]='CC3' OR [DefectCode]='CC2' OR [DefectCode]='CC1' OR [DefectCode]='BS' OR [DefectCode]='BH' OR [DefectCode]='BC' OR [DefectCode]='SR1' OR [DefectCode]='SS3' OR [DefectCode]='SS2' OR [DefectCode]='SS1' OR [DefectCode]='W5' OR [DefectCode]='W4' OR [DefectCode]='W3' OR [DefectCode]='W2' OR [DefectCode]='W1' OR [DefectCode]='S3' OR [DefectCode]='S2' OR [DefectCode]='S1' OR [DefectCode]='NE' OR [DefectCode]='MC4' OR [DefectCode]='MC3' OR [DefectCode]='MC2' OR [DefectCode]='MC1' OR [DefectCode]='J3' OR [DefectCode]='J2' OR [DefectCode]='J1' OR [DefectCode]='HS' OR [DefectCode]='HN' OR [DefectCode]='DN' OR [DefectCode]='DM' OR [DefectCode]='DL' OR [DefectCode]='CV4' OR [DefectCode]='CV3' OR [DefectCode]='CV2' OR [DefectCode]='CV1' OR [DefectCode]='CU4' OR [DefectCode]='CU3' OR [DefectCode]='CU2' OR [DefectCode]='CU1' OR [DefectCode]='CS4' OR [DefectCode]='CS3' OR [DefectCode]='CS2' OR [DefectCode]='CS1' OR [DefectCode]='CL4' OR [DefectCode]='CL3' OR [DefectCode]='CL2' OR [DefectCode]='CL1' OR [DefectCode]='CH4' OR [DefectCode]='CH3' OR [DefectCode]='CH2' OR [DefectCode]='CH1' OR [DefectCode]='CD4' OR [DefectCode]='CD3' OR [DefectCode]='CD2' OR [DefectCode]='CD1' OR [DefectCode]='CC4' OR [DefectCode]='CC3' OR [DefectCode]='CC2' OR [DefectCode]='CC1' OR [DefectCode]='BS' OR [DefectCode]='BH' OR [DefectCode]='BC' OR [DefectCode]='SR2' OR [DefectCode]='SR1' OR [DefectCode]='SS3' OR [DefectCode]='SS2' OR [DefectCode]='SS1' OR [DefectCode]='W5' OR [DefectCode]='W4' OR [DefectCode]='W3' OR [DefectCode]='W2' OR [DefectCode]='W1' OR [DefectCode]='S3' OR [DefectCode]='S2' OR [DefectCode]='S1' OR [DefectCode]='NE' OR [DefectCode]='MC4' OR [DefectCode]='MC3' OR [DefectCode]='MC2' OR [DefectCode]='MC1' OR [DefectCode]='J3' OR [DefectCode]='J2' OR [DefectCode]='J1' OR [DefectCode]='HS' OR [DefectCode]='HN' OR [DefectCode]='DN' OR [DefectCode]='DM' OR [DefectCode]='DL' OR [DefectCode]='CV4' OR [DefectCode]='CV3' OR [DefectCode]='CV2' OR [DefectCode]='CV1' OR [DefectCode]='CU4' OR [DefectCode]='CU3' OR [DefectCode]='CU2' OR [DefectCode]='CU1' OR [DefectCode]='CS4' OR [DefectCode]='CS3' OR [DefectCode]='CS2' OR [DefectCode]='CS1' OR [DefectCode]='CL4' OR [DefectCode]='CL3' OR [DefectCode]='CL2' OR [DefectCode]='CL1' OR [DefectCode]='CH4' OR [DefectCode]='CH3' OR [DefectCode]='CH2' OR [DefectCode]='CH1' OR [DefectCode]='CD4' OR [DefectCode]='CD3' OR [DefectCode]='CD2' OR [DefectCode]='CD1' OR [DefectCode]='CC4' OR [DefectCode]='CC3' OR [DefectCode]='CC2' OR [DefectCode]='CC1' OR [DefectCode]='BS' OR [DefectCode]='BH' OR [DefectCode]='BC'))
GO

