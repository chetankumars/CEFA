/****** Object:  Table [WEBTCMI].[ExamRecommendationLinks]    Script Date: 7/21/2021 12:19:47 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [WEBTCMI].[ExamRecommendationLinks](
	[RecommendationId] [int] NOT NULL,
	[ExamId] [int] NOT NULL,
	[RecommendationIncluded] [bit] NULL,
	[IsDeleted] [bit] NOT NULL,
	[LastModificationTime] [datetime2](7) NULL,
	[CreatedDate] [datetime2](7) NULL
) ON [PRIMARY]
GO

ALTER TABLE [WEBTCMI].[ExamRecommendationLinks]  WITH CHECK ADD FOREIGN KEY([ExamId])
REFERENCES [WEBTCMI].[Exams] ([Id])
GO

ALTER TABLE [WEBTCMI].[ExamRecommendationLinks]  WITH CHECK ADD FOREIGN KEY([RecommendationId])
REFERENCES [WEBTCMI].[Recommendations] ([Id])
GO

