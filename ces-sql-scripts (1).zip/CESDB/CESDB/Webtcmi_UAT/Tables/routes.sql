/****** Object:  Table [WEBTCMI].[ROUTES]    Script Date: 7/21/2021 12:23:09 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [WEBTCMI].[ROUTES](
	[CODE] [nvarchar](64) NOT NULL,
	[NAME] [nvarchar](64) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[CODE] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [WEBTCMI].[ROUTES]  WITH CHECK ADD CHECK  (([CODE]='Western' OR [CODE]='WestCoastMainlineSouth' OR [CODE]='Wessex' OR [CODE]='WalesandBorders' OR [CODE]='Sussex' OR [CODE]='Scotland' OR [CODE]='NorthWest' OR [CODE]='NorthandEast' OR [CODE]='NetworkRailHighSpeed' OR [CODE]='Kent' OR [CODE]='EastMidlands' OR [CODE]='EastCoast' OR [CODE]='Central' OR [CODE]='Anglia'))
GO

