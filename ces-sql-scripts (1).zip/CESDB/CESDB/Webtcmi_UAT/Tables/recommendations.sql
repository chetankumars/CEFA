/****** Object:  Table [WEBTCMI].[Recommendations]    Script Date: 7/21/2021 12:22:41 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [WEBTCMI].[Recommendations](
	[Id] [int] NOT NULL,
	[AssetId] [int] NULL,
	[MajorElementId] [int] NULL,
	[Priority] [int] NOT NULL,
	[Probability] [int] NOT NULL,
	[Effect] [int] NOT NULL,
	[ExamAddedId] [int] NOT NULL,
	[ExamRemovedId] [int] NULL,
	[IsDeleted] [bit] NULL,
	[HasBeenSignificant] [bit] NOT NULL,
	[DeletionReason] [nvarchar](64) NOT NULL,
	[LastModificationTime] [datetime2](7) NULL,
	[CreatedDate] [datetime2](7) NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [WEBTCMI].[Recommendations]  WITH CHECK ADD FOREIGN KEY([AssetId])
REFERENCES [WEBTCMI].[ASSETS] ([Id])
GO

ALTER TABLE [WEBTCMI].[Recommendations]  WITH CHECK ADD FOREIGN KEY([ExamAddedId])
REFERENCES [WEBTCMI].[Exams] ([Id])
GO

ALTER TABLE [WEBTCMI].[Recommendations]  WITH CHECK ADD FOREIGN KEY([ExamRemovedId])
REFERENCES [WEBTCMI].[Exams] ([Id])
GO

ALTER TABLE [WEBTCMI].[Recommendations]  WITH CHECK ADD FOREIGN KEY([MajorElementId])
REFERENCES [WEBTCMI].[MajorElements] ([Id])
GO

ALTER TABLE [WEBTCMI].[Recommendations]  WITH CHECK ADD CHECK  (([DeletionReason]='DefectDeleted' OR [DeletionReason]='Other' OR [DeletionReason]='NotFound' OR [DeletionReason]='Repaired' OR [DeletionReason]='Error'))
GO

