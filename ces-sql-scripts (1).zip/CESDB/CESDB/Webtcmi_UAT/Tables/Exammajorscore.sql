/****** Object:  Table [WEBTCMI].[ExamMajorElementScores]    Script Date: 7/21/2021 12:19:13 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [WEBTCMI].[ExamMajorElementScores](
	[ExamId] [int] NOT NULL,
	[MajorElementId] [int] NOT NULL,
	[Score] [float] NOT NULL,
	[LastScoreDate] [datetime2](7) NOT NULL,
	[CreatedDate] [datetime2](7) NULL
) ON [PRIMARY]
GO

ALTER TABLE [WEBTCMI].[ExamMajorElementScores]  WITH CHECK ADD FOREIGN KEY([ExamId])
REFERENCES [WEBTCMI].[Exams] ([Id])
GO

ALTER TABLE [WEBTCMI].[ExamMajorElementScores]  WITH CHECK ADD FOREIGN KEY([MajorElementId])
REFERENCES [WEBTCMI].[MajorElements] ([Id])
GO

