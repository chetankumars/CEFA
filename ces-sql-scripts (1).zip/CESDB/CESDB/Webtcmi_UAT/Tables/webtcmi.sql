/****** Object:  Schema [WEBTCMI]    Script Date: 7/21/2021 12:27:44 PM ******/
CREATE SCHEMA [WEBTCMI]
GO

