/****** Object:  Table [WEBTCMI].[ctl_date]    Script Date: 7/21/2021 12:17:04 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [WEBTCMI].[ctl_date](
	[CREATED_DATE] [datetime] NULL,
	[CREATED_USER] [varchar](100) NULL,
	[LAST_REQUEST_DATE] [datetime2](7) NULL,
	[TABLE_NAME] [varchar](100) NULL
) ON [PRIMARY]
GO

