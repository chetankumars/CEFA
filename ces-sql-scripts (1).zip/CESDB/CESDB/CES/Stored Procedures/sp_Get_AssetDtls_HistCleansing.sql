﻿
/***************************************************************************************************************************************            
* Name						: sp_Get_AssetDtls_HistCleansing            
* Created By				: Cognizant            
* Date Created				: 09-Apr-2021           
* Description				: This stored procedure fetches the Asset data from CARRS and Bridge tables for history cleansing in Asset Details page.  
* Input Parameters			: N/A      
* Output Parameters			: N/A            
* Return Value				: N/A            
* Assumptions				: None    
* Execution Statement		: EXEC [CES].sp_Get_AssetDtls_HistCleansing '3978559C2D8E45D9E04400306E4AD01A'
*								
* Modified Date     Modified By   Revision Number  Modifications            

*******************************************************************************************************************************************/ 



CREATE PROCEDURE [CES].[sp_Get_AssetDtls_HistCleansing] 
    @Asset_GUID VARCHAR (32)
AS 


BEGIN
	SET NOCOUNT ON
    BEGIN TRY
		DECLARE
				@ErrorMsg		VARCHAR(250),
				@result			VARCHAR(MAX)

	IF (@Asset_GUID IS NULL OR LTRIM(RTRIM(@Asset_GUID))='')
		BEGIN
			SET @ErrorMsg = 'Mandatory Input value is missing';
			DROP TABLE IF EXISTS #tbl_AssetAccessDtlsAPI;
			THROW 50000,@ErrorMsg,1;
		END
	
	IF NOT EXISTS (SELECT ASSET_GUID FROM [CES].ASSET WHERE ASSET_GUID = @Asset_GUID)
		BEGIN
			SET @ErrorMsg = 'Asset details does not exist';
			DROP TABLE IF EXISTS #tbl_AssetAccessDtlsAPI;
			THROW 50000,@ErrorMsg,1;
		END
		
		
	DECLARE @ast_dls TABLE
	(
		cr_asset_guid			VARCHAR(32),
		br_asset_guid			VARCHAR(32),
		cr_ralway_id			VARCHAR(64),
		br_ralway_id			VARCHAR(64),
		cr_start_mileage		DECIMAL(18,4),
		br_start_mileage		DECIMAL(18,4),
		cr_end_mileage		DECIMAL(18,4),
		br_end_mileage		DECIMAL(18,4),
		cr_asset_grp			VARCHAR(64),
		br_asset_grp			VARCHAR(64),
		cr_asset_type			VARCHAR(64),
		br_asset_type			VARCHAR(64),
		cr_area			VARCHAR(64),
		br_area			VARCHAR(64),
		cr_elr					VARCHAR(4),
		br_elr					VARCHAR(4),
		cr_assetdesc			VARCHAR(200),
		br_assetdesc			VARCHAR(200),
		cr_prim_material	VARCHAR(500),
		br_prim_material	VARCHAR(500),
		cr_os_grid_ref	VARCHAR(16),
		br_os_grid_ref	VARCHAR(16),
		cr_hce_flag				VARCHAR(4),
		br_hce_flag				VARCHAR(4)
	)

	INSERT INTO @ast_dls (
		cr_asset_guid,
		br_asset_guid,
		cr_ralway_id,
		br_ralway_id,
		cr_start_mileage,
		br_start_mileage,
		cr_end_mileage,
		br_end_mileage,
		cr_asset_grp,
		br_asset_grp,
		cr_asset_type,
		br_asset_type,
		cr_area,
		br_area,
		cr_elr,
		br_elr,
		cr_assetdesc,
		br_assetdesc,
		cr_prim_material,
		br_prim_material,
		cr_os_grid_ref,
		br_os_grid_ref,
		cr_hce_flag,
		br_hce_flag)
		(	SELECT  
				ast.asset_guid AS CR_asset_guid,
				BR_AST.ASSET_GUID AS BR_asset_guid,
				ast.RAILWAY_ID AS CR_ralway_id,
				BR_AST.RAILWAY_ID AS BR_ralway_id,
				(ast.START_MILES + ast.START_YARDS/1760) AS CR_start_mileage,
				BR_AST.START_MILEAGE AS BR_start_mileage,
				(ast.END_MILES + ast.END_YARDS/1760) AS CR_end_mileage,
				BR_AST.END_MILEAGE AS BR_end_mileage,
				asg.ASSET_GROUP_DESC AS CR_asset_grp,
				BR_AST.ASSET_GROUP_DESC AS BR_asset_grp,
				at.ASSET_TYPE_DESC AS CR_asset_type,
				BR_AST.ASSET_TYPE AS BR_asset_type,
				--o.REGION AS CR_region ,
				--BR_AST.REGION AS BR_region,
				AR.AREA_NAME AS CR_area,
				BR_AST.AREA AS BR_area,
				--o.ROUTE AS CR_route,
				--BR_AST.ROUTE AS BR_route,
				elr.ELR_CODE AS CR_elr,
				BR_AST.ENGINE_LINE_REF AS BR_elr,
				--ost.REF_VALUE AS CR_op_status,
				--ast.OWNING_PARTY as CR_owning_party,	
				ast.ASSET_NAME AS CR_assetdesc,
				BR_AST.ASSET_NAME AS BR_assetdesc,
				pm.REF_VALUE as CR_prim_material,	
				BR_AST.PRIMARY_MATERIAL AS BR_prim_material,
				ast.START_OS_GRID_REF AS CR_os_grid_ref,	
				BR_AST.OS_GRID_REF AS BR_os_grid_ref,
				IIF(ast.HCE_FLAG = 'Y','Yes', 'No') AS CR_hce_flag,
				BR_AST.HCE_FLAG AS BR_hce_flag			
			FROM [CES].ASSET AS ast
			INNER JOIN [CES].ORG AS o 
			ON ast.ORG_SR_KEY=o.ORG_SR_KEY
			INNER JOIN [CES].AREA AS ar 
			ON ast.AREA_SR_KEY=ar.AREA_SR_KEY
			INNER JOIN [CES].ASSET_GROUP asg
			ON asg.ASSET_GROUP_SR_KEY = ast.ASSET_GROUP_SR_KEY
			INNER JOIN [CES].ASSET_TYPE AS at 
			ON AST.ASSET_TYPE_SR_KEY=at.ASSET_TYPE_SR_KEY
			INNER JOIN [CES].ENGINE_LINE_REF elr
			ON ast.ENG_LINE_REF = elr.ELR_SR_KEY
			LEFT JOIN [CES].[REFERENCE_VALUE] pm
			ON pm.REF_VAL_SR_KEY = ast.PRIMARY_MATERIAL
			LEFT JOIN [CES].[REFERENCE_VALUE] ost
			ON ost.REF_VAL_SR_KEY = ast.OPERATIONAL_STATUS	
			LEFT JOIN CES.ASSET_BRIDGE BR_AST
			ON ast.asset_guid = BR_AST.ASSET_GUID AND BR_AST.ISACTIVE = 1
			WHERE ast.ASSET_GUID = @Asset_GUID
			AND ast.ISACTIVE = 1
			AND o.ISACTIVE = 1
			AND ar.ISACTIVE = 1
			AND at.ISACTIVE = 1
			AND asg.ISACTIVE = 1
			AND elr.ISACTIVE = 1
			AND pm.ISACTIVE = 1
			AND ost.ISACTIVE = 1
		)  	
		--SELECT * FROM @ast_dls
	--Generating the final output

	
	   	SET @result=(
					SELECT 
							JSON_QUERY(
							(SELECT 
								cr_asset_guid AS asset_guid,	
								cr_ralway_id AS railway_id,		
								cr_start_mileage AS start_mileage,		
								cr_end_mileage AS end_mileage,		
								cr_asset_grp AS asset_group,		
								cr_asset_type AS asset_type,		
								cr_area AS area,		
								cr_elr AS elr,		
								cr_assetdesc AS asset_desc,		
								cr_prim_material AS primary_material,		
								cr_os_grid_ref AS os_grid_ref,		
								cr_hce_flag AS hce_flag
								from @ast_dls
								FOR JSON PATH,WITHOUT_ARRAY_WRAPPER, INCLUDE_NULL_VALUES
								)
							)carrs_data,
							JSON_QUERY(
							(SELECT 
								br_asset_guid AS asset_guid,		
								br_ralway_id AS railway_id,		
								br_start_mileage AS start_mileage,		
								br_end_mileage AS end_mileage,		
								br_asset_grp AS asset_group,		
								br_asset_type AS asset_type,		
								br_area AS area,		
								br_elr AS elr,		
								br_assetdesc AS asset_desc,		
								br_prim_material AS primary_material,		
								br_os_grid_ref AS os_grid_ref,		
								br_hce_flag AS hce_flag
								from @ast_dls
								FOR JSON PATH,WITHOUT_ARRAY_WRAPPER, INCLUDE_NULL_VALUES
								)
							)bridge_data,
							JSON_QUERY(
							(SELECT 
								CASE WHEN cr_asset_guid=br_asset_guid THEN 'No' ELSE 'Yes' END AS asset_guid,		
								CASE WHEN cr_ralway_id=br_ralway_id THEN 'No' ELSE 'Yes' END AS railway_id,		
								CASE WHEN cr_start_mileage=br_start_mileage THEN 'No' ELSE 'Yes' END AS start_mileage,		
								CASE WHEN cr_end_mileage=br_end_mileage THEN 'No' ELSE 'Yes' END AS end_mileage,		
								CASE WHEN cr_asset_grp=br_asset_grp THEN 'No' ELSE 'Yes' END AS asset_group,		
								CASE WHEN cr_asset_type=br_asset_type THEN 'No' ELSE 'Yes' END AS asset_type,		
								CASE WHEN cr_area=br_area THEN 'No' ELSE 'Yes' END AS area,		
								CASE WHEN cr_elr=br_elr THEN 'No' ELSE 'Yes' END AS elr,		
								CASE WHEN cr_assetdesc=br_assetdesc THEN 'No' ELSE 'Yes' END AS asset_desc,		
								CASE WHEN cr_prim_material=br_prim_material THEN 'No' ELSE 'Yes' END AS primary_material,		
								CASE WHEN cr_os_grid_ref=br_os_grid_ref THEN 'No' ELSE 'Yes' END AS os_grid_ref,		
								CASE WHEN cr_hce_flag=br_hce_flag THEN 'No' ELSE 'Yes' END AS hce_flag
								from @ast_dls
								FOR JSON PATH,WITHOUT_ARRAY_WRAPPER,INCLUDE_NULL_VALUES
								)
							)discrepancy				
				FOR JSON PATH,WITHOUT_ARRAY_WRAPPER, INCLUDE_NULL_VALUES
				)
	
				SELECT @result 
	END TRY

	BEGIN CATCH
		SET @ErrorMsg = ERROR_MESSAGE() + 
						' Line Num:' + CONVERT(VARCHAR(5), ERROR_LINE()) + 
						',ErrorNum:' + CONVERT(VARCHAR(5), ERROR_NUMBER()) + 
						',Severity:' + CONVERT(VARCHAR(5), ERROR_SEVERITY()) + 
						',State:' + CONVERT(VARCHAR(10), ERROR_STATE()) + 
						',Procedure:' + CONVERT(VARCHAR(25), OBJECT_NAME(@@procid)) +
						',Procedure:' + CONVERT(VARCHAR(25), ERROR_PROCEDURE());  

		THROW 50000,@ErrorMsg,1;
	END CATCH

	SET NOCOUNT OFF
  END