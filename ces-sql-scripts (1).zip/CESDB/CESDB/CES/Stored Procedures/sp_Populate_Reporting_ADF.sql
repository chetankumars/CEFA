﻿/***************************************************************************************************************************************            
* Name						: sp_Populate_Reporting_ADF            
* Created By				: Cognizant            
* Date Created				: 20-May-2021           
* Description				: This stored procedure provides the report calculation logic and data insertion or update to structure and performance reporting.  
* Input Parameters			: JSON      
* Output Parameters			: @OUT_ErrorNo            
* Return Value				: N/A            
* Assumptions				: None    
* Execution Statement		: EXEC [CES].[sp_Populate_Reporting_ADF] 

*								
* Modified Date		Modified By	   Revision Number    Modifications             : 
*******************************************************************************************************************************************/ 



CREATE PROCEDURE [CES].[sp_Populate_Reporting_ADF]
AS 
BEGIN
	SET NOCOUNT ON
	
	
	BEGIN TRY
		-- declare variables
		DECLARE
				@ErrorMsg				VARCHAR(250),
				@result					NVARCHAR(MAX),
				@ast_guids				NVARCHAR(MAX),				
				@reference_date			DATE,
				@dtl_exam_typ_id		DECIMAL(18),
				@ve_exam_type_id		DECIMAL(18),
				@uw_exam_type_id		DECIMAL(18),
				@exam_req_sta_com_id	DECIMAL(18,0),
				@period_key				DECIMAL(18, 0),
				@previous_period_key	DECIMAL(18, 0),
				@period_start_dt		DATE,
				@period_end_dt			DATE,
				@year_start_dt			DATE,
				@DATE					DATETIME = GETDATE(),
				@Report1_Title			VARCHAR(20) = 'StructuresReport',
				@Report2_Title			VARCHAR(20) = 'ProgressReport',
				@current_year			VARCHAR(30),
				@current_month			DECIMAL(18, 0) = MONTH(GETDATE()),
				@current_date			DATE = GETDATE(),
				@start_dt_default		DATE  = CONVERT(DATE,'1/1/1900',103),
				@end_dt_default			DATE = CONVERT(DATE,'31/12/9999',103),
				@tasklist_yr_id			DECIMAL(18 ,0), --to be updated dynamically
				@asset_type_exclude_key	DECIMAL(18, 0)

			--Temporary table drop if exists
		    DROP TABLE IF EXISTS #tbl_ComplianceRiskStatus_SR_POP;
			DROP TABLE IF EXISTS #tbl_ComplianceSearchResult_SR_POP;			
			DROP TABLE IF EXISTS #tbl_AssetDetails_SR_POP;
			DROP TABLE IF EXISTS #tbl_Reporting_POP;
			DROP TABLE IF EXISTS #tbl_CP_YEAR_SR_POP;
			DROP TABLE IF EXISTS #tbl_Rep_Months_SR_POP;
			DROP TABLE IF EXISTS #tbl_Rep_Days_PR_POP;
			DROP TABLE IF EXISTS #tbl_Tasklist_PR_POP;

			--Contract year Declaration and dynamic data population					
			CREATE TABLE #tbl_CP_YEAR_SR_POP 
			(
				cp_year_value VARCHAR(30),
				cp_year_key DECIMAL(18),
				cp_date_from	DATE,
				cp_date_to		DATE
			)

			INSERT INTO #tbl_CP_YEAR_SR_POP (cp_year_value, cp_year_key, cp_date_from, cp_date_to) 
			(
				Select CASE WHEN MONTH(@DATE)<=3 THEN CONCAT(YEAR(@DATE)-1,'/',YEAR(@DATE)) ELSE CONCAT(YEAR(@DATE),'/',YEAR(@DATE)+1) END AS cp_year
				, 1 As YEAR 
				,CASE WHEN MONTH(@DATE)<=3 THEN Convert(DATETIME, CONCAT(YEAR(@DATE)-1,'/04','/01')) ELSE Convert(DATETIME, CONCAT(YEAR(@DATE),'/04','/01')) END AS cp_date_from
				,CASE WHEN MONTH(@DATE)<=3 THEN Convert(DATETIME, CONCAT(YEAR(@DATE),'/03','/31')) ELSE Convert(DATETIME, CONCAT(YEAR(@DATE)+1,'/03','/31')) END AS cp_date_to
			)
	
			SET @DATE = @DATE-365
			INSERT INTO #tbl_CP_YEAR_SR_POP (cp_year_value, cp_year_key, cp_date_from, cp_date_to) 
			(
				Select CASE WHEN MONTH(@DATE)<=3 THEN CONCAT(YEAR(@DATE)-1,'/',YEAR(@DATE)) ELSE CONCAT(YEAR(@DATE),'/',YEAR(@DATE)+1) END AS cp_year
				, 2 As YEAR
				,CASE WHEN MONTH(@DATE)<=3 THEN Convert(DATETIME, CONCAT(YEAR(@DATE)-1,'/04','/01')) ELSE Convert(DATETIME, CONCAT(YEAR(@DATE),'/04','/01')) END AS cp_date_from
				,CASE WHEN MONTH(@DATE)<=3 THEN Convert(DATETIME, CONCAT(YEAR(@DATE),'/03','/31')) ELSE Convert(DATETIME, CONCAT(YEAR(@DATE)+1,'/03','/31')) END AS cp_date_to
			)

			SET @DATE = @DATE-365
			INSERT INTO #tbl_CP_YEAR_SR_POP (cp_year_value, cp_year_key, cp_date_from, cp_date_to) 
			(
				Select CASE WHEN MONTH(@DATE)<=3 THEN CONCAT(YEAR(@DATE)-1,'/',YEAR(@DATE)) ELSE CONCAT(YEAR(@DATE),'/',YEAR(@DATE)+1) END AS cp_year
				, 3 As YEAR
				,CASE WHEN MONTH(@DATE)<=3 THEN Convert(DATETIME, CONCAT(YEAR(@DATE)-1,'/04','/01')) ELSE Convert(DATETIME, CONCAT(YEAR(@DATE),'/04','/01')) END AS cp_date_from
				,CASE WHEN MONTH(@DATE)<=3 THEN Convert(DATETIME, CONCAT(YEAR(@DATE),'/03','/31')) ELSE Convert(DATETIME, CONCAT(YEAR(@DATE)+1,'/03','/31')) END AS cp_date_to
			)

			SET @DATE = @DATE-365
			INSERT INTO #tbl_CP_YEAR_SR_POP (cp_year_value, cp_year_key, cp_date_from, cp_date_to) 
			(
				Select CASE WHEN MONTH(@DATE)<=3 THEN CONCAT(YEAR(@DATE)-1,'/',YEAR(@DATE)) ELSE CONCAT(YEAR(@DATE),'/',YEAR(@DATE)+1) END AS cp_year
				, 4 As YEAR
				,CASE WHEN MONTH(@DATE)<=3 THEN Convert(DATETIME, CONCAT(YEAR(@DATE)-1,'/04','/01')) ELSE Convert(DATETIME, CONCAT(YEAR(@DATE),'/04','/01')) END AS cp_date_from
				,CASE WHEN MONTH(@DATE)<=3 THEN Convert(DATETIME, CONCAT(YEAR(@DATE),'/03','/31')) ELSE Convert(DATETIME, CONCAT(YEAR(@DATE)+1,'/03','/31')) END AS cp_date_to
			)

			SET @DATE = @DATE-365
			INSERT INTO #tbl_CP_YEAR_SR_POP (cp_year_value, cp_year_key, cp_date_from, cp_date_to)  
			(
				Select CASE WHEN MONTH(@DATE)<=3 THEN CONCAT(YEAR(@DATE)-1,'/',YEAR(@DATE)) ELSE CONCAT(YEAR(@DATE),'/',YEAR(@DATE)+1) END AS cp_year
				, 5 As YEAR
				,CASE WHEN MONTH(@DATE)<=3 THEN Convert(DATETIME, CONCAT(YEAR(@DATE)-1,'/04','/01')) ELSE Convert(DATETIME, CONCAT(YEAR(@DATE),'/04','/01')) END AS cp_date_from
				,CASE WHEN MONTH(@DATE)<=3 THEN Convert(DATETIME, CONCAT(YEAR(@DATE),'/03','/31')) ELSE Convert(DATETIME, CONCAT(YEAR(@DATE)+1,'/03','/31')) END AS cp_date_to
			)

			INSERT INTO #tbl_CP_YEAR_SR_POP (cp_year_value, cp_year_key, cp_date_from, cp_date_to)  
			(
				Select 'Previous Years' AS cp_year
				, 6 As YEAR				
				,@start_dt_default AS cp_date_from
				,CASE WHEN MONTH(@DATE)<=3 THEN Convert(DATETIME, CONCAT(YEAR(@DATE)-1,'/04','/01'))-1 ELSE Convert(DATETIME, CONCAT(YEAR(@DATE),'/04','/01'))-1 END AS cp_date_from
			)
			--Reporting month table declaration and dynamic data population
			CREATE TABLE #tbl_Rep_Months_SR_POP 
			(
				rm_month_value	VARCHAR(30),
				rm_month_key	DECIMAL(18),
				rm_date_from	DATE,
				rm_date_to		DATE
			)
			SET @DATE = GETDATE();
			INSERT INTO #tbl_Rep_Months_SR_POP (rm_month_value, rm_month_key, rm_date_from, rm_date_to) 
			(
				SELECT '0 - 6 months',1,@DATE, DATEADD(DAY, -183, @DATE)
			)
			INSERT INTO #tbl_Rep_Months_SR_POP (rm_month_value, rm_month_key, rm_date_from, rm_date_to) 
			(
				SELECT '6 - 12 months',2,DATEADD(DAY, -184, @DATE), DATEADD(DAY, -365, @DATE)
			)
			INSERT INTO #tbl_Rep_Months_SR_POP (rm_month_value, rm_month_key, rm_date_from, rm_date_to) 
			(
				SELECT '1 - 2 years',3,DATEADD(DAY, -366, @DATE), DATEADD(DAY, -730, @DATE)
			)
			INSERT INTO #tbl_Rep_Months_SR_POP (rm_month_value, rm_month_key, rm_date_from, rm_date_to) 
			(
				SELECT '2 - 3 years',4,DATEADD(DAY, -731, @DATE), DATEADD(DAY, -1095, @DATE)
			)
			INSERT INTO #tbl_Rep_Months_SR_POP (rm_month_value, rm_month_key, rm_date_from, rm_date_to) 
			(
				SELECT '> 3 years',5,DATEADD(DAY, -1096, @DATE), @start_dt_default
			)

			--Reporting days to month table  declaration and dynamic data population
			CREATE TABLE #tbl_Rep_Days_PR_POP 
			(
				rd_days_value	VARCHAR(100),
				rd_days_key	DECIMAL(18),
				rd_date_from	DATE,
				rd_date_to		DATE
			)
			SET @DATE = GETDATE();
			INSERT INTO #tbl_Rep_Days_PR_POP (rd_days_value, rd_days_key, rd_date_from, rd_date_to) 
			(
				SELECT '< 1 Month Passed Site Tolerance',1,@DATE, DATEADD(DAY, -30, @DATE)
			)
			INSERT INTO #tbl_Rep_Days_PR_POP (rd_days_value, rd_days_key, rd_date_from, rd_date_to) 
			(
				SELECT '1 - 3 Months Passed Site Tolerance',2,DATEADD(DAY, -31, @DATE), DATEADD(DAY, -91, @DATE)
			)
			INSERT INTO #tbl_Rep_Days_PR_POP (rd_days_value, rd_days_key, rd_date_from, rd_date_to) 
			(
				SELECT '3 - 6 Months Passed Site Tolerance',3,DATEADD(DAY, -92, @DATE), DATEADD(DAY, -183, @DATE)
			)
			INSERT INTO #tbl_Rep_Days_PR_POP (rd_days_value, rd_days_key, rd_date_from, rd_date_to)  
			(
				SELECT '6 - 12 Months Passed Site Tolerance',4,DATEADD(DAY, -184, @DATE), DATEADD(DAY, -365, @DATE)
			)
			INSERT INTO #tbl_Rep_Days_PR_POP (rd_days_value, rd_days_key, rd_date_from, rd_date_to) 
			(
				SELECT '> 12 Months Passed Site Tolerance',5,DATEADD(DAY, -366, @DATE), @start_dt_default
			)

			--Temporary table creations scripts	
			
			CREATE TABLE #tbl_Tasklist_PR_POP  -- To hold tasklist and exam data for current tasklist year
			(
					asset_guid					VARCHAR(32),					
					org_sr_key					DECIMAL(18,0),					
					exam_id						DECIMAL(18),					
					exam_req_stat				VARCHAR(18),
					exam_rpt_stat				VARCHAR(18),
					exam_type_id				DECIMAL(18,0),	
					baseline_plan_dt			DATE,
					plan_dt						DATE,
					exam_dt						DATE,
					submission_dt				DATE,
					signed_off_dt				DATE,
					exam_sr_key					DECIMAL(18,0),
					work_year_key				DECIMAL(18,0),
					work_yr_start_dt			DATE,
					work_yr_end_dt				DATE
			)

			CREATE TABLE #tbl_ComplianceRiskStatus_SR_POP	 -- to hold data for compliance and risk status
			(
				asset_guid				VARCHAR(32),
				dtl_compliance			VARCHAR(100),
				dtl_risk_status			VARCHAR(100),
				dtl_frequency			VARCHAR(60),
				dtl_exam_type_id		DECIMAL(18),
				dtl_comp_date			DATE,
				dtl_comp_st_rt_date		DATE,
				dtl_comp_st_date		DATE,
				dtl_exam_planned_date	DATE,
				dtl_exam_actual_date	DATE,			
				dtl_supplier			VARCHAR(64),

				ve_compliance			VARCHAR(100),
				ve_risk_status			VARCHAR(100),
				ve_frequency			VARCHAR(60),
				ve_exam_type_id			DECIMAL(18),
				ve_comp_date			DATE,
				ve_comp_st_rt_date		DATE,
				ve_comp_st_date			DATE,
				ve_exam_planned_date	DATE,
				ve_exam_actual_date		DATE,			
				ve_supplier				VARCHAR(64),

				uw_compliance			VARCHAR(100),
				uw_risk_status			VARCHAR(100),
				uw_frequency			VARCHAR(60),
				uw_exam_type_id			DECIMAL(18),
				uw_comp_date			DATE,
				uw_comp_st_rt_date		DATE,
				uw_comp_st_date			DATE,
				uw_exam_planned_date	DATE,
				uw_exam_actual_date		DATE,			
				uw_supplier				VARCHAR(64)

			)	

			CREATE TABLE #tbl_AssetDetails_SR_POP	-- to hold asset and route details 
			(
				asset_guid			VARCHAR(32),
				org_sr_key			DECIMAL(18)	
			)
			

		CREATE TABLE #tbl_ComplianceSearchResult_SR_POP  -- to hold data for asset, route and compliance details
		(
				asset_guid					VARCHAR(32),
				org_sr_key					DECIMAL(18),				
				dtl_compliance				VARCHAR(64),
				dtl_risk_status				VARCHAR(64),
				dtl_frequency				VARCHAR(64),
				dtl_exam_type_id			DECIMAL(18),
				dtl_compliance_date			DATE,
				dtl_compliance_st_rt_date	DATE,
				dtl_compliance_st_date		DATE,
				dtl_planned_date			DATE,
				dtl_latest_actual_ex_date	DATE,			
				dtl_supplier				VARCHAR(64),

				ve_compliance				VARCHAR(64),
				ve_risk_status				VARCHAR(64),
				ve_frequency				VARCHAR(64),
				ve_exam_type_id				DECIMAL(18),
				ve_compliance_date			DATE,
				ve_compliance_st_rt_date	DATE,
				ve_compliance_st_date		DATE,
				ve_planned_date				DATE,
				ve_latest_actual_ex_date	DATE,			
				ve_supplier					VARCHAR(64),

				uw_compliance				VARCHAR(64),
				uw_risk_status				VARCHAR(64),
				uw_frequency				VARCHAR(64),
				uw_exam_type_id				DECIMAL(18),
				uw_compliance_date			DATE,
				uw_compliance_st_rt_date	DATE,
				uw_compliance_st_date		DATE,
				uw_planned_date				DATE,
				uw_latest_actual_ex_date	DATE,			
				uw_supplier					VARCHAR(64)
		)

		CREATE TABLE #tbl_Reporting_POP
			(
				period_sr_key			DECIMAL(18, 0),
				org_sr_key				DECIMAL(18, 0),
				report_name				VARCHAR(100),
				report_section_key		DECIMAL(18, 0),
				kpi_value				VARCHAR(100),
				kpi_key					DECIMAL(18, 0),
				detailed_exams			DECIMAL(18, 4),
				visual_exams			DECIMAL(18, 4),
				underwater_exams		DECIMAL(18, 4)
			)

	
		--to set reference date for compliance calculation
		SET @reference_date = DATEADD(dd, DATEDIFF(dd, 0, GETDATE()), 0)
		
		-- get exam type keys
		SELECT @dtl_exam_typ_id = EXAM_TYPE_SR_KEY FROM CES.EXAM_TYPE WHERE EXAM_TYPE = 'Detailed' AND ISACTIVE = 1
		SELECT @ve_exam_type_id = EXAM_TYPE_SR_KEY FROM CES.EXAM_TYPE WHERE EXAM_TYPE = 'Visual' AND ISACTIVE = 1
		SELECT @uw_exam_type_id = EXAM_TYPE_SR_KEY FROM CES.EXAM_TYPE WHERE EXAM_TYPE = 'Underwater' AND ISACTIVE = 1
		SELECT @exam_req_sta_com_id = REF_VAL_SR_KEY FROM CES.REFERENCE_VALUE WHERE REF_TYP_SR_KEY=(SELECT REF_TYP_SR_KEY FROM CES.REFERENCE_TYPE WHERE REF_TYP_NAME='Exam Request Status' ) AND REF_VALUE='Completed' AND ISACTIVE=1
		SET @current_year = CASE WHEN MONTH(@current_date)<=3 THEN CONCAT(YEAR(@current_date)-1,'/',YEAR(@current_date)) ELSE CONCAT(YEAR(@current_date),'/',YEAR(@current_date)+1) END
		--get period key and previous day period key
		SELECT @year_start_dt = CASE WHEN MONTH(@current_date)<=3 THEN Convert(DATETIME, CONCAT(YEAR(@current_date)-1,'/04','/01')) ELSE Convert(DATETIME, CONCAT(YEAR(@current_date),'/04','/01')) END
		SELECT  @period_key = [PERIOD_SR_KEY] FROM CES.[PERIOD] WHERE ISACTIVE=1 AND (( DATEDIFF(DAY, @year_start_dt, @current_date))+1 BETWEEN PERIOD_DAYS_FROM AND PERIOD_DAYS_TO )
		SELECT @previous_period_key = [PERIOD_SR_KEY] FROM CES.[PERIOD] WHERE ISACTIVE=1 AND (( DATEDIFF(DAY, @year_start_dt, DATEADD(DAY,-1, @current_date)))+1 BETWEEN PERIOD_DAYS_FROM AND PERIOD_DAYS_TO )
		SELECT @tasklist_yr_id = REF_VAL_SR_KEY FROM CES.REFERENCE_VALUE WHERE REF_TYP_SR_KEY=(SELECT REF_TYP_SR_KEY FROM CES.REFERENCE_TYPE WHERE REF_TYP_NAME='Financial Year' ) AND REF_VALUE=@current_year AND ISACTIVE=1
		SELECT @asset_type_exclude_key = ASSET_TYPE_SR_KEY FROM CES.ASSET_TYPE WHERE ASSET_TYPE_DESC='Bridge Span' AND ASSET_TYPE='SP'
		--print @asset_type_exclude_key
		--Code to check leap year 
		--SET @Year = YEAR(@year_start_dt)+1
		--SELECT CASE WHEN ((@Year % 4 = 0 AND @Year % 100 <> 0) OR @Year % 400 = 0) THEN 1 ELSE 0 END

		--To handle leap year missing day @period_key will be null when 31-Mar of leap year AND @previous_period_key will be 13
		IF @period_key IS NULL AND @previous_period_key = 13 
			SET @period_key =13
		 
		SELECT @period_start_dt  = CASE WHEN @period_key=1 THEN  DATEADD(DAY, [PERIOD_DAYS_FROM],@year_start_dt) ELSE DATEADD(DAY, [PERIOD_DAYS_FROM]-1,@year_start_dt) END FROM CES.[PERIOD] WHERE [PERIOD_SR_KEY]=@period_key
		SELECT @period_end_dt  =  CASE WHEN @period_key=13 THEN DATEADD(DAY, [PERIOD_DAYS_TO],@year_start_dt) ELSE DATEADD(DAY, [PERIOD_DAYS_TO]-1,@year_start_dt) END FROM CES.[PERIOD] WHERE [PERIOD_SR_KEY]=@period_key
		
		
			--Asset identification with organization key for route identification
			INSERT INTO #tbl_AssetDetails_SR_POP
					(
							asset_guid,
							org_sr_key							
					)(
				
								SELECT 
									ast.ASSET_GUID AS asset_guid,
									o.ORG_SR_KEY AS org_sr_key
												
								FROM [CES].ASSET ast
								INNER JOIN [CES].ORG o
								ON ast.ORG_SR_KEY = o.ORG_SR_KEY								

								WHERE
									ast.ISACTIVE= 1
								AND o.ISACTIVE = 1	
								AND ast.ASSET_TYPE_SR_KEY <> @asset_type_exclude_key
					)		
			
			--Creating Asset GUID array for passing to child SP calculating Compliance and Risk Status
			set @ast_guids =  (SELECT CONCAT('[', '"' + (SELECT distinct STRING_AGG(STRING_ESCAPE(asset_guid, 'json'), '","') FROM #tbl_AssetDetails_SR_POP) + '"', ']'))
			
			
			
			--Retrieving the compliance and RIsk Status for selected assets
			INSERT INTO #tbl_ComplianceRiskStatus_SR_POP
				(
					asset_guid,
					dtl_compliance,
					dtl_risk_status,
					dtl_frequency,
					dtl_exam_type_id,
					dtl_comp_date,
					dtl_comp_st_rt_date,
					dtl_comp_st_date,
					dtl_exam_planned_date,
					dtl_exam_actual_date,			
					dtl_supplier,

					ve_compliance,
					ve_risk_status,
					ve_frequency,
					ve_exam_type_id,
					ve_comp_date,
					ve_comp_st_rt_date,
					ve_comp_st_date,
					ve_exam_planned_date,
					ve_exam_actual_date,			
					ve_supplier,

					uw_compliance,
					uw_risk_status,
					uw_frequency,
					uw_exam_type_id,
					uw_comp_date,
					uw_comp_st_rt_date,
					uw_comp_st_date,
					uw_exam_planned_date,
					uw_exam_actual_date,			
					uw_supplier
					
			)
			EXEC [CES].[sp_Get_Asset_Compliance_Risk_Status] @ast_guids,@reference_date, 'Reporting'
		
			--to get Compliance and RA details for selected
			INSERT INTO #tbl_ComplianceSearchResult_SR_POP
					(
							asset_guid,
							org_sr_key,
							
							dtl_compliance,
							dtl_risk_status,
							dtl_frequency,
							dtl_exam_type_id,
							dtl_compliance_date,
							dtl_compliance_st_rt_date,
							dtl_compliance_st_date,
							dtl_planned_date,
							dtl_latest_actual_ex_date,			
							dtl_supplier,

							ve_compliance,
							ve_risk_status,
							ve_frequency,
							ve_exam_type_id,
							ve_compliance_date,
							ve_compliance_st_rt_date,
							ve_compliance_st_date,
							ve_planned_date,
							ve_latest_actual_ex_date,			
							ve_supplier,

							uw_compliance,
							uw_risk_status,
							uw_frequency,
							uw_exam_type_id,
							uw_compliance_date,
							uw_compliance_st_rt_date,
							uw_compliance_st_date,
							uw_planned_date,
							uw_latest_actual_ex_date,			
							uw_supplier
					)

					
					SELECT 
						ASSET.asset_guid,
						ASSET.org_sr_key,
						
						dtl_compliance,
						dtl_risk_status,
						dtl_frequency,
						dtl_exam_type_id,
						dtl_comp_date,
						dtl_comp_st_rt_date,
						dtl_comp_st_date,
						dtl_exam_planned_date,
						dtl_exam_actual_date,			
						dtl_supplier,

						ve_compliance,
						ve_risk_status,
						ve_frequency,
						ve_exam_type_id,
						ve_comp_date,
						ve_comp_st_rt_date,
						ve_comp_st_date,
						ve_exam_planned_date,
						ve_exam_actual_date,			
						ve_supplier,

						uw_compliance,
						uw_risk_status,
						uw_frequency,
						uw_exam_type_id,
						uw_comp_date,
						uw_comp_st_rt_date,
						uw_comp_st_date,
						uw_exam_planned_date,
						uw_exam_actual_date,			
						uw_supplier

				FROM #tbl_AssetDetails_SR_POP ASSET
				LEFT JOIN #tbl_ComplianceRiskStatus_SR_POP CR
				ON ASSET.ASSET_GUID = CR.asset_guid


				--Get exam counts from task list for current task list year and YTD
				INSERT INTO #tbl_Tasklist_PR_POP
					(
							asset_guid,
							org_sr_key,
							exam_id,
							exam_req_stat,
							exam_rpt_stat,
							exam_type_id,
							baseline_plan_dt,
							plan_dt,
							exam_dt,
							submission_dt,
							signed_off_dt,
							exam_sr_key,
							work_year_key,
							work_yr_start_dt,
							work_yr_end_dt							
					)
					(
						SELECT 
						final.asset_guid,
						final.ORG_SR_KEY,
						final.exam_id,
						final.exam_req_stat,
						final.exam_rpt_stat,
						final.EXAM_TYPE_SR_KEY AS exam_type_id,						
						final.baseline_plan_dt,
						final.plan_dt,
						final.exam_dt,
						final.submission_dt,
						final.signed_off_dt,
						final.exam_sr_key
						,final.WORK_YEAR_KEY
						,final.WORK_YR_START_DT
						,final.WORK_YR_END_DT
					FROM
					(
							SELECT 
								ast.ASSET_GUID AS asset_guid,
								o.ORG_SR_KEY,
								ex.exam_id,
								cmp.exam_frequency,
								ex.EXAM_REQ_STATUS AS exam_req_stat,
								ex.EXAM_REPORT_STATUS AS exam_rpt_stat,
								et.EXAM_TYPE AS exam_type,
								et.EXAM_TYPE_SR_KEY AS exam_type_id,
								cmp.COMP_DATE AS compliance_dt,
								wrk.EXAM_DUE_DATE AS due_dt,
								ex.EXAM_BASELINE_DATE AS baseline_plan_dt,
								ex.EXAM_PLANNED_DATE AS plan_dt,
								ex.EXAM_ACTUAL_DATE AS exam_dt,
								ex.EXAM_SUBMISSION_DATE AS submission_dt,
								ex.EXAM_SIGNOFF_DATE AS signed_off_dt,
								wrk.WORK_STATUS AS task_list_stat,
								wrk.WORK_SR_KEY AS task_list_id,
								ex.EXAM_SR_KEY,
								ex.EXAM_TYPE_SR_KEY,
								ISNULL(cmp.exam_freq_in_months,0) AS exam_freq_in_months,
								wrk.WORK_YR_START_DT,
								wrk.WORK_YR_END_DT,
								wrk.WORK_YEAR_KEY
								
							FROM [CES].ASSET ast
							INNER JOIN [CES].ORG o
							ON ast.ORG_SR_KEY = o.ORG_SR_KEY
							INNER JOIN [CES].EXAM ex
							ON ex.ASSET_GUID = ast.ASSET_GUID
							INNER JOIN [CES].WORK wrk
							ON wrk.WORK_SR_KEY = ex.WORK_SR_KEY
							AND wrk.ISACTIVE = 1
							INNER JOIN [CES].EXAM_TYPE et
							ON et.EXAM_TYPE_SR_KEY = ex.EXAM_TYPE_SR_KEY
							INNER JOIN [CES].SUPPLIER s
							ON s.SUPPLIER_SR_KEY = ex.SUPPLIER_SR_KEY
							OUTER APPLY
								(
									SELECT
										COMP_DATE,
										( (ISNULL(INTERVAL_YEARS,0)*12) + (ISNULL(INTERVAL_MONTHS,0)) + (ISNULL(INTERVAL_DAYS,0)/30) ) AS exam_freq_in_months,
										(CAST(ISNULL(INTERVAL_YEARS,0) AS VARCHAR) + 'y '+CAST(ISNULL(INTERVAL_MONTHS,0) AS VARCHAR)+ 'm '+CAST(ISNULL(INTERVAL_DAYS,0) AS VARCHAR)+ 'd') AS exam_frequency
										
									FROM 
									(
										SELECT 
											COMP_DATE,
											INTERVAL_YEARS,
											INTERVAL_MONTHS,
											INTERVAL_DAYS,
											ROW_NUMBER() OVER (ORDER BY EFFECTIVE_FROM_DT DESC) rnk
										FROM CES.COMPLIANCE c
										WHERE ASSET_GUID = ex.ASSET_GUID
										AND EXAM_TYPE_SR_KEY = ex.EXAM_TYPE_SR_KEY
										AND @current_date BETWEEN EFFECTIVE_FROM_DT AND ISNULL(EFFECTIVE_TO_DT,@end_dt_default)
										AND c.ISACTIVE = 1
									)c
									WHERE rnk = 1
								) cmp
							
							WHERE
								ast.ISACTIVE= 1
							AND ast.ASSET_TYPE_SR_KEY <> @asset_type_exclude_key
							AND o.ISACTIVE = 1
							AND ex.ISACTIVE = 1
							AND et.ISACTIVE = 1	
							AND s.ISACTIVE = 1
							
					)final
					LEFT JOIN [CES].EXAM ltst_exm
					ON ltst_exm.ASSET_GUID = final.asset_guid
					AND ltst_exm.EXAM_TYPE_SR_KEY = final.EXAM_TYPE_SR_KEY
					AND ltst_exm.IS_LAST_EXAM = 'Y'		
					AND ltst_exm.ISACTIVE = 1
					INNER JOIN [CES].COMPLIANCE_TOLERANCE ct
					ON ct.EXAM_TYPE_SR_KEY = final.EXAM_TYPE_SR_KEY
					AND ct.ISACTIVE = 1
					AND final.exam_freq_in_months BETWEEN ct.FREQ_INTERVAL_MONTHS_FROM AND ct.FREQ_INTERVAL_MONTHS_TO					
				)

				

				--Populate reporting temp table
				INSERT INTO #tbl_Reporting_POP
				(
					period_sr_key,
					org_sr_key,
					report_name,
					report_section_key,
					kpi_value,
					kpi_key,
					detailed_exams,
					visual_exams,
					underwater_exams
				)
				(
				--Structures Report KPI Calculations for Section 1
					SELECT @period_key
					,CS.org_sr_key AS ORG_KEY
					,@Report1_Title,1,CP.cp_year_value  AS KPI_VALUE,CP.cp_year_key AS KPI_KEY
					,ISNULL(SUM(CASE WHEN CS.dtl_exam_type_id=@dtl_exam_typ_id AND CS.dtl_compliance='Non-compliant on-site' AND CS.dtl_compliance_date BETWEEN CP.cp_date_from AND CP.cp_date_to THEN 1 ELSE 0 END) , 0) AS dtl_exams
					,ISNULL(SUM(CASE WHEN CS.ve_exam_type_id=@ve_exam_type_id AND CS.ve_compliance='Non-compliant on-site'  AND (CS.dtl_compliance IS NULL OR CS.dtl_compliance<>'Non-compliant on-site' OR CS.dtl_compliance<>'Non-compliant for submission' OR CS.dtl_compliance<>'Non-compliant awaiting sign-off') AND CS.ve_compliance_date BETWEEN CP.cp_date_from AND CP.cp_date_to THEN 1 ELSE 0 END) , 0) AS ve_exams
					,ISNULL(SUM(CASE WHEN CS.uw_exam_type_id=@uw_exam_type_id AND CS.uw_compliance='Non-compliant on-site' AND CS.uw_compliance_date BETWEEN CP.cp_date_from AND CP.cp_date_to THEN 1 ELSE 0 END) , 0) AS uw_exams
					FROM #tbl_CP_YEAR_SR_POP CP, #tbl_ComplianceSearchResult_SR_POP CS 
					Group By CP.cp_year_value
					,CS.org_sr_key
					,CP.cp_year_key
					--Structures Report KPI Calculations for Section 2
					UNION ALL
					SELECT @period_key
					,CS.org_sr_key AS ORG_KEY
					,@Report1_Title,2,RM.rm_month_value AS KPI_VALUE,RM.rm_month_key AS KPI_KEY					
					,ISNULL(SUM(CASE WHEN CS.dtl_exam_type_id=@dtl_exam_typ_id AND CS.dtl_compliance='Non-compliant for submission' AND CS.dtl_compliance_st_rt_date BETWEEN RM.rm_date_to AND RM.rm_date_from THEN 1 ELSE 0 END) , 0) AS dtl_exams
					,ISNULL(SUM(CASE WHEN CS.ve_exam_type_id=@ve_exam_type_id AND CS.ve_compliance='Non-compliant for submission' AND (CS.dtl_compliance IS NULL OR CS.dtl_compliance<>'Non-compliant on-site' OR CS.dtl_compliance<>'Non-compliant for submission' OR CS.dtl_compliance<>'Non-compliant awaiting sign-off') AND CS.ve_compliance_st_rt_date BETWEEN RM.rm_date_to AND RM.rm_date_from THEN 1 ELSE 0 END) , 0) AS ve_exams
					,ISNULL(SUM(CASE WHEN CS.uw_exam_type_id=@uw_exam_type_id AND CS.uw_compliance='Non-compliant for submission' AND CS.uw_compliance_st_rt_date BETWEEN RM.rm_date_to AND RM.rm_date_from THEN 1 ELSE 0 END) , 0) AS uw_exams
					FROM #tbl_Rep_Months_SR_POP RM, #tbl_ComplianceSearchResult_SR_POP CS
					Group By RM.rm_month_value
					,CS.org_sr_key
					,RM.rm_month_key
					--Structures Report KPI Calculations for Section 3
					UNION ALL
					SELECT @period_key
					,CS.org_sr_key AS ORG_KEY
					,@Report1_Title,3,RM.rm_month_value AS KPI_VALUE,RM.rm_month_key AS KPI_KEY					
					,ISNULL(SUM(CASE WHEN CS.dtl_exam_type_id=@dtl_exam_typ_id AND CS.dtl_compliance='Non-compliant awaiting sign-off' AND CS.dtl_compliance_st_rt_date BETWEEN RM.rm_date_to AND RM.rm_date_from THEN 1 ELSE 0 END) , 0) AS dtl_exams
					,ISNULL(SUM(CASE WHEN CS.ve_exam_type_id=@ve_exam_type_id AND CS.ve_compliance='Non-compliant awaiting sign-off' AND (CS.dtl_compliance IS NULL OR CS.dtl_compliance<>'Non-compliant on-site' OR CS.dtl_compliance<>'Non-compliant for submission' OR CS.dtl_compliance<>'Non-compliant awaiting sign-off') AND CS.ve_compliance_st_rt_date BETWEEN RM.rm_date_to AND RM.rm_date_from THEN 1 ELSE 0 END) , 0) AS ve_exams
					,ISNULL(SUM(CASE WHEN CS.uw_exam_type_id=@uw_exam_type_id AND CS.uw_compliance='Non-compliant awaiting sign-off' AND CS.uw_compliance_st_rt_date BETWEEN RM.rm_date_to AND RM.rm_date_from THEN 1 ELSE 0 END) , 0) AS uw_exams
					FROM #tbl_Rep_Months_SR_POP RM, #tbl_ComplianceSearchResult_SR_POP CS
					Group By RM.rm_month_value
					,CS.org_sr_key
					,RM.rm_month_key
					--Progress Report KPI Calculations for Section 1
					UNION ALL
					SELECT @period_key
					,CS.org_sr_key AS ORG_KEY
					,@Report2_Title,1,'Number Non-Compliant on site' AS KPI_VALUE,1 AS KPI_KEY					
					,ISNULL(SUM(CASE WHEN CS.dtl_exam_type_id=@dtl_exam_typ_id AND CS.dtl_compliance='Non-compliant on-site' THEN 1 ELSE 0 END) , 0) AS dtl_exams
					,ISNULL(SUM(CASE WHEN CS.ve_exam_type_id=@ve_exam_type_id AND CS.ve_compliance='Non-compliant on-site' AND (CS.dtl_compliance IS NULL OR CS.dtl_compliance<>'Non-compliant on-site' OR CS.dtl_compliance<>'Non-compliant for submission' OR CS.dtl_compliance<>'Non-compliant awaiting sign-off') THEN 1 ELSE 0 END) , 0) AS ve_exams
					,ISNULL(SUM(CASE WHEN CS.uw_exam_type_id=@uw_exam_type_id AND CS.uw_compliance='Non-compliant on-site' THEN 1 ELSE 0 END) , 0) AS uw_exams
					FROM #tbl_ComplianceSearchResult_SR_POP CS
					Group By CS.org_sr_key
					--Progress Report KPI Calculations for Section 2
					UNION ALL
					SELECT @period_key
					,CS.org_sr_key AS ORG_KEY
					,@Report2_Title,2,RD.rd_days_value AS KPI_VALUE,RD.rd_days_key AS KPI_KEY					
					,ISNULL(SUM(CASE WHEN CS.dtl_exam_type_id=@dtl_exam_typ_id AND CS.dtl_compliance='Non-compliant on-site' AND CS.dtl_compliance_st_date BETWEEN RD.rd_date_to AND RD.rd_date_from THEN 1 ELSE 0 END) , 0) AS dtl_exams
					,ISNULL(SUM(CASE WHEN CS.ve_exam_type_id=@ve_exam_type_id AND CS.ve_compliance='Non-compliant on-site' AND (CS.dtl_compliance IS NULL OR CS.dtl_compliance<>'Non-compliant on-site' OR CS.dtl_compliance<>'Non-compliant for submission' OR CS.dtl_compliance<>'Non-compliant awaiting sign-off') AND CS.ve_compliance_st_date BETWEEN RD.rd_date_to AND RD.rd_date_from THEN 1 ELSE 0 END) , 0) AS ve_exams
					,ISNULL(SUM(CASE WHEN CS.uw_exam_type_id=@uw_exam_type_id AND CS.uw_compliance='Non-compliant on-site' AND CS.uw_compliance_st_date BETWEEN RD.rd_date_to AND RD.rd_date_from THEN 1 ELSE 0 END) , 0) AS uw_exams
					FROM #tbl_Rep_Days_PR_POP RD, #tbl_ComplianceSearchResult_SR_POP CS
					Group By RD.rd_days_value
					,CS.org_sr_key
					,RD.rd_days_key
					--Progress Report KPI Calculations for Section 3
					UNION ALL
					SELECT @period_key
					,CS.org_sr_key AS ORG_KEY
					,@Report2_Title,3,'Non-Compliant Valid Risk Assessment' AS KPI_VALUE,3 AS KPI_KEY					
					,ISNULL(SUM(CASE WHEN CS.dtl_exam_type_id=@dtl_exam_typ_id AND CS.dtl_compliance='Non-compliant on-site' AND (CS.dtl_risk_status IN ('Completed (Data)','Complete (result: Higher)','Complete (result: Lower)')) THEN 1 ELSE 0 END) , 0) AS dtl_exams
					,ISNULL(SUM(CASE WHEN CS.ve_exam_type_id=@ve_exam_type_id AND CS.ve_compliance='Non-compliant on-site' AND (CS.dtl_compliance IS NULL OR CS.dtl_compliance<>'Non-compliant on-site' OR CS.dtl_compliance<>'Non-compliant for submission' OR CS.dtl_compliance<>'Non-compliant awaiting sign-off') AND (CS.ve_risk_status IN ('Completed (Data)','Complete (result: Higher)','Complete (result: Lower)')) THEN 1 ELSE 0 END) , 0) AS ve_exams
					,ISNULL(SUM(CASE WHEN CS.uw_exam_type_id=@uw_exam_type_id AND CS.uw_compliance='Non-compliant on-site' AND (CS.uw_risk_status IN ('Completed (Data)','Complete (result: Higher)','Complete (result: Lower)')) THEN 1 ELSE 0 END) , 0) AS uw_exams
					FROM #tbl_ComplianceSearchResult_SR_POP CS
					Group By CS.org_sr_key	
					--Progress Report KPI Calculations for Section 4
					UNION ALL
					--************************************************************* Need to verify Calculation ************************************************************************************
					SELECT @period_key AS period_key
					,CS.org_sr_key AS ORG_KEY
					,@Report2_Title AS report_name,4 As repot_section,'% of Asset Stock Non compliant' AS KPI_VALUE,4 AS KPI_KEY
					,ISNULL(SUM(CASE WHEN CS.dtl_exam_type_id=@dtl_exam_typ_id AND CS.dtl_compliance='Non-compliant on-site' THEN 1 ELSE 0 END)/NULLIF(CONVERT(decimal(18,2), COUNT(CS.ASSET_GUID)), 0), 0) AS dtl_exams
					,ISNULL(SUM(CASE WHEN CS.ve_exam_type_id=@ve_exam_type_id AND CS.ve_compliance='Non-compliant on-site' AND (CS.dtl_compliance IS NULL OR CS.dtl_compliance<>'Non-compliant on-site' OR CS.dtl_compliance<>'Non-compliant for submission' OR CS.dtl_compliance<>'Non-compliant awaiting sign-off') THEN 1 ELSE 0 END)/NULLIF(CONVERT(decimal(18,2), COUNT(CS.ASSET_GUID)), 0), 0) AS ve_exams
					,ISNULL(SUM(CASE WHEN CS.uw_exam_type_id=@uw_exam_type_id AND CS.uw_compliance='Non-compliant on-site' THEN 1 ELSE 0 END)/NULLIF(CONVERT(decimal(18,2), COUNT(CS.ASSET_GUID)), 0), 0) AS uw_exams
					FROM #tbl_ComplianceSearchResult_SR_POP CS
					Group By CS.org_sr_key
					UNION ALL
					--Progress Report KPI Calculations for Section 5
					SELECT @period_key
					,TL.org_sr_key AS ORG_KEY
					,@Report2_Title,5,'Year Work Bank Total'  AS KPI_VALUE,5 AS KPI_KEY					
					,ISNULL(SUM(CASE WHEN TL.exam_type_id=@dtl_exam_typ_id THEN 1 ELSE 0 END), 0) AS dtl_exams
					,ISNULL(SUM(CASE WHEN TL.exam_type_id=@ve_exam_type_id THEN 1 ELSE 0 END), 0) AS ve_exams
					,ISNULL(SUM(CASE WHEN TL.exam_type_id=@uw_exam_type_id THEN 1 ELSE 0 END), 0) AS uw_exams
					FROM #tbl_Tasklist_PR_POP TL
					Group By TL.org_sr_key
					UNION ALL
					--Progress Report KPI Calculations for Section 6
					SELECT @period_key
					,TL.org_sr_key AS ORG_KEY
					,@Report2_Title,6,'Exams Planned YTD (Baseline)'  AS KPI_VALUE,6 AS KPI_KEY					
					,ISNULL(SUM(CASE WHEN TL.exam_type_id=@dtl_exam_typ_id AND TL.baseline_plan_dt IS NOT NULL THEN 1 ELSE 0 END), 0) AS dtl_exams
					,ISNULL(SUM(CASE WHEN TL.exam_type_id=@ve_exam_type_id AND TL.baseline_plan_dt IS NOT NULL THEN 1 ELSE 0 END), 0) AS ve_exams
					,ISNULL(SUM(CASE WHEN TL.exam_type_id=@uw_exam_type_id AND TL.baseline_plan_dt IS NOT NULL THEN 1 ELSE 0 END), 0) AS uw_exams
					FROM #tbl_Tasklist_PR_POP TL
					Group By TL.org_sr_key	
					UNION ALL
					--Progress Report KPI Calculations for Section 7
					SELECT @period_key
					,TL.org_sr_key AS ORG_KEY
					,@Report2_Title,7,'Exams Completed YTD'  AS KPI_VALUE,7 AS KPI_KEY					
					,ISNULL(SUM(CASE WHEN TL.exam_type_id=@dtl_exam_typ_id AND TL.exam_req_stat = @exam_req_sta_com_id AND TL.work_year_key=@tasklist_yr_id AND TL.exam_dt BETWEEN TL.work_yr_start_dt AND TL.work_yr_end_dt THEN 1 ELSE 0 END), 0) AS dtl_exams
					,ISNULL(SUM(CASE WHEN TL.exam_type_id=@ve_exam_type_id AND TL.exam_req_stat = @exam_req_sta_com_id AND TL.work_year_key=@tasklist_yr_id AND TL.exam_dt BETWEEN TL.work_yr_start_dt AND TL.work_yr_end_dt THEN 1 ELSE 0 END), 0) AS ve_exams
					,ISNULL(SUM(CASE WHEN TL.exam_type_id=@uw_exam_type_id AND TL.exam_req_stat = @exam_req_sta_com_id AND TL.work_year_key=@tasklist_yr_id AND TL.exam_dt BETWEEN TL.work_yr_start_dt AND TL.work_yr_end_dt THEN 1 ELSE 0 END), 0) AS uw_exams
					FROM #tbl_Tasklist_PR_POP TL
					Group By TL.org_sr_key
					UNION ALL
					--Progress Report KPI Calculations for Section 9
					SELECT @period_key
					,TL.org_sr_key AS ORG_KEY
					,@Report2_Title,9,'Completed Exams in Period'  AS KPI_VALUE,9 AS KPI_KEY					
					,ISNULL(SUM(CASE WHEN TL.exam_type_id=@dtl_exam_typ_id AND TL.exam_req_stat = @exam_req_sta_com_id AND (TL.exam_dt BETWEEN @period_start_dt AND @period_end_dt) THEN 1 ELSE 0 END), 0) AS dtl_exams
					,ISNULL(SUM(CASE WHEN TL.exam_type_id=@ve_exam_type_id AND TL.exam_req_stat = @exam_req_sta_com_id AND (TL.exam_dt BETWEEN @period_start_dt AND @period_end_dt) THEN 1 ELSE 0 END), 0) AS ve_exams
					,ISNULL(SUM(CASE WHEN TL.exam_type_id=@uw_exam_type_id AND TL.exam_req_stat = @exam_req_sta_com_id AND (TL.exam_dt BETWEEN @period_start_dt AND @period_end_dt) THEN 1 ELSE 0 END), 0) AS uw_exams
					FROM #tbl_Tasklist_PR_POP TL
					Group By TL.org_sr_key
					UNION ALL
					--Progress Report KPI Calculations for Section 10
					SELECT @period_key
					,TL.org_sr_key AS ORG_KEY
					,@Report2_Title,10,'Completed which were planned'  AS KPI_VALUE,10 AS KPI_KEY					
					,ISNULL(SUM(CASE WHEN TL.exam_type_id=@dtl_exam_typ_id AND TL.exam_req_stat = @exam_req_sta_com_id AND TL.work_year_key=@tasklist_yr_id AND (TL.exam_dt BETWEEN @period_start_dt AND @period_end_dt) AND (TL.plan_dt BETWEEN @period_start_dt AND @period_end_dt) THEN 1 ELSE 0 END), 0) AS dtl_exams
					,ISNULL(SUM(CASE WHEN TL.exam_type_id=@ve_exam_type_id AND TL.exam_req_stat = @exam_req_sta_com_id AND TL.work_year_key=@tasklist_yr_id AND (TL.exam_dt BETWEEN @period_start_dt AND @period_end_dt) AND (TL.plan_dt BETWEEN @period_start_dt AND @period_end_dt) THEN 1 ELSE 0 END), 0) AS ve_exams
					,ISNULL(SUM(CASE WHEN TL.exam_type_id=@uw_exam_type_id AND TL.exam_req_stat = @exam_req_sta_com_id AND TL.work_year_key=@tasklist_yr_id AND (TL.exam_dt BETWEEN @period_start_dt AND @period_end_dt) AND (TL.plan_dt BETWEEN @period_start_dt AND @period_end_dt) THEN 1 ELSE 0 END), 0) AS uw_exams
					FROM #tbl_Tasklist_PR_POP TL
					Group By TL.org_sr_key
					UNION ALL
					--Progress Report KPI Calculations for Section 11
					SELECT @period_key
					,TL.org_sr_key AS ORG_KEY
					,@Report2_Title,11,'Completed which were NOT planned'  AS KPI_VALUE,11 AS KPI_KEY					
					,ISNULL(SUM(CASE WHEN TL.exam_type_id=@dtl_exam_typ_id AND TL.exam_req_stat = @exam_req_sta_com_id AND TL.work_year_key=@tasklist_yr_id AND (TL.exam_dt BETWEEN @period_start_dt AND @period_end_dt) AND (TL.plan_dt NOT BETWEEN @period_start_dt AND @period_end_dt) THEN 1 ELSE 0 END), 0) AS dtl_exams
					,ISNULL(SUM(CASE WHEN TL.exam_type_id=@ve_exam_type_id AND TL.exam_req_stat = @exam_req_sta_com_id AND TL.work_year_key=@tasklist_yr_id AND (TL.exam_dt BETWEEN @period_start_dt AND @period_end_dt) AND (TL.plan_dt NOT BETWEEN @period_start_dt AND @period_end_dt) THEN 1 ELSE 0 END), 0) AS ve_exams
					,ISNULL(SUM(CASE WHEN TL.exam_type_id=@uw_exam_type_id AND TL.exam_req_stat = @exam_req_sta_com_id AND TL.work_year_key=@tasklist_yr_id AND (TL.exam_dt BETWEEN @period_start_dt AND @period_end_dt) AND (TL.plan_dt NOT BETWEEN @period_start_dt AND @period_end_dt) THEN 1 ELSE 0 END), 0) AS uw_exams
					FROM #tbl_Tasklist_PR_POP TL
					Group By TL.org_sr_key
				)

				
				SET @Date = getdate()---365;	
				
				--Populate structures reporting history table with previous period data when the day of new period starts
				IF(@period_key != @previous_period_key)
				BEGIN	
					--To truncate history table on the first period of financial year
					IF(@previous_period_key=1)
						TRUNCATE TABLE [CES].[REPORTING_HISTORY] 

					--To be updated only in History on first day of period
					IF NOT EXISTS (SELECT 1 FROM [CES].[REPORTING_HISTORY] WHERE PERIOD_SR_KEY=@period_key
					AND REPORT_NAME=@Report2_Title AND REPORT_SECTION_KEY=8 
					AND (CASE WHEN MONTH(SNAPSHOT_DATE)<=3 THEN CONCAT(YEAR(SNAPSHOT_DATE)-1,'/',YEAR(SNAPSHOT_DATE)) ELSE CONCAT(YEAR(SNAPSHOT_DATE),'/',YEAR(SNAPSHOT_DATE)+1) END)= @current_year
					) -- to check previous period data exists in History table
						BEGIN
							--insert history table with previous period data
							INSERT INTO [CES].[REPORTING_HISTORY] 
							(PERIOD_SR_KEY,ORG_SR_KEY,REPORT_NAME,REPORT_SECTION_KEY,KPI_VALUE,KPI_KEY,
							DETAILED_EXAMS,VISUAL_EXAMS,UNDERWATER_EXAMS,SNAPSHOT_DATE,
							ISACTIVE,CREATED_USER,CREATED_DATE,UPDATED_USER,UPDATED_DATE)
							(
							--Progress Report KPI Calculations for Section 8 
								SELECT @period_key
								,TL.org_sr_key AS ORG_KEY
								,@Report2_Title,8,'Planned Exams in Period'  AS KPI_VALUE,8 AS KPI_KEY					
								,ISNULL(SUM(CASE WHEN TL.exam_type_id=@dtl_exam_typ_id AND TL.work_year_key=@tasklist_yr_id AND TL.plan_dt BETWEEN @period_start_dt AND @period_end_dt THEN 1 ELSE 0 END), 0) AS dtl_exams
								,ISNULL(SUM(CASE WHEN TL.exam_type_id=@ve_exam_type_id AND TL.work_year_key=@tasklist_yr_id AND TL.plan_dt BETWEEN @period_start_dt AND @period_end_dt THEN 1 ELSE 0 END), 0) AS ve_exams
								,ISNULL(SUM(CASE WHEN TL.exam_type_id=@uw_exam_type_id AND TL.work_year_key=@tasklist_yr_id AND TL.plan_dt BETWEEN @period_start_dt AND @period_end_dt THEN 1 ELSE 0 END), 0) AS uw_exams
								,@Date AS SnapShot_Date, 1, 'CES',@DATE, 'CES',@DATE
								FROM #tbl_Tasklist_PR_POP TL
								Group By TL.org_sr_key
							)
						END
					IF NOT EXISTS (SELECT 1 FROM [CES].[REPORTING_HISTORY] WHERE PERIOD_SR_KEY=@previous_period_key
					AND REPORT_NAME<>@Report2_Title AND  REPORT_SECTION_KEY<>8 
					AND (CASE WHEN MONTH(SNAPSHOT_DATE)<=3 THEN CONCAT(YEAR(SNAPSHOT_DATE)-1,'/',YEAR(SNAPSHOT_DATE)) ELSE CONCAT(YEAR(SNAPSHOT_DATE),'/',YEAR(SNAPSHOT_DATE)+1) END)=@current_year
					) -- to check previous period data exists in History table
					BEGIN
						--insert history table with previous period data
						INSERT INTO [CES].[REPORTING_HISTORY] 
						(PERIOD_SR_KEY,ORG_SR_KEY,REPORT_NAME,REPORT_SECTION_KEY,KPI_VALUE,KPI_KEY,
						DETAILED_EXAMS,VISUAL_EXAMS,UNDERWATER_EXAMS,SNAPSHOT_DATE,
						ISACTIVE,CREATED_USER,CREATED_DATE,UPDATED_USER,UPDATED_DATE)
						(
							SELECT PERIOD_SR_KEY,ORG_SR_KEY,REPORT_NAME,REPORT_SECTION_KEY,KPI_VALUE,KPI_KEY,
							DETAILED_EXAMS,VISUAL_EXAMS,UNDERWATER_EXAMS,SNAPSHOT_DATE,
							ISACTIVE,CREATED_USER,CREATED_DATE,UPDATED_USER,UPDATED_DATE
							FROM [CES].[REPORTING] WHERE PERIOD_SR_KEY=@previous_period_key AND REPORT_NAME<>@Report2_Title AND  REPORT_SECTION_KEY<>8
						)
					END
				END
				
				--Truncate and load Structure reporting table for current date
				
				TRUNCATE TABLE [CES].[REPORTING] 
				
				INSERT INTO [CES].[REPORTING] 
				(PERIOD_SR_KEY,ORG_SR_KEY,REPORT_NAME,REPORT_SECTION_KEY,KPI_VALUE,KPI_KEY,
				DETAILED_EXAMS,VISUAL_EXAMS,UNDERWATER_EXAMS,SNAPSHOT_DATE,
				ISACTIVE,CREATED_USER,CREATED_DATE,UPDATED_USER,UPDATED_DATE)
				(
					SELECT
					period_sr_key,
					org_sr_key,
					report_name,
					report_section_key,
					kpi_value,
					kpi_key,
					detailed_exams,
					visual_exams,
					underwater_exams			
					,@Date AS SnapShot_Date, 1, 'CES',@DATE, 'CES',@DATE
					FROM #tbl_Reporting_POP 					
				)
				--Insert the progress report section 8 from history table 
				INSERT INTO [CES].[REPORTING] 
				(PERIOD_SR_KEY,ORG_SR_KEY,REPORT_NAME,REPORT_SECTION_KEY,KPI_VALUE,KPI_KEY,
				DETAILED_EXAMS,VISUAL_EXAMS,UNDERWATER_EXAMS,SNAPSHOT_DATE,
				ISACTIVE,CREATED_USER,CREATED_DATE,UPDATED_USER,UPDATED_DATE)
				(
					SELECT PERIOD_SR_KEY,ORG_SR_KEY,REPORT_NAME,REPORT_SECTION_KEY,KPI_VALUE,KPI_KEY,
							DETAILED_EXAMS,VISUAL_EXAMS,UNDERWATER_EXAMS,SNAPSHOT_DATE,
							ISACTIVE,CREATED_USER,CREATED_DATE,UPDATED_USER,UPDATED_DATE FROM [CES].[REPORTING_HISTORY]
					WHERE PERIOD_SR_KEY=@period_key
					AND REPORT_NAME=@Report2_Title AND  REPORT_SECTION_KEY=8 
					AND (CASE WHEN MONTH(SNAPSHOT_DATE)<=3 THEN CONCAT(YEAR(SNAPSHOT_DATE)-1,'/',YEAR(SNAPSHOT_DATE)) ELSE CONCAT(YEAR(SNAPSHOT_DATE),'/',YEAR(SNAPSHOT_DATE)+1) END)= @current_year
				)
				
	END TRY
	BEGIN CATCH
		SET @ErrorMsg = ERROR_MESSAGE() + 
						' Line Num:' + CONVERT(VARCHAR(5), ERROR_LINE()) + 
						',ErrorNum:' + CONVERT(VARCHAR(5), ERROR_NUMBER()) + 
						',Severity:' + CONVERT(VARCHAR(5), ERROR_SEVERITY()) + 
						',State:' + CONVERT(VARCHAR(10), ERROR_STATE()) + 
						',Procedure:' + CONVERT(VARCHAR(25), ERROR_PROCEDURE());  
		
		--Temporary table drop if exists
		DROP TABLE IF EXISTS #tbl_ComplianceRiskStatus_SR_POP;
		DROP TABLE IF EXISTS #tbl_ComplianceSearchResult_SR_POP;			
		DROP TABLE IF EXISTS #tbl_AssetDetails_SR_POP;
		DROP TABLE IF EXISTS #tbl_Reporting_POP;
		DROP TABLE IF EXISTS #tbl_CP_YEAR_SR_POP;
		DROP TABLE IF EXISTS #tbl_Rep_Months_SR_POP;
		DROP TABLE IF EXISTS #tbl_Rep_Days_PR_POP;
		DROP TABLE IF EXISTS #tbl_Tasklist_PR_POP;
		
		THROW 50000,@ErrorMsg,1;

		
	END CATCH

	--Temporary table drop if exists
	DROP TABLE IF EXISTS #tbl_ComplianceRiskStatus_SR_POP;
	DROP TABLE IF EXISTS #tbl_ComplianceSearchResult_SR_POP;			
	DROP TABLE IF EXISTS #tbl_AssetDetails_SR_POP;
	DROP TABLE IF EXISTS #tbl_Reporting_POP;
	DROP TABLE IF EXISTS #tbl_CP_YEAR_SR_POP;
	DROP TABLE IF EXISTS #tbl_Rep_Months_SR_POP;
	DROP TABLE IF EXISTS #tbl_Rep_Days_PR_POP;
	DROP TABLE IF EXISTS #tbl_Tasklist_PR_POP;

	SET NOCOUNT OFF

END
