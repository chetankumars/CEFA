﻿
/***************************************************************************************************************************************            
* Name						: sp_Get_ComplianceAssetSearch_SearchResult            
* Created By				: Cognizant            
* Date Created				: 09-Feb-2021           
* Description				: This stored procedure provides the search result for asset basic and advanced search for compliance screen.  
* Input Parameters			: JSON      
* Output Parameters			: @OUT_ErrorNo            
* Return Value				: N/A            
* Assumptions				: None    
* Execution Statement		: Exec [CES].sp_Get_ComplianceAssetSearch_SearchResult '{
																		"region_name": "Southern",
																		"route_id": 9,
																		"area_id": 0,
																		"elr_id":[0],	
																		"start_mileage_from": -1,
																		"start_mileage_to": 99999,
																		"railway_id": null,
																		"ast_grp_id": 0,
																		"ast_typ_id": [0],
																		"reference_date": null,
																		"owning_party": null,
																		"dtl_risk_assessment_id": [0],
																		"ve_risk_assessment_id": [0],
																		"uw_risk_assessment_id": [0],
																		"dtl_compliance_id": [0],
																		"ve_compliance_id": [0],
																		"uw_compliance_id": [0],
																		"isexporttodoc": "Y",
																		"sortcolumn": "StartMileage",
																		"sortorder": "desc",
																		"pageno": 1,
																		"rowsperpage": 25
																	}'

																	
* Sample Inputs														"elr_id":[227,199],
																	"owning_party": "Network Rail (CE-Struct)",
																	285	Compliant	Compliance
																	286	Non-compliant on-site	Compliance
																	287	Non-compliant awaiting sign-off	Compliance
																	288	Non-compliant for submission	Compliance
																	289	Not Required	Risk
																	290	Required	Risk
																	291	Review Required	Risk
																	292	Not Compliant (CIV/021)	Risk
																	293	Awaiting Risk Assessment	Risk
																	294	Complete (Data)	Risk
																	295	Complete (result: Higher)	Risk
																	296	Complete (result: Lower)	Risk
*								
* Modified Date     Modified By     Revision Number      Modifications
  14-Jul-2021       Cognizant        2.0                 Add Mitigation Date to output from Risk Assessment table														 
														 User Stories #37084
  27-Jul-2021       Cognizant        2.1                 Multi select option enabled for following fields "dtl_risk_assessment_id", "ve_risk_assessment_id",
														"uw_risk_assessment_id", "dtl_compliance_id", "ve_compliance_id", "uw_compliance_id"
														 User Story # 22846        

*******************************************************************************************************************************************/ 



CREATE PROCEDURE [CES].[sp_Get_ComplianceAssetSearch_SearchResult]
	@Input_JSON		NVARCHAR(MAX)
AS 
BEGIN
	SET NOCOUNT ON
	
	
	BEGIN TRY
		DECLARE
				@ErrorMsg						VARCHAR(250),
				@result							NVARCHAR(MAX),
				@result_return					NVARCHAR(MAX),
				@ast_guids						NVARCHAR(MAX),
				@region_name					VARCHAR(64),
				@route_id						DECIMAL(18),
				@area_id						DECIMAL(18),
				@elr_id							NVARCHAR(MAX),
				@railway_id						VARCHAR(64),
				@owning_party					VARCHAR(64),
				@start_mileage_from				DECIMAL(18,4),
				@start_mileage_to				DECIMAL(18,4),				
				@ast_grp_id						DECIMAL(18),
				@ast_typ_array					NVARCHAR(MAX),
				@asset_desc						VARCHAR(200),
				@reference_date					DATE,
				@ret_reference_date				VARCHAR(64),
				@dtl_risk_assessment_id			NVARCHAR(MAX),
				@ve_risk_assessment_id			NVARCHAR(MAX),
				@uw_risk_assessment_id			NVARCHAR(MAX),
				@ve_compliance_id				NVARCHAR(MAX),
				@uw_compliance_id				NVARCHAR(MAX),
				@dtl_compliance_id				NVARCHAR(MAX),
				@isexporttodoc					VARCHAR(1),
				@sortcolumn						VARCHAR(30),
				@sortorder						VARCHAR(5),
				@pageno							DECIMAL(18),
				@rowsperpage					DECIMAL(18),
				
				@isasttypselected				CHAR(1) = 'N',
				@isbasicsearch					CHAR(1) = 'Y',
				@totalresultcnt					INT,
				@dtl_exam_typ_id				DECIMAL(18),
				@ve_exam_type_id				DECIMAL(18),
				@uw_exam_type_id				DECIMAL(18),
				--@exam_report_status_rejected_id	DECIMAL(18),
				--@exam_req_status_scheduled_id	DECIMAL(18),
				--@risk_assessed_status_id		DECIMAL(18),
				@dtl_risk_assessment_value		VARCHAR(500),
				@ve_risk_assessment_value		VARCHAR(500),
				@uw_risk_assessment_value		VARCHAR(500),
				@ve_compliance_value			VARCHAR(500),
				@uw_compliance_value			VARCHAR(500),
				@dtl_compliance_value			VARCHAR(500),
				@iselrselected					CHAR(1) = 'N',
				@isdtlriskselected				CHAR(1) = 'N',
				@isveriskselected				CHAR(1) = 'N',
				@isuwriskselected				CHAR(1) = 'N',
				@isdtlcomplianceselected		CHAR(1) = 'N',
				@isvecomplianceselected			CHAR(1) = 'N',
				@isuwcomplianceselected			CHAR(1) = 'N'
				
			DECLARE @ast_typ TABLE
			(
				ast_typ_id DECIMAL(18)
			)

			DECLARE @elr_id_array TABLE
			(
				elr_id DECIMAL(18)
			)
			
			DECLARE @dtl_risk_id_array TABLE
			(
				dtl_risk_id DECIMAL(18)
			)

			DECLARE @ve_risk_id_array TABLE
			(
				ve_risk_id DECIMAL(18)
			)
			
			DECLARE @uw_risk_id_array TABLE
			(
				uw_risk_id DECIMAL(18)
			)

			DECLARE @dtl_compliance_id_array TABLE
			(
				dtl_compliance_id DECIMAL(18)
			)

			DECLARE @ve_compliance_id_array TABLE
			(
				ve_compliance_id DECIMAL(18)
			)

			DECLARE @uw_compliance_id_array TABLE
			(
				uw_compliance_id DECIMAL(18)
			)

		    DROP TABLE IF EXISTS #tbl_ComplianceRiskStatus;
			DROP TABLE IF EXISTS #tbl_ComplianceSearchResult;
			
			DROP TABLE IF EXISTS #tbl_AssetDetails;
			DROP TABLE IF EXISTS #tbl_ComplianceRiskStatusFilter;

			CREATE TABLE #tbl_ComplianceRiskStatusFilter
			(
				crstatus_ref_value			VARCHAR(500),
				crstatus_ex_type			DECIMAL(18),		
				crstatus_type				VARCHAR(20),			
			)			
			
			CREATE TABLE #tbl_ComplianceRiskStatus
			(
				asset_guid				VARCHAR(32),
				dtl_compliance			VARCHAR(100),
				dtl_risk_status			VARCHAR(100),
				dtl_frequency			VARCHAR(60),
				dtl_exam_type_id		DECIMAL(18),
				dtl_comp_date			DATE,
				dtl_exam_planned_date	DATE,
				dtl_exam_actual_date	DATE,			
				dtl_supplier			VARCHAR(64),
				dtl_mitigation_date		DATE,

				ve_compliance			VARCHAR(100),
				ve_risk_status			VARCHAR(100),
				ve_frequency			VARCHAR(60),
				ve_exam_type_id			DECIMAL(18),
				ve_comp_date			DATE,
				ve_exam_planned_date	DATE,
				ve_exam_actual_date		DATE,			
				ve_supplier				VARCHAR(64),
				ve_mitigation_date		DATE,

				uw_compliance			VARCHAR(100),
				uw_risk_status			VARCHAR(100),
				uw_frequency			VARCHAR(60),
				uw_exam_type_id			DECIMAL(18),
				uw_comp_date			DATE,
				uw_exam_planned_date	DATE,
				uw_exam_actual_date		DATE,			
				uw_supplier				VARCHAR(64),
				uw_mitigation_date		DATE

			)	

			CREATE TABLE #tbl_AssetDetails
			(
				asset_guid			VARCHAR(32),
				region				VARCHAR(64),
				route				VARCHAR(64),
				area				VARCHAR(64),
				elr					VARCHAR(4),
				railway_id			VARCHAR(64),
				asset_desc			VARCHAR(200),
				mileage_from		DECIMAL(18,4),
				mileage_to			DECIMAL(18,4),
				asset_grp			VARCHAR(64),
				asset_type			VARCHAR(64),
				operational_stat	VARCHAR(200),
				owning_party		VARCHAR(64),
				primary_material	VARCHAR(100)
			)
			

		CREATE TABLE #tbl_ComplianceSearchResult
		(
				asset_guid					VARCHAR(32),
				region						VARCHAR(64),
				route						VARCHAR(64),
				area						VARCHAR(64),
				elr							VARCHAR(4),
				railway_id					VARCHAR(64),
				asset_desc					VARCHAR(200),
				mileage_from				DECIMAL(18,4),
				mileage_to					DECIMAL(18,4),
				asset_grp					VARCHAR(64),
				asset_type					VARCHAR(64),
				operational_stat			VARCHAR(200),
				owning_party				VARCHAR(64),
				primary_material			VARCHAR(100),
				dtl_compliance				VARCHAR(64),
				dtl_risk_status				VARCHAR(64),
				dtl_frequency				VARCHAR(64),
				dtl_exam_type_id			DECIMAL(18),
				dtl_compliance_date			DATE,
				dtl_planned_date			DATE,
				dtl_latest_actual_ex_date	DATE,			
				dtl_supplier				VARCHAR(64),
				dtl_mitigation_date			Date,

				ve_compliance				VARCHAR(64),
				ve_risk_status				VARCHAR(64),
				ve_frequency				VARCHAR(64),
				ve_exam_type_id				DECIMAL(18),
				ve_compliance_date			DATE,
				ve_planned_date				DATE,
				ve_latest_actual_ex_date	DATE,			
				ve_supplier					VARCHAR(64),
				ve_mitigation_date			Date,

				uw_compliance				VARCHAR(64),
				uw_risk_status				VARCHAR(64),
				uw_frequency				VARCHAR(64),
				uw_exam_type_id				DECIMAL(18),
				uw_compliance_date			DATE,
				uw_planned_date				DATE,
				uw_latest_actual_ex_date	DATE,			
				uw_supplier					VARCHAR(64),
				uw_mitigation_date			Date
		)

		SELECT 
			@region_name = COALESCE(@region_name,CASE LOWER([key]) WHEN 'region_name' THEN [value] ELSE NULL END),
			@route_id = COALESCE(@route_id,CASE LOWER([key]) WHEN 'route_id' THEN [value] ELSE NULL END),
			@area_id = COALESCE(@area_id,CASE LOWER([key]) WHEN 'area_id' THEN [value] ELSE NULL END),
			@elr_id = COALESCE(@elr_id,CASE LOWER([key]) WHEN 'elr_id' THEN [value] ELSE NULL END),
			@start_mileage_from = COALESCE(@start_mileage_from,CASE LOWER([key]) WHEN 'start_mileage_from' THEN [value] ELSE NULL END),
			@start_mileage_to = COALESCE(@start_mileage_to,CASE LOWER([key]) WHEN 'start_mileage_to' THEN [value] ELSE NULL END),
			@railway_id = COALESCE(@railway_id,CASE LOWER([key]) WHEN 'railway_id' THEN [value] ELSE NULL END),
			@owning_party = COALESCE(@owning_party,CASE LOWER([key]) WHEN 'owning_party' THEN [value] ELSE NULL END),			
			@ast_grp_id = COALESCE(@ast_grp_id,CASE LOWER([key]) WHEN 'ast_grp_id' THEN [value] ELSE NULL END),
			@ast_typ_array = COALESCE(@ast_typ_array,CASE LOWER([key]) WHEN 'ast_typ_id' THEN [value] ELSE NULL END),
		    @ret_reference_date = COALESCE(@ret_reference_date,CASE LOWER([key]) WHEN 'reference_date' THEN [value] ELSE NULL END),
			@dtl_risk_assessment_id = COALESCE(@dtl_risk_assessment_id,CASE LOWER([key]) WHEN 'dtl_risk_assessment_id' THEN [value] ELSE NULL END),
			@ve_risk_assessment_id = COALESCE(@ve_risk_assessment_id,CASE LOWER([key]) WHEN 've_risk_assessment_id' THEN [value] ELSE NULL END),
			@uw_risk_assessment_id = COALESCE(@uw_risk_assessment_id,CASE LOWER([key]) WHEN 'uw_risk_assessment_id' THEN [value] ELSE NULL END),
			@ve_compliance_id = COALESCE(@ve_compliance_id,CASE LOWER([key]) WHEN 've_compliance_id' THEN [value] ELSE NULL END),
			@uw_compliance_id = COALESCE(@uw_compliance_id,CASE LOWER([key]) WHEN 'uw_compliance_id' THEN [value] ELSE NULL END),
			@dtl_compliance_id = COALESCE(@dtl_compliance_id,CASE LOWER([key]) WHEN 'dtl_compliance_id' THEN [value] ELSE NULL END),
			@isexporttodoc = COALESCE(@isexporttodoc,CASE LOWER([key]) WHEN 'isexporttodoc' THEN [value] ELSE NULL END),
			@sortcolumn = COALESCE(@sortcolumn,CASE LOWER([key]) WHEN 'sortcolumn' THEN [value] ELSE NULL END),
			@sortorder = COALESCE(@sortorder,CASE LOWER([key]) WHEN 'sortorder' THEN [value] ELSE NULL END),
			@pageno = COALESCE(@pageno,CASE LOWER([key]) WHEN 'pageno' THEN [value] ELSE NULL END),
			@rowsperpage = COALESCE(@rowsperpage,CASE LOWER([key]) WHEN 'rowsperpage' THEN [value] ELSE NULL END)
			
		FROM	OPENJSON(@Input_JSON);

		IF @ret_reference_date IS NOT NULL
			SET @reference_date = CONVERT(date,@ret_reference_date, 103)
		ELSE
			SET @reference_date = DATEADD(dd, DATEDIFF(dd, 0, GETDATE()), 0)

		IF (@region_name IS NULL or ltrim(rtrim(@region_name)) = '')
		BEGIN

			SET @ErrorMsg = 'Region cannot be NULL or empty';
			DROP TABLE IF EXISTS #tbl_ComplianceRiskStatus;
			DROP TABLE IF EXISTS #tbl_ComplianceSearchResult;
			
			DROP TABLE IF EXISTS #tbl_AssetDetails;
			DROP TABLE IF EXISTS #tbl_ComplianceRiskStatusFilter;
			THROW 50000,@ErrorMsg,1;
		END


		IF @ast_typ_array IS NOT NULL 
		BEGIN
			INSERT INTO @ast_typ (ast_typ_id)
			SELECT[value] FROM OPENJSON(@ast_typ_array);

			IF EXISTS (SELECT 1 FROM @ast_typ WHERE ast_typ_id=0)
				SET @isasttypselected = 'N'
			ELSE
				SET @isasttypselected = 'Y'
		END 

		IF @elr_id IS NOT NULL 
		BEGIN
			INSERT INTO @elr_id_array (elr_id)
			SELECT[value] FROM OPENJSON(@elr_id);

			IF EXISTS (SELECT 1 FROM @elr_id_array WHERE elr_id=0)
				SET @iselrselected = 'N'
			ELSE
				SET @iselrselected = 'Y'
		END 
		
		IF @dtl_risk_assessment_id IS NOT NULL 
		BEGIN
			INSERT INTO @dtl_risk_id_array (dtl_risk_id)
			SELECT[value] FROM OPENJSON(@dtl_risk_assessment_id);

			IF EXISTS (SELECT 1 FROM @dtl_risk_id_array WHERE dtl_risk_id=0)
				SET @isdtlriskselected = 'N'
			ELSE
				SET @isdtlriskselected = 'Y'
		END 

		IF @ve_risk_assessment_id IS NOT NULL 
		BEGIN
			INSERT INTO @ve_risk_id_array (ve_risk_id)
			SELECT[value] FROM OPENJSON(@ve_risk_assessment_id);

			IF EXISTS (SELECT 1 FROM @ve_risk_id_array WHERE ve_risk_id=0)
				SET @isveriskselected = 'N'
			ELSE
				SET @isveriskselected = 'Y'
		END 

		IF @uw_risk_assessment_id IS NOT NULL 
		BEGIN
			INSERT INTO @uw_risk_id_array (uw_risk_id)
			SELECT[value] FROM OPENJSON(@uw_risk_assessment_id);

			IF EXISTS (SELECT 1 FROM @uw_risk_id_array WHERE uw_risk_id=0)
				SET @isuwriskselected = 'N'
			ELSE
				SET @isuwriskselected = 'Y'
		END 

		IF @dtl_compliance_id IS NOT NULL 
		BEGIN
			INSERT INTO @dtl_compliance_id_array (dtl_compliance_id)
			SELECT[value] FROM OPENJSON(@dtl_compliance_id);

			IF EXISTS (SELECT 1 FROM @dtl_compliance_id_array WHERE dtl_compliance_id=0)
				SET @isdtlcomplianceselected = 'N'
			ELSE
				SET @isdtlcomplianceselected = 'Y'
		END 

		IF @ve_compliance_id IS NOT NULL 
		BEGIN
			INSERT INTO @ve_compliance_id_array (ve_compliance_id)
			SELECT[value] FROM OPENJSON(@ve_compliance_id);

			IF EXISTS (SELECT 1 FROM @ve_compliance_id_array WHERE ve_compliance_id=0)
				SET @isvecomplianceselected = 'N'
			ELSE
				SET @isvecomplianceselected = 'Y'
		END 

		IF @uw_compliance_id IS NOT NULL 
		BEGIN
			INSERT INTO @uw_compliance_id_array (uw_compliance_id)
			SELECT[value] FROM OPENJSON(@uw_compliance_id);

			IF EXISTS (SELECT 1 FROM @uw_compliance_id_array WHERE uw_compliance_id=0)
				SET @isuwcomplianceselected = 'N'
			ELSE
				SET @isuwcomplianceselected = 'Y'
		END 

		--IF (@iselrselected = 'N' AND @start_mileage_from = -1 AND @start_mileage_to = 99999 AND @railway_id IS NULL AND @owning_party IS NULL AND @ast_grp_id = 0 AND @isasttypselected = 'N' AND @ret_reference_date IS NULL
		--AND @dtl_risk_assessment_id = 0 AND @ve_risk_assessment_id = 0 AND @uw_risk_assessment_id = 0 AND @ve_compliance_id = 0 AND @uw_compliance_id = 0 AND @dtl_compliance_id = 0)
		IF (@iselrselected = 'N' AND @start_mileage_from = -1 AND @start_mileage_to = 99999 AND @railway_id IS NULL AND @owning_party IS NULL AND @ast_grp_id = 0 AND @isasttypselected = 'N' AND @ret_reference_date IS NULL 
		AND @isdtlriskselected = 'N' AND @isveriskselected = 'N' AND @isuwriskselected = 'N' AND @isdtlcomplianceselected = 'N' AND @isvecomplianceselected = 'N' AND @isuwcomplianceselected = 'N')
				
			SET @isbasicsearch = 'Y'
		ELSE
			SET @isbasicsearch = 'N'
		
	
		SELECT @dtl_exam_typ_id = EXAM_TYPE_SR_KEY FROM CES.EXAM_TYPE WHERE EXAM_TYPE = 'Detailed' AND ISACTIVE = 1
		SELECT @ve_exam_type_id = EXAM_TYPE_SR_KEY FROM CES.EXAM_TYPE WHERE EXAM_TYPE = 'Visual' AND ISACTIVE = 1
		SELECT @uw_exam_type_id = EXAM_TYPE_SR_KEY FROM CES.EXAM_TYPE WHERE EXAM_TYPE = 'Underwater' AND ISACTIVE = 1
		--SELECT @exam_report_status_rejected_id = REF_VAL_SR_KEY FROM CES.REFERENCE_VALUE WHERE REF_TYP_SR_KEY=(SELECT REF_TYP_SR_KEY FROM CES.REFERENCE_TYPE WHERE REF_TYP_NAME='Exam Report Status') AND REF_VALUE='Rejected'
		--SELECT @exam_req_status_scheduled_id = REF_VAL_SR_KEY FROM CES.REFERENCE_VALUE WHERE REF_TYP_SR_KEY=(SELECT REF_TYP_SR_KEY FROM CES.REFERENCE_TYPE WHERE REF_TYP_NAME='Exam Request Status') AND REF_VALUE='Scheduled'
		--SELECT @risk_assessed_status_id = REF_VAL_SR_KEY FROM CES.REFERENCE_VALUE WHERE REF_TYP_SR_KEY=(SELECT REF_TYP_SR_KEY FROM CES.REFERENCE_TYPE WHERE REF_TYP_NAME='Risk Assessment Status') AND REF_VALUE='Risk Assessed (Data)'

		
		
				
		IF @isbasicsearch = 'N'		-- Advanced Search
		BEGIN
		
			--print 'advanced search'
			--#tbl_ComplianceRiskStatusFilter;
			--@isdtlriskselected = 'N' AND @isveriskselected = 'N' AND @isuwriskselected = 'N' AND @isdtlcomplianceselected = 'N' AND @isvecomplianceselected = 'N' AND @isuwcomplianceselected = 'N'
			--IF @dtl_risk_assessment_id <> 0  SELECT @dtl_risk_assessment_value = UPPER(RFV.REF_VALUE) FROM [CES].REFERENCE_VALUE RFV WHERE REF_VAL_SR_KEY=@dtl_risk_assessment_id AND RFV.ISACTIVE=1
			--ELSE SET @dtl_risk_assessment_value = ''	
			--IF @ve_risk_assessment_id <> 0  SELECT @ve_risk_assessment_value = UPPER(RFV.REF_VALUE) FROM [CES].REFERENCE_VALUE RFV WHERE REF_VAL_SR_KEY=@ve_risk_assessment_id AND RFV.ISACTIVE=1
			--ELSE SET @ve_risk_assessment_value = ''	
			--IF @uw_risk_assessment_id <> 0  SELECT @uw_risk_assessment_value = UPPER(RFV.REF_VALUE) FROM [CES].REFERENCE_VALUE RFV WHERE REF_VAL_SR_KEY=@uw_risk_assessment_id AND RFV.ISACTIVE=1
			--ELSE SET @uw_risk_assessment_value = ''	
			--IF @ve_compliance_id <> 0  SELECT @ve_compliance_value = UPPER(RFV.REF_VALUE) FROM [CES].REFERENCE_VALUE RFV WHERE REF_VAL_SR_KEY=@ve_compliance_id AND RFV.ISACTIVE=1
			--ELSE SET @ve_compliance_value = ''	
			--IF @uw_compliance_id <> 0  SELECT @uw_compliance_value = UPPER(RFV.REF_VALUE) FROM [CES].REFERENCE_VALUE RFV WHERE REF_VAL_SR_KEY=@uw_compliance_id AND RFV.ISACTIVE=1
			--ELSE SET @uw_compliance_value = ''	
			--IF @dtl_compliance_id <> 0  SELECT @dtl_compliance_value = UPPER(RFV.REF_VALUE) FROM [CES].REFERENCE_VALUE RFV WHERE REF_VAL_SR_KEY=@dtl_compliance_id AND RFV.ISACTIVE=1
			--ELSE SET @dtl_compliance_value = ''	
			
			----Get multi selected Compliance and Risk Status values for filtering
			IF @isdtlriskselected = 'Y' 
			BEGIN
				INSERT INTO #tbl_ComplianceRiskStatusFilter(crstatus_ref_value,crstatus_ex_type,crstatus_type) 
				(
					SELECT UPPER(RFV.REF_VALUE),@dtl_exam_typ_id,'Risk' FROM [CES].REFERENCE_VALUE RFV 
					WHERE REF_VAL_SR_KEY in (SELECT dtl_risk_id FROM @dtl_risk_id_array) AND RFV.ISACTIVE=1	
				)		
			END

			IF @isveriskselected = 'Y' 
			BEGIN
				INSERT INTO #tbl_ComplianceRiskStatusFilter(crstatus_ref_value,crstatus_ex_type,crstatus_type) 
				(
					SELECT UPPER(RFV.REF_VALUE),@ve_exam_type_id,'Risk' FROM [CES].REFERENCE_VALUE RFV 
					WHERE REF_VAL_SR_KEY in (SELECT ve_risk_id FROM @ve_risk_id_array) AND RFV.ISACTIVE=1	
				)		
			END

			IF @isuwriskselected = 'Y' 
			BEGIN
				INSERT INTO #tbl_ComplianceRiskStatusFilter(crstatus_ref_value,crstatus_ex_type,crstatus_type) 
				(
					SELECT UPPER(RFV.REF_VALUE),@uw_exam_type_id,'Risk' FROM [CES].REFERENCE_VALUE RFV 
					WHERE REF_VAL_SR_KEY in (SELECT uw_risk_id FROM @uw_risk_id_array) AND RFV.ISACTIVE=1	
				)		
			END

			IF @isdtlcomplianceselected = 'Y' 
			BEGIN
				INSERT INTO #tbl_ComplianceRiskStatusFilter(crstatus_ref_value,crstatus_ex_type,crstatus_type) 
				(
					SELECT UPPER(RFV.REF_VALUE),@dtl_exam_typ_id,'Compliance' FROM [CES].REFERENCE_VALUE RFV 
					WHERE REF_VAL_SR_KEY in (SELECT dtl_compliance_id FROM @dtl_compliance_id_array) AND RFV.ISACTIVE=1	
				)		
			END

			IF @isvecomplianceselected = 'Y' 
			BEGIN
				INSERT INTO #tbl_ComplianceRiskStatusFilter(crstatus_ref_value,crstatus_ex_type,crstatus_type) 
				(
					SELECT UPPER(RFV.REF_VALUE),@ve_exam_type_id,'Compliance' FROM [CES].REFERENCE_VALUE RFV 
					WHERE REF_VAL_SR_KEY in (SELECT ve_compliance_id FROM @ve_compliance_id_array) AND RFV.ISACTIVE=1	
				)		
			END

			IF @isuwcomplianceselected = 'Y' 
			BEGIN
				INSERT INTO #tbl_ComplianceRiskStatusFilter(crstatus_ref_value,crstatus_ex_type,crstatus_type) 
				(
					SELECT UPPER(RFV.REF_VALUE),@uw_exam_type_id,'Compliance' FROM [CES].REFERENCE_VALUE RFV 
					WHERE REF_VAL_SR_KEY in (SELECT uw_compliance_id FROM @uw_compliance_id_array) AND RFV.ISACTIVE=1	
				)		
			END

			--Asset identification based on filter criteria execpt compliance and RA status filters
			INSERT INTO #tbl_AssetDetails
					(
							asset_guid,
							region,
							[route],
							area,						
							elr,
							railway_id,
							asset_desc,
							mileage_from,
							mileage_to,							
							asset_grp,
							asset_type,
							operational_stat,
							owning_party,
							primary_material
					)(
				
								SELECT 
									ast.ASSET_GUID AS asset_guid,
									o.REGION AS region,
									o.ROUTE AS [route],
									a.AREA_NAME AS area,
									elr.ELR_CODE AS elr,
									ast.RAILWAY_ID AS railway_id,
									ast.ASSET_NAME AS asset_desc,
									(ast.START_MILES + ast.START_YARDS/1760) AS mileage_from,
									(ast.END_MILES + ast.END_YARDS/1760) AS mileage_to,
					
									asg.ASSET_GROUP_DESC AS asset_grp,
									asp.ASSET_TYPE_DESC AS asset_type,
									ops.REF_VALUE AS operational_stat,
									ast.OWNING_PARTY,
									mat.REF_VALUE AS primary_material
												
								FROM [CES].ASSET ast
								INNER JOIN [CES].ORG o
								ON ast.ORG_SR_KEY = o.ORG_SR_KEY
								INNER JOIN [CES].AREA a
								ON a.AREA_SR_KEY = ast.AREA_SR_KEY
								INNER JOIN [CES].ENGINE_LINE_REF elr
								ON elr.ELR_SR_KEY = ast.ENG_LINE_REF
								AND elr.ORG_SR_KEY = ast.ORG_SR_KEY
								AND elr.AREA_SR_KEY = ast.AREA_SR_KEY
								INNER JOIN [CES].ASSET_GROUP asg
								ON asg.ASSET_GROUP_SR_KEY = ast.ASSET_GROUP_SR_KEY
								INNER JOIN [CES].ASSET_TYPE asp
								ON asp.ASSET_TYPE_SR_KEY = ast.ASSET_TYPE_SR_KEY
								LEFT JOIN [CES].REFERENCE_VALUE ops
								ON ops.REF_VAL_SR_KEY = ast.OPERATIONAL_STATUS
								AND ops.ISACTIVE = 1
								LEFT JOIN [CES].REFERENCE_VALUE mat
								ON mat.REF_VAL_SR_KEY = ast.PRIMARY_MATERIAL
								AND mat.ISACTIVE = 1				

								WHERE
									ast.ISACTIVE= 1
								AND o.ISACTIVE = 1
								AND elr.ISACTIVE = 1
								AND asg.ISACTIVE = 1
								AND asp.ISACTIVE = 1
								AND o.REGION = @region_name
								AND ( @route_id =0 OR (@route_id <> 0 AND o.ORG_SR_KEY = @route_id))
								AND	( @area_id =0 OR (@area_id <> 0 AND a.AREA_SR_KEY = @area_id))
								AND ( @iselrselected = 'N' OR (@iselrselected = 'Y' AND ast.ENG_LINE_REF IN (SELECT elr_id FROM @elr_id_array)) )
								AND ( (ast.START_MILES + ast.START_YARDS/1760) BETWEEN @start_mileage_from AND @start_mileage_to)
								--AND ( @railway_id IS NULL OR (@railway_id IS NOT NULL AND ast.RAILWAY_ID = @railway_id))
								AND ( @railway_id IS NULL OR (@railway_id IS NOT NULL AND ast.RAILWAY_ID LIKE ('%' + @railway_id + '%')))
								AND ( @owning_party IS NULL OR (@owning_party IS NOT NULL AND ast.OWNING_PARTY = @owning_party))
								AND ( @ast_grp_id =0 OR (@ast_grp_id <> 0 AND asg.ASSET_GROUP_SR_KEY = @ast_grp_id))
								AND ( @isasttypselected = 'N' OR (@isasttypselected = 'Y' AND asp.ASSET_TYPE_SR_KEY IN (SELECT ast_typ_id FROM @ast_typ)) )
					)		
		
			--Creating Asset GUID array for passing to child SP calculating Compliance and Risk Status
			set @ast_guids =  (SELECT CONCAT('[', '"' + (SELECT distinct STRING_AGG(STRING_ESCAPE(asset_guid, 'json'), '","') FROM #tbl_AssetDetails) + '"', ']'))
			--print @ast_guids

			--Retrieving the compliance and RIsk Status for selected assets
			INSERT INTO #tbl_ComplianceRiskStatus
				(
					asset_guid,
					dtl_compliance,
					dtl_risk_status,
					dtl_frequency,
					dtl_exam_type_id,
					dtl_comp_date,
					dtl_exam_planned_date,
					dtl_exam_actual_date,			
					dtl_supplier,
					dtl_mitigation_date,

					ve_compliance,
					ve_risk_status,
					ve_frequency,
					ve_exam_type_id,
					ve_comp_date,
					ve_exam_planned_date,
					ve_exam_actual_date,			
					ve_supplier,
					ve_mitigation_date,

					uw_compliance,
					uw_risk_status,
					uw_frequency,
					uw_exam_type_id,
					uw_comp_date,
					uw_exam_planned_date,
					uw_exam_actual_date,			
					uw_supplier,
					uw_mitigation_date
			)
			EXEC [CES].[sp_Get_Asset_Compliance_Risk_Status] @ast_guids,@reference_date,'ComplianceSearch'
		
			--Compliance and RA filters on asset
			INSERT INTO #tbl_ComplianceSearchResult
					(
							asset_guid,
							region,
							[route],
							area,						
							elr,
							railway_id,
							asset_desc,
							mileage_from,
							mileage_to,							
							asset_grp,
							asset_type,
							operational_stat,
							owning_party,
							primary_material,
							dtl_compliance,
							dtl_risk_status,
							dtl_frequency,
							dtl_exam_type_id,
							dtl_compliance_date,
							dtl_planned_date,
							dtl_latest_actual_ex_date,			
							dtl_supplier,
							dtl_mitigation_date,

							ve_compliance,
							ve_risk_status,
							ve_frequency,
							ve_exam_type_id,
							ve_compliance_date,
							ve_planned_date,
							ve_latest_actual_ex_date,			
							ve_supplier,
							ve_mitigation_date,

							uw_compliance,
							uw_risk_status,
							uw_frequency,
							uw_exam_type_id,
							uw_compliance_date,
							uw_planned_date,
							uw_latest_actual_ex_date,			
							uw_supplier,
							uw_mitigation_date
					)

					
					SELECT 
						ASSET.asset_guid,
						ASSET.region,
						ASSET.route,
						ASSET.area,
						ASSET.elr,
						ASSET.railway_id,
						ASSET.asset_desc,
						ASSET.mileage_from,
						ASSET.mileage_to,
				
						ASSET.asset_grp,
						ASSET.asset_type,
						ASSET.operational_stat,
						ASSET.owning_party,
						ASSET.primary_material,	

						dtl_compliance,
						dtl_risk_status,
						dtl_frequency,
						dtl_exam_type_id,
						dtl_comp_date,
						dtl_exam_planned_date,
						dtl_exam_actual_date,			
						dtl_supplier,
						dtl_mitigation_date,

						ve_compliance,
						ve_risk_status,
						ve_frequency,
						ve_exam_type_id,
						ve_comp_date,
						ve_exam_planned_date,
						ve_exam_actual_date,			
						ve_supplier,
						ve_mitigation_date,

						uw_compliance,
						uw_risk_status,
						uw_frequency,
						uw_exam_type_id,
						uw_comp_date,
						uw_exam_planned_date,
						uw_exam_actual_date,			
						uw_supplier,
						uw_mitigation_date

						

				FROM #tbl_AssetDetails ASSET
				LEFT JOIN #tbl_ComplianceRiskStatus CR
				ON ASSET.ASSET_GUID = CR.asset_guid

							
				WHERE
				--( @dtl_risk_assessment_id =0 OR (@dtl_risk_assessment_id <> 0 AND UPPER(dtl_risk_status) = @dtl_risk_assessment_value))																			
				--AND ( @ve_risk_assessment_id =0 OR (@ve_risk_assessment_id <> 0 AND UPPER(ve_risk_status) = @ve_risk_assessment_value))
				--AND ( @uw_risk_assessment_id =0 OR (@uw_risk_assessment_id <> 0 AND UPPER(uw_risk_status) = @uw_risk_assessment_value))
				--AND ( @ve_compliance_id =0 OR (@ve_compliance_id <> 0 AND UPPER(ve_compliance) = @ve_compliance_value))
				--AND ( @uw_compliance_id =0 OR (@uw_compliance_id <> 0 AND UPPER(uw_compliance) = @uw_compliance_value))
				--AND ( @dtl_compliance_id =0 OR (@dtl_compliance_id <> 0 AND UPPER(dtl_compliance) = @dtl_compliance_value))
				(@isdtlriskselected = 'N' OR (@isdtlriskselected = 'Y' AND UPPER(dtl_risk_status) IN (SELECT UPPER(crstatus_ref_value) FROM #tbl_ComplianceRiskStatusFilter WHERE crstatus_ex_type=@dtl_exam_typ_id AND crstatus_type='Risk')) )
				AND (@isveriskselected = 'N' OR (@isveriskselected = 'Y' AND UPPER(ve_risk_status) IN (SELECT UPPER(crstatus_ref_value) FROM #tbl_ComplianceRiskStatusFilter WHERE crstatus_ex_type=@ve_exam_type_id AND crstatus_type='Risk')) )
				AND (@isuwriskselected = 'N' OR (@isuwriskselected = 'Y' AND UPPER(uw_risk_status) IN (SELECT UPPER(crstatus_ref_value) FROM #tbl_ComplianceRiskStatusFilter WHERE crstatus_ex_type=@uw_exam_type_id AND crstatus_type='Risk')) )
				AND (@isdtlcomplianceselected = 'N' OR (@isdtlcomplianceselected = 'Y' AND UPPER(dtl_compliance) IN (SELECT UPPER(crstatus_ref_value) FROM #tbl_ComplianceRiskStatusFilter WHERE crstatus_ex_type=@dtl_exam_typ_id AND crstatus_type='Compliance')) )
				AND (@isvecomplianceselected = 'N' OR (@isvecomplianceselected = 'Y' AND UPPER(ve_compliance) IN (SELECT UPPER(crstatus_ref_value) FROM #tbl_ComplianceRiskStatusFilter WHERE crstatus_ex_type=@ve_exam_type_id AND crstatus_type='Compliance')) )
				AND (@isuwcomplianceselected = 'N' OR (@isuwcomplianceselected = 'Y' AND UPPER(uw_compliance) IN (SELECT UPPER(crstatus_ref_value) FROM #tbl_ComplianceRiskStatusFilter WHERE crstatus_ex_type=@uw_exam_type_id AND crstatus_type='Compliance')) )
			
		END

		ELSE	--Basic search
		BEGIN
		
					--print 'basic search'

					INSERT INTO #tbl_AssetDetails
						(
								asset_guid,
								region,
								[route],
								area,						
								elr,
								railway_id,
								asset_desc,
								mileage_from,
								mileage_to,							
								asset_grp,
								asset_type,
								operational_stat,
								owning_party,
								primary_material
						)(
						SELECT 
							ast.ASSET_GUID AS asset_guid,
							o.REGION AS region,
							o.[ROUTE] AS [route],
							a.AREA_NAME AS area,
							elr.ELR_CODE AS elr,
							ast.RAILWAY_ID AS railway_id,
							ast.ASSET_NAME AS asset_desc,
							(ast.START_MILES + ast.START_YARDS/1760) AS mileage_from,
							(ast.END_MILES + ast.END_YARDS/1760) AS mileage_to,
				
							asg.ASSET_GROUP_DESC AS asset_grp,
							asp.ASSET_TYPE_DESC AS asset_type,
							ops.REF_VALUE AS operational_stat,
							ast.OWNING_PARTY,
							mat.REF_VALUE AS primary_material				 
					

						FROM [CES].ASSET ast
						INNER JOIN [CES].ORG o
						ON ast.ORG_SR_KEY = o.ORG_SR_KEY
						INNER JOIN [CES].AREA a
						ON a.AREA_SR_KEY = ast.AREA_SR_KEY
						INNER JOIN [CES].ENGINE_LINE_REF elr
						ON elr.ELR_SR_KEY = ast.ENG_LINE_REF
						INNER JOIN [CES].ASSET_GROUP asg
						ON asg.ASSET_GROUP_SR_KEY = ast.ASSET_GROUP_SR_KEY
						INNER JOIN [CES].ASSET_TYPE asp
						ON asp.ASSET_TYPE_SR_KEY = ast.ASSET_TYPE_SR_KEY
						LEFT JOIN [CES].REFERENCE_VALUE ops
						ON ops.REF_VAL_SR_KEY = ast.OPERATIONAL_STATUS
						AND ops.ISACTIVE = 1
						LEFT JOIN [CES].REFERENCE_VALUE mat
						ON mat.REF_VAL_SR_KEY = ast.PRIMARY_MATERIAL
						AND mat.ISACTIVE = 1
				

						WHERE
							ast.ISACTIVE= 1
						AND o.ISACTIVE = 1
						AND elr.ISACTIVE = 1
						AND asg.ISACTIVE = 1
						AND asp.ISACTIVE = 1
						AND o.REGION = @region_name
						AND ( @route_id =0 OR (@route_id <> 0 AND o.ORG_SR_KEY = @route_id))
						AND	( @area_id =0 OR (@area_id <> 0 AND a.AREA_SR_KEY = @area_id))
						)

					--Creating Asset GUID array for passing to child SP calculating Compliance and Risk Status
					set @ast_guids =  (SELECT CONCAT('[', '"' + (SELECT distinct STRING_AGG(STRING_ESCAPE(asset_guid, 'json'), '","') FROM #tbl_AssetDetails) + '"', ']'))
					--print @ast_guids

					--Retrieving the compliance and RIsk Status for selected assets
					INSERT INTO #tbl_ComplianceRiskStatus
						(
							asset_guid,
							dtl_compliance,
							dtl_risk_status,
							dtl_frequency,
							dtl_exam_type_id,
							dtl_comp_date,
							dtl_exam_planned_date,
							dtl_exam_actual_date,			
							dtl_supplier,
							dtl_mitigation_date,

							ve_compliance,
							ve_risk_status,
							ve_frequency,
							ve_exam_type_id,
							ve_comp_date,
							ve_exam_planned_date,
							ve_exam_actual_date,			
							ve_supplier,
							ve_mitigation_date,

							uw_compliance,
							uw_risk_status,
							uw_frequency,
							uw_exam_type_id,
							uw_comp_date,
							uw_exam_planned_date,
							uw_exam_actual_date,			
							uw_supplier,
							uw_mitigation_date
					)
					EXEC [CES].[sp_Get_Asset_Compliance_Risk_Status] @ast_guids,@reference_date,'ComplianceSearch'

					--Compliance and RA filters on asset
					INSERT INTO #tbl_ComplianceSearchResult
					(
							asset_guid,
							region,
							[route],
							area,						
							elr,
							railway_id,
							asset_desc,
							mileage_from,
							mileage_to,							
							asset_grp,
							asset_type,
							operational_stat,
							owning_party,
							primary_material,
							dtl_compliance,
							dtl_risk_status,
							dtl_frequency,
							dtl_exam_type_id,
							dtl_compliance_date,
							dtl_planned_date,
							dtl_latest_actual_ex_date,			
							dtl_supplier,
							dtl_mitigation_date,

							ve_compliance,
							ve_risk_status,
							ve_frequency,
							ve_exam_type_id,
							ve_compliance_date,
							ve_planned_date,
							ve_latest_actual_ex_date,			
							ve_supplier,
							ve_mitigation_date,

							uw_compliance,
							uw_risk_status,
							uw_frequency,
							uw_exam_type_id,
							uw_compliance_date,
							uw_planned_date,
							uw_latest_actual_ex_date,			
							uw_supplier,
							uw_mitigation_date
					)(
					SELECT 
						ASSET.asset_guid,
						ASSET.region,
						ASSET.route,
						ASSET.area,
						ASSET.elr,
						ASSET.railway_id,
						ASSET.asset_desc,
						ASSET.mileage_from,
						ASSET.mileage_to,
				
						ASSET.asset_grp,
						ASSET.asset_type,
						ASSET.operational_stat,
						ASSET.owning_party,
						ASSET.primary_material,	

						dtl_compliance,
						dtl_risk_status,
						dtl_frequency,
						dtl_exam_type_id,
						dtl_comp_date,
						dtl_exam_planned_date,
						dtl_exam_actual_date,			
						dtl_supplier,
						dtl_mitigation_date,

						ve_compliance,
						ve_risk_status,
						ve_frequency,
						ve_exam_type_id,
						ve_comp_date,
						ve_exam_planned_date,
						ve_exam_actual_date,			
						ve_supplier,
						ve_mitigation_date,

						uw_compliance,
						uw_risk_status,
						uw_frequency,
						uw_exam_type_id,
						uw_comp_date,
						uw_exam_planned_date,
						uw_exam_actual_date,			
						uw_supplier,
						uw_mitigation_date

				FROM #tbl_AssetDetails ASSET
				LEFT JOIN #tbl_ComplianceRiskStatus CR
				ON ASSET.ASSET_GUID = CR.asset_guid
				)

		END
		
		--Total count of records
		SELECT @totalresultcnt = COUNT(1) FROM #tbl_ComplianceSearchResult

	
		--If no records are returned in search result
		IF  @totalresultcnt=0 
		BEGIN

			SET @result=
					(
						SELECT 
							JSON_QUERY(
										(
											select
												@pageno AS currentpage,
												@totalresultcnt AS totalcount,
												0 AS totalpages
											FOR JSON PATH,WITHOUT_ARRAY_WRAPPER
										)
							) searchdatacount,
							JSON_QUERY('[]') searchresult
						
						FOR JSON PATH,WITHOUT_ARRAY_WRAPPER, INCLUDE_NULL_VALUES
				)

		END	
		--If alt least 1 record is returned in search result
		ELSE
		BEGIN
			IF @isexporttodoc = 'Y' --Export to Excel
			
			BEGIN
					IF @sortorder = 'asc' 
					BEGIN
				
						SET @result=
						(
							SELECT 
								JSON_QUERY(
											(
												select
													@pageno AS currentpage,
													@totalresultcnt AS totalcount,
													--CEILING(@totalresultcnt/@rowsperpage) AS totalpages
													1 AS totalpages
												FOR JSON PATH,WITHOUT_ARRAY_WRAPPER
											)
								) searchdatacount,
							(
								SELECT
									asset_guid,
									region,
									route,	
									area,
									elr,
									railway_id,
									asset_desc,
									mileage_from,
									mileage_to,							
									asset_grp,
									asset_type,
									operational_stat,
									owning_party,
									primary_material,
									dtl_compliance,
									dtl_risk_status,
									dtl_frequency,
									dtl_exam_type_id,
									dtl_compliance_date,
									dtl_planned_date,
									dtl_latest_actual_ex_date,			
									dtl_supplier,
									dtl_mitigation_date,
									ve_compliance,
									ve_risk_status,
									ve_frequency,
									ve_exam_type_id,
									ve_compliance_date,
									ve_planned_date,
									ve_latest_actual_ex_date,			
									ve_supplier,
									ve_mitigation_date,
									uw_compliance,
									uw_risk_status,
									uw_frequency,
									uw_exam_type_id,
									uw_compliance_date,
									uw_planned_date,
									uw_latest_actual_ex_date,			
									uw_supplier,
									uw_mitigation_date
								FROM
								(

									SELECT
											asset_guid,
											region,
											route,
											area,		
											elr,
											railway_id,
											asset_desc,
											mileage_from,
											mileage_to,							
											asset_grp,
											asset_type,
											operational_stat,
											owning_party,
											primary_material,
											dtl_compliance,
											dtl_risk_status,
											dtl_frequency,
											dtl_exam_type_id,
											dtl_compliance_date,
											dtl_planned_date,
											dtl_latest_actual_ex_date,			
											dtl_supplier,
											dtl_mitigation_date,
											ve_compliance,
											ve_risk_status,
											ve_frequency,
											ve_exam_type_id,
											ve_compliance_date,
											ve_planned_date,
											ve_latest_actual_ex_date,			
											ve_supplier,
											ve_mitigation_date,
											uw_compliance,
											uw_risk_status,
											uw_frequency,
											uw_exam_type_id,
											uw_compliance_date,
											uw_planned_date,
											uw_latest_actual_ex_date,			
											uw_supplier,
											uw_mitigation_date,
											ROW_NUMBER() OVER (ORDER BY 
																		CASE WHEN @sortcolumn = 'StartMileage' THEN mileage_from ELSE NULL END ASC, 
																		CASE WHEN @sortcolumn = 'AssetGUID' THEN asset_guid ELSE NULL END ASC, 
																		CASE WHEN @sortcolumn = 'Region' THEN region ELSE NULL END ASC, 
																		CASE WHEN @sortcolumn = 'Route' THEN route ELSE NULL END ASC, 
																		CASE WHEN @sortcolumn = 'ELR' THEN elr ELSE NULL END ASC, 
																		CASE WHEN @sortcolumn = 'RailwayID' THEN railway_id ELSE NULL END ASC,  
																		CASE WHEN @sortcolumn = 'AssetDescription' THEN asset_desc  ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'AssetGroup' THEN asset_grp ELSE NULL END ASC, 
																		CASE WHEN @sortcolumn = 'AssetType' THEN asset_type ELSE NULL END ASC, 
																		CASE WHEN @sortcolumn = 'OperationalStat' THEN operational_stat ELSE NULL END ASC, 
																		CASE WHEN @sortcolumn = 'OwningParty' THEN owning_party ELSE NULL END ASC, 
																		CASE WHEN @sortcolumn = 'Material' THEN primary_material ELSE NULL END ASC, 
																		CASE WHEN @sortcolumn = 'DtlCompliance' THEN dtl_compliance ELSE NULL END ASC, 
																		CASE WHEN @sortcolumn = 'DtlRiskStatus' THEN dtl_risk_status  ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'DtlComplianceDate' THEN dtl_compliance_date  ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'DtlPlannedDate' THEN dtl_planned_date  ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'DtlActualExamDate' THEN dtl_latest_actual_ex_date  ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'DtlSupplier' THEN dtl_supplier  ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'DtlMitigationDate' THEN dtl_mitigation_date  ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'VECompliance' THEN ve_compliance ELSE NULL END ASC, 
																		CASE WHEN @sortcolumn = 'VERiskStatus' THEN ve_risk_status ELSE NULL END ASC, 
																		CASE WHEN @sortcolumn = 'VEComplianceDate' THEN ve_compliance_date  ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'VEPlannedDate' THEN ve_planned_date  ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'VEActualExamDate' THEN ve_latest_actual_ex_date  ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'VESupplier' THEN ve_supplier  ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'VEMitigationDate' THEN ve_mitigation_date  ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'UWCompliance' THEN uw_compliance  ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'UWRiskStatus' THEN uw_risk_status ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'UWComplianceDate' THEN uw_compliance_date  ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'UWPlannedDate' THEN uw_planned_date  ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'UWActualExamDate' THEN uw_latest_actual_ex_date  ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'UWSupplier' THEN uw_supplier  ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'UWMitigationDate'  THEN uw_mitigation_date  ELSE NULL END ASC
																	
																	) AS ordrnk

									FROM #tbl_ComplianceSearchResult
								)sr
								ORDER BY ordrnk
								FOR JSON AUTO, INCLUDE_NULL_VALUES
							)searchresult
							FOR JSON PATH,WITHOUT_ARRAY_WRAPPER, INCLUDE_NULL_VALUES
						)
					END
					ELSE IF @sortorder = 'desc' 
					BEGIN					
					

						SET @result=
						(
							SELECT 
								JSON_QUERY(
											(
												select
													@pageno AS currentpage,
													@totalresultcnt AS totalcount,
													1 AS totalpages
													--CEILING(@totalresultcnt/@rowsperpage) AS totalpages
												FOR JSON PATH,WITHOUT_ARRAY_WRAPPER
											)
								) searchdatacount,
							(
								SELECT
									asset_guid,
									region,
									route,
									area,
									elr,
									railway_id,
									asset_desc,
									mileage_from,
									mileage_to,							
									asset_grp,
									asset_type,
									operational_stat,
									owning_party,
									primary_material,
									dtl_compliance,
									dtl_risk_status,
									dtl_frequency,
									dtl_exam_type_id,
									dtl_compliance_date,
									dtl_planned_date,
									dtl_latest_actual_ex_date,			
									dtl_supplier,
									dtl_mitigation_date,
									ve_compliance,
									ve_risk_status,
									ve_frequency,
									ve_exam_type_id,
									ve_compliance_date,
									ve_planned_date,
									ve_latest_actual_ex_date,			
									ve_supplier,
									ve_mitigation_date,
									uw_compliance,
									uw_risk_status,
									uw_frequency,
									uw_exam_type_id,
									uw_compliance_date,
									uw_planned_date,
									uw_latest_actual_ex_date,			
									uw_supplier,
									uw_mitigation_date
								FROM
								(
									SELECT
											asset_guid,
											region,
											route,
											area,
											elr,
											railway_id,
											asset_desc,
											mileage_from,
											mileage_to,							
											asset_grp,
											asset_type,
											operational_stat,
											owning_party,
											primary_material,
											dtl_compliance,
											dtl_risk_status,
											dtl_frequency,
											dtl_exam_type_id,
											dtl_compliance_date,
											dtl_planned_date,
											dtl_latest_actual_ex_date,			
											dtl_supplier,
											dtl_mitigation_date,
											ve_compliance,
											ve_risk_status,
											ve_frequency,
											ve_exam_type_id,
											ve_compliance_date,
											ve_planned_date,
											ve_latest_actual_ex_date,			
											ve_supplier,
											ve_mitigation_date,
											uw_compliance,
											uw_risk_status,
											uw_frequency,
											uw_exam_type_id,
											uw_compliance_date,
											uw_planned_date,
											uw_latest_actual_ex_date,			
											uw_supplier,
											uw_mitigation_date,
											ROW_NUMBER() OVER (ORDER BY 
																		CASE WHEN @sortcolumn = 'StartMileage' THEN mileage_from ELSE NULL END DESC, 
																		CASE WHEN @sortcolumn = 'AssetGUID' THEN asset_guid ELSE NULL END DESC, 
																		CASE WHEN @sortcolumn = 'Region' THEN region ELSE NULL END DESC, 
																		CASE WHEN @sortcolumn = 'Route' THEN route ELSE NULL END DESC, 
																		CASE WHEN @sortcolumn = 'ELR' THEN elr ELSE NULL END DESC, 
																		CASE WHEN @sortcolumn = 'RailwayID' THEN railway_id ELSE NULL END DESC,  
																		CASE WHEN @sortcolumn = 'AssetDescription' THEN asset_desc  ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'AssetGroup' THEN asset_grp ELSE NULL END DESC, 
																		CASE WHEN @sortcolumn = 'AssetType' THEN asset_type ELSE NULL END DESC, 
																		CASE WHEN @sortcolumn = 'OperationalStat' THEN operational_stat ELSE NULL END DESC, 
																		CASE WHEN @sortcolumn = 'OwningParty' THEN owning_party ELSE NULL END DESC, 
																		CASE WHEN @sortcolumn = 'Material' THEN primary_material ELSE NULL END DESC, 
																		CASE WHEN @sortcolumn = 'DtlCompliance' THEN dtl_compliance ELSE NULL END DESC, 
																		CASE WHEN @sortcolumn = 'DtlRiskStatus' THEN dtl_risk_status  ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'DtlComplianceDate' THEN dtl_compliance_date  ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'DtlPlannedDate' THEN dtl_planned_date  ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'DtlActualExamDate' THEN dtl_latest_actual_ex_date  ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'DtlSupplier' THEN dtl_supplier  ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'DtlMitigationDate' THEN dtl_mitigation_date  ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'VECompliance' THEN ve_compliance ELSE NULL END DESC, 
																		CASE WHEN @sortcolumn = 'VERiskStatus' THEN ve_risk_status ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'VEComplianceDate' THEN ve_compliance_date  ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'VEPlannedDate' THEN ve_planned_date  ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'VEActualExamDate' THEN ve_latest_actual_ex_date  ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'VESupplier' THEN ve_supplier  ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'VEMitigationDate' THEN ve_mitigation_date  ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'UWCompliance' THEN uw_compliance  ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'UWRiskStatus' THEN uw_risk_status ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'UWComplianceDate' THEN uw_compliance_date  ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'UWPlannedDate' THEN uw_planned_date  ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'UWActualExamDate' THEN uw_latest_actual_ex_date  ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'UWSupplier' THEN uw_supplier  ELSE NULL END DESC,
																	 	CASE WHEN @sortcolumn = 'UWMitigationDate'  THEN uw_mitigation_date  ELSE NULL END DESC																
																	) AS ordrnk

									FROM #tbl_ComplianceSearchResult
								)sr
								ORDER BY ordrnk
								FOR JSON AUTO, INCLUDE_NULL_VALUES
							)searchresult
							FOR JSON PATH,WITHOUT_ARRAY_WRAPPER, INCLUDE_NULL_VALUES
						)
					END

					--Select * from #tbl_ComplianceSearchResult
					--print len(@result)
					--	print @result
			END

			ELSE IF @isexporttodoc = 'N' --Screen output
			
			BEGIN
				IF @sortorder = 'asc' 
					BEGIN
			
						SET @result=
						(
							SELECT 
								JSON_QUERY(
											(
												select
													@pageno AS currentpage,
													@totalresultcnt AS totalcount,
													CEILING(@totalresultcnt/@rowsperpage) AS totalpages
												FOR JSON PATH,WITHOUT_ARRAY_WRAPPER
											)
								) searchdatacount,
							(
								SELECT
									asset_guid,
									region,
									route,
									area,
									elr,
									railway_id,
									asset_desc,
									mileage_from,
									mileage_to,							
									asset_grp,
									asset_type,
									operational_stat,
									owning_party,
									primary_material,
									dtl_compliance,
									dtl_risk_status,
									dtl_frequency,
									dtl_exam_type_id,
									dtl_compliance_date,
									dtl_planned_date,
									dtl_latest_actual_ex_date,			
									dtl_supplier,
									dtl_mitigation_date,
									ve_compliance,
									ve_risk_status,
									ve_frequency,
									ve_exam_type_id,
									ve_compliance_date,
									ve_planned_date,
									ve_latest_actual_ex_date,			
									ve_supplier,
									ve_mitigation_date,
									uw_compliance,
									uw_risk_status,
									uw_frequency,
									uw_exam_type_id,
									uw_compliance_date,
									uw_planned_date,
									uw_latest_actual_ex_date,			
									uw_supplier,
									uw_mitigation_date
								FROM
								(
									SELECT
											asset_guid,
											region,
											route,
											area,
											elr,
											railway_id,
											asset_desc,
											mileage_from,
											mileage_to,							
											asset_grp,
											asset_type,
											operational_stat,
											owning_party,
											primary_material,
											dtl_compliance,
											dtl_risk_status,
											dtl_frequency,
											dtl_exam_type_id,
											dtl_compliance_date,
											dtl_planned_date,
											dtl_latest_actual_ex_date,			
											dtl_supplier,
											dtl_mitigation_date,
											ve_compliance,
											ve_risk_status,
											ve_frequency,
											ve_exam_type_id,
											ve_compliance_date,
											ve_planned_date,
											ve_latest_actual_ex_date,			
											ve_supplier,
											ve_mitigation_date,
											uw_compliance,
											uw_risk_status,
											uw_frequency,
											uw_exam_type_id,
											uw_compliance_date,
											uw_planned_date,
											uw_latest_actual_ex_date,			
											uw_supplier,
											uw_mitigation_date,
											ROW_NUMBER() OVER (ORDER BY 
																		CASE WHEN @sortcolumn = 'StartMileage' THEN mileage_from ELSE NULL END ASC, 
																		CASE WHEN @sortcolumn = 'AssetGUID' THEN asset_guid ELSE NULL END ASC, 
																		CASE WHEN @sortcolumn = 'Region' THEN region ELSE NULL END ASC, 
																		CASE WHEN @sortcolumn = 'Route' THEN route ELSE NULL END ASC, 
																		CASE WHEN @sortcolumn = 'ELR' THEN elr ELSE NULL END ASC, 
																		CASE WHEN @sortcolumn = 'RailwayID' THEN railway_id ELSE NULL END ASC,  
																		CASE WHEN @sortcolumn = 'AssetDescription' THEN asset_desc  ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'AssetGroup' THEN asset_grp ELSE NULL END ASC, 
																		CASE WHEN @sortcolumn = 'AssetType' THEN asset_type ELSE NULL END ASC, 
																		CASE WHEN @sortcolumn = 'OperationalStat' THEN operational_stat ELSE NULL END ASC, 
																		CASE WHEN @sortcolumn = 'OwningParty' THEN owning_party ELSE NULL END ASC, 
																		CASE WHEN @sortcolumn = 'Material' THEN primary_material ELSE NULL END ASC, 
																		CASE WHEN @sortcolumn = 'DtlCompliance' THEN dtl_compliance ELSE NULL END ASC, 
																		CASE WHEN @sortcolumn = 'DtlRiskStatus' THEN dtl_risk_status  ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'DtlComplianceDate' THEN dtl_compliance_date  ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'DtlPlannedDate' THEN dtl_planned_date  ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'DtlActualExamDate' THEN dtl_latest_actual_ex_date  ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'DtlSupplier' THEN dtl_supplier  ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'DtlMitigationDate' THEN dtl_mitigation_date  ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'VECompliance' THEN ve_compliance ELSE NULL END ASC, 
																		CASE WHEN @sortcolumn = 'VERiskStatus' THEN ve_risk_status ELSE NULL END ASC, 
																		CASE WHEN @sortcolumn = 'VEComplianceDate' THEN ve_compliance_date  ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'VEPlannedDate' THEN ve_planned_date  ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'VEActualExamDate' THEN ve_latest_actual_ex_date  ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'VESupplier' THEN ve_supplier  ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'VEMitigationDate' THEN ve_mitigation_date  ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'UWCompliance' THEN uw_compliance  ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'UWRiskStatus' THEN uw_risk_status ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'UWComplianceDate' THEN uw_compliance_date  ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'UWPlannedDate' THEN uw_planned_date  ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'UWActualExamDate' THEN uw_latest_actual_ex_date  ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'UWSupplier' THEN uw_supplier  ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'UWMitigationDate'  THEN uw_mitigation_date  ELSE NULL END ASC
																																		
																	) AS ordrnk

									FROM #tbl_ComplianceSearchResult
								)sr
								WHERE sr.ordrnk BETWEEN ((@pageno - 1) * @rowsperpage +1) AND (@pageno * @rowsperpage)
								
								ORDER BY ordrnk
								FOR JSON AUTO, INCLUDE_NULL_VALUES
							)searchresult
							FOR JSON PATH,WITHOUT_ARRAY_WRAPPER, INCLUDE_NULL_VALUES
						)
					END
				
					ELSE IF @sortorder = 'desc' 
					BEGIN
				
						SET @result=
						(
							SELECT 
								JSON_QUERY(
											(
												select
													@pageno AS currentpage,
													@totalresultcnt AS totalcount,
													CEILING(@totalresultcnt/@rowsperpage) AS totalpages
												FOR JSON PATH,WITHOUT_ARRAY_WRAPPER
											)
								) searchdatacount,
							(
								SELECT
									asset_guid,
									region,
									route,	
									area,
									elr,
									railway_id,
									asset_desc,
									mileage_from,
									mileage_to,							
									asset_grp,
									asset_type,
									operational_stat,
									owning_party,
									primary_material,
									dtl_compliance,
									dtl_risk_status,
									dtl_frequency,
									dtl_exam_type_id,
									dtl_compliance_date,
									dtl_planned_date,
									dtl_latest_actual_ex_date,			
									dtl_supplier,
									dtl_mitigation_date,
									ve_compliance,
									ve_risk_status,
									ve_frequency,
									ve_exam_type_id,
									ve_compliance_date,
									ve_planned_date,
									ve_latest_actual_ex_date,			
									ve_supplier,
									ve_mitigation_date,
									uw_compliance,
									uw_risk_status,
									uw_frequency,
									uw_exam_type_id,
									uw_compliance_date,
									uw_planned_date,
									uw_latest_actual_ex_date,			
									uw_supplier,
									uw_mitigation_date
								FROM
								(
									SELECT
											asset_guid,
											region,
											route,
											area,
											elr,
											railway_id,
											asset_desc,
											mileage_from,
											mileage_to,							
											asset_grp,
											asset_type,
											operational_stat,
											owning_party,
											primary_material,
											dtl_compliance,
											dtl_risk_status,
											dtl_frequency,
											dtl_exam_type_id,
											dtl_compliance_date,
											dtl_planned_date,
											dtl_latest_actual_ex_date,			
											dtl_supplier,
											dtl_mitigation_date,
											ve_compliance,
											ve_risk_status,
											ve_frequency,
											ve_exam_type_id,
											ve_compliance_date,
											ve_planned_date,
											ve_latest_actual_ex_date,			
											ve_supplier,
											ve_mitigation_date,
											uw_compliance,
											uw_risk_status,
											uw_frequency,
											uw_exam_type_id,
											uw_compliance_date,
											uw_planned_date,
											uw_latest_actual_ex_date,			
											uw_supplier,
											uw_mitigation_date,
											ROW_NUMBER() OVER (ORDER BY 
																		CASE WHEN @sortcolumn = 'StartMileage' THEN mileage_from ELSE NULL END DESC, 
																		CASE WHEN @sortcolumn = 'AssetGUID' THEN asset_guid ELSE NULL END DESC, 
																		CASE WHEN @sortcolumn = 'Region' THEN region ELSE NULL END DESC, 
																		CASE WHEN @sortcolumn = 'Route' THEN route ELSE NULL END DESC, 
																		CASE WHEN @sortcolumn = 'ELR' THEN elr ELSE NULL END DESC, 
																		CASE WHEN @sortcolumn = 'RailwayID' THEN railway_id ELSE NULL END DESC,  
																		CASE WHEN @sortcolumn = 'AssetDescription' THEN asset_desc  ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'AssetGroup' THEN asset_grp ELSE NULL END DESC, 
																		CASE WHEN @sortcolumn = 'AssetType' THEN asset_type ELSE NULL END DESC, 
																		CASE WHEN @sortcolumn = 'OperationalStat' THEN operational_stat ELSE NULL END DESC, 
																		CASE WHEN @sortcolumn = 'OwningParty' THEN owning_party ELSE NULL END DESC, 
																		CASE WHEN @sortcolumn = 'Material' THEN primary_material ELSE NULL END DESC, 
																		CASE WHEN @sortcolumn = 'DtlCompliance' THEN dtl_compliance ELSE NULL END DESC, 
																		CASE WHEN @sortcolumn = 'DtlRiskStatus' THEN dtl_risk_status  ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'DtlComplianceDate' THEN dtl_compliance_date  ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'DtlPlannedDate' THEN dtl_planned_date  ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'DtlActualExamDate' THEN dtl_latest_actual_ex_date  ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'DtlSupplier' THEN dtl_supplier  ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'DtlMitigationDate' THEN dtl_mitigation_date  ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'VECompliance' THEN ve_compliance ELSE NULL END DESC, 
																		CASE WHEN @sortcolumn = 'VERiskStatus' THEN ve_risk_status ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'VEComplianceDate' THEN ve_compliance_date  ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'VEPlannedDate' THEN ve_planned_date  ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'VEActualExamDate' THEN ve_latest_actual_ex_date  ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'VESupplier' THEN ve_supplier  ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'VEMitigationDate' THEN ve_mitigation_date  ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'UWCompliance' THEN uw_compliance  ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'UWRiskStatus' THEN uw_risk_status ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'UWComplianceDate' THEN uw_compliance_date  ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'UWPlannedDate' THEN uw_planned_date  ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'UWActualExamDate' THEN uw_latest_actual_ex_date  ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'UWSupplier' THEN uw_supplier  ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'UWMitigationDate'  THEN uw_mitigation_date  ELSE NULL END DESC
																	
																	) AS ordrnk

									FROM #tbl_ComplianceSearchResult
								)sr
								WHERE sr.ordrnk BETWEEN ((@pageno - 1) * @rowsperpage +1) AND (@pageno * @rowsperpage)
								
								ORDER BY ordrnk
								FOR JSON AUTO, INCLUDE_NULL_VALUES
							)searchresult
							FOR JSON PATH,WITHOUT_ARRAY_WRAPPER, INCLUDE_NULL_VALUES
						)
					END
		
			END

		END
		--SET @result_return =''
		--print @result
		--SELECT @result_return + @result

		SELECT @result
		
	END TRY
	BEGIN CATCH
		SET @ErrorMsg = ERROR_MESSAGE() + 
						' Line Num:' + CONVERT(VARCHAR(5), ERROR_LINE()) + 
						',ErrorNum:' + CONVERT(VARCHAR(5), ERROR_NUMBER()) + 
						',Severity:' + CONVERT(VARCHAR(5), ERROR_SEVERITY()) + 
						',State:' + CONVERT(VARCHAR(10), ERROR_STATE()) + 
						',Procedure:' + CONVERT(VARCHAR(25), ERROR_PROCEDURE());  
		
		DROP TABLE IF EXISTS #tbl_ComplianceRiskStatus;
		DROP TABLE IF EXISTS #tbl_ComplianceSearchResult;
	
		DROP TABLE IF EXISTS #tbl_AssetDetails;
		THROW 50000,@ErrorMsg,1;

		
	END CATCH

	DROP TABLE IF EXISTS #tbl_ComplianceRiskStatus;
	DROP TABLE IF EXISTS #tbl_ComplianceSearchResult;
	
	DROP TABLE IF EXISTS #tbl_AssetDetails;
	SET NOCOUNT OFF
END