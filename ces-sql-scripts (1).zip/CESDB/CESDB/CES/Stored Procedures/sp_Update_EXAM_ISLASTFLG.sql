﻿/***************************************************************************************************************************************            
* Name						: sp_Update_EXAM_ISLASTFLG     
* Created By				: Cognizant            
* Date Created				: 18-July-2021           
* Description				: This stored procedure updates the Exam Table ISLAST flag through ADF/UI/API.  
* Input Parameters			: JSON   
* Output Parameters			: Returns 1 for succesful save, else 0            
* Return Value				: N/A            
* Assumptions				: None    
* Execution Statement		: EXEC [CES].[sp_Update_EXAM_ISLASTFLG] '[ 
																		{"ASSET_GUID":"3978559E727145D9E04400306E4AD01A",
																			"EXAM_TYPE_SR_KEY":1
																			}
																	]','Amey Rail'	
*								
* Modified Date     Modified By   Revision Number  Modifications            

*******************************************************************************************************************************************/ 

CREATE  PROCEDURE [CES].[sp_Update_EXAM_ISLASTFLG]
	@UserKey		VARCHAR(64)
AS 

BEGIN
	SET NOCOUNT ON
    BEGIN TRY
		DECLARE
				@ErrorMsg			VARCHAR(250),
				@ErrorDescription   VARCHAR(4000),
				@Output				BIT = 0,
				@CurrentDate		DATETIME  = GETDATE()

	--select * from #tmpExamData
		
			--Update the Records ISLAST = 'N' for all Asset and Exam Type
			UPDATE t1 SET 
			t1.IS_LAST_EXAM = 'N',
			t1.UPDATED_DATE = @CurrentDate,
			t1.UPDATED_USER = @UserKey
			FROM CES.Exam t1
			INNER JOIN #tmpExamData t2 
			ON t1.ASSET_GUID = t2.ASSET_GUID 
			AND t1.EXAM_TYPE_SR_KEY = t2.EXAM_TYPE_SR_KEY
			WHERE t1.IS_LAST_EXAM = 'Y';
		
			--Rank and Update the Record with ISLAST = 'Y' for based on Asset, ExamType
			UPDATE e
			SET IS_LAST_EXAM = 'Y',
			UPDATED_DATE = @CurrentDate,
			UPDATED_USER = @UserKey
			FROM CES.EXAM e
			JOIN (
				SELECT 
					EXAM_SR_KEY
				FROM
					(SELECT ex.EXAM_SR_KEY,
							DENSE_RANK() OVER (PARTITION BY ex.ASSET_GUID, ex.EXAM_TYPE_SR_KEY 
							ORDER BY CASE WHEN RV.REF_VALUE ='In Progress' 
								OR (RV.REF_VALUE IN ('Planned','Requested','Scheduled') AND ex.EXAM_ACTUAL_DATE IS NOT NULL)
								OR (RV.REF_VALUE = 'Completed' AND ISNULL(RQ.REF_VALUE,'') <> 'Rejected by audit') THEN 1 ELSE 0 END DESC, 
							ISNULL(ex.EXAM_ACTUAL_DATE,CONVERT(DATE,'1/1/1900',103)) DESC, ex.EXAM_ID DESC) rnk
					 FROM CES.EXAM ex
					 INNER JOIN #tmpExamData tex ON ex.ASSET_GUID = tex.ASSET_GUID and ex.EXAM_TYPE_SR_KEY = tex.EXAM_TYPE_SR_KEY
					 INNER JOIN CES.REFERENCE_VALUE RV ON EX.EXAM_REQ_STATUS = RV.REF_VAL_SR_KEY				 
					 LEFT JOIN CES.REFERENCE_VALUE RQ ON EX.EXAM_REPORT_STATUS = RQ.REF_VAL_SR_KEY
					 WHERE ex.ISACTIVE =1
					)t
				WHERE rnk=1
				)f
			ON e.EXAM_SR_KEY = f.EXAM_SR_KEY
		
		SET @Output = 1
		SELECT @Output [Output],NULL AS ErrorMsg

	END TRY
	BEGIN CATCH
		
		IF @ErrorMsg IS NULL
			SET @ErrorMsg = ERROR_MESSAGE() 
		
		SET @ErrorDescription = @ErrorMsg + 
							' Line Num:' + CONVERT(VARCHAR(5), ERROR_LINE()) + 
							',ErrorNum:' + CONVERT(VARCHAR(5), ERROR_NUMBER()) + 
							',Severity:' + CONVERT(VARCHAR(5), ERROR_SEVERITY()) + 
							',State:' + CONVERT(VARCHAR(10), ERROR_STATE()) + 
							',Procedure:' + CONVERT(VARCHAR(25), OBJECT_NAME(@@procid)) +
							',Procedure:' + CONVERT(VARCHAR(25), ERROR_PROCEDURE())

		SET @Output = 0;
		
		SELECT @Output [Output],NULL AS ErrorMsg;
		THROW 50000,@ErrorDescription,1;
	END CATCH

	SET NOCOUNT OFF
  END
