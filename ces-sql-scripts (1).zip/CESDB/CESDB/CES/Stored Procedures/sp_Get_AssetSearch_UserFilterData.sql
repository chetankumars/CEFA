﻿/***************************************************************************************************************************************            
* Name						: sp_Get_AssetSearch_UserFilterData            
* Created By				: Cognizant            
* Date Created				: 11-Dec-2020           
* Description				: This stored procedure gets the data for all the dropdowns for asset basic and advanced search.  
* Input Parameters			: N/A      
* Output Parameters			: N/A            
* Return Value				: N/A            
* Assumptions				: None    
* Execution Statement		: Exec [CES].sp_Get_AssetSearch_UserFilterData '290'
*								
* Modified Date     Modified By   Revision Number  Modifications            

*******************************************************************************************************************************************/ 



CREATE PROCEDURE [CES].[sp_Get_AssetSearch_UserFilterData]
	@User_ID	DECIMAL(18)
AS

BEGIN
	SET NOCOUNT ON
	BEGIN TRY
		DECLARE
				@ErrorMsg	VARCHAR(250),
				@result		VARCHAR(MAX),
				@isallaccess	CHAR(1)

	--Checking if the user has config data present in Entitlement table. If Yes, then Region/route/area will be filtered accordingly,
	--If Not, user will have access to all region/route/area with no default option set
	IF EXISTS (SELECT 1 FROM ENTITLEMENT WHERE USER_SR_KEY = @User_ID)
		SET @isallaccess = 'N'
	ELSE
		SET @isallaccess = 'Y'

	SET @result=
	(	 
		SELECT 
			--Region/Route/Area/ELR combinations
			(
				SELECT 
					regions.region_id,
					regions.REGION AS region_name,
					routes.ORG_SR_KEY AS route_id,
					routes.ROUTE AS route_name,
					areas.AREA_SR_KEY AS area_id,
					areas.AREA_NAME AS area_name,
					elr.ELR_SR_KEY AS elr_id,
					elr.ELR_CODE as elr_code
				FROM 
					(
						SELECT 
							ROW_NUMBER() OVER (ORDER BY REGION) region_id,
							REGION 
						FROM
						(
							SELECT DISTINCT REGION 
							FROM [CES].ORG
							WHERE ISACTIVE = 1
						)r
					) regions
				INNER JOIN [CES].ORG routes
				ON regions.REGION  = routes.REGION
				LEFT JOIN [CES].AREA areas
				ON routes.ORG_SR_KEY = areas.ORG_SR_KEY
				AND areas.ISACTIVE = 1
				LEFT JOIN [CES].ENGINE_LINE_REF elr
				ON elr.ORG_SR_KEY = routes.ORG_SR_KEY
				AND elr.ISACTIVE = 1
				AND elr.AREA_SR_KEY = areas.AREA_SR_KEY
				WHERE  routes.ISACTIVE = 1
				AND	( (@isallaccess = 'Y') OR (@isallaccess = 'N' AND
									EXISTS (SELECT 1 FROM [CES].ENTITLEMENT ent
											WHERE ent.ORG_SR_KEY = routes.ORG_SR_KEY
											AND ISNULL(ent.AREA_SR_KEY,0) = ISNULL(areas.AREA_SR_KEY,0)
											AND ent.USER_SR_KEY = @User_ID
											AND ent.ISACTIVE = 1)
											)
					)
							
				ORDER BY 
					regions.region,
					routes.ROUTE,
					areas.AREA_NAME,
					elr.ELR_CODE
				FOR JSON AUTO, INCLUDE_NULL_VALUES
			) regions,
			
			--Asset Group/Asset Types combinations 
			(
				SELECT 
					asg.ASSET_GROUP_SR_KEY AS asg_id, 
					asg.ASSET_GROUP_DESC AS asg_name,
					ast.ASSET_TYPE_SR_KEY AS ast_id,
					ast.ASSET_TYPE_DESC AS ast_name
				FROM [CES].ASSET_GROUP asg
				INNER JOIN [CES].ASSET_TYPE ast
				ON asg.ASSET_GROUP_SR_KEY = ast.ASSET_GROUP_SR_KEY
				WHERE  asg.ISACTIVE = 1
				AND ast.ISACTIVE = 1
					
				ORDER BY
					asg.ASSET_GROUP_DESC,
					ast.ASSET_TYPE_DESC
				FOR JSON AUTO, INCLUDE_NULL_VALUES
			) AS asset_groups,

			--Operational Status
			(
				SELECT
					rv.REF_VAL_SR_KEY AS opstat_id,
					rv.REF_VALUE AS opstat_name
				FROM	[CES].REFERENCE_VALUE rv
				INNER JOIN [CES].REFERENCE_TYPE rt
				ON rv.REF_TYP_SR_KEY = rt.REF_TYP_SR_KEY
				WHERE rt.REF_TYP_CODE = 'OPS'
				AND rv.ISACTIVE = 1
				AND rt.ISACTIVE = 1
				ORDER BY 
					rv.REF_VALUE
				FOR JSON AUTO,INCLUDE_NULL_VALUES
			)oprstats,

			--Owning Party
			(
				SELECT 
					ROW_NUMBER() OVER (ORDER BY a.ownparty_name) ownparty_id,
					a.ownparty_name
				FROM
					(
						SELECT DISTINCT
							ast.OWNING_PARTY AS ownparty_name
						FROM	[CES].ASSET ast
						WHERE ast.OWNING_PARTY IS NOT NULL
						AND ast.ISACTIVE = 1
					)a
					ORDER BY a.ownparty_name
				FOR JSON AUTO, INCLUDE_NULL_VALUES
			)ownparty,

			--Material Types
			(
				SELECT
					rv.REF_VAL_SR_KEY AS mattyp_id,
					rv.REF_VALUE AS mattyp_name
				FROM	[CES].REFERENCE_VALUE rv
				INNER JOIN [CES].REFERENCE_TYPE rt
				ON rv.REF_TYP_SR_KEY = rt.REF_TYP_SR_KEY
				WHERE rt.REF_TYP_CODE = 'MAT'
				AND rt.ISACTIVE = 1
				AND rv.ISACTIVE = 1
				ORDER BY 
					rv.REF_VALUE
				FOR JSON AUTO,INCLUDE_NULL_VALUES
			)mattyps,

			--HCE Flag
			(
				SELECT
					hceflg_id,
					hceflg_name
				FROM 
					(
						SELECT
							1 hceflg_id,
							'Yes' hceflg_name

						UNION

						SELECT
							2 hceflg_id,
							'No' hceflg_name
					)h
				FOR JSON AUTO
			)hceflg,

			--Structure Carries
			(
				SELECT 
					ROW_NUMBER() OVER (ORDER BY a.strccarries_name) strccarries_id,
					a.strccarries_name
				FROM
					(
						SELECT DISTINCT
							ast.STRUCTURE_CARRIES AS strccarries_name
						FROM	[CES].ASSET ast
						WHERE ast.ISACTIVE = 1
						AND	  ast.STRUCTURE_CARRIES IS NOT NULL	
					)a
					ORDER BY a.strccarries_name
				FOR JSON AUTO,INCLUDE_NULL_VALUES
			)strccarries,

			--Structure Over
			(
				SELECT 
					ROW_NUMBER() OVER (ORDER BY a.strcover_name) strcover_id,
					a.strcover_name
				FROM
					(
						SELECT DISTINCT
							ast.STRUCTURE_OVER AS strcover_name
						FROM	[CES].ASSET ast
						WHERE ast.ISACTIVE = 1
						AND		ast.STRUCTURE_OVER IS NOT NULL	
					)a
					ORDER BY a.strcover_name
				FOR JSON AUTO,INCLUDE_NULL_VALUES
			)strcover,

			--Supplier
			(
				SELECT 
					SUPPLIER_SR_KEY AS supplier_id,
					supplier_name
				FROM	[CES].SUPPLIER 
				WHERE ISACTIVE = 1
				ORDER BY SUPPLIER_SR_KEY
				FOR JSON AUTO,INCLUDE_NULL_VALUES
			)supplier,

			--Tasklist year
			(
				SELECT 
					rv.REF_VAL_SR_KEY AS tasklist_yr_id,
					rv.REF_VALUE AS tasklist_yr_name
				FROM	[CES].REFERENCE_VALUE rv
				INNER JOIN [CES].REFERENCE_TYPE rt
				ON		rv.REF_TYP_SR_KEY = rt.REF_TYP_SR_KEY
				WHERE rv.ISACTIVE = 1
				AND	  rt.ISACTIVE = 1
				AND	  rt.REF_TYP_CODE = 'FYR'
				AND	  EXISTS ( SELECT 1 FROm CES.WORK
							   WHERE WORK_YEAR_KEY = rv.REF_VAL_SR_KEY)
				ORDER BY rv.REF_VALUE
				FOR JSON AUTO,INCLUDE_NULL_VALUES
			) tasklistyr,

			--Exam Status
			(
				SELECT 
					rv.REF_VAL_SR_KEY AS exam_status_id,
					rv.REF_VALUE AS exam_status_name
				FROM	[CES].REFERENCE_VALUE rv
				INNER JOIN [CES].REFERENCE_TYPE rt
				ON		rv.REF_TYP_SR_KEY = rt.REF_TYP_SR_KEY
				WHERE rv.ISACTIVE = 1
				AND	  rt.ISACTIVE = 1
				AND	  rt.REF_TYP_CODE = 'ERS'
				ORDER BY rv.REF_VAL_SR_KEY
				FOR JSON AUTO,INCLUDE_NULL_VALUES
			)examstatus,

			--Exam Type
			(
				SELECT 
					EXAM_TYPE_SR_KEY AS exam_typ_id,
					EXAM_TYPE AS exam_typ_name
				FROM	CES.EXAM_TYPE
				WHERE ISACTIVE = 1
				AND EXAM_TYPE NOT IN ('Network Rail Site Visit','Inspection For Assessment')
				ORDER BY EXAM_TYPE_SR_KEY
				FOR JSON AUTO,INCLUDE_NULL_VALUES
			)examtype,

			--Task list Status
			(
				SELECT 
					rv.REF_VAL_SR_KEY AS tasklist_status_id,
					rv.REF_VALUE AS tasklist_status_name
				FROM	[CES].REFERENCE_VALUE rv
				INNER JOIN [CES].REFERENCE_TYPE rt
				ON		rv.REF_TYP_SR_KEY = rt.REF_TYP_SR_KEY
				WHERE rv.ISACTIVE = 1
				AND	  rt.ISACTIVE = 1
				AND	  rt.REF_TYP_CODE = 'TLS'
				ORDER BY rv.REF_VAL_SR_KEY
				FOR JSON AUTO,INCLUDE_NULL_VALUES
			)tskliststatus,

			--Compliance Status
			(
				SELECT 
					rv.REF_VAL_SR_KEY AS comp_status_id,
					rv.REF_VALUE AS comp_status_name
				FROM	[CES].REFERENCE_VALUE rv
				INNER JOIN [CES].REFERENCE_TYPE rt
				ON		rv.REF_TYP_SR_KEY = rt.REF_TYP_SR_KEY
				WHERE rv.ISACTIVE = 1
				AND	  rt.ISACTIVE = 1
				AND	  rt.REF_TYP_CODE = 'CST'
				ORDER BY rv.REF_VAL_SR_KEY
				FOR JSON AUTO,INCLUDE_NULL_VALUES
			)complncstatus,

			--Risk Assessment Status
			(
				SELECT 
					rv.REF_VAL_SR_KEY AS risk_status_id,
					rv.REF_VALUE AS risk_status_name
				FROM	[CES].REFERENCE_VALUE rv
				INNER JOIN [CES].REFERENCE_TYPE rt
				ON		rv.REF_TYP_SR_KEY = rt.REF_TYP_SR_KEY
				WHERE rv.ISACTIVE = 1
				AND	  rt.ISACTIVE = 1
				AND	  rt.REF_TYP_CODE = 'RAS'
				ORDER BY rv.REF_VAL_SR_KEY
				FOR JSON AUTO,INCLUDE_NULL_VALUES
			)riskassesstatus,

			--Outside Party
			(
				SELECT 
					ROW_NUMBER() OVER (ORDER BY a.outsideparty_name) outsideparty_id,
					a.outsideparty_name
				FROM
					(
						SELECT DISTINCT
							ast.OUTSIDE_PARTY AS outsideparty_name
						FROM	[CES].ASSET ast
						WHERE ast.OUTSIDE_PARTY IS NOT NULL
						AND ast.ISACTIVE = 1
					)a
					ORDER BY a.outsideparty_name
				FOR JSON AUTO, INCLUDE_NULL_VALUES
			)outsideparty,

			--All Region/Route/Areas in CES needed for Admin screen
			(
				SELECT 
					regions.region_id,
					regions.REGION AS region_name,
					routes.ORG_SR_KEY AS route_id,
					routes.ROUTE AS route_name,
					areas.AREA_SR_KEY AS area_id,
					areas.AREA_NAME AS area_name
				FROM 
					(
						SELECT 
							ROW_NUMBER() OVER (ORDER BY REGION) region_id,
							REGION 
						FROM
						(
							SELECT DISTINCT REGION 
							FROM [CES].ORG
							WHERE ISACTIVE = 1
						)r
					) regions
				INNER JOIN [CES].ORG routes
				ON regions.REGION  = routes.REGION
				LEFT JOIN [CES].AREA areas
				ON routes.ORG_SR_KEY = areas.ORG_SR_KEY
				AND areas.ISACTIVE = 1
				WHERE  routes.ISACTIVE = 1
				
							
				ORDER BY 
					regions.region,
					routes.ROUTE,
					areas.AREA_NAME
				FOR JSON AUTO, INCLUDE_NULL_VALUES
			) rra

		FOR JSON PATH,WITHOUT_ARRAY_WRAPPER
	)

	--PRINT @result
	SELECT @result

	END TRY

	BEGIN CATCH
		SET @ErrorMsg = ERROR_MESSAGE() + 
						' Line Num:' + CONVERT(VARCHAR(5), ERROR_LINE()) + 
						',ErrorNum:' + CONVERT(VARCHAR(5), ERROR_NUMBER()) + 
						',Severity:' + CONVERT(VARCHAR(5), ERROR_SEVERITY()) + 
						',State:' + CONVERT(VARCHAR(10), ERROR_STATE()) + 
						',Procedure:' + CONVERT(VARCHAR(25), OBJECT_NAME(@@procid)) +
						',Procedure:' + CONVERT(VARCHAR(25), ERROR_PROCEDURE());  

		THROW 50000,@ErrorMsg,1;
	END CATCH
	SET NOCOUNT OFF
END