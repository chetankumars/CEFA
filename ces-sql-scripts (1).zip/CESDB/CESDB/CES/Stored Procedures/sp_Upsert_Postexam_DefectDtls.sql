﻿







CREATE PROCEDURE [CES].[sp_Upsert_Postexam_DefectDtls]
	@Input_JSON		NVARCHAR(MAX)
	
AS 

BEGIN
	SET NOCOUNT ON
    BEGIN TRY
		DECLARE
		
		
		        @ErrorMsg			VARCHAR(250),
				@ErrorDescription   VARCHAR(4000),
				@Output				BIT = 0
				
		
		CREATE TABLE #tmpAstDefectDtls
		
		(
			DEFECT_ID			 DECIMAL(18),
			ASSET_GUID           VARCHAR(32),
			EXAM_SR_KEY			 DECIMAL(18),
			DETERIORATION        VARCHAR(64),
			LOCATION_MAJOR		 VARCHAR(250),
			LOCATION_MINOR		 VARCHAR(250),
			RECOMMEND_RAISED     VARCHAR(5),
			REPAIRED             VARCHAR(5),
			ACCESS_GAINED        VARCHAR(5),
			ACCESS_REQUIRED      VARCHAR(5),
			RISK_SCORE 			 VARCHAR(10),
			FLAG_FOR_CLOSURE     VARCHAR(5),
			DEF_DESCRIPTION      VARCHAR(250),
			DEF_LOCATION		 VARCHAR(250),
			CREATED_USER         VARCHAR(64),
			CREATED_DATE         DATETIME,
			UPDATED_USER		 VARCHAR(64),
			UPDATED_DATE         DATETIME,
			SYNC_FLAG			 VARCHAR(5)
					
		)
		
		CREATE TABLE #tmpAstDefectID
		(
		    DEFECT_ID			 DECIMAL(18),
			ASSET_GUID           VARCHAR(32),
			EXAM_SR_KEY			 DECIMAL(18),
			DETERIORATION        VARCHAR(64),
			LOCATION_MAJOR		 VARCHAR(250),
			LOCATION_MINOR		 VARCHAR(250),
			RECOMMEND_RAISED     VARCHAR(5),
			REPAIRED             VARCHAR(5),
			ACCESS_GAINED        VARCHAR(5),
			ACCESS_REQUIRED      VARCHAR(5),
			RISK_SCORE 			 VARCHAR(10),
			FLAG_FOR_CLOSURE     VARCHAR(5),
			DEF_DESCRIPTION      VARCHAR(250),
			DEF_LOCATION		 VARCHAR(250),
			CREATED_USER         VARCHAR(64),
			CREATED_DATE         DATETIME,
			UPDATED_USER		 VARCHAR(64),
			UPDATED_DATE         DATETIME,
			SYNC_FLAG			 VARCHAR(5)
			
		)

		CREATE TABLE #tmpAstNewDefectID
		(
				Defect_ID		DECIMAL(18),
				New_Defect_ID	DECIMAL(18)
		)
		-------Parsing the input JSON and gathering the records	

       INSERT INTO #tmpAstDefectDtls
		(
			    
			DEFECT_ID			 ,
			ASSET_GUID           ,
			EXAM_SR_KEY			 ,
			DETERIORATION        ,
			LOCATION_MAJOR		 ,
			LOCATION_MINOR		 ,
			RECOMMEND_RAISED     ,
			REPAIRED             ,
			ACCESS_GAINED        ,
			ACCESS_REQUIRED      ,
			RISK_SCORE 			 ,
			FLAG_FOR_CLOSURE     ,
			DEF_DESCRIPTION      ,
			DEF_LOCATION		 ,
			CREATED_USER         ,
			CREATED_DATE         ,		 
            UPDATED_USER         ,
		    UPDATED_DATE         ,
			SYNC_FLAG            )
		
		SELECT
			DEFECT_ID			 ,
			XML_ASSET_GUID       ,
			EXAM_SR_KEY			 ,
			DETERIORATION        ,
			LOCATION_MAJOR		 ,
			LOCATION_MINOR		 ,
			RECOMMEND_RAISED     ,
			REPAIRED             ,
			ACCESS_GAINED        ,
			ACCESS_REQUIRED      ,
			RISK_SCORE 			 ,
			FLAG_FOR_CLOSURE     ,
			DEF_DESCRIPTION      ,
			DEF_LOCATION		 ,
			CREATED_USER         ,
			CREATED_DATE         ,		 
            UPDATED_USER         ,
		    UPDATED_DATE         ,
			SYNC_FLAG            
		FROM OPENJSON(@Input_JSON)
		With 
		(   DEFECT_ID			 DECIMAL(18),
			XML_ASSET_GUID       VARCHAR(32),
			EXAM_SR_KEY			 DECIMAL(18),
			DETERIORATION        VARCHAR(64),
			LOCATION_MAJOR		 VARCHAR(250),
			LOCATION_MINOR		 VARCHAR(250),
			RECOMMEND_RAISED     VARCHAR(5),
			REPAIRED             VARCHAR(5),
			ACCESS_GAINED        VARCHAR(5),
			ACCESS_REQUIRED      VARCHAR(5),
			RISK_SCORE 			 VARCHAR(10),
			FLAG_FOR_CLOSURE     VARCHAR(5),
			DEF_DESCRIPTION      VARCHAR(250),
			DEF_LOCATION		 VARCHAR(250),
			CREATED_USER         VARCHAR(64),
			CREATED_DATE         DATETIME,
			UPDATED_USER		 VARCHAR(64),
			UPDATED_DATE         DATETIME,
			SYNC_FLAG			 VARCHAR(5)
		) tmp_dd

		INSERT INTO #tmpAstNewDefectID
		(
			NEW_DEFECT_ID,DEFECT_ID
		)
		SELECT NEXT VALUE FOR SEQ_DEFECT_ID New_Defect_ID,
		defect_id
		FROM
		(
			select distinct defect_id
			from #tmpAstDefectDtls 
			WHERE SYNC_FLAG='I'
		)tmp
		

	--- Find the Defect_id based on Seq_id
	
		INSERT INTO #tmpAstDefectID 
	
			(   DEFECT_ID            ,
			    ASSET_GUID           ,
			    EXAM_SR_KEY			 ,
			    DETERIORATION        ,
			    LOCATION_MAJOR		 ,
			    LOCATION_MINOR		 ,
				RECOMMEND_RAISED     ,
				REPAIRED             ,
				ACCESS_GAINED        ,
				ACCESS_REQUIRED      ,
				RISK_SCORE 			 ,
				FLAG_FOR_CLOSURE     ,
				DEF_DESCRIPTION      ,
				DEF_LOCATION		 ,
				CREATED_USER         ,
			    CREATED_DATE         ,		 
                UPDATED_USER         ,
		        UPDATED_DATE         ,
			    SYNC_FLAG 			
			    	
			)
		
		SELECT Did.New_Defect_ID as Defect_id,
                def.ASSET_GUID           ,
			    def.EXAM_SR_KEY			 ,
			    def.DETERIORATION        ,
			    def.LOCATION_MAJOR		 ,
			    def.LOCATION_MINOR		 ,
				def.RECOMMEND_RAISED     ,
				def.REPAIRED             ,
				def.ACCESS_GAINED        ,
				def.ACCESS_REQUIRED      ,
				def.RISK_SCORE 			 ,
				def.FLAG_FOR_CLOSURE     ,
				def.DEF_DESCRIPTION      ,
				def.DEF_LOCATION		 ,
				def.CREATED_USER         ,
			    def.CREATED_DATE         ,		 
                def.UPDATED_USER         ,
		        def.UPDATED_DATE         ,
				def.SYNC_FLAG	        

		from
			#tmpAstNewDefectID Did 
		INNER JOIN #tmpAstDefectDtls def ON  Def.DEFECT_ID=Did.DEFECT_ID
		ORDER BY DEFECT_ID
		
		
		select * from #tmpAstDefectID 
		return	

	   SET @Output = 1
		
		SELECT @Output AS SaveStatus,NULL AS ErrorMsg;

	END TRY
		 
	BEGIN CATCH
		IF (@@TRANCOUNT >0)
			ROLLBACK TRAN
			
		IF @ErrorMsg IS NULL
			SET @ErrorMsg = ERROR_MESSAGE() 
			
		SET @ErrorDescription = @ErrorMsg + 
							' Line Num:' + CONVERT(VARCHAR(5), ERROR_LINE()) + 
							',ErrorNum:' + CONVERT(VARCHAR(5), ERROR_NUMBER()) + 
							',Severity:' + CONVERT(VARCHAR(5), ERROR_SEVERITY()) + 
							',State:' + CONVERT(VARCHAR(10), ERROR_STATE()) + 
							',Procedure:' + CONVERT(VARCHAR(25), OBJECT_NAME(@@procid)) +
							',Procedure:' + CONVERT(VARCHAR(25), ERROR_PROCEDURE())

		SET @Output = 0;
		SELECT @Output AS SaveStatus,@ErrorMsg AS ErrorMsg;
			
		DROP TABLE IF EXISTS #tmpAstDefectID;
		DROP TABLE IF EXISTS #tmpAstDefectDtls; 
		DROP TABLE IF EXISTS #tmpAstNewDefectID;
		THROW 50000,@ErrorDescription,1;
	END CATCH

	DROP TABLE IF EXISTS #tmpAstDefectID;
	DROP TABLE IF EXISTS #tmpAstDefectDtls; 
	DROP TABLE IF EXISTS #tmpAstNewDefectID;

	SET NOCOUNT OFF
	END