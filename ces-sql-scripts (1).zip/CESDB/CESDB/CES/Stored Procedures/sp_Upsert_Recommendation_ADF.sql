﻿


CREATE PROCEDURE [CES].[sp_Upsert_Recommendation_ADF]
	@Input_JSON		NVARCHAR(MAX)

AS 

BEGIN
	SET NOCOUNT ON
    BEGIN TRY
		DECLARE
				@ErrorMsg			VARCHAR(250),
				@ErrorDescription   VARCHAR(4000),
				@Output				BIT = 0,
				@CurrentDate		DATETIME  = GETDATE(),
				@User				VARCHAR(16) = 'CARRS'
		
		DROP TABLE IF EXISTS #tmpAsRecommendation_ADF

		CREATE TABLE #tmpAsRecommendation_ADF
		(
			EXAM_SR_KEY		   decimal(18),
			CARRS_RECOMMEND_ID decimal(18),
			RCMN_NUM		   decimal(18),
			RCMN_STATUS 	   decimal(18),
			DESCRIPTION        varchar(1000),
			PRIORITY_YEAR	   decimal(18),
			LOCATION  		   varchar(128)	,
			ESTIMATED_COST	   decimal(18),
            QUANTITY		   decimal(18),
			QUANTITY_UNIT      varchar(32),
			EXTENT             varchar(12),
			PROBABILITY		   varchar(5),
			SEVERITY		   varchar(5),
			RISK_SCORE		   varchar(5),
			WORK_CATEGORY	   decimal(18),
			CREATED_DATE       datetime,
			CREATED_USER	   varchar(64),
			UPDATED_DATE	   datetime,
			UPDATED_USER       varchar(64),
			ISACTIVE           bit
		)
		
		--Parsing the input JSON and gathering the records					
		INSERT INTO #tmpAsRecommendation_ADF
		(
			EXAM_SR_KEY		  ,
			CARRS_RECOMMEND_ID,
			RCMN_NUM		  ,
			RCMN_STATUS 	  ,
			DESCRIPTION       ,
			PRIORITY_YEAR	  ,
			LOCATION  		  ,
			ESTIMATED_COST	  ,
            QUANTITY		  ,
			QUANTITY_UNIT     ,
			EXTENT            ,
			PROBABILITY		  ,
			SEVERITY		  ,
			RISK_SCORE		  ,
			WORK_CATEGORY	  ,
			CREATED_DATE      ,
			CREATED_USER	  ,
			UPDATED_DATE	  ,
			UPDATED_USER      ,
			ISACTIVE          
		)
		SELECT				
			ast.EXAM_SR_KEY				      ,
			ast.RECOMMEND_ID				  ,
			ast.RECOMMEND_NUM      		      ,
			ast.RCMN_STATUS		              ,
			ast.RECOMMEND_DESC                ,
			ast.PRIORITY_YEAR		          ,
			ast.LOC_DESC		              ,
			ast.ESTIMATED_COST_AMT 			  ,
			ast.RECOMMEND_QTY			      ,
			ast.QUANTITY_UNIT                 ,
			ast.EXTENT	                      ,
			ast.PROBABILITY					  ,
			ast.SEVERITY					  ,
			ast.RISK_SCORE					  ,
			ast.WORK_CATEGORY				  ,
			ast.CREATED_DATE                  ,
			ast.CREATED_USER			      ,
			ast.UPDATED_DATE			      ,
			ast.UPDATED_USER                  ,
			CASE
			 WHEN ast.DELETED_FLG = 'Y' THEN 0
			 WHEN ast.DELETED_FLG = 'N' THEN 1
			END AS ISACTIVE
		FROM	OPENJSON(@Input_JSON)
		WITH 
			(
			EXAM_SR_KEY		   decimal(18),
			RECOMMEND_ID       decimal(18),
			RECOMMEND_NUM      decimal(18),
			RCMN_STATUS 	   decimal(18),
			RECOMMEND_DESC     varchar(1000),
			PRIORITY_YEAR	   decimal(18),
			LOC_DESC		   varchar(128)	,
			ESTIMATED_COST_AMT decimal(18),
            RECOMMEND_QTY	   decimal(18),
			QUANTITY_UNIT      varchar(32),
			EXTENT             varchar(12),
			PROBABILITY		   varchar(5),
			SEVERITY		   varchar(5),
			RISK_SCORE		   varchar(5),
			WORK_CATEGORY	   decimal(18),
			CREATED_DATE       datetime,
			CREATED_USER	   varchar(64),
			UPDATED_DATE	   datetime,
			UPDATED_USER       varchar(64),
			DELETED_FLG		   char
			) AS ast

		--- Validation Checks -- Start

		BEGIN TRAN

		MERGE CES.RECOMMENDATION AS TARGET
		USING #tmpAsRecommendation_ADF As SOURCE
		ON (TARGET.EXAM_SR_KEY   = SOURCE.EXAM_SR_KEY and
            TARGET.RCMN_NUM      = SOURCE.RCMN_NUM and
			TARGET.DESCRIPTION   = SOURCE.DESCRIPTION 
			)					   
						
		WHEN MATCHED 
		   THEN UPDATE SET 
		    TARGET.CARRS_RECOMMEND_ID =SOURCE.CARRS_RECOMMEND_ID,
            TARGET.RCMN_STATUS  =SOURCE.RCMN_STATUS 	  ,
            TARGET.PRIORITY_YEAR  =SOURCE.PRIORITY_YEAR	  ,
            TARGET.LOCATION   =SOURCE.LOCATION  		  ,
            TARGET.ESTIMATED_COST =SOURCE.ESTIMATED_COST	  ,
            TARGET.QUANTITY  =SOURCE.QUANTITY		  ,
            TARGET.QUANTITY_UNIT   =SOURCE.QUANTITY_UNIT     ,
            TARGET.EXTENT  =SOURCE.EXTENT            ,
            TARGET.PROBABILITY  =SOURCE.PROBABILITY		  ,
            TARGET.SEVERITY  =SOURCE.SEVERITY		  ,
            TARGET.RISK_SCORE  =SOURCE.RISK_SCORE		  ,
            TARGET.WORK_CATEGORY  =SOURCE.WORK_CATEGORY	  ,
            TARGET.CREATED_DATE  =SOURCE.CREATED_DATE      ,
            TARGET.CREATED_USER  =SOURCE.CREATED_USER	  ,				
		    UPDATED_USER = @User									, 
		    UPDATED_DATE = @CurrentDate
		WHEN NOT MATCHED BY TARGET AND (SOURCE.ISACTIVE = 1)
		   THEN INSERT (
		    EXAM_SR_KEY         ,
		    CARRS_RECOMMEND_ID	,
			RCMN_NUM            ,
			RCMN_STATUS 		,
			DESCRIPTION 		,
			PRIORITY_YEAR       ,
			LOCATION			,
			ESTIMATED_COST 		,
			QUANTITY 			,
			QUANTITY_UNIT 		,
			EXTENT              ,
			PROBABILITY	        ,
			SEVERITY            ,
			RISK_SCORE          ,
			WORK_CATEGORY       ,
			CREATED_DATE        ,
			CREATED_USER		
			) 
			VALUES(
			SOURCE.EXAM_SR_KEY         ,
		    SOURCE.CARRS_RECOMMEND_ID  ,
			SOURCE.RCMN_NUM            ,
			SOURCE.RCMN_STATUS 		   ,
			SOURCE.DESCRIPTION 		   ,
			SOURCE.PRIORITY_YEAR       ,
			SOURCE.LOCATION			   ,
			SOURCE.ESTIMATED_COST 	   ,
			SOURCE.QUANTITY 		   ,
			SOURCE.QUANTITY_UNIT 	   ,
			SOURCE.EXTENT              ,
			SOURCE.PROBABILITY	       ,
			SOURCE.SEVERITY            ,
			SOURCE.RISK_SCORE          ,
			SOURCE.WORK_CATEGORY       ,			
			@CurrentDate,
			@User);		
		COMMIT TRAN
		SET @Output = 1

		 SELECT @Output AS SaveStatus,NULL AS ErrorMsg;
	END TRY

	BEGIN CATCH
		IF (@@TRANCOUNT >0)
			ROLLBACK TRAN
		
		IF @ErrorMsg IS NULL
			SET @ErrorMsg = ERROR_MESSAGE() 
		
		SET @ErrorDescription = @ErrorMsg + 
							' Line Num:' + CONVERT(VARCHAR(5), ERROR_LINE()) + 
							',ErrorNum:' + CONVERT(VARCHAR(5), ERROR_NUMBER()) + 
							',Severity:' + CONVERT(VARCHAR(5), ERROR_SEVERITY()) + 
							',State:' + CONVERT(VARCHAR(10), ERROR_STATE()) + 
							',Procedure:' + CONVERT(VARCHAR(25), OBJECT_NAME(@@procid)) +
							',Procedure:' + CONVERT(VARCHAR(25), ERROR_PROCEDURE())

		SET @Output = 0;
		SELECT @Output AS SaveStatus,@ErrorMsg AS ErrorMsg;

		THROW 50000,@ErrorDescription,1;
	END CATCH

	DROP TABLE IF EXISTS #tmpAsRecommendation_ADF;
	SET NOCOUNT OFF
  END