﻿
/***************************************************************************************************************************************            
* Name						: sp_Update_EXAM_ISLATEST_Sync_ADF     
* Created By				: Cognizant            
* Date Created				: 28-Feb-2021           
* Description				: This stored procedure updates the Exam Table ISLAST flag through ADF.  
* Input Parameters			: JSON   
* Output Parameters			: Returns 1 for succesful save, else 0            
* Return Value				: N/A            
* Assumptions				: None    
* Execution Statement		: EXEC CES.sp_Update_ISLATEST_Sync_ADF '[ 
																	{ 
																	"ASSET_GUID": "3978559C3BF045D9E04400306E4AD01A", 
																	"EXAM_TYPE_SR_KEY": 1, 
																	"EXAM_ACTUAL_DATE": null
																	}, 
																	{ 
																	"ASSET_GUID": "3978559C3BF045D9E04400306E4AD01A", 
																	"EXAM_TYPE_SR_KEY": 1, 
																	"EXAM_ACTUAL_DATE": '2021-01-01 23:23:28'
																	 } 
																]'	
*								
* Modified Date     Modified By   Revision Number  Modifications            

*******************************************************************************************************************************************/ 

CREATE   PROCEDURE [CES].[sp_Update_EXAM_ISLASTFLG_Sync_ADF]
	@Input_JSON		NVARCHAR(MAX)

AS 

BEGIN
	SET NOCOUNT ON
    BEGIN TRY
		DECLARE
				@ErrorMsg			VARCHAR(250),
				@ErrorDescription   VARCHAR(4000),
				@Output				BIT = 0,
				@CurrentDate		DATETIME  = GETDATE(),
				@User				VARCHAR(16) = 'CARRS'

	
		DROP TABLE IF EXISTS #tmpAsExam_ADF
		DROP TABLE IF EXISTS #tmpAsOldExam_ADF

		CREATE TABLE #tmpAsExam_ADF
		(
			ASSET_GUID				VARCHAR(32),
			EXAM_TYPE_SR_KEY		DECIMAL(9),
			NEW_EXAM_ACTUAL_DATE	DATE	
		)

		CREATE TABLE #tmpAsOldExam_ADF
		(
			ASSET_GUID				VARCHAR(32),
			EXAM_TYPE_SR_KEY		DECIMAL(9),
			NEW_EXAM_ACTUAL_DATE	DATE,
			OLD_EXAM_ACTUAL_DATE	DATE,
			ISNewLatest				CHAR,
			ISOldLatest				CHAR		
		)
		
		--Parsing the input JSON and gathering the records					
		INSERT INTO #tmpAsExam_ADF
		(
			ASSET_GUID,
			EXAM_TYPE_SR_KEY,
			NEW_EXAM_ACTUAL_DATE
		)
		SELECT				
			ast.ASSET_GUID,
			ast.EXAM_TYPE_SR_KEY,
			ISNULL(ast.EXAM_ACTUAL_DATE,CONVERT(DATE,'1/1/1900',103))
		FROM	OPENJSON(@Input_JSON)
		WITH 
			(
				ASSET_GUID				VARCHAR(32),
				EXAM_TYPE_SR_KEY		DECIMAL(9),
				EXAM_ACTUAL_DATE		DATE	
			) AS ast

		

	INSERT INTO #tmpAsOldExam_ADF
	(
			ASSET_GUID,
			EXAM_TYPE_SR_KEY,
			NEW_EXAM_ACTUAL_DATE,
			OLD_EXAM_ACTUAL_DATE,
			ISNewLatest,
			ISOldLatest			
	)
	Select tExam.ASSET_GUID, tExam.EXAM_TYPE_SR_KEY, tExam.NEW_EXAM_ACTUAL_DATE, ISNULL(CEX.EXAM_ACTUAL_DATE,CONVERT(DATE,'1/1/1900',103)),
	CASE
            WHEN tExam.NEW_EXAM_ACTUAL_DATE > ISNULL(CEX.EXAM_ACTUAL_DATE,CONVERT(DATE,'1/1/1900',103))
               THEN 'Y'
               ELSE 'N'
       END as ISNewLatest,
	   CASE
            WHEN tExam.NEW_EXAM_ACTUAL_DATE <= ISNULL(CEX.EXAM_ACTUAL_DATE,CONVERT(DATE,'1/1/1900',103))
               THEN 'Y'
               ELSE 'N'
       END as ISOldLatest 
	FROM #tmpAsExam_ADF tExam 
	LEFT Join CES.EXAM CEX  
	ON CEX.ASSET_GUID = tExam.ASSET_GUID 
	AND CEX.EXAM_TYPE_SR_KEY = tExam.EXAM_TYPE_SR_KEY 
	AND CEX.IS_LAST_EXAM = 'Y'
	

	
		
	------------------------------------
	BEGIN TRAN
	
		UPDATE CES.EXAM  
		SET 
			IS_LAST_EXAM = 'N', 
			UPDATED_USER =@User, 
			UPDATED_DATE = @CurrentDate 
		FROM CES.EXAM EX
		INNER JOIN #tmpAsOldExam_ADF tempOld 
		ON tempOld.ASSET_GUID = EX.ASSET_GUID
		AND tempOld.EXAM_TYPE_SR_KEY = EX.EXAM_TYPE_SR_KEY
		AND tempOld.OLD_EXAM_ACTUAL_DATE = ISNULL(EX.EXAM_ACTUAL_DATE,CONVERT(DATE,'1/1/1900',103))
		WHERE tempOld.ISOldLatest = 'N'

		UPDATE CES.EXAM 
		SET 
			IS_LAST_EXAM = 'Y', 
			UPDATED_USER =@User, 
			UPDATED_DATE = @CurrentDate 
		FROM CES.EXAM EX
		INNER JOIN #tmpAsOldExam_ADF tempOld 
		ON tempOld.ASSET_GUID = EX.ASSET_GUID
		AND tempOld.EXAM_TYPE_SR_KEY = EX.EXAM_TYPE_SR_KEY
		AND tempOld.NEW_EXAM_ACTUAL_DATE = ISNULL(EX.EXAM_ACTUAL_DATE,CONVERT(DATE,'1/1/1900',103))
		WHERE tempOld.ISnewLatest = 'Y'
		
		COMMIT TRAN
		SET @Output = 1
	END TRY
	BEGIN CATCH
		IF (@@TRANCOUNT >0)
			ROLLBACK TRAN
		
		IF @ErrorMsg IS NULL
			SET @ErrorMsg = ERROR_MESSAGE() 
		
		SET @ErrorDescription = @ErrorMsg + 
							' Line Num:' + CONVERT(VARCHAR(5), ERROR_LINE()) + 
							',ErrorNum:' + CONVERT(VARCHAR(5), ERROR_NUMBER()) + 
							',Severity:' + CONVERT(VARCHAR(5), ERROR_SEVERITY()) + 
							',State:' + CONVERT(VARCHAR(10), ERROR_STATE()) + 
							',Procedure:' + CONVERT(VARCHAR(25), OBJECT_NAME(@@procid)) +
							',Procedure:' + CONVERT(VARCHAR(25), ERROR_PROCEDURE())

		SET @Output = 0;
		SELECT @Output AS SaveStatus,@ErrorMsg AS ErrorMsg;

		DROP TABLE IF EXISTS #tmpAsExam_ADF;
		DROP TABLE IF EXISTS #tmpAsOldExam_ADF;
		THROW 50000,@ErrorDescription,1;
	END CATCH

	DROP TABLE IF EXISTS #tmpAsExam_ADF
	DROP TABLE IF EXISTS #tmpAsOldExam_ADF
	SET NOCOUNT OFF
  END