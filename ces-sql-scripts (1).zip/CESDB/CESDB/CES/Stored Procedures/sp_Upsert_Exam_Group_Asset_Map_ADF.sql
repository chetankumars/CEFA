﻿/***************************************************************************************************************************************            
* Name						: sp_Upsert_Exam_Group_Asset_Map_ADF     
* Created By				: Cognizant            
* Date Created				: 12-April-2021           
* Description				: This stored procedure Upsert the Exam_Group_Asset_Map table through ADF.  
* Input Parameters			: JSON   
* Output Parameters			: Returns 1 for succesful save, else 0            
* Return Value				: N/A            
* Assumptions				: None    
* Execution Statement		: EXEC CES.sp_Upsert_Exam_Group_ADF '[
        {
            "ASSET_GUID": 3978559C311045D9E04400306E4AD01A,
			"EXAM_GROUP_SR_KEY":123,
            "DELETED_FLG": "N"
        },
        {
			"ASSET_GUID": 3978559D34D845D9E04400306E4AD01A,
			"EXAM_GROUP_SR_KEY":345,
            "DELETED_FLG": "N"
        }
    ]'	


*								
* Modified Date     Modified By   Revision Number  Modifications            

*******************************************************************************************************************************************/ 

CREATE PROCEDURE [CES].[sp_Upsert_Exam_Group_Asset_Map_ADF]
	@Input_JSON		NVARCHAR(MAX)

AS 

BEGIN
	SET NOCOUNT ON
    BEGIN TRY
		DECLARE
				@ErrorMsg			VARCHAR(250),
				@ErrorDescription   VARCHAR(4000),
				@Output				BIT = 0,
				@CurrentDate		DATETIME  = GETDATE(),
				@User				VARCHAR(16) = 'CARRS'
		
		DROP TABLE IF EXISTS #tmpAsExam_Group_Asset_Map_ADF
		
		CREATE TABLE #tmpAsExam_Group_Asset_Map_ADF
		(
			ASSET_GUID varchar(32),
			EXAM_GROUP_SR_KEY decimal(9),
            ISACTIVE bit
		)
		
		--Parsing the input JSON and gathering the records					
		INSERT INTO #tmpAsExam_Group_Asset_Map_ADF
		(
			ASSET_GUID,
			EXAM_GROUP_SR_KEY,
            ISACTIVE
		)
		SELECT				
			egt.ASSET_GUID,
			egt.EXAM_GROUP_SR_KEY,
            CASE
			 WHEN egt.DELETED_FLG = 'Y' THEN 0
			 WHEN egt.DELETED_FLG = 'N' THEN 1
			END AS ISACTIVE
		FROM	OPENJSON(@Input_JSON)
		WITH 
			(
				ASSET_GUID varchar(32),
				EXAM_GROUP_SR_KEY decimal(9),
				DELETED_FLG char
			) AS egt

		--- Validation Checks -- Start
				
		BEGIN TRAN

		MERGE CES.EXAM_GROUP_ASSET_MAP AS TARGET
		USING #tmpAsExam_Group_Asset_Map_ADF As SOURCE
		ON (TARGET.ASSET_GUID = SOURCE.ASSET_GUID AND TARGET.EXAM_GROUP_SR_KEY = SOURCE.EXAM_GROUP_SR_KEY)
		WHEN MATCHED 
		   THEN UPDATE SET TARGET.ISACTIVE = SOURCE.ISACTIVE, TARGET.UPDATED_USER = @User, TARGET.UPDATED_DATE = @CurrentDate
		WHEN NOT MATCHED BY TARGET AND (SOURCE.ISACTIVE = 1)
		   THEN INSERT (EXAM_GROUP_SR_KEY, ASSET_GUID, CREATED_USER, CREATED_DATE) 
		   VALUES(SOURCE.EXAM_GROUP_SR_KEY, SOURCE.ASSET_GUID, @User, @CurrentDate);		
		COMMIT TRAN
		SET @Output = 1

		 SELECT @Output AS SaveStatus,NULL AS ErrorMsg;
	END TRY

	BEGIN CATCH
		IF (@@TRANCOUNT >0)
			ROLLBACK TRAN
		
		IF @ErrorMsg IS NULL
			SET @ErrorMsg = ERROR_MESSAGE() 
		
		SET @ErrorDescription = @ErrorMsg + 
							' Line Num:' + CONVERT(VARCHAR(5), ERROR_LINE()) + 
							',ErrorNum:' + CONVERT(VARCHAR(5), ERROR_NUMBER()) + 
							',Severity:' + CONVERT(VARCHAR(5), ERROR_SEVERITY()) + 
							',State:' + CONVERT(VARCHAR(10), ERROR_STATE()) + 
							',Procedure:' + CONVERT(VARCHAR(25), OBJECT_NAME(@@procid)) +
							',Procedure:' + CONVERT(VARCHAR(25), ERROR_PROCEDURE())

		SET @Output = 0;
		SELECT @Output AS SaveStatus,@ErrorMsg AS ErrorMsg;

		THROW 50000,@ErrorDescription,1;
	END CATCH

	DROP TABLE IF EXISTS #tmpAsExam_Group_Asset_Map_ADF;
	SET NOCOUNT OFF
  END