﻿/***************************************************************************************************************************************            
* Name						: sp_AlterSeq_ADF_SEQ_DEFECT_ID            
* Created By				: Cognizant            
* Date Created				: 27-Dec-2020           
* Description				: This stored procedure is used by Defect processing ADF migration pipeline to reseed the DEFECT ID sequence (after migration).  
* Input Parameters			: N/A      
* Output Parameters			: N/A            
* Return Value				: N/A            
* Assumptions				: None    
* Execution Statement		: Exec [CES].[sp_AlterSeq_ADF_SEQ_DEFECT_ID] 
*								
* Modified Date     Modified By   Revision Number  Modifications            

*******************************************************************************************************************************************/ 

CREATE PROCEDURE [CES].[sp_AlterSeq_ADF_SEQ_DEFECT_ID] 
     
AS      
 
BEGIN  
	SET NOCOUNT ON;         
	DECLARE  
		@Max_Defect_ID NVARCHAR(100),
		@Update_Sequence NVARCHAR(100);
			
	SELECT @Max_Defect_ID=MAX(DEFECT_ID) 
	FROM CES.DEFECT;

	IF @Max_Defect_ID IS NOT NULL
	BEGIN
	
		SET @Update_Sequence = 'ALTER SEQUENCE CES.SEQ_DEFECT_ID RESTART WITH' + ' ' + @Max_Defect_ID;
		
		EXECUTE sp_executesql @Update_Sequence
	END
	SET NOCOUNT OFF;    
END
