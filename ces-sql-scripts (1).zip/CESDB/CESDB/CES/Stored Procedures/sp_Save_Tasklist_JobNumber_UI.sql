﻿/***************************************************************************************************************************************            
* Name						: sp_Save_Tasklist_JobNumber_UI            
* Created By				: Cognizant            
* Date Created				: 14-Jul-2021           
* Description				: This stored procedure is used to save the job number for specific asset and exam type in tasklist.  
* Input Parameters			: Asset GUID, Exam Type      
* Output Parameters			: N/A            
* Return Value				: N/A            
* Assumptions				: None    
* Execution Statement		: EXEC [CES].[sp_Save_Tasklist_JobNumber_UI]  '{
																			"examkey": 2,
																			"jobnumber": "B-2122-372;63ANG5788",
																			"current_user_key":  "9725949A-1EB7-497E-B397-A511422AFAFE"
																		   }'

*								
* Modified Date     Modified By   Revision Number  Modifications            

*******************************************************************************************************************************************/ 



CREATE PROCEDURE [CES].[sp_Save_Tasklist_JobNumber_UI] 
	@Input_JSON		NVARCHAR(MAX)    
AS 

BEGIN
	SET NOCOUNT ON

  BEGIN TRY
		DECLARE
				@ErrorMsg			VARCHAR(250),
				@result				NVARCHAR(MAX),
				@Exam_sr_key		DECIMAL(18,0),
				@Jobnumber			VARCHAR(8000),
				@current_user_key	VARCHAR(64),				
				@current_date		DATETIME = GETDATE()

		SELECT 			
			@Exam_sr_key = COALESCE(@Exam_sr_key,CASE LOWER([key]) WHEN 'examkey' THEN [value] ELSE NULL END),
			@current_user_key = COALESCE(@current_user_key,CASE LOWER([key]) WHEN 'current_user_key' THEN [value] ELSE NULL END),
			@Jobnumber = COALESCE(@Jobnumber,CASE LOWER([key]) WHEN 'jobnumber' THEN [value] ELSE NULL END)
		FROM OPENJSON(@Input_JSON);

		--Temp table creation start
		DROP TABLE IF EXISTS #tmpTaskListJobnumber_UI;

		CREATE TABLE #tmpTaskListJobnumber_UI
		(
			Exam_key				DECIMAL(18),
			JobNumber				VARCHAR(8000),
			Current_User_key        VARCHAR(64)
		)
		--Temp table creation End

		--- Validation Checks -- Start
		IF (@Exam_sr_key IS NULL)
		BEGIN
			SET @ErrorMsg = 'Exam key is blank in input.';
			DROP TABLE IF EXISTS #tmpTaskListJobnumber_UI;
			THROW 50000,@ErrorMsg,1;
		END

		IF (@current_user_key IS NULL OR @current_user_key='')
		BEGIN
			SET @ErrorMsg = 'Logged in user key is blank in input.';
			DROP TABLE IF EXISTS #tmpTaskListJobnumber_UI;
			THROW 50000,@ErrorMsg,1;
		END

		--Parsing the input JSON and gathering the records					
		INSERT INTO #tmpTaskListJobnumber_UI
		(
			Exam_key,
			JobNumber,
			Current_User_key
		)
		SELECT				
			ast.examkey,
			ast.jobnumber,
			ast.current_user_key
		FROM	OPENJSON(@Input_JSON)
		WITH 
			(
				examkey	  DECIMAL(18),
				jobnumber VARCHAR(8000),
				current_user_key   VARCHAR(64)
			) AS ast

		IF EXISTS (
					SELECT 1 
					FROM #tmpTaskListJobnumber_UI t
					INNER JOIN  CES.EXAM ex
					ON t.Exam_key = ex.EXAM_SR_KEY
					WHERE ex.EXAM_COMPLETED_IND = 'Y'
					AND ex.ISACTIVE = 1 
				  )
		BEGIN
				SET @ErrorMsg = 'The Exam is in completed status';
				DROP TABLE IF EXISTS #tmpTaskListJobnumber_UI;
				THROW 50000,@ErrorMsg,1;
		END

		--- Validation Checks -- End

		--BEGIN TRAN JobNumberDts
		BEGIN TRAN
		UPDATE w
			SET 
				w.JOB_NUMBER = t.jobnumber,
				w.UPDATED_USER = t.Current_User_key,
				w.UPDATED_DATE = @current_date
			FROM #tmpTaskListJobnumber_UI t
			INNER JOIN CES.EXAM ex
			ON ex.EXAM_SR_KEY = t.Exam_key
			INNER JOIN CES.WORK w 
			ON w.WORK_SR_KEY = ex.WORK_SR_KEY

			SET @result= (
							SELECT 1 AS save_status,NULL AS error_msg
							FOR JSON PATH,WITHOUT_ARRAY_WRAPPER, INCLUDE_NULL_VALUES
						)
		--	END
		--COMMIT TRAN JobNumberDts
		COMMIT TRAN
		 SELECT @result
	END TRY

	BEGIN CATCH
	--IF (@@TRANCOUNT >0)
	--	ROLLBACK TRAN JobNumberDts

	IF (@@TRANCOUNT >0)
		ROLLBACK TRAN 

	IF @ErrorMsg IS NULL
		SET @ErrorMsg = ERROR_MESSAGE() 

		SET @ErrorMsg = ERROR_MESSAGE() + 
						' Line Num:' + CONVERT(VARCHAR(5), ERROR_LINE()) + 
						',ErrorNum:' + CONVERT(VARCHAR(5), ERROR_NUMBER()) + 
						',Severity:' + CONVERT(VARCHAR(5), ERROR_SEVERITY()) + 
						',State:' + CONVERT(VARCHAR(10), ERROR_STATE()) + 
						',Procedure:' + CONVERT(VARCHAR(25), OBJECT_NAME(@@procid)) +
						',Procedure:' + CONVERT(VARCHAR(25), ERROR_PROCEDURE());  

		SET @result= (
						SELECT 0 AS save_status,@ErrorMsg AS error_msg, NULL AS user_id
						FOR JSON PATH,WITHOUT_ARRAY_WRAPPER, INCLUDE_NULL_VALUES
					)
		SELECT @result;

		DROP TABLE IF EXISTS #tmpTaskListJobnumber_UI;

		THROW 50000,@ErrorMsg,1;
	END CATCH
	SET NOCOUNT OFF
END
