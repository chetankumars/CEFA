﻿/***************************************************************************************************************************************            
* Name						: sp_Get_Admin_Users_for_Selected_RRA            
* Created By				: Cognizant            
* Date Created				: 10-Mar-2021           
* Description				: This stored procedure used to get list of users for selected Region, Route, and Area.
* Input Parameters			: JSON      
* Output Parameters			: @OUT_ErrorNo            
* Return Value				: N/A            
* Assumptions				: None    
* Execution Statement		: Exec [CES].sp_Get_Admin_Users_for_Selected_RRA '{		
																				"region_name": "Wales and Western",
																				"route_id": 13,
																				"area_id": 17
															                   }'
*								
* Modified Date     Modified By   Revision Number  Modifications            

*******************************************************************************************************************************************/ 



CREATE PROCEDURE [CES].[sp_Get_Admin_Users_for_Selected_RRA]
	@Input_JSON		NVARCHAR(MAX)
AS 
BEGIN
	SET NOCOUNT ON
	
	
	BEGIN TRY
		DECLARE
				@ErrorMsg				VARCHAR(250),
				@result					NVARCHAR(MAX),
				@region_name			VARCHAR(64),
				@route_id				DECIMAL(18),
				@area_id				DECIMAL(18),
				@user_id                VARCHAR(64),
				@totalresultcnt         INT,
				@user_ids				NVARCHAR(MAX)
				
				
 
		CREATE TABLE #tbl_AdminUsersforSelectedRRA_CES
		(
			user_id                VARCHAR(64)				
		)

		  SELECT 
			@region_name = COALESCE(@region_name,CASE LOWER([key]) WHEN 'region_name' THEN [value] ELSE NULL END),
			@route_id = COALESCE(@route_id,CASE LOWER([key]) WHEN 'route_id' THEN [value] ELSE NULL END),
			@area_id = COALESCE(@area_id,CASE LOWER([key]) WHEN 'area_id' THEN [value] ELSE NULL END)
	
		 FROM	OPENJSON(@Input_JSON);


		-- Validateion start

		IF (@region_name IS NULL OR @route_id IS NULL OR @area_id IS NULL)
		BEGIN

			SET @ErrorMsg = 'Mandatory Input value is missing';
			DROP TABLE IF EXISTS #tbl_AdminUsersforSelectedRRA_CES;
			THROW 50000,@ErrorMsg,1;
		END

		-- Validateion END

		INSERT INTO #tbl_AdminUsersforSelectedRRA_CES
		   (
				user_id
			)

			SELECT 
				ent.USER_SR_KEY AS user_id
			FROM CES.ENTITLEMENT AS ent 
			INNER JOIN [CES].ORG AS o
			ON o.ORG_SR_KEY = ent.ORG_SR_KEY AND o.ISACTIVE = 1 
			INNER JOIN [CES].AREA AS a
			ON a.AREA_SR_KEY = ent.AREA_SR_KEY AND a.ORG_SR_KEY = ent.ORG_SR_KEY AND a.ISACTIVE = 1

			WHERE O.REGION = @region_name
			AND ( @route_id =0 OR (@route_id <> 0 AND ent.ORG_SR_KEY = @route_id))
			AND	( @area_id =0 OR (@area_id <> 0 AND ent.AREA_SR_KEY = @area_id))			
			AND ent.ISACTIVE = 1 
			


--select * from #tbl_AdminUsersforSelectedRRA_CES
		SELECT  @totalresultcnt = count (1) FROM #tbl_AdminUsersforSelectedRRA_CES

		--SELECT @totalresultcnt

		--If no records are returned in search result
		IF  @totalresultcnt=0 
		BEGIN
			SET @result=
					(
						SELECT @totalresultcnt searchdatacount,							
							JSON_QUERY('[]') user_ids
						
						FOR JSON PATH,WITHOUT_ARRAY_WRAPPER, INCLUDE_NULL_VALUES
				)
		END	

		--If alt least 1 record is returned in search result
		ELSE
		BEGIN
       --select getdate()

	   set @user_ids =  (SELECT CONCAT('[',  (SELECT distinct STRING_AGG(STRING_ESCAPE(user_id, 'json'), ',') FROM #tbl_AdminUsersforSelectedRRA_CES) , ']'))
	   PRINT @user_ids

				SET @result=
				(
					SELECT @totalresultcnt AS searchdatacount,Json_Query(@user_ids ) AS user_ids
							FOR JSON PATH, INCLUDE_NULL_VALUES, WITHOUT_ARRAY_WRAPPER
					    )
	
		END	

	--PRINT @result
		SELECT @result
		
	END TRY
	BEGIN CATCH
		SET @ErrorMsg = ERROR_MESSAGE() + 
						' Line Num:' + CONVERT(VARCHAR(5), ERROR_LINE()) + 
						',ErrorNum:' + CONVERT(VARCHAR(5), ERROR_NUMBER()) + 
						',Severity:' + CONVERT(VARCHAR(5), ERROR_SEVERITY()) + 
						',State:' + CONVERT(VARCHAR(10), ERROR_STATE()) + 
						',Procedure:' + CONVERT(VARCHAR(25), ERROR_PROCEDURE());  
		
		
		THROW 50000,@ErrorMsg,1;

		
	END CATCH

	DROP TABLE IF EXISTS #tbl_AdminUsersforSelectedRRA_CES;
	SET NOCOUNT OFF
END