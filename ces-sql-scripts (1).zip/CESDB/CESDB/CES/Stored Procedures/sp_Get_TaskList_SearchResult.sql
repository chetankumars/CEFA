﻿/***************************************************************************************************************************************            
* Name						: sp_Get_TaskList_SearchResult            
* Created By				: Cognizant            
* Date Created				: 25-Jan-2020           
* Description				: This stored procedure provides the search result for task list basic and advanced search.  
* Input Parameters			: JSON      
* Output Parameters			: JSON            
* Return Value				: N/A            
* Assumptions				: None    
* Execution Statement		: Exec [CES].sp_Get_TaskList_SearchResult '{
																			"region_name": "Southern",
																			"route_id": 0,
																			"area_id": 0,
																			"supplier_id": 0,
																			"exam_type_id": 0,
																			"exam_status_id": 0,
																			"elr_id":[0],	
																			"start_mileage_from": -1,
																			"start_mileage_to": 99999,
																			"railway_id": null,
																			"ast_grp_id": 0,
																			"ast_typ_id": [0],
																			"exam_id": 0,
																			"task_list_stat_id": 0,
																			"compliance_date_from": "1/1/1900",
																			"compliance_date_to": "31/12/9999",
																			"tasklist_yr_id": 134,
																			"due_date_from": "1/1/1900",
																			"due_date_to": "31/12/9999",
																			"isexporttodoc": "N",
																			"sortcolumn": "StartMileage",
																			"sortorder": "desc",
																			"pageno": 1,
																			"rowsperpage": 100
																		}','N'
*								
* Modified Date     Modified By   Revision Number  Modifications            

*******************************************************************************************************************************************/ 



CREATE PROCEDURE [CES].[sp_Get_TaskList_SearchResult]
	@Input_JSON			NVARCHAR(MAX),
	@IsSupplierSearch	CHAR(1)
--WITH RECOMPILE
AS
BEGIN
	SET NOCOUNT ON
	BEGIN TRY
		DECLARE
				@ErrorMsg				VARCHAR(250),
				@result					NVARCHAR(MAX),
				@region_name			VARCHAR(64),
				@route_id				DECIMAL(18),
				@area_id				DECIMAL(18),
				@elr_id					NVARCHAR(MAX),
				@supplier_id			DECIMAL(18),
				@exam_type_id			DECIMAL(18),
				@exam_status_id			DECIMAL(18),
				@start_mileage_from		DECIMAL(18,4),
				@start_mileage_to		DECIMAL(18,4),
				@railway_id				VARCHAR(64),
				@ast_grp_id				DECIMAL(18),
				@exam_id				DECIMAL(18),
				@task_list_stat_id		DECIMAL(18),
				@compliance_date_from	DATE,
				@compliance_date_to		DATE,
				@tasklist_yr_id			DECIMAL(18),
				@due_date_from			DATE,
				@due_date_to			DATE,
				@isexporttodoc			VARCHAR(1),
				@sortcolumn				VARCHAR(30),
				@sortorder				VARCHAR(5),
				@pageno					DECIMAL(18),
				@rowsperpage			DECIMAL(18),
				@ast_typ_array			NVARCHAR(MAX),
				@isasttypselected		CHAR(1) = 'N',
				@isbasicsearch			CHAR(1) = 'Y',
				@totalresultcnt			INT,
				@current_date			DATE = GETDATE(),
				@task_list_status		VARCHAR(30),
				@task_list_id			VARCHAR(18),
				@iselrselected			CHAR(1) = 'N',
				@start_dt_default		DATE  = CONVERT(DATE,'1/1/1900',103),
				@end_dt_default			DATE = CONVERT(DATE,'31/12/9999',103)

		DECLARE @ast_typ TABLE
		(
			ast_typ_id DECIMAL(18)
		)

		CREATE TABLE #tbl_SearchResult
		(
				asset_guid					VARCHAR(32),
				region						VARCHAR(64),
				route						VARCHAR(64),
				area						VARCHAR(64),
				elr							VARCHAR(4),
				start_mileage				DECIMAL(18,4),
				end_mileage					DECIMAL(18,4),
				railway_id					VARCHAR(64),
				asset_desc					VARCHAR(200),
				asset_grp					VARCHAR(64),
				asset_type					VARCHAR(64),
				hce_flg						VARCHAR(4),
				exam_id						DECIMAL(18),
				exam_frequency				VARCHAR(20),
				exam_req_stat				VARCHAR(18),
				exam_rpt_stat				VARCHAR(18),
				exam_type					VARCHAR(32),
				compliance_dt				DATE,
				supplier					VARCHAR(64),
				due_dt						DATE,
				onsite_pre_compl_tol_dt		DATE,
				onsite_post_compl_tol_dt	DATE,
				baseline_plan_dt			DATE,
				plan_dt						DATE,
				exam_dt						DATE,
				submission_dt				DATE,
				signed_off_dt				DATE,
				cr_id						VARCHAR(20),
				specific_exam_req			VARCHAR(1000),
				tenanted_arch				VARCHAR(5),
				task_list_stat				VARCHAR(18),
				nr_internal_note			VARCHAR(4000),
				comments_to_sec				VARCHAR(4000),
				other_supplier_comment		VARCHAR(4000),
				posession_critical			VARCHAR(32),
				job_number					VARCHAR(8000),
				task_list_id				DECIMAL(18),
				exam_sr_key					DECIMAL(18),
				due_dt_earliest				DATE,
				due_dt_latest				DATE,
				max_tolerance_dt			DATE,
				exam_grp_key				DECIMAL(18)
		)

		DECLARE @elr_id_array TABLE
		(
			elr_id DECIMAL(18)
		)


		SELECT 
			@region_name = COALESCE(@region_name,CASE LOWER([key]) WHEN 'region_name' THEN [value] ELSE NULL END),
			@route_id = COALESCE(@route_id,CASE LOWER([key]) WHEN 'route_id' THEN [value] ELSE NULL END),
			@area_id = COALESCE(@area_id,CASE LOWER([key]) WHEN 'area_id' THEN [value] ELSE NULL END),
			@supplier_id = COALESCE(@supplier_id,CASE LOWER([key]) WHEN 'supplier_id' THEN [value] ELSE NULL END),
			@exam_type_id = COALESCE(@exam_type_id,CASE LOWER([key]) WHEN 'exam_type_id' THEN [value] ELSE NULL END),
			@exam_status_id = COALESCE(@exam_status_id,CASE LOWER([key]) WHEN 'exam_status_id' THEN [value] ELSE NULL END),
			@elr_id = COALESCE(@elr_id,CASE LOWER([key]) WHEN 'elr_id' THEN [value] ELSE NULL END),
			@start_mileage_from = COALESCE(@start_mileage_from,CASE LOWER([key]) WHEN 'start_mileage_from' THEN [value] ELSE NULL END),
			@start_mileage_to = COALESCE(@start_mileage_to,CASE LOWER([key]) WHEN 'start_mileage_to' THEN [value] ELSE NULL END),
			@railway_id = COALESCE(@railway_id,CASE LOWER([key]) WHEN 'railway_id' THEN [value] ELSE NULL END),
			@ast_grp_id = COALESCE(@ast_grp_id,CASE LOWER([key]) WHEN 'ast_grp_id' THEN [value] ELSE NULL END),
			@ast_typ_array = COALESCE(@ast_typ_array,CASE LOWER([key]) WHEN 'ast_typ_id' THEN [value] ELSE NULL END),
			@exam_id = COALESCE(@exam_id,CASE LOWER([key]) WHEN 'exam_id' THEN [value] ELSE NULL END),
			@task_list_stat_id = COALESCE(@task_list_stat_id,CASE LOWER([key]) WHEN 'task_list_stat_id' THEN [value] ELSE NULL END),
			@compliance_date_from = COALESCE(@compliance_date_from,CASE LOWER([key]) WHEN 'compliance_date_from' THEN CONVERT(DATE,[value],103) ELSE NULL END),
			@compliance_date_to = COALESCE(@compliance_date_to,CASE LOWER([key]) WHEN 'compliance_date_to' THEN CONVERT(DATE,[value],103) ELSE NULL END),
			@tasklist_yr_id = COALESCE(@tasklist_yr_id,CASE LOWER([key]) WHEN 'tasklist_yr_id' THEN [value] ELSE NULL END),
			@due_date_from = COALESCE(@due_date_from,CASE LOWER([key]) WHEN 'due_date_from' THEN CONVERT(DATE,[value],103) ELSE NULL END),
			@due_date_to = COALESCE(@due_date_to,CASE LOWER([key]) WHEN 'due_date_to' THEN CONVERT(DATE,[value],103) ELSE NULL END),
			@isexporttodoc = COALESCE(@isexporttodoc,CASE LOWER([key]) WHEN 'isexporttodoc' THEN [value] ELSE NULL END),
			@sortcolumn = COALESCE(@sortcolumn,CASE LOWER([key]) WHEN 'sortcolumn' THEN [value] ELSE NULL END),
			@sortorder = COALESCE(@sortorder,CASE LOWER([key]) WHEN 'sortorder' THEN [value] ELSE NULL END),
			@pageno = COALESCE(@pageno,CASE LOWER([key]) WHEN 'pageno' THEN [value] ELSE NULL END),
			@rowsperpage = COALESCE(@rowsperpage,CASE LOWER([key]) WHEN 'rowsperpage' THEN [value] ELSE NULL END)

		FROM	OPENJSON(@Input_JSON);



		IF (@region_name IS NULL)
		BEGIN

			SET @ErrorMsg = 'Region cannot be NULL';
			DROP TABLE IF EXISTS #tbl_SearchResult;
			THROW 50000,@ErrorMsg,1;
		END

		IF (@IsSupplierSearch = 'N')
		BEGIN
			IF (@supplier_id IS NULL OR @region_name IS NULL)
			BEGIN
				SET @ErrorMsg = 'Region and/or Supplier cannot be NULL';
				DROP TABLE IF EXISTS #tbl_SearchResult;
				THROW 50000,@ErrorMsg,1;
			END
		END

		IF @ast_typ_array IS NOT NULL 
		BEGIN
			INSERT INTO @ast_typ (ast_typ_id)
			SELECT[value] FROM OPENJSON(@ast_typ_array);

			IF EXISTS (SELECT 1 FROM @ast_typ WHERE ast_typ_id=0)
				SET @isasttypselected = 'N'
			ELSE
				SET @isasttypselected = 'Y'
		END 

		IF @elr_id IS NOT NULL 
		BEGIN
			INSERT INTO @elr_id_array (elr_id)
			SELECT[value] FROM OPENJSON(@elr_id);

			IF EXISTS (SELECT 1 FROM @elr_id_array WHERE elr_id=0)
				SET @iselrselected = 'N'
			ELSE
				SET @iselrselected = 'Y'
		END 

		--NR role search
		IF (@IsSupplierSearch = 'N')
		BEGIN
			IF (@iselrselected = 'N' AND @start_mileage_from = -1 AND @start_mileage_to = 99999 AND @railway_id IS NULL AND @ast_grp_id = 0 AND @isasttypselected = 'N' AND @exam_id = 0 AND @exam_type_id = 0
				AND @exam_status_id =0 AND @task_list_stat_id = 0 AND @compliance_date_from = @start_dt_default AND @compliance_date_to = @end_dt_default 
				AND @due_date_from = @start_dt_default AND	@due_date_to = @end_dt_default )
				BEGIN
					SET @isbasicsearch = 'Y'   --Advanced Search
				END
			ELSE
				BEGIN
					SET @isbasicsearch = 'N'	--Basic Search
				END
		END

		--Supplier Search
		ELSE
		BEGIN
			IF (@iselrselected = 'N' AND @start_mileage_from = -1 AND @start_mileage_to = 99999 AND @railway_id IS NULL AND @ast_grp_id = 0 AND @isasttypselected = 'N' AND @exam_id = 0 AND @exam_type_id = 0
				AND @task_list_stat_id = 0 AND @due_date_from = @start_dt_default AND @due_date_to = @end_dt_default )
				BEGIN
					SET @isbasicsearch = 'Y'	--Advanced Search
				END
			ELSE
				BEGIN
					SET @isbasicsearch = 'N'	--Basic Search
				END
		END


		--NR role search
		IF (@IsSupplierSearch = 'N')
		BEGIN
			IF @isbasicsearch = 'N'		-- Advanced Search
			BEGIN

		
					INSERT INTO #tbl_SearchResult
					(
							asset_guid,
							region,
							route,
							area,
							elr,
							start_mileage,
							end_mileage,
							railway_id,
							asset_desc,
							asset_grp,
							asset_type,
							hce_flg,
							exam_id,
							exam_frequency,
							exam_req_stat,
							exam_rpt_stat,
							exam_type,
							compliance_dt,
							supplier,
							due_dt,
							onsite_pre_compl_tol_dt,
							onsite_post_compl_tol_dt,
							baseline_plan_dt,
							plan_dt,
							exam_dt,
							submission_dt,
							signed_off_dt,
							cr_id,
							specific_exam_req,
							tenanted_arch,
							task_list_stat,
							nr_internal_note,
							comments_to_sec,
							other_supplier_comment,
							posession_critical,
							job_number,
							task_list_id,
							exam_sr_key,
							due_dt_earliest,
							due_dt_latest,
							max_tolerance_dt,
							exam_grp_key
					)
					
																
					SELECT 
						final.asset_guid,
						final.region,
						final.route,
						final.area,
						final.elr,
						final.start_mileage,
						final.end_mileage,
						final.railway_id,
						final.asset_desc,
						final.asset_grp,
						final.asset_type,
						final.hce_flg,
						final.exam_id,
						final.exam_frequency,
						final.exam_req_stat,
						final.exam_rpt_stat,
						final.exam_type,
						final.compliance_dt,
						final.supplier,
						final.due_dt,
						CASE WHEN exam_type IN ('Visual','Detailed','Enhanced') 
							THEN CONVERT(DATE, DATEADD( week, (0- ct.SITE_TOLERANCE_WEEKS), DATEADD(month,exam_freq_in_months,ltst_exm.EXAM_ACTUAL_DATE)),103) 
							WHEN exam_type IN ('Underwater', 'Line Of Route' ) OR exam_type LIKE '%Additional%'
							THEN WORK_YR_START_DT 
							ELSE NULL
						END AS onsite_pre_compl_tol_dt,
						CASE WHEN exam_type IN ('Visual','Detailed','Enhanced') 
							THEN CONVERT(DATE, DATEADD( week, ct.SITE_TOLERANCE_WEEKS, DATEADD(month,exam_freq_in_months,ltst_exm.EXAM_ACTUAL_DATE)),103)
							WHEN exam_type IN ('Underwater', 'Line Of Route' ) OR exam_type LIKE '%Additional%'
							THEN WORK_YR_END_DT 
							ELSE NULL
						END AS onsite_post_compl_tol_dt,
						final.baseline_plan_dt,
						final.plan_dt,
						final.exam_dt,
						final.submission_dt,
						final.signed_off_dt,
						final.cr_id,
						final.specific_exam_req,
						final.tenanted_arch,
						final.task_list_stat,
						final.nr_internal_note,
						final.comment_to_sec,
						final.other_supplier_comment,
						acs.POSSESSION AS posession_critical,
						final.job_number,
						final.task_list_id,
						final.exam_sr_key,
						CASE WHEN exam_type IN ('Visual','Detailed','Enhanced') 
							THEN CONVERT(DATE, DATEADD( week, (0- ct.SITE_TOLERANCE_WEEKS), final.due_dt),103) 
							WHEN exam_type IN ('Underwater', 'Line Of Route' ) OR exam_type LIKE '%Additional%'
							THEN WORK_YR_START_DT 
							ELSE NULL
						END AS due_dt_earliest,
						CASE WHEN exam_type IN ('Visual','Detailed','Enhanced') 
							THEN CONVERT(DATE, DATEADD( week, ct.SITE_TOLERANCE_WEEKS, final.due_dt),103) 
							WHEN exam_type IN ('Underwater', 'Line Of Route' ) OR exam_type LIKE '%Additional%'
							THEN WORK_YR_END_DT 
							ELSE NULL
						END AS due_dt_latest,
						--CONVERT(DATE, DATEADD( week, ISNULL(ct.REVIEW_TOLERANCE_WEEKS,0), final.due_dt),103) AS max_tolerance_dt,
						CONVERT(DATE, DATEADD( week, ISNULL(ct.REVIEW_TOLERANCE_WEEKS,0),
									CASE WHEN exam_type IN ('Visual','Detailed','Enhanced') 
										THEN CONVERT(DATE, DATEADD( week, ct.SITE_TOLERANCE_WEEKS, final.due_dt),103) 
										WHEN exam_type IN ('Underwater', 'Line Of Route' ) OR exam_type LIKE '%Additional%'
										THEN WORK_YR_END_DT 
										ELSE NULL
									END
								),103) AS max_tolerance_dt,
						final.EXAM_GROUP_SR_KEY
					FROM
					(
							SELECT 
								ast.ASSET_GUID AS asset_guid,
								o.REGION AS region,
								o.ROUTE AS route,
								a.AREA_NAME AS area,
								elr.ELR_CODE AS elr,
								(ast.START_MILES + ast.START_YARDS/1760) AS start_mileage,
								(ast.END_MILES + ast.END_YARDS/1760) AS end_mileage,
								ast.RAILWAY_ID AS railway_id,
								ast.ASSET_NAME AS asset_desc,
								asg.ASSET_GROUP_DESC AS asset_grp,
								asp.ASSET_TYPE_DESC AS asset_type,
								CASE WHEN ast.hce_flag = 'Y' THEN 'Yes' ELSE 'No' END AS hce_flg,
								ex.exam_id,
								cmp.exam_frequency,
								ex.EXAM_REQ_STATUS AS exam_req_stat,
								ex.EXAM_REPORT_STATUS AS exam_rpt_stat,
								et.EXAM_TYPE AS exam_type,
								cmp.COMP_DATE AS compliance_dt,
								s.SUPPLIER_NAME AS supplier,
								wrk.EXAM_DUE_DATE AS due_dt,
								--NULL AS onsite_pre_compl_tol_dt,
								--NULL AS onsite_post_compl_tol_dt,
								ex.EXAM_BASELINE_DATE AS baseline_plan_dt,
								ex.EXAM_PLANNED_DATE AS plan_dt,
								ex.EXAM_ACTUAL_DATE AS exam_dt,
								ex.EXAM_SUBMISSION_DATE AS submission_dt,
								ex.EXAM_SIGNOFF_DATE AS signed_off_dt,
								ex.CHANGE_REQ_ID AS cr_id,
								ex.EXAM_REQUIREMENT AS specific_exam_req,
								CASE WHEN ast.TENANTED_FLG = 'Y' THEN 'Yes'
									 WHEN ast.TENANTED_FLG = 'N' THEN 'No'
									 ELSE 'N/A'
								END AS tenanted_arch,
								wrk.WORK_STATUS AS task_list_stat,
								ex.INTERNAL_NOTES AS nr_internal_note,
								ex.comment_to_sec,
								ex.SUPPLIER_COMMENTS AS other_supplier_comment,
								--NULL AS posession_critical,
								wrk.job_number,
								wrk.WORK_SR_KEY AS task_list_id,
								ex.EXAM_SR_KEY,
								ex.EXAM_TYPE_SR_KEY,
								ISNULL(cmp.exam_freq_in_months,0) AS exam_freq_in_months,
								wrk.WORK_YR_START_DT,
								wrk.WORK_YR_END_DT,
								ex.EXAM_GROUP_SR_KEY
								
							FROM [CES].ASSET ast
							INNER JOIN [CES].ORG o
							ON ast.ORG_SR_KEY = o.ORG_SR_KEY
							INNER JOIN [CES].AREA a
							ON a.AREA_SR_KEY = ast.AREA_SR_KEY
							INNER JOIN [CES].ENGINE_LINE_REF elr
							ON elr.ELR_SR_KEY = ast.ENG_LINE_REF
							AND elr.ORG_SR_KEY = ast.ORG_SR_KEY
							AND elr.AREA_SR_KEY = ast.AREA_SR_KEY
							INNER JOIN [CES].ASSET_GROUP asg
							ON asg.ASSET_GROUP_SR_KEY = ast.ASSET_GROUP_SR_KEY
							INNER JOIN [CES].ASSET_TYPE asp
							ON asp.ASSET_TYPE_SR_KEY = ast.ASSET_TYPE_SR_KEY
							INNER JOIN [CES].EXAM ex
							ON ex.ASSET_GUID = ast.ASSET_GUID
							INNER JOIN [CES].WORK wrk
							ON wrk.WORK_SR_KEY = ex.WORK_SR_KEY
							AND wrk.ISACTIVE = 1
							INNER JOIN [CES].EXAM_TYPE et
							ON et.EXAM_TYPE_SR_KEY = ex.EXAM_TYPE_SR_KEY
							INNER JOIN [CES].SUPPLIER s
							ON s.SUPPLIER_SR_KEY = ex.SUPPLIER_SR_KEY
							OUTER APPLY
								(
									SELECT
										COMP_DATE,
										( (ISNULL(INTERVAL_YEARS,0)*12) + (ISNULL(INTERVAL_MONTHS,0)) + (ISNULL(INTERVAL_DAYS,0)/30) ) AS exam_freq_in_months,
										(CAST(ISNULL(INTERVAL_YEARS,0) AS VARCHAR) + 'y '+CAST(ISNULL(INTERVAL_MONTHS,0) AS VARCHAR)+ 'm '+CAST(ISNULL(INTERVAL_DAYS,0) AS VARCHAR)+ 'd') AS exam_frequency
										
									FROM 
									(
										SELECT 
											COMP_DATE,
											INTERVAL_YEARS,
											INTERVAL_MONTHS,
											INTERVAL_DAYS,
											ROW_NUMBER() OVER (ORDER BY EFFECTIVE_FROM_DT DESC) rnk
										FROM CES.COMPLIANCE c
										WHERE ASSET_GUID = ex.ASSET_GUID
										AND EXAM_TYPE_SR_KEY = ex.EXAM_TYPE_SR_KEY
										AND @current_date BETWEEN EFFECTIVE_FROM_DT AND ISNULL(EFFECTIVE_TO_DT,@end_dt_default)
										AND c.ISACTIVE = 1
									)c
									WHERE rnk = 1
								) cmp
														
							WHERE
								ast.ISACTIVE= 1
							AND o.ISACTIVE = 1
							AND a.ISACTIVE = 1
							AND elr.ISACTIVE = 1
							AND asg.ISACTIVE = 1
							AND asp.ISACTIVE = 1
							AND ex.ISACTIVE = 1
							AND et.ISACTIVE = 1
							AND s.ISACTIVE = 1
							AND o.REGION = @region_name
							AND ( @route_id =0 OR (@route_id <> 0 AND o.ORG_SR_KEY = @route_id))
							AND	( @area_id =0 OR (@area_id <> 0 AND a.AREA_SR_KEY = @area_id))
							AND ( @supplier_id = 0 OR (@supplier_id <> 0 AND ex.SUPPLIER_SR_KEY = @supplier_id) )
							AND ( @iselrselected = 'N' OR (@iselrselected = 'Y' AND ast.ENG_LINE_REF IN (SELECT elr_id FROM @elr_id_array)) )
							AND ( (ast.START_MILES + ast.START_YARDS/1760) BETWEEN @start_mileage_from AND @start_mileage_to)
							--AND ( @railway_id IS NULL OR (@railway_id IS NOT NULL AND ast.RAILWAY_ID = @railway_id))
							AND ( @railway_id IS NULL OR (@railway_id IS NOT NULL AND ast.RAILWAY_ID LIKE ('%' + @railway_id + '%')))
							AND ( @ast_grp_id =0 OR (@ast_grp_id <> 0 AND asg.ASSET_GROUP_SR_KEY = @ast_grp_id))
							AND ( @isasttypselected = 'N' OR (@isasttypselected = 'Y' AND asp.ASSET_TYPE_SR_KEY IN (SELECT ast_typ_id FROM @ast_typ)) )
							AND ( @exam_id = 0 OR (@exam_id <>0 AND ex.EXAM_ID = @exam_id) )
							AND	( @exam_type_id = 0 OR (@exam_type_id <>0 AND et.EXAM_TYPE_SR_KEY = @exam_type_id))
							AND ( @exam_status_id = 0 OR (@exam_status_id<>0 AND ex.EXAM_REQ_STATUS = @exam_status_id) )
							AND ( @task_list_stat_id = 0 OR (@task_list_stat_id<>0 AND wrk.WORK_STATUS = @task_list_stat_id) )
							AND ( @tasklist_yr_id = 0 OR (@tasklist_yr_id<>0 AND wrk.WORK_YEAR_KEY = @tasklist_yr_id) )
							AND ( CONVERT (DATE,wrk.EXAM_DUE_DATE,103) BETWEEN @due_date_from AND @due_date_to)
							AND ( ( @compliance_date_from = @start_dt_default AND @compliance_date_to = @end_dt_default)
								OR ( (@compliance_date_from <> @start_dt_default OR @compliance_date_to <> @end_dt_default)
									AND CONVERT(DATE, cmp.COMP_DATE, 103) BETWEEN @compliance_date_from AND @compliance_date_to ) )
					)final
					LEFT JOIN [CES].EXAM ltst_exm
					ON ltst_exm.ASSET_GUID = final.asset_guid
					AND ltst_exm.EXAM_TYPE_SR_KEY = final.EXAM_TYPE_SR_KEY
					AND ltst_exm.IS_LAST_EXAM = 'Y'		
					AND ltst_exm.ISACTIVE = 1
					LEFT JOIN [CES].COMPLIANCE_TOLERANCE ct
					ON ct.EXAM_TYPE_SR_KEY = final.EXAM_TYPE_SR_KEY
					AND ct.ISACTIVE = 1
					AND final.exam_freq_in_months BETWEEN ct.FREQ_INTERVAL_MONTHS_FROM AND ct.FREQ_INTERVAL_MONTHS_TO
					LEFT JOIN CES.ACCESS acs
					ON acs.ASSET_GUID = final.asset_guid
					AND acs.EXAM_TYPE_SR_KEY = final.EXAM_TYPE_SR_KEY

			END
			--NR role search
			ELSE	--Basic search
			BEGIN
		
					
					INSERT INTO #tbl_SearchResult
					(
							asset_guid,
							region,
							route,
							area,
							elr,
							start_mileage,
							end_mileage,
							railway_id,
							asset_desc,
							asset_grp,
							asset_type,
							hce_flg,
							exam_id,
							exam_frequency,
							exam_req_stat,
							exam_rpt_stat,
							exam_type,
							compliance_dt,
							supplier,
							due_dt,
							onsite_pre_compl_tol_dt,
							onsite_post_compl_tol_dt,
							baseline_plan_dt,
							plan_dt,
							exam_dt,
							submission_dt,
							signed_off_dt,
							cr_id,
							specific_exam_req,
							tenanted_arch,
							task_list_stat,
							nr_internal_note,
							comments_to_sec,
							other_supplier_comment,
							posession_critical,
							job_number,
							task_list_id,
							exam_sr_key,
							due_dt_earliest,
							due_dt_latest,
							max_tolerance_dt,
							exam_grp_key
					)
																
					SELECT 
						final.asset_guid,
						final.region,
						final.route,
						final.area,
						final.elr,
						final.start_mileage,
						final.end_mileage,
						final.railway_id,
						final.asset_desc,
						final.asset_grp,
						final.asset_type,
						final.hce_flg,
						final.exam_id,
						final.exam_frequency,
						final.exam_req_stat,
						final.exam_rpt_stat,
						final.exam_type,
						final.compliance_dt,
						final.supplier,
						final.due_dt,
						CASE WHEN exam_type IN ('Visual','Detailed','Enhanced') 
							THEN CONVERT(DATE, DATEADD( week, (0- ct.SITE_TOLERANCE_WEEKS), DATEADD(month,exam_freq_in_months,ltst_exm.EXAM_ACTUAL_DATE)),103) 
							WHEN exam_type IN ('Underwater', 'Line Of Route' ) OR exam_type LIKE '%Additional%'
							THEN WORK_YR_START_DT 
							ELSE NULL
						END AS onsite_pre_compl_tol_dt,
						CASE WHEN exam_type IN ('Visual','Detailed','Enhanced') 
							THEN CONVERT(DATE, DATEADD( week, ct.SITE_TOLERANCE_WEEKS, DATEADD(month,exam_freq_in_months,ltst_exm.EXAM_ACTUAL_DATE)),103)
							WHEN exam_type IN ('Underwater', 'Line Of Route' ) OR exam_type LIKE '%Additional%'
							THEN WORK_YR_END_DT 
							ELSE NULL
						END AS onsite_post_compl_tol_dt,
						final.baseline_plan_dt,
						final.plan_dt,
						final.exam_dt,
						final.submission_dt,
						final.signed_off_dt,
						final.cr_id,
						final.specific_exam_req,
						final.tenanted_arch,
						final.task_list_stat,
						final.nr_internal_note,
						final.comment_to_sec,
						final.other_supplier_comment,
						acs.POSSESSION AS posession_critical,
						final.job_number,
						final.task_list_id,
						final.exam_sr_key,
						CASE WHEN exam_type IN ('Visual','Detailed','Enhanced') 
							THEN CONVERT(DATE, DATEADD( week, (0- ct.SITE_TOLERANCE_WEEKS), final.due_dt),103) 
							WHEN exam_type IN ('Underwater', 'Line Of Route' ) OR exam_type LIKE '%Additional%'
							THEN WORK_YR_START_DT 
							ELSE NULL
						END AS due_dt_earliest,
						CASE WHEN exam_type IN ('Visual','Detailed','Enhanced') 
							THEN CONVERT(DATE, DATEADD( week, ct.SITE_TOLERANCE_WEEKS, final.due_dt),103) 
							WHEN exam_type IN ('Underwater', 'Line Of Route' ) OR exam_type LIKE '%Additional%'
							THEN WORK_YR_END_DT 
							ELSE NULL
						END AS due_dt_latest,
						--CONVERT(DATE, DATEADD( week, ISNULL(ct.REVIEW_TOLERANCE_WEEKS,0), final.due_dt),103) AS max_tolerance_dt,
						CONVERT(DATE, DATEADD( week, ISNULL(ct.REVIEW_TOLERANCE_WEEKS,0),
									CASE WHEN exam_type IN ('Visual','Detailed','Enhanced') 
										THEN CONVERT(DATE, DATEADD( week, ct.SITE_TOLERANCE_WEEKS, final.due_dt),103) 
										WHEN exam_type IN ('Underwater', 'Line Of Route' ) OR exam_type LIKE '%Additional%'
										THEN WORK_YR_END_DT 
										ELSE NULL
									END
								),103) AS max_tolerance_dt,
						final.EXAM_GROUP_SR_KEY
					FROM
					(
							SELECT 
								ast.ASSET_GUID AS asset_guid,
								o.REGION AS region,
								o.ROUTE AS route,
								a.AREA_NAME AS area,
								elr.ELR_CODE AS elr,
								(ast.START_MILES + ast.START_YARDS/1760) AS start_mileage,
								(ast.END_MILES + ast.END_YARDS/1760) AS end_mileage,
								ast.RAILWAY_ID AS railway_id,
								ast.ASSET_NAME AS asset_desc,
								asg.ASSET_GROUP_DESC AS asset_grp,
								asp.ASSET_TYPE_DESC AS asset_type,
								CASE WHEN ast.hce_flag = 'Y' THEN 'Yes' ELSE 'No' END AS hce_flg,
								ex.exam_id,
								cmp.exam_frequency,
								ex.EXAM_REQ_STATUS AS exam_req_stat,
								ex.EXAM_REPORT_STATUS AS exam_rpt_stat,
								et.EXAM_TYPE AS exam_type,
								cmp.COMP_DATE AS compliance_dt,
								s.SUPPLIER_NAME AS supplier,
								wrk.EXAM_DUE_DATE AS due_dt,
								--NULL AS onsite_pre_compl_tol_dt,
								--NULL AS onsite_post_compl_tol_dt,
								ex.EXAM_BASELINE_DATE AS baseline_plan_dt,
								ex.EXAM_PLANNED_DATE AS plan_dt,
								ex.EXAM_ACTUAL_DATE AS exam_dt,
								ex.EXAM_SUBMISSION_DATE AS submission_dt,
								ex.EXAM_SIGNOFF_DATE AS signed_off_dt,
								ex.CHANGE_REQ_ID AS cr_id,
								ex.EXAM_REQUIREMENT AS specific_exam_req,
								CASE WHEN ast.TENANTED_FLG = 'Y' THEN 'Yes'
									 WHEN ast.TENANTED_FLG = 'N' THEN 'No'
									 ELSE 'N/A'
								END AS tenanted_arch,
								wrk.WORK_STATUS AS task_list_stat,
								ex.INTERNAL_NOTES AS nr_internal_note,
								ex.comment_to_sec,
								ex.SUPPLIER_COMMENTS AS other_supplier_comment,
								--NULL AS posession_critical,
								wrk.job_number,
								wrk.WORK_SR_KEY AS task_list_id,
								ex.EXAM_SR_KEY,
								ex.EXAM_TYPE_SR_KEY,
								ISNULL(cmp.exam_freq_in_months,0) AS exam_freq_in_months,
								wrk.WORK_YR_START_DT,
								wrk.WORK_YR_END_DT,
								ex.EXAM_GROUP_SR_KEY
								
							FROM [CES].ASSET ast
							INNER JOIN [CES].ORG o
							ON ast.ORG_SR_KEY = o.ORG_SR_KEY
							INNER JOIN [CES].AREA a
							ON a.AREA_SR_KEY = ast.AREA_SR_KEY
							INNER JOIN [CES].ENGINE_LINE_REF elr
							ON elr.ELR_SR_KEY = ast.ENG_LINE_REF
							INNER JOIN [CES].ASSET_GROUP asg
							ON asg.ASSET_GROUP_SR_KEY = ast.ASSET_GROUP_SR_KEY
							INNER JOIN [CES].ASSET_TYPE asp
							ON asp.ASSET_TYPE_SR_KEY = ast.ASSET_TYPE_SR_KEY
							INNER JOIN [CES].EXAM ex
							ON ex.ASSET_GUID = ast.ASSET_GUID
							INNER JOIN [CES].WORK wrk
							ON wrk.WORK_SR_KEY = ex.WORK_SR_KEY
							AND wrk.ISACTIVE = 1
							INNER JOIN [CES].EXAM_TYPE et
							ON et.EXAM_TYPE_SR_KEY = ex.EXAM_TYPE_SR_KEY
							INNER JOIN [CES].SUPPLIER s
							ON s.SUPPLIER_SR_KEY = ex.SUPPLIER_SR_KEY
							OUTER APPLY
								(
									SELECT
										COMP_DATE,
										( (ISNULL(INTERVAL_YEARS,0)*12) + (ISNULL(INTERVAL_MONTHS,0)) + (ISNULL(INTERVAL_DAYS,0)/30) ) AS exam_freq_in_months,
										(CAST(ISNULL(INTERVAL_YEARS,0) AS VARCHAR) + 'y '+CAST(ISNULL(INTERVAL_MONTHS,0) AS VARCHAR)+ 'm '+CAST(ISNULL(INTERVAL_DAYS,0) AS VARCHAR)+ 'd') AS exam_frequency
										
									FROM 
									(
										SELECT 
											COMP_DATE,
											INTERVAL_YEARS,
											INTERVAL_MONTHS,
											INTERVAL_DAYS,
											ROW_NUMBER() OVER (ORDER BY EFFECTIVE_FROM_DT DESC) rnk
										FROM CES.COMPLIANCE c
										WHERE ASSET_GUID = ex.ASSET_GUID
										AND EXAM_TYPE_SR_KEY = ex.EXAM_TYPE_SR_KEY
										AND @current_date BETWEEN EFFECTIVE_FROM_DT AND ISNULL(EFFECTIVE_TO_DT,@end_dt_default)
										AND c.ISACTIVE = 1
									)c
									WHERE rnk = 1
								) cmp
							
							
							WHERE
								ast.ISACTIVE= 1
							AND o.ISACTIVE = 1
							AND a.ISACTIVE = 1
							AND elr.ISACTIVE = 1
							AND asg.ISACTIVE = 1
							AND asp.ISACTIVE = 1
							AND ex.ISACTIVE = 1
							AND et.ISACTIVE = 1
							AND s.ISACTIVE = 1
							AND o.REGION = @region_name
							AND ( @route_id =0 OR (@route_id <> 0 AND o.ORG_SR_KEY = @route_id))
							AND	( @area_id =0 OR (@area_id <> 0 AND a.AREA_SR_KEY = @area_id))
							AND ( @supplier_id = 0 OR (@supplier_id <> 0 AND ex.SUPPLIER_SR_KEY = @supplier_id) )
							AND ( @tasklist_yr_id = 0 OR (@tasklist_yr_id<>0 AND wrk.WORK_YEAR_KEY = @tasklist_yr_id) )
							
					)final
					LEFT JOIN [CES].EXAM ltst_exm
					ON ltst_exm.ASSET_GUID = final.asset_guid
					AND ltst_exm.EXAM_TYPE_SR_KEY = final.EXAM_TYPE_SR_KEY
					AND ltst_exm.IS_LAST_EXAM = 'Y'		
					AND ltst_exm.ISACTIVE = 1
					LEFT JOIN [CES].COMPLIANCE_TOLERANCE ct
					ON ct.EXAM_TYPE_SR_KEY = final.EXAM_TYPE_SR_KEY
					AND ct.ISACTIVE = 1
					AND final.exam_freq_in_months BETWEEN ct.FREQ_INTERVAL_MONTHS_FROM AND ct.FREQ_INTERVAL_MONTHS_TO
					LEFT JOIN CES.ACCESS acs
					ON acs.ASSET_GUID = final.asset_guid
					AND acs.EXAM_TYPE_SR_KEY = final.EXAM_TYPE_SR_KEY


			END
		END
		ELSE  ---Search Screen for Supplier Roles
		BEGIN
			---Search Screen for Supplier Roles		
			IF @isbasicsearch = 'N'		-- Advanced Search
			BEGIN

		
					INSERT INTO #tbl_SearchResult
					(
							asset_guid,
							region,
							route,
							area,
							elr,
							start_mileage,
							end_mileage,
							railway_id,
							asset_desc,
							asset_grp,
							asset_type,
							hce_flg,
							exam_id,
							exam_frequency,
							exam_req_stat,
							exam_rpt_stat,
							exam_type,
							compliance_dt,
							supplier,
							due_dt,
							onsite_pre_compl_tol_dt,
							onsite_post_compl_tol_dt,
							baseline_plan_dt,
							plan_dt,
							exam_dt,
							submission_dt,
							signed_off_dt,
							cr_id,
							specific_exam_req,
							tenanted_arch,
							task_list_stat,
							nr_internal_note,
							comments_to_sec,
							other_supplier_comment,
							posession_critical,
							job_number,
							task_list_id,
							exam_sr_key,
							due_dt_earliest,
							due_dt_latest,
							max_tolerance_dt,
							exam_grp_key
					)
					
																
					SELECT 
						final.asset_guid,
						final.region,
						final.route,
						final.area,
						final.elr,
						final.start_mileage,
						final.end_mileage,
						final.railway_id,
						final.asset_desc,
						final.asset_grp,
						final.asset_type,
						final.hce_flg,
						final.exam_id,
						final.exam_frequency,
						final.exam_req_stat,
						final.exam_rpt_stat,
						final.exam_type,
						final.compliance_dt,
						final.supplier,
						final.due_dt,
						NULL AS onsite_pre_compl_tol_dt,
						NULL AS onsite_post_compl_tol_dt,
						final.baseline_plan_dt,
						final.plan_dt,
						final.exam_dt,
						final.submission_dt,
						final.signed_off_dt,
						final.cr_id,
						final.specific_exam_req,
						final.tenanted_arch,
						final.task_list_stat,
						final.nr_internal_note,
						final.comment_to_sec,
						final.other_supplier_comment,
						NULL AS posession_critical,
						final.job_number,
						final.task_list_id,
						final.exam_sr_key,
						CASE WHEN exam_type IN ('Visual','Detailed','Enhanced') 
							THEN CONVERT(DATE, DATEADD( week, (0- ct.SITE_TOLERANCE_WEEKS), final.due_dt),103) 
							WHEN exam_type IN ('Underwater', 'Line Of Route' ) OR exam_type LIKE '%Additional%'
							THEN WORK_YR_START_DT 
							ELSE NULL
						END AS due_dt_earliest,
						CASE WHEN exam_type IN ('Visual','Detailed','Enhanced') 
							THEN CONVERT(DATE, DATEADD( week, ct.SITE_TOLERANCE_WEEKS, final.due_dt),103) 
							WHEN exam_type IN ('Underwater', 'Line Of Route' ) OR exam_type LIKE '%Additional%'
							THEN WORK_YR_END_DT 
							ELSE NULL
						END AS due_dt_latest,
						--CONVERT(DATE, DATEADD( week, ISNULL(ct.REVIEW_TOLERANCE_WEEKS,0), final.due_dt),103) AS max_tolerance_dt,
						CONVERT(DATE, DATEADD( week, ISNULL(ct.REVIEW_TOLERANCE_WEEKS,0),
									CASE WHEN exam_type IN ('Visual','Detailed','Enhanced') 
										THEN CONVERT(DATE, DATEADD( week, ct.SITE_TOLERANCE_WEEKS, final.due_dt),103) 
										WHEN exam_type IN ('Underwater', 'Line Of Route' ) OR exam_type LIKE '%Additional%'
										THEN WORK_YR_END_DT 
										ELSE NULL
									END
								),103) AS max_tolerance_dt,
						final.EXAM_GROUP_SR_KEY
					FROM
					(
							SELECT 
								ast.ASSET_GUID AS asset_guid,
								o.REGION AS region,
								o.ROUTE AS route,
								a.AREA_NAME AS area,
								elr.ELR_CODE AS elr,
								(ast.START_MILES + ast.START_YARDS/1760) AS start_mileage,
								(ast.END_MILES + ast.END_YARDS/1760) AS end_mileage,
								ast.RAILWAY_ID AS railway_id,
								ast.ASSET_NAME AS asset_desc,
								asg.ASSET_GROUP_DESC AS asset_grp,
								asp.ASSET_TYPE_DESC AS asset_type,
								CASE WHEN ast.hce_flag = 'Y' THEN 'Yes' ELSE 'No' END AS hce_flg,
								ex.exam_id,
								cmp.exam_frequency,
								ex.EXAM_REQ_STATUS AS exam_req_stat,
								ex.EXAM_REPORT_STATUS AS exam_rpt_stat,
								et.EXAM_TYPE AS exam_type,
								NULL AS compliance_dt,
								s.SUPPLIER_NAME AS supplier,
								wrk.EXAM_DUE_DATE AS due_dt,
								--NULL AS onsite_pre_compl_tol_dt,
								--NULL AS onsite_post_compl_tol_dt,
								ex.EXAM_BASELINE_DATE AS baseline_plan_dt,
								ex.EXAM_PLANNED_DATE AS plan_dt,
								ex.EXAM_ACTUAL_DATE AS exam_dt,
								ex.EXAM_SUBMISSION_DATE AS submission_dt,
								ex.EXAM_SIGNOFF_DATE AS signed_off_dt,
								ex.CHANGE_REQ_ID AS cr_id,
								ex.EXAM_REQUIREMENT AS specific_exam_req,
								CASE WHEN ast.TENANTED_FLG = 'Y' THEN 'Yes'
									 WHEN ast.TENANTED_FLG = 'N' THEN 'No'
									 ELSE 'N/A'
								END AS tenanted_arch,
								wrk.WORK_STATUS AS task_list_stat,
								ex.INTERNAL_NOTES AS nr_internal_note,
								ex.comment_to_sec,
								ex.SUPPLIER_COMMENTS AS other_supplier_comment,
								--NULL AS posession_critical,
								wrk.job_number,
								wrk.WORK_SR_KEY AS task_list_id,
								ex.EXAM_SR_KEY,
								ex.EXAM_TYPE_SR_KEY,
								ISNULL(cmp.exam_freq_in_months,0) AS exam_freq_in_months,
								wrk.WORK_YR_START_DT,
								wrk.WORK_YR_END_DT,
								ex.EXAM_GROUP_SR_KEY
								
							FROM [CES].ASSET ast
							INNER JOIN [CES].ORG o
							ON ast.ORG_SR_KEY = o.ORG_SR_KEY
							INNER JOIN [CES].AREA a
							ON a.AREA_SR_KEY = ast.AREA_SR_KEY
							INNER JOIN [CES].ENGINE_LINE_REF elr
							ON elr.ELR_SR_KEY = ast.ENG_LINE_REF
							AND elr.ORG_SR_KEY = ast.ORG_SR_KEY
							AND elr.AREA_SR_KEY = ast.AREA_SR_KEY
							INNER JOIN [CES].ASSET_GROUP asg
							ON asg.ASSET_GROUP_SR_KEY = ast.ASSET_GROUP_SR_KEY
							INNER JOIN [CES].ASSET_TYPE asp
							ON asp.ASSET_TYPE_SR_KEY = ast.ASSET_TYPE_SR_KEY
							INNER JOIN [CES].EXAM ex
							ON ex.ASSET_GUID = ast.ASSET_GUID
							INNER JOIN [CES].WORK wrk
							ON wrk.WORK_SR_KEY = ex.WORK_SR_KEY
							AND wrk.ISACTIVE = 1
							INNER JOIN [CES].EXAM_TYPE et
							ON et.EXAM_TYPE_SR_KEY = ex.EXAM_TYPE_SR_KEY
							INNER JOIN [CES].SUPPLIER s
							ON s.SUPPLIER_SR_KEY = ex.SUPPLIER_SR_KEY
							
							OUTER APPLY
								(
									SELECT
										COMP_DATE,
										( (ISNULL(INTERVAL_YEARS,0)*12) + (ISNULL(INTERVAL_MONTHS,0)) + (ISNULL(INTERVAL_DAYS,0)/30) ) AS exam_freq_in_months,
										(CAST(ISNULL(INTERVAL_YEARS,0) AS VARCHAR) + 'y '+CAST(ISNULL(INTERVAL_MONTHS,0) AS VARCHAR)+ 'm '+CAST(ISNULL(INTERVAL_DAYS,0) AS VARCHAR)+ 'd') AS exam_frequency
										
									FROM 
									(
										SELECT 
											COMP_DATE,
											INTERVAL_YEARS,
											INTERVAL_MONTHS,
											INTERVAL_DAYS,
											ROW_NUMBER() OVER (ORDER BY EFFECTIVE_FROM_DT DESC) rnk
										FROM CES.COMPLIANCE c
										WHERE ASSET_GUID = ex.ASSET_GUID
										AND EXAM_TYPE_SR_KEY = ex.EXAM_TYPE_SR_KEY
										AND @current_date BETWEEN EFFECTIVE_FROM_DT AND ISNULL(EFFECTIVE_TO_DT,@end_dt_default)
										AND c.ISACTIVE = 1
									)c
									WHERE rnk = 1
								) cmp

														
							WHERE
								ast.ISACTIVE= 1
							AND o.ISACTIVE = 1
							AND a.ISACTIVE = 1
							AND elr.ISACTIVE = 1
							AND asg.ISACTIVE = 1
							AND asp.ISACTIVE = 1
							AND ex.ISACTIVE = 1
							AND et.ISACTIVE = 1
							AND s.ISACTIVE = 1
							AND o.REGION = @region_name
							AND ( @route_id =0 OR (@route_id <> 0 AND o.ORG_SR_KEY = @route_id))
							AND	( @area_id =0 OR (@area_id <> 0 AND a.AREA_SR_KEY = @area_id))
							AND ex.SUPPLIER_SR_KEY = @supplier_id
							AND ( @iselrselected = 'N' OR (@iselrselected = 'Y' AND ast.ENG_LINE_REF IN (SELECT elr_id FROM @elr_id_array)) )
							AND ( (ast.START_MILES + ast.START_YARDS/1760) BETWEEN @start_mileage_from AND @start_mileage_to)
							--AND ( @railway_id IS NULL OR (@railway_id IS NOT NULL AND ast.RAILWAY_ID = @railway_id))
							AND ( @railway_id IS NULL OR (@railway_id IS NOT NULL AND ast.RAILWAY_ID LIKE ('%' + @railway_id + '%')))
							AND ( @ast_grp_id =0 OR (@ast_grp_id <> 0 AND asg.ASSET_GROUP_SR_KEY = @ast_grp_id))
							AND ( @isasttypselected = 'N' OR (@isasttypselected = 'Y' AND asp.ASSET_TYPE_SR_KEY IN (SELECT ast_typ_id FROM @ast_typ)) )
							AND ( @exam_id = 0 OR (@exam_id <>0 AND ex.EXAM_ID = @exam_id) )
							AND	( @exam_type_id = 0 OR (@exam_type_id <>0 AND et.EXAM_TYPE_SR_KEY = @exam_type_id))
							--AND ( @exam_status_id = 0 OR (@exam_status_id<>0 AND ex.EXAM_REQ_STATUS = @exam_status_id) )
							AND ( @task_list_stat_id = 0 OR (@task_list_stat_id<>0 AND wrk.WORK_STATUS = @task_list_stat_id) )
							AND ( @tasklist_yr_id = 0 OR (@tasklist_yr_id<>0 AND wrk.WORK_YEAR_KEY = @tasklist_yr_id) )
							AND ( CONVERT (DATE,wrk.EXAM_DUE_DATE,103) BETWEEN @due_date_from AND @due_date_to)
							
					)final
					LEFT JOIN [CES].COMPLIANCE_TOLERANCE ct
					ON ct.EXAM_TYPE_SR_KEY = final.EXAM_TYPE_SR_KEY
					AND ct.ISACTIVE = 1
					AND final.exam_freq_in_months BETWEEN ct.FREQ_INTERVAL_MONTHS_FROM AND ct.FREQ_INTERVAL_MONTHS_TO
					

			END
			---Search Screen for Supplier Roles
			ELSE	--Basic search
			BEGIN
		
					
					INSERT INTO #tbl_SearchResult
					(
							asset_guid,
							region,
							route,
							area,
							elr,
							start_mileage,
							end_mileage,
							railway_id,
							asset_desc,
							asset_grp,
							asset_type,
							hce_flg,
							exam_id,
							exam_frequency,
							exam_req_stat,
							exam_rpt_stat,
							exam_type,
							compliance_dt,
							supplier,
							due_dt,
							onsite_pre_compl_tol_dt,
							onsite_post_compl_tol_dt,
							baseline_plan_dt,
							plan_dt,
							exam_dt,
							submission_dt,
							signed_off_dt,
							cr_id,
							specific_exam_req,
							tenanted_arch,
							task_list_stat,
							nr_internal_note,
							comments_to_sec,
							other_supplier_comment,
							posession_critical,
							job_number,
							task_list_id,
							exam_sr_key,
							due_dt_earliest,
							due_dt_latest,
							max_tolerance_dt,
							exam_grp_key
					)
					
																
					SELECT 
						final.asset_guid,
						final.region,
						final.route,
						final.area,
						final.elr,
						final.start_mileage,
						final.end_mileage,
						final.railway_id,
						final.asset_desc,
						final.asset_grp,
						final.asset_type,
						final.hce_flg,
						final.exam_id,
						final.exam_frequency,
						final.exam_req_stat,
						final.exam_rpt_stat,
						final.exam_type,
						final.compliance_dt,
						final.supplier,
						final.due_dt,
						NULL AS onsite_pre_compl_tol_dt,
						NULL AS onsite_post_compl_tol_dt,
						final.baseline_plan_dt,
						final.plan_dt,
						final.exam_dt,
						final.submission_dt,
						final.signed_off_dt,
						final.cr_id,
						final.specific_exam_req,
						final.tenanted_arch,
						final.task_list_stat,
						final.nr_internal_note,
						final.comment_to_sec,
						final.other_supplier_comment,
						NULL AS posession_critical,
						final.job_number,
						final.task_list_id,
						final.exam_sr_key,
						CASE WHEN exam_type IN ('Visual','Detailed','Enhanced') 
							THEN CONVERT(DATE, DATEADD( week, (0- ct.SITE_TOLERANCE_WEEKS), final.due_dt),103) 
							WHEN exam_type IN ('Underwater', 'Line Of Route' ) OR exam_type LIKE '%Additional%'
							THEN WORK_YR_START_DT 
							ELSE NULL
						END AS due_dt_earliest,
						CASE WHEN exam_type IN ('Visual','Detailed','Enhanced') 
							THEN CONVERT(DATE, DATEADD( week, ct.SITE_TOLERANCE_WEEKS, final.due_dt),103) 
							WHEN exam_type IN ('Underwater', 'Line Of Route' ) OR exam_type LIKE '%Additional%'
							THEN WORK_YR_END_DT 
							ELSE NULL
						END AS due_dt_latest,
						--CONVERT(DATE, DATEADD( week, ISNULL(ct.REVIEW_TOLERANCE_WEEKS,0), final.due_dt),103) AS max_tolerance_dt,
						CONVERT(DATE, DATEADD( week, ISNULL(ct.REVIEW_TOLERANCE_WEEKS,0),
									CASE WHEN exam_type IN ('Visual','Detailed','Enhanced') 
										THEN CONVERT(DATE, DATEADD( week, ct.SITE_TOLERANCE_WEEKS, final.due_dt),103) 
										WHEN exam_type IN ('Underwater', 'Line Of Route' ) OR exam_type LIKE '%Additional%'
										THEN WORK_YR_END_DT 
										ELSE NULL
									END
								),103) AS max_tolerance_dt,
						final.EXAM_GROUP_SR_KEY
					FROM
					(
							SELECT 
								ast.ASSET_GUID AS asset_guid,
								o.REGION AS region,
								o.ROUTE AS route,
								a.AREA_NAME AS area,
								elr.ELR_CODE AS elr,
								(ast.START_MILES + ast.START_YARDS/1760) AS start_mileage,
								(ast.END_MILES + ast.END_YARDS/1760) AS end_mileage,
								ast.RAILWAY_ID AS railway_id,
								ast.ASSET_NAME AS asset_desc,
								asg.ASSET_GROUP_DESC AS asset_grp,
								asp.ASSET_TYPE_DESC AS asset_type,
								CASE WHEN ast.hce_flag = 'Y' THEN 'Yes' ELSE 'No' END AS hce_flg,
								ex.exam_id,
								cmp.exam_frequency,
								ex.EXAM_REQ_STATUS AS exam_req_stat,
								ex.EXAM_REPORT_STATUS AS exam_rpt_stat,
								et.EXAM_TYPE AS exam_type,
								NULL AS compliance_dt,
								s.SUPPLIER_NAME AS supplier,
								wrk.EXAM_DUE_DATE AS due_dt,
								--NULL AS onsite_pre_compl_tol_dt,
								--NULL AS onsite_post_compl_tol_dt,
								ex.EXAM_BASELINE_DATE AS baseline_plan_dt,
								ex.EXAM_PLANNED_DATE AS plan_dt,
								ex.EXAM_ACTUAL_DATE AS exam_dt,
								ex.EXAM_SUBMISSION_DATE AS submission_dt,
								ex.EXAM_SIGNOFF_DATE AS signed_off_dt,
								ex.CHANGE_REQ_ID AS cr_id,
								ex.EXAM_REQUIREMENT AS specific_exam_req,
								CASE WHEN ast.TENANTED_FLG = 'Y' THEN 'Yes'
									 WHEN ast.TENANTED_FLG = 'N' THEN 'No'
									 ELSE 'N/A'
								END AS tenanted_arch,
								wrk.WORK_STATUS AS task_list_stat,
								ex.INTERNAL_NOTES AS nr_internal_note,
								ex.comment_to_sec,
								ex.SUPPLIER_COMMENTS AS other_supplier_comment,
								--NULL AS posession_critical,
								wrk.job_number,
								wrk.WORK_SR_KEY AS task_list_id,
								ex.EXAM_SR_KEY,
								ex.EXAM_TYPE_SR_KEY,
								ISNULL(cmp.exam_freq_in_months,0) AS exam_freq_in_months,
								wrk.WORK_YR_START_DT,
								wrk.WORK_YR_END_DT,
								ex.EXAM_GROUP_SR_KEY
								
							FROM [CES].ASSET ast
							INNER JOIN [CES].ORG o
							ON ast.ORG_SR_KEY = o.ORG_SR_KEY
							INNER JOIN [CES].AREA a
							ON a.AREA_SR_KEY = ast.AREA_SR_KEY
							INNER JOIN [CES].ENGINE_LINE_REF elr
							ON elr.ELR_SR_KEY = ast.ENG_LINE_REF
							AND elr.ORG_SR_KEY = ast.ORG_SR_KEY
							AND elr.AREA_SR_KEY = ast.AREA_SR_KEY
							INNER JOIN [CES].ASSET_GROUP asg
							ON asg.ASSET_GROUP_SR_KEY = ast.ASSET_GROUP_SR_KEY
							INNER JOIN [CES].ASSET_TYPE asp
							ON asp.ASSET_TYPE_SR_KEY = ast.ASSET_TYPE_SR_KEY
							INNER JOIN [CES].EXAM ex
							ON ex.ASSET_GUID = ast.ASSET_GUID
							INNER JOIN [CES].WORK wrk
							ON wrk.WORK_SR_KEY = ex.WORK_SR_KEY
							AND wrk.ISACTIVE = 1
							INNER JOIN [CES].EXAM_TYPE et
							ON et.EXAM_TYPE_SR_KEY = ex.EXAM_TYPE_SR_KEY
							INNER JOIN [CES].SUPPLIER s
							ON s.SUPPLIER_SR_KEY = ex.SUPPLIER_SR_KEY
							OUTER APPLY
								(
									SELECT
										COMP_DATE,
										( (ISNULL(INTERVAL_YEARS,0)*12) + (ISNULL(INTERVAL_MONTHS,0)) + (ISNULL(INTERVAL_DAYS,0)/30) ) AS exam_freq_in_months,
										(CAST(ISNULL(INTERVAL_YEARS,0) AS VARCHAR) + 'y '+CAST(ISNULL(INTERVAL_MONTHS,0) AS VARCHAR)+ 'm '+CAST(ISNULL(INTERVAL_DAYS,0) AS VARCHAR)+ 'd') AS exam_frequency
										
									FROM 
									(
										SELECT 
											COMP_DATE,
											INTERVAL_YEARS,
											INTERVAL_MONTHS,
											INTERVAL_DAYS,
											ROW_NUMBER() OVER (ORDER BY EFFECTIVE_FROM_DT DESC) rnk
										FROM CES.COMPLIANCE c
										WHERE ASSET_GUID = ex.ASSET_GUID
										AND EXAM_TYPE_SR_KEY = ex.EXAM_TYPE_SR_KEY
										AND @current_date BETWEEN EFFECTIVE_FROM_DT AND ISNULL(EFFECTIVE_TO_DT,@end_dt_default)
										AND c.ISACTIVE = 1
									)c
									WHERE rnk = 1
								) cmp
														
							WHERE
								ast.ISACTIVE= 1
							AND o.ISACTIVE = 1
							AND a.ISACTIVE = 1
							AND elr.ISACTIVE = 1
							AND asg.ISACTIVE = 1
							AND asp.ISACTIVE = 1
							AND ex.ISACTIVE = 1
							AND et.ISACTIVE = 1
							AND s.ISACTIVE = 1
							AND o.REGION = @region_name
							AND ( @route_id =0 OR (@route_id <> 0 AND o.ORG_SR_KEY = @route_id))
							AND	( @area_id =0 OR (@area_id <> 0 AND a.AREA_SR_KEY = @area_id))
							AND ex.SUPPLIER_SR_KEY = @supplier_id
							AND ( @tasklist_yr_id = 0 OR (@tasklist_yr_id<>0 AND wrk.WORK_YEAR_KEY = @tasklist_yr_id) )
																					
					)final
					LEFT JOIN [CES].COMPLIANCE_TOLERANCE ct
					ON ct.EXAM_TYPE_SR_KEY = final.EXAM_TYPE_SR_KEY
					AND ct.ISACTIVE = 1
					AND final.exam_freq_in_months BETWEEN ct.FREQ_INTERVAL_MONTHS_FROM AND ct.FREQ_INTERVAL_MONTHS_TO
					
			END	
		END

		--Total count of records
		SELECT @totalresultcnt = COUNT(1) FROM #tbl_SearchResult

		--If no records are returned in search result
		IF  @totalresultcnt=0 
		BEGIN
			SET @result=
					(
						SELECT 
							JSON_QUERY(
										(
											select
												@pageno AS currentpage,
												@totalresultcnt AS totalcount,
												0 AS totalpages
											FOR JSON PATH,WITHOUT_ARRAY_WRAPPER
										)
							) searchdatacount,
							--NULL AS task_list_stat,
							--NULL AS task_list_id,
							JSON_QUERY('[]') tasklistkeys ,
							JSON_QUERY('[]') searchresult
						
						FOR JSON PATH,WITHOUT_ARRAY_WRAPPER, INCLUDE_NULL_VALUES
				)
		END	
		--If alt least 1 record is returned in search result
		ELSE
		BEGIN
			IF @isexporttodoc = 'Y' --Export to Excel
			BEGIN
					IF @sortorder = 'asc' 
					BEGIN
			
						SET @result=
						(
							SELECT 
								JSON_QUERY(
											(
												select
													@pageno AS currentpage,
													@totalresultcnt AS totalcount,
													CEILING(@totalresultcnt/@rowsperpage) AS totalpages
												FOR JSON PATH,WITHOUT_ARRAY_WRAPPER
											)
								) searchdatacount,
								--@task_list_status AS task_list_stat,
								--@task_list_id AS task_list_id,
							JSON_QUERY('[]') tasklistkeys ,
							(
								SELECT
									asset_guid,
									region,
									route,
									area,
									elr,
									start_mileage,
									end_mileage,
									railway_id,
									asset_desc,
									asset_grp,
									asset_type,
									hce_flg,
									exam_id,
									exam_frequency,
									exam_req_stat,
									exam_rpt_stat,
									exam_type,
									compliance_dt,
									supplier,
									due_dt,
									onsite_pre_compl_tol_dt,
									onsite_post_compl_tol_dt,
									baseline_plan_dt,
									plan_dt,
									exam_dt,
									submission_dt,
									signed_off_dt,
									cr_id,
									specific_exam_req,
									tenanted_arch,
									task_list_stat,
									nr_internal_note,
									comments_to_sec,
									other_supplier_comment,
									posession_critical,
									job_number,
									bcmi_required,
									due_dt_earliest,
									due_dt_latest,
									max_tolerance_dt,
									task_list_id,
									exam_group_id
								FROM
								(
									SELECT
											asset_guid,
											region,
											route,
											area,
											elr,
											start_mileage,
											end_mileage,
											railway_id,
											asset_desc,
											asset_grp,
											asset_type,
											hce_flg,
											exam_id,
											exam_frequency,
											ers.REF_VALUE AS exam_req_stat,
											eps.REF_VALUE AS exam_rpt_stat,
											exam_type,
											compliance_dt,
											supplier,
											due_dt,
											onsite_pre_compl_tol_dt,
											onsite_post_compl_tol_dt,
											baseline_plan_dt,
											plan_dt,
											exam_dt,
											submission_dt,
											signed_off_dt,
											cr_id,
											specific_exam_req,
											tenanted_arch,
											ts.REF_VALUE AS task_list_stat,
											nr_internal_note,
											comments_to_sec,
											other_supplier_comment,
											posession_critical,
											job_number,
											NULL AS bcmi_required,
											due_dt_earliest,
											due_dt_latest,
											max_tolerance_dt,
											task_list_id,
											eg.CARRS_EXAM_GROUP_ID AS exam_group_id,
											ROW_NUMBER() OVER (ORDER BY 
																		CASE WHEN @sortcolumn = 'AssetGUID' THEN asset_guid ELSE NULL END ASC, 
																		CASE WHEN @sortcolumn = 'Region' THEN region ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'Route' THEN route ELSE NULL END ASC, 
																		CASE WHEN @sortcolumn = 'Area' THEN area ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'ELR' THEN elr ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'RailwayID' THEN railway_id ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'AssetDesc' THEN asset_desc ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'AssetGroup' THEN asset_grp ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'AssetType' THEN asset_type ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'HCEFlg' THEN hce_flg ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'ExamID' THEN exam_id ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'ExamFrequency' THEN exam_frequency ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'ExamReqStat' THEN ers.REF_VALUE ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'ExamRptStat' THEN eps.REF_VALUE ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'ExamType' THEN exam_type ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'ComplianceDt' THEN compliance_dt ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'Supplier' THEN supplier ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'DueDate' THEN due_dt ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'PrecomTolrncDt' THEN onsite_pre_compl_tol_dt ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'PostcomTolrncDt' THEN onsite_post_compl_tol_dt ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'BaselinePlnDt' THEN baseline_plan_dt ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'PlannedDt' THEN plan_dt ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'ExamDt' THEN exam_dt ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'SubmissionDt' THEN submission_dt ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'SignOffDt' THEN signed_off_dt ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'CRID' THEN cr_id ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'SpecExamReq' THEN specific_exam_req ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'TenantedArch' THEN tenanted_arch ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'TaskListStat' THEN ts.REF_VALUE ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'NRInternalNotes' THEN nr_internal_note ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'CommentsToSEC' THEN comments_to_sec ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'JobNumber' THEN job_number ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'OtherSupplierComment' THEN other_supplier_comment ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'PossessionCritical' THEN posession_critical ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'StartMileage' THEN start_mileage ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'EndMileage' THEN end_mileage ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'ExamGroupID' THEN eg.CARRS_EXAM_GROUP_ID ELSE NULL END ASC
																	
																	) AS ordrnk

									FROM #tbl_SearchResult t
									LEFT JOIN [CES].REFERENCE_VALUE ers
									ON t.exam_req_stat = ers.REF_VAL_SR_KEY
									LEFT JOIN [CES].REFERENCE_VALUE eps
									ON t.exam_rpt_stat = eps.REF_VAL_SR_KEY
									LEFT JOIN [CES].REFERENCE_VALUE ts
									ON t.task_list_stat = ts.REF_VAL_SR_KEY
									LEFT JOIN [CES].EXAM_GROUP eg
									ON eg.EXAM_GROUP_SR_KEY = t.exam_grp_key
								)sr
								ORDER BY ordrnk
								FOR JSON AUTO, INCLUDE_NULL_VALUES
							)searchresult
							FOR JSON PATH,WITHOUT_ARRAY_WRAPPER, INCLUDE_NULL_VALUES
						)
					END
					ELSE IF @sortorder = 'desc' 
					BEGIN
					
						SET @result=
						(
							SELECT 
								JSON_QUERY(
											(
												select
													@pageno AS currentpage,
													@totalresultcnt AS totalcount,
													CEILING(@totalresultcnt/@rowsperpage) AS totalpages
												FOR JSON PATH,WITHOUT_ARRAY_WRAPPER
											)
								) searchdatacount,
							--@task_list_status AS task_list_stat,
							--@task_list_id AS task_list_id,
							JSON_QUERY('[]') tasklistkeys ,
							(
								SELECT
									asset_guid,
									region,
									route,
									area,
									elr,
									start_mileage,
									end_mileage,
									railway_id,
									asset_desc,
									asset_grp,
									asset_type,
									hce_flg,
									exam_id,
									exam_frequency,
									exam_req_stat,
									exam_rpt_stat,
									exam_type,
									compliance_dt,
									supplier,
									due_dt,
									onsite_pre_compl_tol_dt,
									onsite_post_compl_tol_dt,
									baseline_plan_dt,
									plan_dt,
									exam_dt,
									submission_dt,
									signed_off_dt,
									cr_id,
									specific_exam_req,
									tenanted_arch,
									task_list_stat,
									nr_internal_note,
									comments_to_sec,
									other_supplier_comment,
									posession_critical,
									job_number,
									bcmi_required,
									due_dt_earliest,
									due_dt_latest,
									max_tolerance_dt,
									task_list_id,
									exam_group_id
								FROM
								(
									SELECT
											asset_guid,
											region,
											route,
											area,
											elr,
											start_mileage,
											end_mileage,
											railway_id,
											asset_desc,
											asset_grp,
											asset_type,
											hce_flg,
											exam_id,
											exam_frequency,
											ers.REF_VALUE AS exam_req_stat,
											eps.REF_VALUE AS exam_rpt_stat,
											exam_type,
											compliance_dt,
											supplier,
											due_dt,
											onsite_pre_compl_tol_dt,
											onsite_post_compl_tol_dt,
											baseline_plan_dt,
											plan_dt,
											exam_dt,
											submission_dt,
											signed_off_dt,
											cr_id,
											specific_exam_req,
											tenanted_arch,
											ts.REF_VALUE AS task_list_stat,
											nr_internal_note,
											comments_to_sec,
											other_supplier_comment,
											posession_critical,
											job_number,
											NULL AS bcmi_required,
											due_dt_earliest,
											due_dt_latest,
											max_tolerance_dt,
											task_list_id,
											eg.CARRS_EXAM_GROUP_ID AS exam_group_id,
											ROW_NUMBER() OVER (ORDER BY 
																		CASE WHEN @sortcolumn = 'AssetGUID' THEN asset_guid ELSE NULL END DESC, 
																		CASE WHEN @sortcolumn = 'Region' THEN region ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'Route' THEN route ELSE NULL END DESC, 
																		CASE WHEN @sortcolumn = 'Area' THEN area ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'ELR' THEN elr ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'RailwayID' THEN railway_id ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'AssetDesc' THEN asset_desc ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'AssetGroup' THEN asset_grp ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'AssetType' THEN asset_type ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'HCEFlg' THEN hce_flg ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'ExamID' THEN exam_id ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'ExamFrequency' THEN exam_frequency ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'ExamReqStat' THEN ers.REF_VALUE ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'ExamRptStat' THEN eps.REF_VALUE ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'ExamType' THEN exam_type ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'ComplianceDt' THEN compliance_dt ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'Supplier' THEN supplier ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'DueDate' THEN due_dt ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'PrecomTolrncDt' THEN onsite_pre_compl_tol_dt ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'PostcomTolrncDt' THEN onsite_post_compl_tol_dt ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'BaselinePlnDt' THEN baseline_plan_dt ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'PlannedDt' THEN plan_dt ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'ExamDt' THEN exam_dt ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'SubmissionDt' THEN submission_dt ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'SignOffDt' THEN signed_off_dt ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'CRID' THEN cr_id ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'SpecExamReq' THEN specific_exam_req ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'TenantedArch' THEN tenanted_arch ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'TaskListStat' THEN ts.REF_VALUE ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'NRInternalNotes' THEN nr_internal_note ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'CommentsToSEC' THEN comments_to_sec ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'JobNumber' THEN job_number ELSE NULL END DESC,																		
																		CASE WHEN @sortcolumn = 'OtherSupplierComment' THEN other_supplier_comment ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'PossessionCritical' THEN posession_critical ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'StartMileage' THEN start_mileage ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'EndMileage' THEN end_mileage ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'ExamGroupID' THEN eg.CARRS_EXAM_GROUP_ID ELSE NULL END ASC

																	
																	) AS ordrnk

									FROM #tbl_SearchResult t
									LEFT JOIN [CES].REFERENCE_VALUE ers
									ON t.exam_req_stat = ers.REF_VAL_SR_KEY
									LEFT JOIN [CES].REFERENCE_VALUE eps
									ON t.exam_rpt_stat = eps.REF_VAL_SR_KEY
									LEFT JOIN [CES].REFERENCE_VALUE ts
									ON t.task_list_stat = ts.REF_VAL_SR_KEY
									LEFT JOIN [CES].EXAM_GROUP eg
									ON eg.EXAM_GROUP_SR_KEY = t.exam_grp_key
								)sr
								ORDER BY ordrnk
								FOR JSON AUTO, INCLUDE_NULL_VALUES
							)searchresult
							FOR JSON PATH,WITHOUT_ARRAY_WRAPPER, INCLUDE_NULL_VALUES
						)
					END
			END
			ELSE IF @isexporttodoc = 'N' --Screen output
			BEGIN
				IF @sortorder = 'asc' 
					BEGIN
			
						SET @result=
						(
							SELECT 
								JSON_QUERY(
											(
												select
													@pageno AS currentpage,
													@totalresultcnt AS totalcount,
													CEILING(@totalresultcnt/@rowsperpage) AS totalpages
												FOR JSON PATH,WITHOUT_ARRAY_WRAPPER
											)
								) searchdatacount,
							--@task_list_status AS task_list_stat,
							--@task_list_id AS task_list_id,
							(
								SELECT
									exam_sr_key,
									task_list_id,
									task_list_stat
								FROM #tbl_SearchResult
								FOR JSON AUTO, INCLUDE_NULL_VALUES
							)tasklistkeys ,
							(
								
								SELECT
									asset_guid,
									region,
									route,
									area,
									elr,
									start_mileage,
									end_mileage,
									railway_id,
									asset_desc,
									asset_grp,
									asset_type,
									hce_flg,
									exam_id,
									exam_frequency,
									exam_req_stat,
									exam_rpt_stat,
									exam_type,
									compliance_dt,
									supplier,
									due_dt,
									onsite_pre_compl_tol_dt,
									onsite_post_compl_tol_dt,
									baseline_plan_dt,
									plan_dt,
									exam_dt,
									submission_dt,
									signed_off_dt,
									cr_id,
									specific_exam_req,
									tenanted_arch,
									task_list_stat,
									nr_internal_note,
									comments_to_sec,
									other_supplier_comment,
									posession_critical,
									job_number,
									NULL AS bcmi_required,
									due_dt_earliest,
									due_dt_latest,
									max_tolerance_dt,
									task_list_id,
									exam_group_id
								FROM
								(
									SELECT
											asset_guid,
											region,
											route,
											area,
											elr,
											start_mileage,
											end_mileage,
											railway_id,
											asset_desc,
											asset_grp,
											asset_type,
											hce_flg,
											exam_id,
											exam_frequency,
											ers.REF_VALUE AS exam_req_stat,
											eps.REF_VALUE AS exam_rpt_stat,
											exam_type,
											compliance_dt,
											supplier,
											due_dt,
											onsite_pre_compl_tol_dt,
											onsite_post_compl_tol_dt,
											baseline_plan_dt,
											plan_dt,
											exam_dt,
											submission_dt,
											signed_off_dt,
											cr_id,
											specific_exam_req,
											tenanted_arch,
											ts.REF_VALUE AS task_list_stat,
											nr_internal_note,
											comments_to_sec,
											other_supplier_comment,
											posession_critical,
											job_number,
											task_list_id,
											due_dt_earliest,
											due_dt_latest,
											max_tolerance_dt,
											eg.CARRS_EXAM_GROUP_ID AS exam_group_id,
											ROW_NUMBER() OVER (ORDER BY 
																		CASE WHEN @sortcolumn = 'AssetGUID' THEN asset_guid ELSE NULL END ASC, 
																		CASE WHEN @sortcolumn = 'Region' THEN region ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'Route' THEN route ELSE NULL END ASC, 
																		CASE WHEN @sortcolumn = 'Area' THEN area ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'ELR' THEN elr ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'RailwayID' THEN railway_id ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'AssetDesc' THEN asset_desc ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'AssetGroup' THEN asset_grp ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'AssetType' THEN asset_type ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'HCEFlg' THEN hce_flg ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'ExamID' THEN exam_id ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'ExamFrequency' THEN exam_frequency ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'ExamReqStat' THEN ers.REF_VALUE ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'ExamRptStat' THEN eps.REF_VALUE ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'ExamType' THEN exam_type ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'ComplianceDt' THEN compliance_dt ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'Supplier' THEN supplier ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'DueDate' THEN due_dt ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'PrecomTolrncDt' THEN onsite_pre_compl_tol_dt ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'PostcomTolrncDt' THEN onsite_post_compl_tol_dt ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'BaselinePlnDt' THEN baseline_plan_dt ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'PlannedDt' THEN plan_dt ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'ExamDt' THEN exam_dt ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'SubmissionDt' THEN submission_dt ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'SignOffDt' THEN signed_off_dt ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'CRID' THEN cr_id ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'SpecExamReq' THEN specific_exam_req ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'TenantedArch' THEN tenanted_arch ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'TaskListStat' THEN ts.REF_VALUE ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'NRInternalNotes' THEN nr_internal_note ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'CommentsToSEC' THEN comments_to_sec ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'JobNumber' THEN job_number ELSE NULL END ASC,																		
																		CASE WHEN @sortcolumn = 'OtherSupplierComment' THEN other_supplier_comment ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'PossessionCritical' THEN posession_critical ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'StartMileage' THEN start_mileage ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'EndMileage' THEN end_mileage ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'ExamGroupID' THEN eg.CARRS_EXAM_GROUP_ID ELSE NULL END ASC
																	 
																	
																	) AS ordrnk

									FROM #tbl_SearchResult t
									LEFT JOIN [CES].REFERENCE_VALUE ers
									ON t.exam_req_stat = ers.REF_VAL_SR_KEY
									LEFT JOIN [CES].REFERENCE_VALUE eps
									ON t.exam_rpt_stat = eps.REF_VAL_SR_KEY
									LEFT JOIN [CES].REFERENCE_VALUE ts
									ON t.task_list_stat = ts.REF_VAL_SR_KEY
									LEFT JOIN [CES].EXAM_GROUP eg
									ON eg.EXAM_GROUP_SR_KEY = t.exam_grp_key
									
								)sr
								WHERE sr.ordrnk BETWEEN ((@pageno - 1) * @rowsperpage +1) AND (@pageno * @rowsperpage)
								
								ORDER BY ordrnk
								FOR JSON AUTO, INCLUDE_NULL_VALUES
							)searchresult
							FOR JSON PATH,WITHOUT_ARRAY_WRAPPER, INCLUDE_NULL_VALUES
						)
					END
				
					ELSE IF @sortorder = 'desc' 
					BEGIN
				
						SET @result=
						(
							SELECT 
								JSON_QUERY(
											(
												select
													@pageno AS currentpage,
													@totalresultcnt AS totalcount,
													CEILING(@totalresultcnt/@rowsperpage) AS totalpages
												FOR JSON PATH,WITHOUT_ARRAY_WRAPPER
											)
								) searchdatacount,
							--@task_list_status AS task_list_stat,
							--@task_list_id AS task_list_id,
							(
								SELECT
									exam_sr_key,
									task_list_id,
									task_list_stat
								FROM #tbl_SearchResult
								FOR JSON AUTO, INCLUDE_NULL_VALUES
							)tasklistkeys ,
							(
								SELECT
									asset_guid,
									region,
									route,
									area,
									elr,
									start_mileage,
									end_mileage,
									railway_id,
									asset_desc,
									asset_grp,
									asset_type,
									hce_flg,
									exam_id,
									exam_frequency,
									exam_req_stat,
									exam_rpt_stat,
									exam_type,
									compliance_dt,
									supplier,
									due_dt,
									onsite_pre_compl_tol_dt,
									onsite_post_compl_tol_dt,
									baseline_plan_dt,
									plan_dt,
									exam_dt,
									submission_dt,
									signed_off_dt,
									cr_id,
									specific_exam_req,
									tenanted_arch,
									task_list_stat,
									nr_internal_note,
									comments_to_sec,
									other_supplier_comment,
									posession_critical,
									job_number,
									NULL AS bcmi_required,
									due_dt_earliest,
									due_dt_latest,
									max_tolerance_dt,
									task_list_id,
									exam_group_id
								FROM
								(
									SELECT
											asset_guid,
											region,
											route,
											area,
											elr,
											start_mileage,
											end_mileage,
											railway_id,
											asset_desc,
											asset_grp,
											asset_type,
											hce_flg,
											exam_id,
											exam_frequency,
											ers.REF_VALUE AS exam_req_stat,
											eps.REF_VALUE AS exam_rpt_stat,
											exam_type,
											compliance_dt,
											supplier,
											due_dt,
											onsite_pre_compl_tol_dt,
											onsite_post_compl_tol_dt,
											baseline_plan_dt,
											plan_dt,
											exam_dt,
											submission_dt,
											signed_off_dt,
											cr_id,
											specific_exam_req,
											tenanted_arch,
											ts.REF_VALUE AS task_list_stat,
											nr_internal_note,
											comments_to_sec,
											other_supplier_comment,
											posession_critical,
											job_number,
											task_list_id,
											due_dt_earliest,
											due_dt_latest,
											max_tolerance_dt,
											eg.CARRS_EXAM_GROUP_ID AS exam_group_id,
											ROW_NUMBER() OVER (ORDER BY 
																		CASE WHEN @sortcolumn = 'AssetGUID' THEN asset_guid ELSE NULL END DESC, 
																		CASE WHEN @sortcolumn = 'Region' THEN region ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'Route' THEN route ELSE NULL END DESC, 
																		CASE WHEN @sortcolumn = 'Area' THEN area ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'ELR' THEN elr ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'RailwayID' THEN railway_id ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'AssetDesc' THEN asset_desc ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'AssetGroup' THEN asset_grp ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'AssetType' THEN asset_type ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'HCEFlg' THEN hce_flg ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'ExamID' THEN exam_id ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'ExamFrequency' THEN exam_frequency ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'ExamReqStat' THEN ers.REF_VALUE ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'ExamRptStat' THEN eps.REF_VALUE ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'ExamType' THEN exam_type ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'ComplianceDt' THEN compliance_dt ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'Supplier' THEN supplier ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'DueDate' THEN due_dt ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'PrecomTolrncDt' THEN onsite_pre_compl_tol_dt ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'PostcomTolrncDt' THEN onsite_post_compl_tol_dt ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'BaselinePlnDt' THEN baseline_plan_dt ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'PlannedDt' THEN plan_dt ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'ExamDt' THEN exam_dt ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'SubmissionDt' THEN submission_dt ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'SignOffDt' THEN signed_off_dt ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'CRID' THEN cr_id ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'SpecExamReq' THEN specific_exam_req ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'TenantedArch' THEN tenanted_arch ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'TaskListStat' THEN ts.REF_VALUE ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'NRInternalNotes' THEN nr_internal_note ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'CommentsToSEC' THEN comments_to_sec ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'JobNumber' THEN job_number ELSE NULL END DESC,																		
																		CASE WHEN @sortcolumn = 'OtherSupplierComment' THEN other_supplier_comment ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'PossessionCritical' THEN posession_critical ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'StartMileage' THEN start_mileage ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'EndMileage' THEN end_mileage ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'ExamGroupID' THEN eg.CARRS_EXAM_GROUP_ID ELSE NULL END ASC
																	
																	) AS ordrnk

									FROM #tbl_SearchResult t
									LEFT JOIN [CES].REFERENCE_VALUE ers
									ON t.exam_req_stat = ers.REF_VAL_SR_KEY
									LEFT JOIN [CES].REFERENCE_VALUE eps
									ON t.exam_rpt_stat = eps.REF_VAL_SR_KEY
									LEFT JOIN [CES].REFERENCE_VALUE ts
									ON t.task_list_stat = ts.REF_VAL_SR_KEY
									LEFT JOIN [CES].EXAM_GROUP eg
									ON eg.EXAM_GROUP_SR_KEY = t.exam_grp_key
								)sr
								WHERE sr.ordrnk BETWEEN ((@pageno - 1) * @rowsperpage +1) AND (@pageno * @rowsperpage)
								
								ORDER BY ordrnk
								FOR JSON AUTO, INCLUDE_NULL_VALUES
							)searchresult
							FOR JSON PATH,WITHOUT_ARRAY_WRAPPER, INCLUDE_NULL_VALUES
						)
					END
		
			END
		END

		--PRINT @result
		SELECT @result


	END TRY
	BEGIN CATCH
		SET @ErrorMsg = ERROR_MESSAGE() + 
						' Line Num:' + CONVERT(VARCHAR(5), ERROR_LINE()) + 
						',ErrorNum:' + CONVERT(VARCHAR(5), ERROR_NUMBER()) + 
						',Severity:' + CONVERT(VARCHAR(5), ERROR_SEVERITY()) + 
						',State:' + CONVERT(VARCHAR(10), ERROR_STATE()) + 
						',Procedure:' + CONVERT(VARCHAR(25), ERROR_PROCEDURE());  

		THROW 50000,@ErrorMsg,1;

		
	END CATCH

	DROP TABLE IF EXISTS #tbl_SearchResult;
	SET NOCOUNT OFF
END