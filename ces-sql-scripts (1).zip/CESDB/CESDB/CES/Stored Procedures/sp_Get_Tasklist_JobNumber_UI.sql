﻿/***************************************************************************************************************************************            
* Name						: sp_Get_Tasklist_JobNumber_UI            
* Created By				: Cognizant            
* Date Created				: 14-Jul-2021           
* Description				: This stored procedure is used to get the job number for specific asset and exam type in tasklist.  
* Input Parameters			: Asset GUID, Exam Type      
* Output Parameters			: N/A            
* Return Value				: N/A            
* Assumptions				: None    
* Execution Statement		: EXEC [CES].[sp_Get_Tasklist_JobNumber_UI]  735205
												     
													                     "examkey": 2																			
																		  

*								
* Modified Date     Modified By   Revision Number  Modifications            

*******************************************************************************************************************************************/ 



CREATE PROCEDURE [CES].[sp_Get_Tasklist_JobNumber_UI]
	@Exam_SR_Key		DECIMAL(18,0)    
AS 


BEGIN
	SET NOCOUNT ON

  BEGIN TRY
		DECLARE
				@ErrorMsg		VARCHAR(250),
				@result			NVARCHAR(MAX),
				@Exam_id		DECIMAL(18,0),
				@Jobnumber		VARCHAR(8000),
				@totalcount		DECIMAL(18,0)
				
		--Temp table creation start
		DROP TABLE IF EXISTS #tmpTaskListGetJobnumber_UI;

		CREATE TABLE #tmpTaskListGetJobnumber_UI
		(
			Exam_ID				DECIMAL(18),
			JobNumber				VARCHAR(8000)
		)
		--Temp table creation End

		--- Validation Checks -- Start
		IF (@Exam_SR_Key IS NULL)
		BEGIN
			SET @ErrorMsg = 'Exam key is blank in input.';
			DROP TABLE IF EXISTS #tmpTaskListGetJobnumber_UI;
			THROW 50000,@ErrorMsg,1;
		END
		--- Validation Checks -- End
		 
		 --Fetch job number details
		 INSERT INTO #tmpTaskListGetJobnumber_UI
		(
			Exam_ID,
			JobNumber
		)
		SELECT ex.EXAM_ID,w.JOB_NUMBER from CES.WORK w INNER JOIN CES.EXAM ex on ex.WORK_SR_KEY=w.WORK_SR_KEY
		WHERE ex.EXAM_SR_KEY=@Exam_SR_Key

		--To check if  the row count is > 0
		SET @totalcount= (SELECT COUNT(1) FROM #tmpTaskListGetJobnumber_UI)

		IF @totalcount>0 
		BEGIN
			SET @result=
						(
							SELECT JobNumber AS jobnumber, Exam_ID AS exam_id, NULL AS error_msg FROM #tmpTaskListGetJobnumber_UI
							FOR JSON PATH, INCLUDE_NULL_VALUES, WITHOUT_ARRAY_WRAPPER
						)
		END
		ELSE
		BEGIN
			SET @result=
						(
							SELECT NULL jobnumber, NULL AS exam_id, 'No jobnumber details found' AS error_msg
							FOR JSON PATH, INCLUDE_NULL_VALUES, WITHOUT_ARRAY_WRAPPER
						)
		END

		SELECT @result
	END TRY

	BEGIN CATCH
	

		SET @ErrorMsg = ERROR_MESSAGE() + 
						' Line Num:' + CONVERT(VARCHAR(5), ERROR_LINE()) + 
						',ErrorNum:' + CONVERT(VARCHAR(5), ERROR_NUMBER()) + 
						',Severity:' + CONVERT(VARCHAR(5), ERROR_SEVERITY()) + 
						',State:' + CONVERT(VARCHAR(10), ERROR_STATE()) + 
						',Procedure:' + CONVERT(VARCHAR(25), OBJECT_NAME(@@procid)) +
						',Procedure:' + CONVERT(VARCHAR(25), ERROR_PROCEDURE());  
							
		DROP TABLE IF EXISTS #tmpTaskListGetJobnumber_UI;

		THROW 50000,@ErrorMsg,1;
	END CATCH

	DROP TABLE IF EXISTS #tmpTaskListGetJobnumber_UI;
	SET NOCOUNT OFF
END