﻿/***************************************************************************************************************************************            
* Name						: [CES].[sp_Insert_Work_Exam_Sync_ADF]    
* Created By				: Cognizant            
* Date Created				: 28-Feb-2021           
* Description				: This stored procedure updates the Exam Table ISLAST flag through ADF.  
* Input Parameters			: JSON   
* Output Parameters			: Returns 1 for succesful save, else 0            
* Return Value				: N/A            
* Assumptions				: None    
* Execution Statement		: EXEC [CES].[sp_Insert_Work_Exam_Sync_ADF] 
*								
* Modified Date     Modified By   Revision Number  Modifications            

*******************************************************************************************************************************************/ 
CREATE   PROCEDURE [CES].[sp_Insert_Work_Exam_Sync_ADF]
AS 
BEGIN
	SET NOCOUNT ON
    BEGIN TRY
		DECLARE
				@ErrorMsg			VARCHAR(250),
				@ErrorDescription   VARCHAR(4000),
				@Output				BIT = 0,
				@CurrentDate		DATETIME  = GETDATE(),
				@User				VARCHAR(16) = 'CARRS',
				@outputJson			Nvarchar(MAX)
	
	------------------------------------	
	BEGIN TRAN

	INSERT INTO CES.WORK
		(
				WORK_YEAR_KEY,
				WORK_YR_START_DT,
				WORK_YR_END_DT,
				ORG_SR_KEY,
				ASSET_GUID,
				EXAM_TYPE_SR_KEY,
				EXAM_DUE_DATE,
				WORK_STATUS,
				NR_INTERNAL_NOTES,
				COMMENTS_TO_SEC,
				CREATED_USER,
				CREATED_DATE,
				WORK_SR_KEY
		)
		Select 
		VRV.REF_VAL_SR_KEY AS WorkYear_SR_KEY, 
		concat(SUBSTRING(A.WorkYear, 1, 4), '-04-01') as WorkStartYear,
		concat(SUBSTRING(A.WorkYear, 6, 4), '-03-31') as WorkEndYear,
		A.ORG_SR_KEY,
		A.ASSET_GUID,
		A.EXAM_TYPE_SR_KEY,
		A.EXAM_DUE_DATE,
		TRV.REF_VAL_SR_KEY AS TaskListKey,
		A.INTERNAL_NOTES,
		A.COMMENT_TO_SEC,		
		@User,
		@CurrentDate,
		A.WORK_SR_KEY
		from (
		Select
		EX.EXAM_ID,
		EX.ASSET_GUID,
		AST.ORG_SR_KEY,
		EX.EXAM_TYPE_SR_KEY,
		ET.EXAM_TYPE,
		EX.EXAM_BASELINE_DATE AS EXAM_DUE_DATE,
		RV.REF_VALUE,	
		CASE 
		WHEN ET.EXAM_TYPE = 'Detailed' OR ET.EXAM_TYPE = 'Visual' OR ET.EXAM_TYPE = 'Underwater' OR ET.EXAM_TYPE = 'Line Of Route' THEN 
			CASE
			WHEN RV.REF_VALUE ='Planned' THEN 'Ready for CEFA PM review' 
			WHEN RV.REF_VALUE ='Requested' THEN 'Issued' 
			Else 'Agreed' END
		Else 'Agreed'
		END AS TaskListStatus,
		EX.INTERNAL_NOTES,
		EX.COMMENT_TO_SEC,
		CASE
		WHEN MONTH(EXAM_BASELINE_DATE) > 3 THEN CONCAT(YEAR(EXAM_BASELINE_DATE), '/',YEAR(DATEADD(YEAR, 1, EXAM_BASELINE_DATE)))
		ELSE CONCAT(YEAR(DATEADD(YEAR, -1, EXAM_BASELINE_DATE)),'/', YEAR(EXAM_BASELINE_DATE))
		END AS WorkYear,
		EX.WORK_SR_KEY
		from CES.EXAM_STG EX
		Inner Join CES.Asset AST ON AST.ASSET_GUID = EX.ASSET_GUID
		INner Join CES.Reference_Value RV ON  RV.REF_VAL_SR_KEY = EXAM_REQ_STATUS
		Inner Join CES.Exam_Type ET ON ET.EXAM_TYPE_SR_KEY = EX.EXAM_TYPE_SR_KEY
		WHERE
		EXAM_BASELINE_DATE > '2021-03-31')A
		INner Join CTL_CES_ADL_CONTROL.vw_ADF_Reference_Type_Value TRV ON TRV.REF_TYP_CODE = 'TLS' and TRV.REF_VALUE = A.TaskListStatus
		Inner Join CTL_CES_ADL_CONTROL.vw_ADF_Reference_Type_Value VRV ON VRV.REF_TYP_CODE = 'FYR' and VRV.REF_VALUE = A.WorkYear
		
		
		INSERT INTO CES.EXAM
		(
				EXAM_ID,
				ASSET_GUID,
				EXAM_GROUP_SR_KEY,
				WORK_SR_KEY,
				EXAM_BASELINE_DATE,
				EXAM_PLANNED_DATE,
				EXAM_ACTUAL_DATE,
				EXAM_REVIEW_DATE,
				EXAM_SUBMISSION_DATE,
				EXAM_SIGNOFF_DATE,
				EXAM_TYPE_SR_KEY,
				EXAM_REQ_STATUS,
				EXAM_REPORT_STATUS,
				EXAM_COMPLETED_IND,
				EXAMINER_NAME,
				EXAMINER_COMMENT,
				REVIEWER_NAME,
				REVIEWER_COMMENT,
				SUPPLIER_SR_KEY,
				SUPPLIER_REPORT_FILENAME,
				CMI_SCORE,
				CMI_DATE,
				STRUC_DESCRIPTION,
				AT_OR_BETWEEN_STATIONS,
				SPAN_TEXT,
				CREATED_USER,
				CREATED_DATE,								
				EXAM_REQUIREMENT,
				IS_LAST_EXAM
		)
		SELECT 
				EXAM_ID,
				ASSET_GUID,
				EXAM_GROUP_SR_KEY,
				CASE WHEN EXAM_BASELINE_DATE > '2021-03-31' THEN WORK_SR_KEY
				ELSE NULL END AS WORK_SR_KEY,
				CASE WHEN ET.EXAM_TYPE = 'Detailed' OR ET.EXAM_TYPE = 'Visual' OR ET.EXAM_TYPE = 'Underwater' OR ET.EXAM_TYPE = 'Line Of Route' THEN NULL
				ELSE EXAM_BASELINE_DATE END AS EXAM_BASELINE_DATE,
				CASE WHEN ET.EXAM_TYPE = 'Detailed' OR ET.EXAM_TYPE = 'Visual' OR ET.EXAM_TYPE = 'Underwater' OR ET.EXAM_TYPE = 'Line Of Route' THEN NULL
				ELSE EXAM_PLANNED_DATE END AS EXAM_PLANNED_DATE,
				EXAM_ACTUAL_DATE,
				EXAM_REVIEW_DATE,
				EXAM_SUBMISSION_DATE,
				EXAM_SIGNOFF_DATE,
				EXS.EXAM_TYPE_SR_KEY,
				EXAM_REQ_STATUS,
				EXAM_REPORT_STATUS,
				EXAM_COMPLETED_IND,
				EXAMINER_NAME,
				EXAMINER_COMMENT,
				REVIEWER_NAME,
				REVIEWER_COMMENT,
				SUPPLIER_SR_KEY,
				SUPPLIER_REPORT_FILENAME,
				CMI_SCORE,
				CMI_DATE,
				STRUC_DESCRIPTION,
				AT_OR_BETWEEN_STATIONS,
				SPAN_TEXT,
				EXS.CREATED_USER,
				EXS.CREATED_DATE,								
				EXAM_REQUIREMENT,
				'N'
		from CES.EXAM_STG EXS
		INNER JOIN CES.EXAM_TYPE ET ON ET.EXAM_TYPE_SR_KEY = EXS.EXAM_TYPE_SR_KEY


		--Update the Records ISLAST = 'N' for all Asset and Exam Type
		UPDATE t1 SET 
		t1.IS_LAST_EXAM = 'N',
		t1.UPDATED_DATE = @CurrentDate,
		t1.UPDATED_USER = @User
		FROM CES.Exam t1
		Inner Join CES.EXAM_STG t2 ON t1.ASSET_GUID = t2.ASSET_GUID AND t1.EXAM_TYPE_SR_KEY = t2.EXAM_TYPE_SR_KEY
		WHERE t1.IS_LAST_EXAM = 'Y';
		
		--Rank and Update the Record with ISLAST = 'Y' for based on Asset, ExamType
		UPDATE e
		SET IS_LAST_EXAM = 'Y',
		UPDATED_DATE = @CurrentDate,
		UPDATED_USER = @User
		FROM CES.EXAM e
		JOIN (
			SELECT 
				EXAM_SR_KEY
			FROM
				(SELECT ex.EXAM_SR_KEY,
						DENSE_RANK() OVER (PARTITION BY ex.ASSET_GUID, ex.EXAM_TYPE_SR_KEY 
						ORDER BY CASE WHEN RV.REF_VALUE ='In Progress' 
                            OR (RV.REF_VALUE IN ('Planned','Requested','Scheduled') AND ex.EXAM_ACTUAL_DATE IS NOT NULL)
                            OR (RV.REF_VALUE = 'Completed' AND ISNULL(RQ.REF_VALUE,'') <> 'Rejected by audit') THEN 1 ELSE 0 END DESC, 
						ISNULL(ex.EXAM_ACTUAL_DATE,CONVERT(DATE,'1/1/1900',103)) DESC, ex.EXAM_ID DESC) rnk
				 FROM CES.EXAM ex
				 Inner Join CES.EXAM_STG tex ON ex.ASSET_GUID = tex.ASSET_GUID and ex.EXAM_TYPE_SR_KEY = tex.EXAM_TYPE_SR_KEY
				 JOIN CES.REFERENCE_VALUE RV ON EX.EXAM_REQ_STATUS = RV.REF_VAL_SR_KEY				 
				 LEFT JOIN CES.REFERENCE_VALUE RQ ON EX.EXAM_REPORT_STATUS = RQ.REF_VAL_SR_KEY
				 WHERE ex.ISACTIVE =1
				)t
			WHERE rnk=1
			)f
		ON e.EXAM_SR_KEY = f.EXAM_SR_KEY
		
		
		COMMIT TRAN
		SET @Output = 1
	END TRY
	BEGIN CATCH
		IF (@@TRANCOUNT >0)
			ROLLBACK TRAN
		
		IF @ErrorMsg IS NULL
			SET @ErrorMsg = ERROR_MESSAGE() 
		
		SET @ErrorDescription = @ErrorMsg + 
							' Line Num:' + CONVERT(VARCHAR(5), ERROR_LINE()) + 
							',ErrorNum:' + CONVERT(VARCHAR(5), ERROR_NUMBER()) + 
							',Severity:' + CONVERT(VARCHAR(5), ERROR_SEVERITY()) + 
							',State:' + CONVERT(VARCHAR(10), ERROR_STATE()) + 
							',Procedure:' + CONVERT(VARCHAR(25), OBJECT_NAME(@@procid)) +
							',Procedure:' + CONVERT(VARCHAR(25), ERROR_PROCEDURE())

		SET @Output = 0;
		SELECT @Output AS SaveStatus,@ErrorMsg AS ErrorMsg;
		
		THROW 50000,@ErrorDescription,1;
	END CATCH
	SET NOCOUNT OFF
  END