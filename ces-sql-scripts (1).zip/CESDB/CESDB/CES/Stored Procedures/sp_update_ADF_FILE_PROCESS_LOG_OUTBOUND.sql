﻿/***************************************************************************************************************************************            
* Name						: [CES].[sp_update_ADF_FILE_PROCESS_LOG_OUTBOUND]             
* Created By				: Cognizant            
* Date Created				: 04-Jan-2021           
* Description				: This stored procedure maintains the dataConfiguration for updating max(IncrementalDate).  
* Input Parameters			: 
* Output Parameters			: N/A            
* Return Value				: N/A            
* Assumptions				: None    
* Execution Statement		: Exec [CES].[sp_update_ADF_FILE_PROCESS_LOG_OUTBOUND]  'a,b'
*								
* Modified Date     Modified By   Revision Number  Modifications            

*******************************************************************************************************************************************/ 

CREATE PROCEDURE [CES].[sp_update_ADF_FILE_PROCESS_LOG_OUTBOUND] 
				
(      
	@OutboundFileName			VARCHAR(255),
	@OutboundBaseFileName		VARCHAR(255),
	@OutboundFileProcessStatus	VARCHAR(255),
	@OutboundErrorDescription	VARCHAR(255),
	@OutboundFileProcessDate	DATETIME
)
AS

BEGIN
SET NOCOUNT ON;

	UPDATE [CES].[FILE_PROCESS_LOG] 
	SET 
	OUTBOUND_FILE_NAME = @OutboundFileName,
	UPDATED_USER = 'CES',
	UPDATED_DATE = getdate()
	WHERE FILE_NAME like '%'+@OutboundBaseFileName+'%'
	AND FILE_NAME!= @OutboundFileName AND FILE_NAME!= concat(@OutboundBaseFileName,'.jpg') AND FILE_NAME!= concat(@OutboundBaseFileName,'.png')
	
	
SET NOCOUNT OFF;
END

