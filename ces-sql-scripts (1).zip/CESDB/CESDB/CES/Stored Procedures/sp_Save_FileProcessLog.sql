﻿
/***************************************************************************************************************************************            
* Name						: sp_Save_FileProcessLog        
* Created By				: Cognizant            
* Date Created				: 03-Feb-2021           
* Description				: This stored procedure saves the file processing logs.  
* Input Parameters			:	File_Type VARCHAR(20) --possible values should be 'Task List Date Upload'/'Exam Data Upload'/'RA Bulk Upload'. Pls pass on accordingly
								File_Name VARCHAR(500) -- provide the file name
								Supplier_ID DECIMAL(18)-- Supplier Id
								Supplier_Name VARCHAR(64) --SUpplier Name , Either supplier ID or Supplier Name will be provided
								User_Key VARCHAR(64) -- User 64 bit  Key (if the upload is from UI)    
* Output Parameters			: Returns 1 for succesful save, else 0            
* Return Value				: N/A            
* Assumptions				: None    
* Execution Statement		: Exec [CES].sp_Save_FileProcessLog 'Task List Date Upload','CES_ExamData_Amey Rail_20200203123476.xlsx', 4, 'sdsffsfsf234gsg';
*								
* Modified Date     Modified By   Revision Number  Modifications            

*******************************************************************************************************************************************/ 



CREATE PROCEDURE [CES].[sp_Save_FileProcessLog]
	@File_Type     VARCHAR(50), 
	@File_Name     VARCHAR(500),
	@Supplier_ID   DECIMAL(18) = NULL, --Either Supplier ID or Supplier Name will be provided as input
	@Supplier_Name VARCHAR(64) = NULL,
	@User_Key      VARCHAR(64) = NULL -- EIther Supplier or User ID will be provided as input

AS
BEGIN

	SET NOCOUNT ON
	BEGIN TRY
		DECLARE
				@ErrorMsg	          VARCHAR(250),
				@ErrorDescription     VARCHAR(4000),
				@current_date		  DATETIME = GETDATE(),
				@File_Process_Status  VARCHAR(50)= 'Submitted',
				@Created_User         VARCHAR(64)= 'CES',
				@Isactive             BIT = 1,
				@Output			      BIT = 0

			--SET @Output = 0;
			
			IF (@File_Type IN ('Task List Date Upload','Exam Data Upload'))
			BEGIN
				IF (@Supplier_ID IS NULL AND @Supplier_Name IS NULL)
				BEGIN
					SET @ErrorMsg = 'Supplier value in input is missing';
					THROW 50000,@ErrorMsg,1;
				END
				ELSE IF (@Supplier_ID IS NULL AND @Supplier_Name IS NOT NULL)
				BEGIN
					SELECT @Supplier_ID = SUPPLIER_SR_KEY
					FROM CES.SUPPLIER
					WHERE ISACTIVE =1
					AND SUPPLIER_NAME = @Supplier_Name
				END
			END
			 
			IF (@File_Type IS NULL AND @File_Name IS NULL AND (@Supplier_ID IS NULL OR @User_Key IS NULL))
			BEGIN
				SET @ErrorMsg = 'Input parameter value is missing';
				THROW 50000,@ErrorMsg,1;
			END
 
			IF (@File_Type NOT IN ('Task List Date Upload','Exam Data Upload','RA Bulk Upload'))
			BEGIN
				SET @ErrorMsg = 'File Type is not correct.';
				THROW 50000,@ErrorMsg,1;
			END

			IF EXISTS (SELECT 1 FROM CES.FILE_PROCESS_LOG WHERE [FILE_NAME] = @File_Name)
			BEGIN
				SET @ErrorMsg = 'File name already exists and submitted for processing earlier.';
				THROW 50000,@ErrorMsg,1;
			END
		
		BEGIN TRAN
    
				INSERT INTO [CES].[FILE_PROCESS_LOG]
				      (
					     FILE_TYPE, 
						 [FILE_NAME],
						 FILE_SUBMISSION_DATE,
						 FILE_PROCESS_STATUS,
						 SUPPLIER_SR_KEY,
						 [USER_ID],
						 ISACTIVE,
						 CREATED_USER,
						 CREATED_DATE
                     )
					SELECT
						@File_Type, 
						@File_Name,
						@current_date,
						@File_Process_Status,
						@Supplier_ID,
						@User_Key,
						@Isactive,
						@Created_User,
						@current_date
		
		IF @@ERROR = 0
			SET @Output = 1
				
		COMMIT TRAN
		
		 SELECT @Output AS SaveStatus,NULL AS ErrorMsg;
	END TRY

	BEGIN CATCH
		IF (@@TRANCOUNT >0)
			ROLLBACK TRAN
		
		IF @ErrorMsg IS NULL
			SET @ErrorMsg = ERROR_MESSAGE() 
		
		SET @ErrorDescription = @ErrorMsg + 
							' Line Num:' + CONVERT(VARCHAR(5), ERROR_LINE()) + 
							',ErrorNum:' + CONVERT(VARCHAR(5), ERROR_NUMBER()) + 
							',Severity:' + CONVERT(VARCHAR(5), ERROR_SEVERITY()) + 
							',State:' + CONVERT(VARCHAR(10), ERROR_STATE()) + 
							',Procedure:' + CONVERT(VARCHAR(25), OBJECT_NAME(@@procid)) +
							',Procedure:' + CONVERT(VARCHAR(25), ERROR_PROCEDURE())

		SET @Output = 0;
		SELECT @Output AS SaveStatus,@ErrorMsg AS ErrorMsg;

		THROW 50000,@ErrorDescription,1;
	END CATCH

	SET NOCOUNT OFF
  END