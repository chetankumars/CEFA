﻿
/***************************************************************************************************************************************            
* Name						: sp_Get_RecommendationDtls_API           
* Created By				: Cognizant            
* Date Created				: 24-Feb-2021           
* Description				: This stored procedure retrive Recommendation list Details API. 
* Input Parameters			: JSON      
* Output Parameters			: N/A            
* Return Value				: N/A            
* Assumptions				: None    
* Execution Statement		: Exec [CES].sp_Get_RecommendationDtls_API '{
																			"region_name":"Southern",
																			"route_name": "Kent",
																			"pageno": 1,
																			"rowsperpage": 100
																		  }'
*								
* Modified Date     Modified By   Revision Number  Modifications            

*******************************************************************************************************************************************/ 



CREATE PROCEDURE [CES].[sp_Get_RecommendationDtls_API]
	@Input_JSON		NVARCHAR(MAX)
AS
BEGIN
	SET NOCOUNT ON
	BEGIN TRY
		DECLARE
				@ErrorMsg					VARCHAR(250),
				@result						NVARCHAR(MAX),
				@region_name	            VARCHAR(64),
				@route_name                 VARCHAR(64),
				@pageno						DECIMAL(18),
				@rowsperpage				DECIMAL(18),
				@totalresultcnt				INT,
				@ErrorDescription			VARCHAR(4000)
			
			
		DECLARE @tbl_org TABLE
		(
			ORG_SR_KEY	DECIMAL(18)
		)

		CREATE TABLE #tbl_Asset
		(
			ASSET_GUID		VARCHAR(32),
			ENG_LINE_REF	DECIMAL(18),
			RAILWAY_ID		VARCHAR(64),
			totalcount		INT
		)
		
		CREATE TABLE #tbl_RCMNSearchResultAPI
		(
				elr	                        VARCHAR(4),
				asset_guid	                VARCHAR(64),
				railway_id	                VARCHAR(64),
				exam_id						DECIMAL(18),
				recommendation_no           DECIMAL (18),
				recommendation_desc         VARCHAR(1000),
				[location]	                VARCHAR(128),
				work_category	            VARCHAR(64),
				quantity	                VARCHAR (45),
				risk_score                  VARCHAR(5),
				recommendation_status	    VARCHAR(64),
				action_no                   DECIMAL (18),  
				work_status                 VARCHAR(500),
                priority_year               VARCHAR(500),
				riskScore                   VARCHAR (5),
				severity                    VARCHAR (5),
				probability                 VARCHAR (5),
				extent                      VARCHAR (12),
                notes                       VARCHAR(4000),
				recommend_sr_key			DECIMAL(18)

		)

	    SELECT 
			@region_name = COALESCE(@region_name,CASE LOWER([key]) WHEN 'region_name' THEN [value] ELSE NULL END),
			@route_name = COALESCE(@route_name,CASE LOWER([key]) WHEN 'route_name' THEN [value] ELSE NULL END),
			@pageno = COALESCE(@pageno,CASE LOWER([key]) WHEN 'pageno' THEN [value] ELSE NULL END),
			@rowsperpage = COALESCE(@rowsperpage,CASE LOWER([key]) WHEN 'rowsperpage' THEN [value] ELSE NULL END)

		FROM	OPENJSON(@Input_JSON);


		-- Validation start

		IF (@region_name IS NULL OR @pageno IS NULL OR @rowsperpage IS NULL)
		BEGIN

			SET @ErrorMsg = 'Mandatory Input value is missing';
			DROP TABLE IF EXISTS #tbl_RCMNSearchResultAPI;
			DROP TABLE IF EXISTS #tbl_Asset;
			THROW 50000,@ErrorMsg,1;
		END

		IF (@rowsperpage > 100)
		BEGIN
			SET @ErrorMsg = 'Maximum number of assets can be returned is 100.';
			DROP TABLE IF EXISTS #tbl_AssetAccessDtlsAPI;
			THROW 50000,@ErrorMsg,1;
		END 

		
		INSERT INTO @tbl_org (ORG_SR_KEY)
		SELECT ORG_SR_KEY
		FROM CES.ORG
		WHERE REGION = @region_name
		AND (@route_name IS NULL OR (@route_name IS NOT NULL AND [ROUTE] = @route_name))
		AND ISACTIVE = 1 

		IF NOT EXISTS (SELECT 1 FROM @tbl_org)
		BEGIN
			SET @ErrorMsg = 'Region /Route Information passed in input is incorrect';
			DROP TABLE IF EXISTS #tbl_RCMNSearchResultAPI;
			DROP TABLE IF EXISTS #tbl_Asset;
			THROW 50000,@ErrorMsg,1;
		END
		-- Validation End

		INSERT INTO #tbl_Asset
		(ASSET_GUID,
		 ENG_LINE_REF,
		 RAILWAY_ID,
		 totalcount)
		SELECT
			ASSET_GUID,
			ENG_LINE_REF,
			RAILWAY_ID,
			totalcount
		FROM
		(
			SELECT
				ASSET_GUID,
				ENG_LINE_REF,
				RAILWAY_ID,
				ROW_NUMBER() OVER (ORDER BY ASSET_GUID) rnk, 
				(DENSE_RANK() OVER (ORDER BY ASSET_GUID)
				+ DENSE_RANK() OVER (ORDER BY ASSET_GUID DESC)
				-1) totalcount
			FROM ASSET a
			INNER JOIN @tbl_org o
			ON o.ORG_SR_KEY = a.ORG_SR_KEY
			WHERE --EXISTS (SELECT 1 FROM @tbl_org WHERE  ORG_SR_KEY = a.ORG_SR_KEY)
			 ISACTIVE =1
			GROUP BY
				ASSET_GUID,
				ENG_LINE_REF,
				RAILWAY_ID	
		)t
		WHERE t.rnk BETWEEN ((@pageno - 1) * @rowsperpage +1) AND (@pageno * @rowsperpage)


		INSERT INTO #tbl_RCMNSearchResultAPI
	   (
				elr,
				asset_guid,
				railway_id,
				exam_id,
				recommendation_no,
				recommendation_desc,
				[location],
				work_category,
				quantity,
				risk_score,
				recommendation_status,
				action_no,  
				work_status,
				priority_year,
				severity,
				probability,
				extent,
				riskScore,
				notes,
				recommend_sr_key
	
		)
		
			SELECT
					elr.ELR_CODE AS elr
					,ast.ASSET_GUID  AS asset_guid
	                ,ast.RAILWAY_ID AS railway_id
					,ex.EXAM_ID
					,r.RCMN_NUM AS recommendation_no
					,r.[DESCRIPTION] AS recommendation_desc
					,r.[LOCATION]   AS [location]
					,wc.REF_VALUE AS work_category
					,(CAST(r.QUANTITY AS VARCHAR(20)) + ' '+ r.QUANTITY_UNIT) AS quantity
					,r.RISK_SCORE AS risk_score
					,rs.REF_VALUE AS recommendation_status
					,ac.ACTION_NUM AS action_no
					,ac.work_status
					,ac.priority_year
					,ac.SEVERITY         AS  severity
                    ,ac.PROBABILITY      AS  probability
                    ,ac.EXTENT           AS  extent
					,ac.RISK_SCORE AS riskScore
					,ac.NOTES AS notes
					,r.RECOMMEND_SR_KEY
			FROM #tbl_Asset AS ast
			INNER JOIN [CES].ENGINE_LINE_REF AS elr
			ON elr.ELR_SR_KEY = ast.ENG_LINE_REF
			INNER JOIN [CES].EXAM AS ex
			ON ex.ASSET_GUID=ast.ASSET_GUID
			INNER JOIN [CES].RECOMMENDATION AS r
			ON r.exam_sr_key=ex.exam_sr_key
			LEFT JOIN CES.REFERENCE_VALUE AS wc
			ON wc.REF_VAL_SR_KEY = r.WORK_CATEGORY
			AND wc.ISACTIVE = 1
		    LEFT JOIN CES.REFERENCE_VALUE rs
			ON rs.REF_VAL_SR_KEY = r.RCMN_STATUS
			AND rs.ISACTIVE = 1	
			LEFT JOIN 
				(SELECT 
					ack.ACTION_NUM,
					acK.SEVERITY         AS  severity,
                    acK.PROBABILITY      AS  probability,
                    acK.EXTENT           AS  extent,
					ack.RISK_SCORE,
					ack.NOTES,
					ws.REF_VALUE  AS work_status,
			        py.REF_VALUE AS priority_year,
					ack.recommend_sr_key
				FROM [CES].[ACTION] AS ack
				LEFT JOIN CES.REFERENCE_VALUE AS ws
				ON ws.REF_VAL_SR_KEY = ack.WORK_STATUS
				AND ws.ISACTIVE = 1
				LEFT JOIN CES.REFERENCE_VALUE AS py
				ON py.REF_VAL_SR_KEY = ack.PRIORITY_YEAR
				AND py.ISACTIVE = 1
				WHERE ack.ISACTIVE = 1
				)ac
			ON ac.recommend_sr_key=r.recommend_sr_key
			
			WHERE ex.ISACTIVE= 1
			AND elr.ISACTIVE = 1
			AND r.ISACTIVE = 1
			
		

		SELECT TOP 1 @totalresultcnt = totalcount FROM #tbl_Asset


		--If no records are returned in search result
		IF  @totalresultcnt=0 
		BEGIN
			SET @result=
					(
						SELECT 
							JSON_QUERY(
										(
											select
												@pageno AS currentpage,
												@totalresultcnt AS totalcount,
												0 AS totalpages
											FOR JSON PATH,WITHOUT_ARRAY_WRAPPER
										)
							) searchdatacount,
							JSON_QUERY('[]') searchresult
						
						FOR JSON PATH,WITHOUT_ARRAY_WRAPPER, INCLUDE_NULL_VALUES
				)
		END	

		--If alt least 1 record is returned in search result
		ELSE
		BEGIN

				SET @result=
				(
					SELECT 
						JSON_QUERY(
									(
											SELECT
													@pageno AS currentpage,
													@totalresultcnt AS totalcount,
													CEILING(@totalresultcnt/@rowsperpage) AS totalpages
											FOR JSON PATH,WITHOUT_ARRAY_WRAPPER
									)
							) searchdatacount,
							(
								SELECT 									
									elr,
									asset_guid AS assetGuid,
									railway_id,
									exam_id AS examID,
									recommendationdtls= (SELECT 
															tb.recommendation_no AS recommendationNo,
															tb.recommendation_desc AS recommendationDesc,
															tb.[location],
															tb.work_category,
															tb.quantity,
															tb.risk_score,
															tb.recommendation_status AS recommendationStatus
			 												,actiondtls =( SELECT		
																					t.action_no AS actionNo,  
																					t.work_status AS workStatus,
																					t.priority_year AS priorityYear,
																					t.riskScore,
																					t.notes,
																					t.severity,
																					t.probability,
																					t.extent
																			FROM #tbl_RCMNSearchResultAPI AS t
																			WHERE t.recommend_sr_key = tb.recommend_sr_key
																			FOR JSON PATH, INCLUDE_NULL_VALUES)
														FROM #tbl_RCMNSearchResultAPI tb
														WHERE tb.exam_id = sr.exam_id
														GROUP BY tb.recommendation_no,
																tb.recommendation_desc,
																tb.[location],
																tb.work_category,
																tb.quantity,
																tb.risk_score,
																tb.recommendation_status,
																tb.exam_id,
																tb.recommend_sr_key
														FOR JSON PATH, INCLUDE_NULL_VALUES
													 )									
								FROM #tbl_RCMNSearchResultAPI AS sr
								GROUP BY asset_guid,
										elr,
										railway_id,
										exam_id
								FOR JSON PATH, INCLUDE_NULL_VALUES
							  ) searchresult
							FOR JSON PATH, INCLUDE_NULL_VALUES, WITHOUT_ARRAY_WRAPPER
					    )
	
		END

		--PRINT @result
		SELECT @result AS response, NULL AS ErrorMsg

	END TRY
	BEGIN CATCH

		IF @ErrorMsg IS NULL
			SET @ErrorMsg = ERROR_MESSAGE() 

		SET @ErrorDescription = @ErrorMsg + 
						' Line Num:' + CONVERT(VARCHAR(5), ERROR_LINE()) + 
						',ErrorNum:' + CONVERT(VARCHAR(5), ERROR_NUMBER()) + 
						',Severity:' + CONVERT(VARCHAR(5), ERROR_SEVERITY()) + 
						',State:' + CONVERT(VARCHAR(10), ERROR_STATE()) + 
						',Procedure:' + CONVERT(VARCHAR(25), OBJECT_NAME(@@procid)) +
						',Procedure:' + CONVERT(VARCHAR(25), ERROR_PROCEDURE());  

		
		SET @result=
					(
						SELECT 
							JSON_QUERY(
										(
											select
												@pageno AS currentpage,
												@totalresultcnt AS totalcount,
												0 AS totalpages
											FOR JSON PATH,WITHOUT_ARRAY_WRAPPER
										)
							) searchdatacount,
							JSON_QUERY('[]') searchresult
						
						FOR JSON PATH,WITHOUT_ARRAY_WRAPPER, INCLUDE_NULL_VALUES
				)

		SELECT @result AS response, @ErrorMsg AS ErrorMsg

		DROP TABLE IF EXISTS #tbl_RCMNSearchResultAPI;
		DROP TABLE IF EXISTS #tbl_Asset;
		

		THROW 50000,@ErrorDescription,1;

		
	END CATCH

	DROP TABLE IF EXISTS #tbl_RCMNSearchResultAPI;
	DROP TABLE IF EXISTS #tbl_Asset;
	SET NOCOUNT OFF
END