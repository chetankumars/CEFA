﻿/****** Object:  StoredProcedure [CES].[sp_Get_Progress_Report]    Script Date: 6/15/2021 5:51:33 AM ******/
--SET ANSI_NULLS ON
--GO
--SET QUOTED_IDENTIFIER ON
--GO

/***************************************************************************************************************************************            
* Name						: sp_Get_Progress_Report           
* Created By				: Cognizant            
* Date Created				: 09-Apr-2021           
* Description				: This stored procedure is to get the structure report data from CES DB based on non compliance exams count for Detailed, Visual, and Under water exams.   
* Input Parameters			: N/A      
* Output Parameters			: N/A            
* Return Value				: N/A            
* Assumptions				: None    
* Execution Statement		: EXEC [CES].[sp_Get_Progress_Report]	'{	
																		"period_id": 0,
																		"exam_type_id": 1
																	}'
*								
* Modified Date     Modified By   Revision Number  Modifications            

*******************************************************************************************************************************************/ 



CREATE PROCEDURE [CES].[sp_Get_Progress_Report] 
    @Input_JSON	NVARCHAR(MAX)
AS 


BEGIN
	SET NOCOUNT ON
    BEGIN TRY
		-- declare variables
		DECLARE
			
			@ErrorMsg			VARCHAR(250),
			@result				VARCHAR(MAX),
			@route_id			DECIMAL(18),
			@exam_type_id		DECIMAL(18),
			@dtl_exam_type_id	DECIMAL(18),
			@ve_exam_type_id	DECIMAL(18),
			@uw_exam_type_id	DECIMAL(18),
			@period_id			DECIMAL(18),
			@period_key			DECIMAL(18, 0),
			@year_id			DECIMAL(18, 0),
			@year				VARCHAR(30),
			@DATE				DATETIME = GETDATE(),
			@current_date		DATETIME = GETDATE(),
			@current_year		VARCHAR(30),
			@Report2_Title		VARCHAR(20) = 'ProgressReport',
			@year_start_dt		DATE,
			@start_dt_default	DATE  = CONVERT(DATE,'1/1/1900',103),
			@is_history_year	CHAR(1) = 'N',
			@states_count		DECIMAL(18,0)

			--Temp table creation
			DROP TABLE IF EXISTS #PR_KPI;
			CREATE TABLE #PR_KPI 
			(
				kpi					VARCHAR(64),
				kpi_key				DECIMAL(18),
				report_section_key	DECIMAL(18)
			)

			--retrieve input values from input Json 
			SELECT 
			@period_id = COALESCE(@period_id,CASE LOWER([key]) WHEN 'period_id' THEN [value] ELSE NULL END),	
			@exam_type_id = COALESCE(@exam_type_id,CASE LOWER([key]) WHEN 'exam_type_id' THEN [value] ELSE NULL END)
			FROM OPENJSON(@Input_JSON);		
			
			

			-- get exam type keys
			SELECT @dtl_exam_type_id = EXAM_TYPE_SR_KEY FROM CES.EXAM_TYPE WHERE EXAM_TYPE = 'Detailed' AND ISACTIVE = 1
			SELECT @ve_exam_type_id = EXAM_TYPE_SR_KEY FROM CES.EXAM_TYPE WHERE EXAM_TYPE = 'Visual' AND ISACTIVE = 1
			SELECT @uw_exam_type_id = EXAM_TYPE_SR_KEY FROM CES.EXAM_TYPE WHERE EXAM_TYPE = 'Underwater' AND ISACTIVE = 1

			--get period key and current year
			SET @current_year = CASE WHEN MONTH(@current_date)<=3 THEN CONCAT(YEAR(@current_date)-1,'/',YEAR(@current_date)) ELSE CONCAT(YEAR(@current_date),'/',YEAR(@current_date)+1) END
			SELECT @year_start_dt = CASE WHEN MONTH(@current_date)<=3 THEN Convert(DATETIME, CONCAT(YEAR(@current_date)-1,'/04','/01')) ELSE Convert(DATETIME, CONCAT(YEAR(@current_date),'/04','/01')) END
			SELECT  @period_key = [PERIOD_SR_KEY] FROM CES.[PERIOD] WHERE ISACTIVE=1 AND (( DATEDIFF(DAY, @year_start_dt, @current_date))+1 BETWEEN PERIOD_DAYS_FROM AND PERIOD_DAYS_TO )
			print @period_key
			--Validation steps and setting default values for parameters if it is empty or null, this is to get national level current period results
			--to validate exam type id
			SET @exam_type_id = CASE 
								WHEN @exam_type_id IS NOT NULL AND @exam_type_id=@dtl_exam_type_id THEN @dtl_exam_type_id
								WHEN @exam_type_id IS NOT NULL AND @exam_type_id=@ve_exam_type_id THEN @ve_exam_type_id
								WHEN @exam_type_id IS NOT NULL AND @exam_type_id=@uw_exam_type_id THEN @uw_exam_type_id
								ELSE 0 END
			

			IF @exam_type_id IS NULL OR @exam_type_id=0
				BEGIN
					SET @ErrorMsg = 'Invalid / null exam type id provided';					
					THROW 50000,@ErrorMsg,1;
				END	
			
			--to validate period id
			IF @period_id IS NULL
				SET @period_id = @period_key
			ELSE IF (@period_id IS NOT NULL)
				IF (@period_id >0)
					BEGIN
						IF NOT EXISTS (SELECT 1 FROM CES.[PERIOD] WHERE PERIOD_SR_KEY=@period_id AND ISACTIVE=1)
						BEGIN
							SET @ErrorMsg = 'Invalid period provided';
							THROW 50000,@ErrorMsg,1;
						END						
					END
				ELSE
					SET @period_id = @period_key
					
			--populate KPI table
			INSERT INTO #PR_KPI(kpi,kpi_key,report_section_key)(
			SELECT DISTINCT KPI_VALUE,KPI_KEY,REPORT_SECTION_KEY FROM [CES].[REPORTING] WHERE
			--PERIOD_SR_KEY=@period_id AND 
			REPORT_NAME=@Report2_Title
			)

			--Select states count 
			SET @states_count = 0 		
				SET @states_count = (SELECT COUNT(O.ORG_SR_KEY)
									FROM [CES].[ORG] O
									WHERE O.ISACTIVE = 1)

			-- Get required results set for structures report
			IF (@period_id=@period_key) 
			BEGIN	
				SET @result=
				(SELECT
			(
				SELECT K.kpi
					,[values] = (	
							SELECT 
							RS1.[route] AS [route],
							CASE WHEN (RS1.REPORT_SECTION_KEY=4) THEN CASE WHEN (RS1.count_assets>0) THEN FORMAT(RS1.count_assets, '0.00%') ELSE '' END ELSE FORMAT(RS1.count_assets, 'N0') END AS [value]
								FROM (
									SELECT O.ROUTE AS [route], RPS.KPI_VALUE AS kpi,RPS.REPORT_SECTION_KEY, 									
									CASE WHEN @exam_type_id=@dtl_exam_type_id THEN ISNULL(SUM(RPS.DETAILED_EXAMS),0) 
									WHEN @exam_type_id=@ve_exam_type_id THEN ISNULL(SUM(RPS.VISUAL_EXAMS),0) 
									WHEN @exam_type_id=@uw_exam_type_id THEN ISNULL(SUM(RPS.UNDERWATER_EXAMS),0) 
									ELSE 0 END AS  count_assets
									FROM [CES].ORG O LEFT JOIN [CES].[REPORTING] RPS ON O.ORG_SR_KEY=RPS.ORG_SR_KEY --AND  RP.PERIOD_SR_KEY=@period_id AND RP.REPORT_NAME=@Report2_Title
									AND RPS.KPI_VALUE=K.kpi AND RPS.REPORT_SECTION_KEY=K.report_section_key AND RPS.KPI_KEY=K.kpi_key AND RPS.PERIOD_SR_KEY=@period_id AND RPS.REPORT_NAME=@Report2_Title
									GROUP BY  O.ORG_SR_KEY,O.[ROUTE], RPS.KPI_VALUE, RPS.KPI_KEY,RPS.REPORT_SECTION_KEY
									UNION ALL
									SELECT 'National' AS [Route],N.kpi,N.REPORT_SECTION_KEY,CASE WHEN N.REPORT_SECTION_KEY=4 THEN ISNULL(N.[value]/NULLIF(CONVERT(decimal(18,2), @states_count), 0), 0) ELSE N.[value] END AS count_assets 
									FROM (
									SELECT RP.KPI_VALUE AS kpi,RP.REPORT_SECTION_KEY, 
									CASE WHEN @exam_type_id=@dtl_exam_type_id THEN ISNULL(SUM(RP.DETAILED_EXAMS),0) 
									WHEN @exam_type_id=@ve_exam_type_id THEN ISNULL(SUM(RP.VISUAL_EXAMS),0) 
									WHEN @exam_type_id=@uw_exam_type_id THEN ISNULL(SUM(RP.UNDERWATER_EXAMS),0)
									ELSE 0 END AS [value]
									FROM [CES].[REPORTING] RP
									WHERE RP.KPI_VALUE=K.kpi AND RP.REPORT_SECTION_KEY=K.report_section_key AND RP.KPI_KEY=K.kpi_key AND RP.PERIOD_SR_KEY=@period_id AND RP.REPORT_NAME=@Report2_Title
									GROUP BY RP.KPI_VALUE, RP.KPI_KEY,RP.REPORT_SECTION_KEY
									)N
								)RS1 
						FOR JSON PATH, INCLUDE_NULL_VALUES) 
			FROM #PR_KPI K
			ORDER BY K.report_section_key ASC, K.kpi_key ASC		
			FOR JSON PATH, INCLUDE_NULL_VALUES
			)kpi_result

			FOR JSON PATH, INCLUDE_NULL_VALUES, WITHOUT_ARRAY_WRAPPER
			)

			END
			ELSE  --- To  get history report 
			BEGIN 
			--print 'history report'
			SET @result=
			(	SELECT
			(
			SELECT K.kpi
					,[values] = (	
							SELECT 
							RS1.[route] AS [route],
							CASE WHEN (RS1.REPORT_SECTION_KEY=4) THEN CASE WHEN (RS1.count_assets>0) THEN FORMAT(RS1.count_assets, '0.00%') ELSE '' END ELSE FORMAT(RS1.count_assets, 'N0') END AS [value]
								FROM (
									SELECT O.ROUTE AS [route], RPS.KPI_VALUE AS kpi,RPS.REPORT_SECTION_KEY, 									
									CASE WHEN @exam_type_id=@dtl_exam_type_id THEN ISNULL(SUM(RPS.DETAILED_EXAMS),0) 
									WHEN @exam_type_id=@ve_exam_type_id THEN ISNULL(SUM(RPS.VISUAL_EXAMS),0) 
									WHEN @exam_type_id=@uw_exam_type_id THEN ISNULL(SUM(RPS.UNDERWATER_EXAMS),0) 
									ELSE 0 END AS  count_assets
									FROM [CES].ORG O LEFT JOIN [CES].[REPORTING_HISTORY] RPS ON O.ORG_SR_KEY=RPS.ORG_SR_KEY --AND  RP.PERIOD_SR_KEY=@period_id AND RP.REPORT_NAME=@Report2_Title
									AND RPS.KPI_VALUE=K.kpi AND RPS.REPORT_SECTION_KEY=K.report_section_key AND RPS.KPI_KEY=K.kpi_key AND RPS.PERIOD_SR_KEY=@period_id AND RPS.REPORT_NAME=@Report2_Title
									GROUP BY  O.ORG_SR_KEY,O.[ROUTE], RPS.KPI_VALUE, RPS.KPI_KEY,RPS.REPORT_SECTION_KEY
									UNION ALL
									SELECT 'National' AS [Route],N.kpi,N.REPORT_SECTION_KEY,CASE WHEN N.REPORT_SECTION_KEY=4 THEN ISNULL(N.[value]/NULLIF(CONVERT(decimal(18,2), @states_count), 0), 0) ELSE N.[value] END AS count_assets 
									FROM (
									SELECT RP.KPI_VALUE AS kpi,RP.REPORT_SECTION_KEY, 
									CASE WHEN @exam_type_id=@dtl_exam_type_id THEN ISNULL(SUM(RP.DETAILED_EXAMS),0) 
									WHEN @exam_type_id=@ve_exam_type_id THEN ISNULL(SUM(RP.VISUAL_EXAMS),0) 
									WHEN @exam_type_id=@uw_exam_type_id THEN ISNULL(SUM(RP.UNDERWATER_EXAMS),0)
									ELSE 0 END AS [value]
									FROM [CES].[REPORTING_HISTORY] RP
									WHERE RP.KPI_VALUE=K.kpi AND RP.REPORT_SECTION_KEY=K.report_section_key AND RP.KPI_KEY=K.kpi_key AND RP.PERIOD_SR_KEY=@period_id AND RP.REPORT_NAME=@Report2_Title
									GROUP BY RP.KPI_VALUE, RP.KPI_KEY,RP.REPORT_SECTION_KEY
									)N
								)RS1 
						FOR JSON PATH, INCLUDE_NULL_VALUES) 
			FROM #PR_KPI K
			ORDER BY K.report_section_key ASC, K.kpi_key ASC	
			FOR JSON PATH, INCLUDE_NULL_VALUES
			)kpi_result

			FOR JSON PATH, INCLUDE_NULL_VALUES, WITHOUT_ARRAY_WRAPPER
			)
			
			
			END	
		
			--Return json
			SELECT @result 
	END TRY

	BEGIN CATCH
		SET @ErrorMsg = ERROR_MESSAGE() + 
						' Line Num:' + CONVERT(VARCHAR(5), ERROR_LINE()) + 
						',ErrorNum:' + CONVERT(VARCHAR(5), ERROR_NUMBER()) + 
						',Severity:' + CONVERT(VARCHAR(5), ERROR_SEVERITY()) + 
						',State:' + CONVERT(VARCHAR(10), ERROR_STATE()) + 
						',Procedure:' + CONVERT(VARCHAR(25), OBJECT_NAME(@@procid)) +
						',Procedure:' + CONVERT(VARCHAR(25), ERROR_PROCEDURE());  
		
		THROW 50000,@ErrorMsg,1;
	END CATCH
	

	SET NOCOUNT OFF
  END