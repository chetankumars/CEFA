﻿
/***************************************************************************************************************************************            
* Name						: sp_Get_RiskAssessment_Form_Dtls          
* Created By				: Cognizant            
* Date Created				: 12-Feb-2021           
* Description				: This stored procedure provides the search result for the Risk Assessment Details. 
* Input Parameters			: Asset_GUID & Exam_Type_ID   
* Output Parameters			: Assessment Date, Review Date & Expiry Date            
* Return Value				: N/A            
* Assumptions				: None    
* Execution Statement		: Exec [CES].sp_Get_RiskAssessment_Form_Dtls '3978559DD3F845D9E04400306E4AD01A',3;
*								
* Modified Date     Modified By   Revision Number  Modifications            

*******************************************************************************************************************************************/ 



CREATE PROCEDURE [CES].[sp_Get_RiskAssessment_Form_Dtls]
	@Asset_GUID		    VARCHAR(32),
	@Exam_Type_ID       DECIMAL(18)  

AS 


BEGIN
	SET NOCOUNT ON
    BEGIN TRY
		DECLARE
				@ErrorMsg					VARCHAR(250),
				@assessment_date			DATE,
				@review_date				DATE, 
				@expiry_date				DATE,
				@current_date				DATE = DATEADD(dd, DATEDIFF(dd, 0, GETDATE()), 0),
				@Exam_Type					VARCHAR(32),
				@Compliance_Date			DATE,
				@Freq_Months				DECIMAL(10,2),
				@RA_REVIEW_TOLERANCE_MONTHS DECIMAL(5),
				@RA_EXPIRY_TOLERANCE_MONTHS DECIMAL(5),
				@REVIEW_TOLERANCE_WEEKS		DECIMAL(5),
				@ve_comp_stat				VARCHAR(200),
				@de_comp_stat				VARCHAR(200),
				@uw_comp_stat				VARCHAR(200),
				@result						VARCHAR(MAX),
				@asset_input				NVARCHAR(MAX),
				@Frequency					VARCHAR(50)
	
		DECLARE  @tbl_ComplianceStatus TABLE
		(
				asset_guid				VARCHAR(32),
				dtl_compliance			VARCHAR(100),
				dtl_risk_status			VARCHAR(100),
				dtl_frequency			VARCHAR(60),
				dtl_exam_type_id		DECIMAL(18),
				dtl_comp_date			DATE,
				dtl_exam_planned_date	DATE,
				dtl_exam_actual_date	DATE,			
				dtl_supplier			VARCHAR(64),

				ve_compliance			VARCHAR(100),
				ve_risk_status			VARCHAR(100),
				ve_frequency			VARCHAR(60),
				ve_exam_type_id			DECIMAL(18),
				ve_comp_date			DATE,
				ve_exam_planned_date	DATE,
				ve_exam_actual_date		DATE,			
				ve_supplier				VARCHAR(64),

				uw_compliance			VARCHAR(100),
				uw_risk_status			VARCHAR(100),
				uw_frequency			VARCHAR(60),
				uw_exam_type_id			DECIMAL(18),
				uw_comp_date			DATE,
				uw_exam_planned_date	DATE,
				uw_exam_actual_date		DATE,			
				uw_supplier				VARCHAR(64)

		)

		SET @asset_input = '["' + @Asset_GUID + '"]'

		--Retrieving the compliance status for the asset
		INSERT INTO @tbl_ComplianceStatus
		(
			asset_guid,
			dtl_compliance,
			dtl_risk_status,
			dtl_frequency,
			dtl_exam_type_id,
			dtl_comp_date,
			dtl_exam_planned_date,
			dtl_exam_actual_date,			
			dtl_supplier,

			ve_compliance,
			ve_risk_status,
			ve_frequency,
			ve_exam_type_id,
			ve_comp_date,
			ve_exam_planned_date,
			ve_exam_actual_date,			
			ve_supplier,

			uw_compliance,
			uw_risk_status,
			uw_frequency,
			uw_exam_type_id,
			uw_comp_date,
			uw_exam_planned_date,
			uw_exam_actual_date,			
			uw_supplier
		)
		EXEC [CES].[sp_Get_Asset_Compliance_Risk_Status] @asset_input,@current_date

		SELECT
			@ve_comp_stat = ve_compliance,
			@de_comp_stat = dtl_compliance,
			@uw_comp_stat = uw_compliance
		FROM @tbl_ComplianceStatus t

		SELECT
			@Exam_Type = EXAM_TYPE
		FROM CES.EXAM_TYPE
		WHERE EXAM_TYPE_SR_KEY = @Exam_Type_ID

		SELECT
			@Compliance_Date = COMP_DATE,
			@Freq_Months = ISNULL(INTERVAL_YEARS,0)*12 + ISNULL(INTERVAL_MONTHS,0) + ISNULL(INTERVAL_DAYS,0)/30,
			@Frequency = CAST(ISNULL(INTERVAL_YEARS,0) AS VARCHAR) +'y'+ CAST(ISNULL(INTERVAL_MONTHS,0) AS VARCHAR) + 'm' + CAST(ISNULL(INTERVAL_DAYS,0) AS VARCHAR) + 'd'
		FROM 
		(
			SELECT 
				COMP_DATE,
				INTERVAL_YEARS,
				INTERVAL_MONTHS,
				INTERVAL_DAYS,
				ROW_NUMBER() OVER (ORDER BY EFFECTIVE_FROM_DT DESC) rnk
			FROM CES.COMPLIANCE c
			WHERE ASSET_GUID = @Asset_GUID
			AND EXAM_TYPE_SR_KEY = @Exam_Type_ID
			AND @current_date BETWEEN EFFECTIVE_FROM_DT AND ISNULL(EFFECTIVE_TO_DT,CONVERT(DATE,'31/12/9999',103))
		)c
		WHERE rnk = 1

		--SELECT 
		--	@Freq_Months = ISNULL(INTERVAL_YEARS,0)*12 + ISNULL(INTERVAL_MONTHS,0) + ISNULL(INTERVAL_DAYS,0)/30,
		--	@Frequency = CAST(ISNULL(INTERVAL_YEARS,0) AS VARCHAR) +'y'+ CAST(ISNULL(INTERVAL_MONTHS,0) AS VARCHAR) + 'm' + CAST(ISNULL(INTERVAL_DAYS,0) AS VARCHAR) + 'd'
		--FROM
		--(
		--	SELECT
		--		INTERVAL_YEARS,
		--		INTERVAL_MONTHS,
		--		INTERVAL_DAYS,
		--		ROW_NUMBER() OVER (ORDER BY EFFECTIVE_FROM_DT DESC) AS rnk
		--	FROM CES.EXAM_CYCLE
		--	WHERE ASSET_GUID = @Asset_GUID
		--	AND EXAM_TYPE_SR_KEY = @Exam_Type_ID
		--	AND @current_date BETWEEN EFFECTIVE_FROM_DT AND ISNULL(EFFECTIVE_TO_DT,CONVERT(DATE,'31/12/9999',103))
		--)f
		--WHERE rnk =1
		
		SELECT
			@RA_REVIEW_TOLERANCE_MONTHS = RA_REVIEW_TOLERANCE_MONTHS,
			@RA_EXPIRY_TOLERANCE_MONTHS = RA_EXPIRY_TOLERANCE_MONTHS,
			@REVIEW_TOLERANCE_WEEKS = REVIEW_TOLERANCE_WEEKS
		FROM	[CES].COMPLIANCE_TOLERANCE
		WHERE EXAM_TYPE_SR_KEY = @Exam_Type_ID
		AND ISNULL(@Freq_Months,0) BETWEEN FREQ_INTERVAL_MONTHS_FROM AND FREQ_INTERVAL_MONTHS_TO

		SET @result = (
							SELECT
							(
								SELECT
									ast.asset_guid,
									elr.ELR_CODE AS elr,
									ast.railway_id,
									asg.ASSET_GROUP_DESC AS asset_grp,
									asst.ASSET_TYPE_DESC AS asset_type,
									rv.REF_VALUE AS ops_status,
									ast.owning_party,
									rvp.REF_VALUE AS prim_material
								FROM CES.ASSET ast
								INNER JOIN CES.ENGINE_LINE_REF elr
								ON ast.ENG_LINE_REF = elr.ELR_SR_KEY
								INNER JOIN CES.ASSET_GROUP asg
								ON asg.ASSET_GROUP_SR_KEY = ast.ASSET_GROUP_SR_KEY
								INNER JOIN CES.ASSET_TYPE asst
								ON asst.ASSET_TYPE_SR_KEY = ast.ASSET_TYPE_SR_KEY
								LEFT JOIN CES.REFERENCE_VALUE rv
								ON rv.REF_VAL_SR_KEY = ast.OPERATIONAL_STATUS
								AND rv.ISACTIVE = 1
								LEFT JOIN CES.REFERENCE_VALUE rvp
								ON rvp.REF_VAL_SR_KEY = ast.PRIMARY_MATERIAL
								AND rvp.ISACTIVE = 1
								WHERE 
									ast.ISACTIVE = 1
									AND elr.ISACTIVE = 1
									AND asg.ISACTIVE = 1
									AND asst.ISACTIVE = 1
									AND ast.ASSET_GUID = @Asset_GUID 
								FOR JSON PATH,INCLUDE_NULL_VALUES
							)assetdtls,
							(
								SELECT
									et.exam_type,
									CASE WHEN et.exam_type = 'Detailed' THEN @de_comp_stat
										 WHEN et.exam_type = 'Visual' THEN @ve_comp_stat
										 WHEN et.exam_type = 'Underwater' THEN @uw_comp_stat
									END AS comp_status,
									e.exam_status,
									ISNULL(@Frequency,'0y0m0d') AS exam_freq,
									@Compliance_Date AS comp_date,
									e.exam_planned_date,
									e.exam_actual_date,
									e.exam_review_date,
									e.exam_signoff_date
								FROM CES.EXAM_TYPE et
								LEFT JOIN
									(
										SELECT
											rv.REF_VALUE AS exam_status,
											ex.exam_planned_date,
											ex.exam_actual_date,
											ex.exam_review_date,
											ex.exam_signoff_date,
											--wrk.EXAM_TYPE_SR_KEY
											ex.EXAM_TYPE_SR_KEY
										FROM  CES.EXAM ex
										--INNER JOIN CES.WORK wrk
										--ON ex.WORK_SR_KEY = wrk.WORK_SR_KEY
										LEFT JOIN CES.REFERENCE_VALUE rv
										ON rv.REF_VAL_SR_KEY = ex.EXAM_REQ_STATUS
										AND rv.ISACTIVE = 1

										WHERE
											ex.ISACTIVE = 1
											--AND wrk.ISACTIVE = 1
											--AND wrk.ASSET_GUID = @Asset_GUID
											--AND @current_date BETWEEN wrk.WORK_YR_START_DT AND wrk.WORK_YR_END_DT
											--AND wrk.EXAM_TYPE_SR_KEY = @Exam_Type_ID
											AND ex.ASSET_GUID = @Asset_GUID
											AND ex.EXAM_TYPE_SR_KEY = @Exam_Type_ID
											AND ex.IS_LAST_EXAM = 'Y'
										)e
									ON et.EXAM_TYPE_SR_KEY = e.EXAM_TYPE_SR_KEY
									WHERE et.ISACTIVE = 1
									AND et.EXAM_TYPE_SR_KEY = @Exam_Type_ID
								FOR JSON PATH,INCLUDE_NULL_VALUES
							)exam_dtls,
							JSON_QUERY(
										(
											SELECT
												CONVERT(DATE,@current_date,103) AS  assessment_date,
												DATEADD(month,ISNULL(@RA_REVIEW_TOLERANCE_MONTHS,0), @current_date) AS review_date,
												DATEADD(month,ISNULL(@RA_EXPIRY_TOLERANCE_MONTHS,0),DATEADD(week, ISNULL(@REVIEW_TOLERANCE_WEEKS,0), @Compliance_Date)) AS [expiry_date]
											FOR JSON PATH,INCLUDE_NULL_VALUES,WITHOUT_ARRAY_WRAPPER
										)
								)RAData
							FOR JSON PATH,WITHOUT_ARRAY_WRAPPER, INCLUDE_NULL_VALUES
						)

		SELECT @result
	END TRY

	BEGIN CATCH
		SET @ErrorMsg = ERROR_MESSAGE() + 
						' Line Num:' + CONVERT(VARCHAR(5), ERROR_LINE()) + 
						',ErrorNum:' + CONVERT(VARCHAR(5), ERROR_NUMBER()) + 
						',Severity:' + CONVERT(VARCHAR(5), ERROR_SEVERITY()) + 
						',State:' + CONVERT(VARCHAR(10), ERROR_STATE()) + 
						',Procedure:' + CONVERT(VARCHAR(25), OBJECT_NAME(@@procid)) +
						',Procedure:' + CONVERT(VARCHAR(25), ERROR_PROCEDURE());  

		THROW 50000,@ErrorMsg,1;
	END CATCH

	SET NOCOUNT OFF
  END