﻿/***************************************************************************************************************************************            
* Name						: sp_Save_Tasklist_ExamDts_UI     
* Created By				: Cognizant            
* Date Created				: 28-Jan-2021           
* Description				: This stored procedure saves the exam dates updated by the supplier through UI.  
* Input Parameters			: JSON   
* Output Parameters			: Returns 1 for succesful save, else 0            
* Return Value				: N/A            
* Assumptions				: None    
* Execution Statement		: EXEC CES.sp_Save_Tasklist_ExamDts_UI '[
																	{
																	  "examkey": 4,
																	  "plannedExamDate": "22/09/2021",
																	  "actualExamDate": "17/07/2021",
																	  "otherSupplierComment": "sfsffs",
																	  "crId": 12
	
																	},
																	{
																	  "examkey": 6,
																	  "plannedExamDate": "09/11/2021",
																	  "actualExamDate": "",
																	  "otherSupplierComment": "",
																	  "crId": ""
																	}
																]','abcxyz1234werfg'

*								
* Modified Date     Modified By   Revision Number  Modifications            

*******************************************************************************************************************************************/ 



CREATE PROCEDURE [CES].[sp_Save_Tasklist_ExamDts_UI]
	@Input_JSON		NVARCHAR(MAX),
	@UserKey		VARCHAR(64)

AS 

BEGIN
	SET NOCOUNT ON
    BEGIN TRY
		DECLARE
				@ErrorMsg			VARCHAR(250),
				@ErrorDescription   VARCHAR(4000),
				@Output				BIT = 0,
				@CurrentDate		DATETIME  = GETDATE(),
				@ValidationDate		DATETIME = DATEADD(dd, DATEDIFF(dd, 0, GETDATE()), 0)

		DROP TABLE IF EXISTS #tmpAstExamDtls_UI
		DROP TABLE IF EXISTS #tmpExamData

		CREATE TABLE #tmpAstExamDtls_UI
		(
			Exam_key		     DECIMAL(18),
			Exam_Planned_Date	 DATE,
			Exam_Actual_Date	 DATE,
			Supplier_Comment	 VARCHAR(2000),
			CRID                 VARCHAR(20)
		)

		CREATE TABLE #tmpExamData
		(
			ASSET_GUID				VARCHAR(32),
			EXAM_TYPE_SR_KEY		DECIMAL(9)
		)

		DECLARE @result TABLE
		(
			[Output]	SMALLINT,
			ErrorMsg	VARCHAR(4000)	
		) 
		
		--Parsing the input JSON and gathering the records					
		INSERT INTO #tmpAstExamDtls_UI
		(
			Exam_key,
			Exam_Planned_Date,
			Exam_Actual_Date,
			Supplier_Comment,
			CRID
		)
		SELECT
				
			ast.examkey,
			CONVERT(DATE,ast.plannedExamDate,103) AS plannedExamDate,
			CONVERT(DATE,ast.actualExamDate,103) AS actualExamDate,
			ast.otherSupplierComment,
			ast.crID
		FROM	OPENJSON(@Input_JSON)
		WITH 
			(
				examkey				 DECIMAL(18),
				plannedExamDate		 VARCHAR(10),
				actualExamDate		 VARCHAR(10),
				otherSupplierComment VARCHAR(2000),
				crId                 VARCHAR(20)

			) AS ast

		

		--- Validation Checks -- Start
		

		IF EXISTS (	SELECT 1 
					FROM #tmpAstExamDtls_UI
					WHERE Exam_Planned_Date < @ValidationDate)
		BEGIN
				SET @ErrorMsg = 'The planned date cannot be in the past';
				THROW 50000,@ErrorMsg,1;
		END

		IF EXISTS (	SELECT 1 
					FROM #tmpAstExamDtls_UI
					WHERE Exam_Actual_Date > @ValidationDate)
		BEGIN
				SET @ErrorMsg = 'The exam date cannot be greater than current date';
				THROW 50000,@ErrorMsg,1;
		END

		IF EXISTS (	SELECT 1 
					FROM #tmpAstExamDtls_UI
					WHERE Exam_Actual_Date IS NULL AND Exam_Planned_Date IS NULL)
		BEGIN
				SET @ErrorMsg = 'Both the planned and exam dates are missing for some or all records';
				THROW 50000,@ErrorMsg,1;
		END

		IF EXISTS (
					SELECT 1 
					FROM #tmpAstExamDtls_UI t
					INNER JOIN  CES.EXAM ex
					ON t.Exam_key = ex.EXAM_SR_KEY
					WHERE ex.EXAM_COMPLETED_IND = 'Y'
					AND ex.ISACTIVE = 1 
				  )
		BEGIN
				SET @ErrorMsg = 'The Exam is in completed status';
				THROW 50000,@ErrorMsg,1;
		END

		--- Validation Checks -- End

		--This table will be used by child SP [sp_Update_EXAM_ISLASTFLG] called later
		INSERT INTO #tmpExamData
		(
			ASSET_GUID,
			EXAM_TYPE_SR_KEY
		) 
		SELECT DISTINCT
			ex.ASSET_GUID,
			ex.EXAM_TYPE_SR_KEY
		FROM #tmpAstExamDtls_UI t
		INNER JOIN CES.EXAM ex
		ON ex.EXAM_SR_KEY = t.Exam_key
		WHERE (ex.EXAM_ACTUAL_DATE IS NULL AND t.Exam_Actual_Date IS NOT NULL)
		OR (ex.EXAM_ACTUAL_DATE IS NOT NULL AND ex.EXAM_ACTUAL_DATE <> t.Exam_Actual_Date)
				

		--BEGIN TRAN ExamDts
		BEGIN TRAN

			---Update the Exam Date and Planned Date if available
			UPDATE ex
			SET 
				EXAM_PLANNED_DATE = ISNULL(t.Exam_Planned_Date,ex.EXAM_PLANNED_DATE),
				EXAM_ACTUAL_DATE = ISNULL(t.Exam_Actual_Date,ex.EXAM_ACTUAL_DATE),
				SUPPLIER_COMMENTS = t.Supplier_Comment,
			    CHANGE_REQ_ID = t.crid,
				UPDATED_USER = @UserKey,
				UPDATED_DATE = @CurrentDate
			FROM #tmpAstExamDtls_UI t
			INNER JOIN CES.EXAM ex
			ON ex.EXAM_SR_KEY = t.Exam_key


			-- SP to update IsLast Exam flag
			INSERT INTO @result([Output],ErrorMsg)
			EXEC [CES].[sp_Update_EXAM_ISLASTFLG] @UserKey 
		 
		 --COMMIT TRAN ExamDts
		 COMMIT TRAN

		 SET @Output = 1

		 SELECT @Output AS SaveStatus,NULL AS ErrorMsg;
	END TRY

	BEGIN CATCH
		--IF (@@TRANCOUNT >0)
		--	ROLLBACK TRAN ExamDts

		IF (@@TRANCOUNT >0)
			ROLLBACK TRAN 
		
		IF @ErrorMsg IS NULL
			SET @ErrorMsg = ERROR_MESSAGE() 
		
		SET @ErrorDescription = @ErrorMsg + 
							' Line Num:' + CONVERT(VARCHAR(5), ERROR_LINE()) + 
							',ErrorNum:' + CONVERT(VARCHAR(5), ERROR_NUMBER()) + 
							',Severity:' + CONVERT(VARCHAR(5), ERROR_SEVERITY()) + 
							',State:' + CONVERT(VARCHAR(10), ERROR_STATE()) + 
							',Procedure:' + CONVERT(VARCHAR(25), OBJECT_NAME(@@procid)) +
							',Procedure:' + CONVERT(VARCHAR(25), ERROR_PROCEDURE())

		SET @Output = 0;
		SELECT @Output AS SaveStatus,@ErrorMsg AS ErrorMsg;

		DROP TABLE IF EXISTS #tmpAstExamDtls_UI;
		DROP TABLE IF EXISTS #tmpExamData;
		THROW 50000,@ErrorDescription,1;
	END CATCH

	DROP TABLE IF EXISTS #tmpAstExamDtls_UI;
	DROP TABLE IF EXISTS #tmpExamData;
	SET NOCOUNT OFF
  END
