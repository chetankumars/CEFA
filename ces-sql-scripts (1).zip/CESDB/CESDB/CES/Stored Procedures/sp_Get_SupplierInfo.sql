﻿/***************************************************************************************************************************************            
* Name						: sp_Get_SupplierInfo            
* Created By				: Cognizant            
* Date Created				: 17-Dec-2020           
* Description				: This stored procedure fetches the supplier info   
* Input Parameters			: User ID     
* Output Parameters			: N/A            
* Return Value				: N/A            
* Assumptions				: None    
* Execution Statement		: Exec [CES].sp_Get_SupplierInfo 2
*								
* Modified Date     Modified By   Revision Number  Modifications            

*******************************************************************************************************************************************/ 



CREATE PROCEDURE [CES].[sp_Get_SupplierInfo]
	@User_ID		DECIMAL(18)
	
AS
BEGIN

	SET NOCOUNT ON
	BEGIN TRY
		DECLARE
				@ErrorMsg	VARCHAR(250)

		SELECT
			supp.SUPPLIER_SR_KEY AS supplier_id,
			supp.SUPPLIER_NAME AS supplier_name
		FROM	[CES].SUPPLIER supp
		WHERE EXISTS (
					SELECT 1 FROM [CES].ENTITLEMENT ent
					WHERE ent.ISACTIVE = 1
					AND supp.SUPPLIER_SR_KEY = ent.SUPPLIER_SR_KEY
					AND ent.USER_SR_KEY = @User_ID
				)
		AND	supp.ISACTIVE = 1
		
		FOR JSON AUTO,WITHOUT_ARRAY_WRAPPER


	END TRY
	BEGIN CATCH

		ROLLBACK TRAN
		SET @ErrorMsg = ERROR_MESSAGE() + 
						' Line Num:' + CONVERT(VARCHAR(5), ERROR_LINE()) + 
						',ErrorNum:' + CONVERT(VARCHAR(5), ERROR_NUMBER()) + 
						',Severity:' + CONVERT(VARCHAR(5), ERROR_SEVERITY()) + 
						',State:' + CONVERT(VARCHAR(10), ERROR_STATE()) + 
						',Procedure:' + CONVERT(VARCHAR(25), OBJECT_NAME(@@procid)) +
						',Procedure:' + CONVERT(VARCHAR(25), ERROR_PROCEDURE());  

		THROW 50000,@ErrorMsg,1;
	END CATCH

	SET NOCOUNT OFF
END