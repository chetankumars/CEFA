﻿/***************************************************************************************************************************************            
* Name						: [CES].[sp_Insert_Work_Exam_Migration_ADF]     
* Created By				: Cognizant            
* Date Created				: 28-Feb-2021           
* Description				: This stored procedure updates the Exam Table ISLAST flag through ADF.  
* Input Parameters			: JSON   
* Output Parameters			: Returns 1 for succesful save, else 0            
* Return Value				: N/A            
* Assumptions				: None    
* Execution Statement		: EXEC [CES].[sp_Insert_Work_Exam_Migration_ADF] 
*								
* Modified Date     Modified By   Revision Number  Modifications            

*******************************************************************************************************************************************/ 
CREATE PROCEDURE [CES].[sp_Insert_Work_Exam_Migration_ADF]
AS 
BEGIN
	SET NOCOUNT ON
    BEGIN TRY
		DECLARE
				@ErrorMsg			VARCHAR(250),
				@ErrorDescription   VARCHAR(4000),
				@Output				BIT = 0,
				@CurrentDate		DATETIME  = GETDATE(),
				@User				VARCHAR(16) = 'CARRS',
				@exam_id			VARCHAR(20) = 'exam_id',
				@WorkInsertQuery	Varchar(max),
				@ExamUpdateQuery	Varchar(max)
	
	------------------------------------
	BEGIN TRAN

	IF COL_LENGTH('CES.WORK', 'exam_id') IS NOT NULL
	BEGIN
		EXECUTE sp_executesql 'ALTER TABLE CES.WORK DROP COLUMN exam_id';
	END

	ALTER TABLE CES.WORK
	ADD exam_id decimal(18)

	COMMIT TRAN

	BEGIN TRAN

	SET @WorkInsertQuery = 'INSERT INTO CES.WORK
		(
				WORK_SR_KEY,
				WORK_YEAR_KEY,
				WORK_YR_START_DT,
				WORK_YR_END_DT,
				ORG_SR_KEY,
				ASSET_GUID,
				EXAM_TYPE_SR_KEY,
				EXAM_DUE_DATE,
				WORK_STATUS,
				NR_INTERNAL_NOTES,
				COMMENTS_TO_SEC,
				CREATED_USER,
				CREATED_DATE,
				'+@exam_id+'
		)
		Select
		NEXT VALUE FOR CES.SEQ_WORK_KEY,
		VRV.REF_VAL_SR_KEY AS WorkYear_SR_KEY, 
		concat(SUBSTRING(A.WorkYear, 1, 4), ''-04-01'') as WorkStartYear,
		concat(SUBSTRING(A.WorkYear, 6, 4), ''-03-31'') as WorkEndYear,
		A.ORG_SR_KEY,
		A.ASSET_GUID,
		A.EXAM_TYPE_SR_KEY,
		A.EXAM_DUE_DATE,
		TRV.REF_VAL_SR_KEY AS TaskListKey,
		A.INTERNAL_NOTES,
		A.COMMENT_TO_SEC,		
		'''+@User+''',
		'''+CONVERT(varchar,@CurrentDate,121)+''',
		A.EXAM_ID
		from (
		Select
		EX.EXAM_ID,
		EX.ASSET_GUID,
		AST.ORG_SR_KEY,
		EX.EXAM_TYPE_SR_KEY,
		ET.EXAM_TYPE,
		EX.EXAM_BASELINE_DATE AS EXAM_DUE_DATE,
		RV.REF_VALUE,	
		CASE 
		WHEN ET.EXAM_TYPE = ''Detailed'' OR ET.EXAM_TYPE = ''Visual'' OR ET.EXAM_TYPE = ''Underwater'' OR ET.EXAM_TYPE = ''Line Of Route'' THEN 
			CASE
			WHEN RV.REF_VALUE =''Planned'' THEN ''Ready for CEFA PM review'' 
			WHEN RV.REF_VALUE =''Requested'' THEN ''Issued'' 
			Else ''Agreed'' END
		Else ''Agreed''
		END AS TaskListStatus,
		EX.INTERNAL_NOTES,
		EX.COMMENT_TO_SEC,
		CASE
		WHEN MONTH(EXAM_BASELINE_DATE) > 3 THEN CONCAT(YEAR(EXAM_BASELINE_DATE), ''/'',YEAR(DATEADD(YEAR, 1, EXAM_BASELINE_DATE)))
		ELSE CONCAT(YEAR(DATEADD(YEAR, -1, EXAM_BASELINE_DATE)),''/'', YEAR(EXAM_BASELINE_DATE))
		END AS WorkYear,
		EX.WORK_SR_KEY
		from CES.Exam EX
		Inner Join CES.Asset AST ON AST.ASSET_GUID = EX.ASSET_GUID
		INner Join CES.Reference_Value RV ON  RV.REF_VAL_SR_KEY = EXAM_REQ_STATUS
		Inner Join CES.Exam_Type ET ON ET.EXAM_TYPE_SR_KEY = EX.EXAM_TYPE_SR_KEY
		WHERE
		EXAM_BASELINE_DATE > ''2021-03-31'')A
		INner Join CTL_CES_ADL_CONTROL.vw_ADF_Reference_Type_Value TRV ON TRV.REF_TYP_CODE = ''TLS'' and TRV.REF_VALUE = A.TaskListStatus
		Inner Join CTL_CES_ADL_CONTROL.vw_ADF_Reference_Type_Value VRV ON VRV.REF_TYP_CODE = ''FYR'' and VRV.REF_VALUE = A.WorkYear'		

		 EXEC (@WorkInsertQuery);	
	
		SET @ExamUpdateQuery = 'UPDATE CES.EXAM  
		SET 
			WORK_SR_KEY = wrk.WORK_SR_KEY,
			EXAM_BASELINE_DATE = CASE WHEN RV.REF_VALUE =''Planned'' OR RV.REF_VALUE =''Requested'' THEN NULL 
										ELSE  EX.EXAM_BASELINE_DATE
									END
			,EXAM_PLANNED_DATE = CASE WHEN RV.REF_VALUE =''Planned'' OR RV.REF_VALUE =''Requested'' THEN NULL 
										ELSE  EX.EXAM_PLANNED_DATE
									END
		FROM CES.EXAM EX
		INNER JOIN CES.WORK wrk 
		ON EX.EXAM_ID = wrk.'+@exam_id+'
		AND EX.ASSET_GUID = wrk.ASSET_GUID
		AND Ex.EXAM_TYPE_SR_KEY = wrk.EXAM_TYPE_SR_KEY
		INner Join CES.Reference_Value RV ON  RV.REF_VAL_SR_KEY = EX.EXAM_REQ_STATUS'	

		EXEC (@ExamUpdateQuery);

		ALTER TABLE CES.WORK
		DROP COLUMN exam_id;
		
		COMMIT TRAN
		SET @Output = 1
	END TRY
	BEGIN CATCH
		IF (@@TRANCOUNT >0)
			ROLLBACK TRAN

		ALTER TABLE CES.WORK
		DROP COLUMN exam_id;
		
		IF @ErrorMsg IS NULL
			SET @ErrorMsg = ERROR_MESSAGE() 
		
		SET @ErrorDescription = @ErrorMsg + 
							' Line Num:' + CONVERT(VARCHAR(5), ERROR_LINE()) + 
							',ErrorNum:' + CONVERT(VARCHAR(5), ERROR_NUMBER()) + 
							',Severity:' + CONVERT(VARCHAR(5), ERROR_SEVERITY()) + 
							',State:' + CONVERT(VARCHAR(10), ERROR_STATE()) + 
							',Procedure:' + CONVERT(VARCHAR(25), OBJECT_NAME(@@procid)) +
							',Procedure:' + CONVERT(VARCHAR(25), ERROR_PROCEDURE())

		SET @Output = 0;
		SELECT @Output AS SaveStatus,@ErrorMsg AS ErrorMsg;
		
		THROW 50000,@ErrorDescription,1;
	END CATCH
	SET NOCOUNT OFF
  END