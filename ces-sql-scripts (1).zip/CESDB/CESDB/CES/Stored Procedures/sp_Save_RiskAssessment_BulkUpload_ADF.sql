﻿/***************************************************************************************************************************************            
* Name						: sp_Save_RiskAssessment_BulkUpload_ADF     
* Created By				: Cognizant            
* Date Created				: 28-Feb-2021           
* Description				: This stored procedure updates the Exam Table ISLATEST flag through ADF.  
* Input Parameters			: JSON   
* Output Parameters			: Returns 1 for succesful save, else 0            
* Return Value				: N/A            
* Assumptions				: None    
* Execution Statement		: EXEC CES.sp_Save_RiskAssessment_BulkUpload_ADF '[ 
																	{ 
																	"ASSET_GUID": "3978559C3BF045D9E04400306E4AD01A", 
																	"EXAM_TYPE_SR_KEY": 1
																	}, 
																	{ 
																	"ASSET_GUID": "3978559C3BF045D9E04400306E4AD01A", 
																	"EXAM_TYPE_SR_KEY": 1
																	 } 
																]', 1	
*								
* Modified Date     Modified By   Revision Number  Modifications            

*******************************************************************************************************************************************/ 

CREATE PROCEDURE [CES].[sp_Save_RiskAssessment_BulkUpload_ADF]
	@Input_JSON		NVARCHAR(MAX),
	@RISK_USER		varchar(64)

AS 

BEGIN
	SET NOCOUNT ON
    BEGIN TRY
		DECLARE
				@ErrorMsg			VARCHAR(250),
				@ErrorDescription   VARCHAR(4000),
				@Output				BIT = 0,
				@CurrentDate		DATETIME  = GETDATE(),
				@User				VARCHAR(16) = 'CES',
				@RA_REVIEW_TOL		decimal(5),
				@RA_EXPIRY_TOL		decimal(5),
				@REVIEW_TOL_WEEKS	decimal(5),
				@RISK_ASSESS_STATUS decimal(9),
				@Vis_Exam_Type_ID		DECIMAL(18)
		
		DROP TABLE IF EXISTS #tmpAsRiskAssesmentDtls_ADF

		CREATE TABLE #tmpAsRiskAssesmentDtls_ADF
		(
			ASSET_GUID				varchar(32),
			EXAM_TYPE_SR_KEY		decimal(9),
			RISK_SR_KEY				decimal(9)
		)

		Select @RISK_ASSESS_STATUS = REF_VAL_SR_KEY 
		from CTL_CES_ADL_CONTROL.vw_ADF_Reference_Type_Value REF 
		WHERE REF.REF_TYP_CODE = 'RAS' 
		and LOWER(REF_VALUE) = 'completed (data)' 
		
		SELECT @Vis_Exam_Type_ID = EXAM_TYPE_SR_KEY 
		FROM CES.EXAM_TYPE 
		WHERE EXAM_TYPE= 'Visual'  
		AND ISACTIVE = 1

		SELECT
			@RA_REVIEW_TOL = RA_REVIEW_TOLERANCE_MONTHS,
			@RA_EXPIRY_TOL = RA_EXPIRY_TOLERANCE_MONTHS,
			@REVIEW_TOL_WEEKS = REVIEW_TOLERANCE_WEEKS
		FROM CES.COMPLIANCE_TOLERANCE
		WHERE ISACTIVE =1
		AND EXAM_TYPE_SR_KEY = @Vis_Exam_Type_ID
		
		--Parsing the input JSON and gathering the records					
		INSERT INTO #tmpAsRiskAssesmentDtls_ADF
		(
			ASSET_GUID,
			EXAM_TYPE_SR_KEY,
			RISK_SR_KEY
		)
		SELECT				
			ast.ASSET_GUID,
			ast.EXAM_TYPE_SR_KEY,
			RA.RISK_SR_KEY
		FROM	OPENJSON(@Input_JSON)
		WITH 
			(
				ASSET_GUID				varchar(32),
				EXAM_TYPE_SR_KEY		decimal(9)
			) AS ast  
		LEFT JOIN [CES].[RISK_ASSESSMENT] RA ON RA.ASSET_GUID = ast.ASSET_GUID
		AND RA.EXAM_TYPE_SR_KEY = ast.EXAM_TYPE_SR_KEY 
		AND RA.ISLATEST = 'Y' -- Join with Risk Assesment table
		AND RA.ISACTIVE =1

	------------------------------------
	BEGIN TRAN
		
			UPDATE ra
			SET ISLATEST = 'N', 
				UPDATED_USER = @RISK_USER, 
				UPDATED_DATE = @CurrentDate

			FROM [CES].[RISK_ASSESSMENT] ra
			INNER JOIN #tmpAsRiskAssesmentDtls_ADF t
			ON ra.RISK_SR_KEY = t.RISK_SR_KEY-- Update with RISk SR KEY
					
			INSERT INTO [CES].[RISK_ASSESSMENT]
					(
					    ASSET_GUID,
						EXAM_TYPE_SR_KEY,
						ASSESSMENT_DATE,
						REVIEW_DATE,					
						[EXPIRY_DATE],
						RISK_ASSESS_STATUS,
						RISK_USER,
						ISLATEST,
						CREATED_USER,
						CREATED_DATE
					)
					Select 
					Uniq.ASSET_GUID, 
					Uniq.EXAM_TYPE_SR_KEY, 
					CONVERT(DATE,@CurrentDate,103) AS  ASSESSMENT_DATE, 
					CONVERT(DATE, DATEADD(MONTH, @RA_REVIEW_TOL, @CurrentDate),103) as REVIEW_DATE, -- Pick the Variables from Table
					CONVERT(DATE,DATEADD(WEEK, @REVIEW_TOL_WEEKS, DATEADD(MONTH, @RA_EXPIRY_TOL, Uniq.COMP_DATE)),103) as [EXPIRY_DATE], -- Pick the Variables from Table
					@RISK_ASSESS_STATUS,
					@RISK_USER AS RISK_USER,
					'Y',
					@RISK_USER AS CREATED_USER,
					@CurrentDate AS CREATED_DATE 
					FROM
					(
						Select 
							COM.ASSET_GUID, 
							COM.EXAM_TYPE_SR_KEY, 
							EFFECTIVE_FROM_DT, 
							COMP_DATE, 
							ROW_NUMBER() OVER (PARTITION BY COM.ASSET_GUID,COM.EXAM_TYPE_SR_KEY ORDER BY EFFECTIVE_FROM_DT DESC) AS Rnk 
						FROM CES.COMPLIANCE COM
						INNER JOIN #tmpAsRiskAssesmentDtls_ADF tempRA 
						ON tempRA.ASSET_GUID = COM.ASSET_GUID 
						AND tempRA.EXAM_TYPE_SR_KEY = COM.EXAM_TYPE_SR_KEY
						WHERE  COM.EXAM_TYPE_SR_KEY = @Vis_Exam_Type_ID 
						AND  GETDATE() BETWEEN EFFECTIVE_FROM_DT AND ISNULL(EFFECTIVE_TO_DT,'9999/12/31')
						AND COM.ISACTIVE =1
					) AS Uniq
					WHERE Uniq.Rnk = 1

		COMMIT TRAN
		SET @Output = 1
		SELECT @Output AS SaveStatus,@ErrorMsg AS ErrorMsg;
	END TRY
	BEGIN CATCH
		IF (@@TRANCOUNT >0)
			ROLLBACK TRAN
		
		IF @ErrorMsg IS NULL
			SET @ErrorMsg = ERROR_MESSAGE() 
		
		SET @ErrorDescription = @ErrorMsg + 
							' Line Num:' + CONVERT(VARCHAR(5), ERROR_LINE()) + 
							',ErrorNum:' + CONVERT(VARCHAR(5), ERROR_NUMBER()) + 
							',Severity:' + CONVERT(VARCHAR(5), ERROR_SEVERITY()) + 
							',State:' + CONVERT(VARCHAR(10), ERROR_STATE()) + 
							',Procedure:' + CONVERT(VARCHAR(25), OBJECT_NAME(@@procid)) +
							',Procedure:' + CONVERT(VARCHAR(25), ERROR_PROCEDURE())

		SET @Output = 0;
		SELECT @Output AS SaveStatus,@ErrorMsg AS ErrorMsg;

		DROP TABLE IF EXISTS #tmpAsRiskAssesmentDtls_ADF;
		THROW 50000,@ErrorDescription,1;
	END CATCH

	DROP TABLE IF EXISTS #tmpAsRiskAssesmentDtls_ADF;
	SET NOCOUNT OFF
  END