﻿/***************************************************************************************************************************************            
* Name						: sp_Delete_Admin_UserRRA            
* Created By				: Cognizant            
* Date Created				: 10-Mar-2021           
* Description				: This stored procedure provides the option to delete existing user RRA they are assigned.  
* Input Parameters			: JSON      
* Output Parameters			: @OUT_ErrorNo            
* Return Value				: 1 - Success / 0 - Fail            
* Assumptions				: None    
* Execution Statement		: Exec CES.sp_Delete_Admin_UserRRA 24,'BDFD2401-040F-4250-B506-444A7684C9AC'
*							  Exec CES.sp_Delete_Admin_UserRRA user_id,current_user_key

* Modified Date     Modified By   Revision Number  Modifications            

*******************************************************************************************************************************************/ 

CREATE PROCEDURE [CES].[sp_Delete_Admin_UserRRA]
	@User_Id			DECIMAL(18),
	@Current_User_Key	VARCHAR(64)
AS 
BEGIN
	SET NOCOUNT ON
	
	
	BEGIN TRY
		DECLARE
				@ErrorMsg				VARCHAR(250),
				@result					NVARCHAR(MAX),
				@current_date			DATETIME

				IF (@User_Id IS NULL or LTRIM(RTRIM(@User_Id)) = '')
				BEGIN
					SET @ErrorMsg = 'User Key provided is blank';
					THROW 50000,@ErrorMsg,1;
				END

				IF (@current_user_key IS NULL or LTRIM(RTRIM(@current_user_key)) = '')
				BEGIN
					SET @ErrorMsg = 'Current logged in user key is blank';
					THROW 50000,@ErrorMsg,1;
				END
				 
				SET @current_date = GETDATE()
				
				IF NOT EXISTS (SELECT 1 FROM CES.[ENTITLEMENT] WHERE USER_SR_KEY = @User_Id AND ISACTIVE=1)
				BEGIN
					SET @ErrorMsg = 'The selected user does not have RRA in system';					
					SET @result=(
							SELECT 0 AS delete_status,@ErrorMsg AS error_msg
							FOR JSON PATH,WITHOUT_ARRAY_WRAPPER, INCLUDE_NULL_VALUES
							)
				END
				ELSE
				BEGIN
				BEGIN TRAN
					UPDATE CES.[ENTITLEMENT]  SET ISACTIVE=0,UPDATED_USER=@Current_User_Key,UPDATED_DATE=@current_date
					WHERE USER_SR_KEY = @User_Id AND ISACTIVE=1					
					SET @result=(
							SELECT 1 AS delete_status,NULL AS error_msg
							FOR JSON PATH,WITHOUT_ARRAY_WRAPPER, INCLUDE_NULL_VALUES
							)
				COMMIT TRAN
				END
				
	
		SELECT @result
		
	END TRY
	BEGIN CATCH
		IF (@@TRANCOUNT >0)
			ROLLBACK TRAN

		SET @ErrorMsg = ERROR_MESSAGE() + 
						' Line Num:' + CONVERT(VARCHAR(5), ERROR_LINE()) + 
						',ErrorNum:' + CONVERT(VARCHAR(5), ERROR_NUMBER()) + 
						',Severity:' + CONVERT(VARCHAR(5), ERROR_SEVERITY()) + 
						',State:' + CONVERT(VARCHAR(10), ERROR_STATE()) + 
						',Procedure:' + CONVERT(VARCHAR(25), ERROR_PROCEDURE());  
		
		
		THROW 50000,@ErrorMsg,1;

		
	END CATCH

	
	SET NOCOUNT OFF
END