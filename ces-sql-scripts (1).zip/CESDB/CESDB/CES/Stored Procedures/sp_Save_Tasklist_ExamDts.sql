﻿/***************************************************************************************************************************************            
* Name						: sp_Save_Tasklist_ExamDts        
* Created By				: Cognizant            
* Date Created				: 19-Jan-2021           
* Description				: This stored procedure saves the exam dates posted by teh supplier through API.  
* Input Parameters			: JSON, Supplier ID   
* Output Parameters			: Returns 1 for succesful save, else 0            
* Return Value				: N/A            
* Assumptions				: None    
* Execution Statement		: EXEC CES.sp_Save_Tasklist_ExamDts '[
																	{
																	  "assetGuid": "3978559E727145D9E04400306E4AD01A",
																	  "examinationType": "Visual",
																	  "examId": 13245650,
																	  "plannedExamDate": "22/09/2021",
																	  "actualExamDate": "17/07/2021",
																	  "otherSupplierComment": "sfsffs",
																	  "crId": 1234
		
																	},
																	{
																	  "assetGuid": "3978559E4C2545D9E04400306E4AD01A",
																	  "examinationType": "Visual",
																	  "examId": 13241822,
																	  "plannedExamDate": "09/11/2021",
																	  "actualExamDate": "",
																	  "otherSupplierComment": "",
																	  "crId": ""
		
																	}
																]',4,"CEFA PM"

																RoleName to upodate job number:"CEFA PM","Super User","Supplier Planner"
								
EXEC [CES].[sp_Save_Tasklist_ExamDts] '[{"examinationType":"Detailed","assetGuid":"3978559CEA4E45D9E04400306E4AD01A","examId":13243142,"plannedExamDate":"2021-07-21T00:00:00","actualExamDate":"2021-07-19T00:00:00","otherSupplierComment":"test 16","crId":"test 16"}]',4
																									
*								
* Modified Date     Modified By   Revision Number  Modifications  
  04-Aug-2021       Cognizant     2.0              Release 2 -US# 38778: Add job number bulk and individually in CES.WORK table    

*******************************************************************************************************************************************/ 



CREATE PROCEDURE [CES].[sp_Save_Tasklist_ExamDts]
	@Input_JSON		NVARCHAR(MAX),
	@Supplier_ID	DECIMAL(18),
	@Role_Name		VARCHAR(100) = NULL --Release 2 -US# 38778: Add job number bulk and individually in CES.WORK table  
AS 

BEGIN
	SET NOCOUNT ON
	--SET ANSI_WARNINGS OFF;
    BEGIN TRY
		DECLARE
				@ErrorMsg			VARCHAR(250),
				@ErrorDescription   VARCHAR(4000),
				@Exam_Dtls			NVARCHAR(MAX),
				@Asset_GUID			VARCHAR(32),
				@Exam_Type			VARCHAR(32),
				@Output				BIT = 0,
				@CurrentDate		DATETIME  = GETDATE(),
				@SupplierName		VARCHAR(64),
				@ExmUpdate_JSON		NVARCHAR(MAX)
		
		 --SET @Output = 0
		 --SET @ErrorMsg = '@@TRANCOUNT : ' + Convert(varchar(10), @@TRANCOUNT)

		 --SELECT @Output AS SaveStatus,@ErrorMsg AS ErrorMsg;

		DROP TABLE IF EXISTS #tmpAstExamDtls
		DROP TABLE IF EXISTS #tmpExamData

		CREATE TABLE #tmpAstExamDtls
		(
			Asset_GUID			 VARCHAR(32),
			Exam_Type			 VARCHAR(32),
			Exam_Type_ID		 DECIMAL(18),
			Exam_ID				 DECIMAL(18),
			Exam_Planned_Date	 DATE,
			Exam_Actual_Date	 DATE,
			Supplier_Comment	 VARCHAR(2000),
			CRID                 VARCHAR(20),
			JobNumber			 VARCHAR(8000)--Release 2 -US# 38778: Add job number bulk and individually in CES.WORK table  
		)

		CREATE TABLE #tmpExamData
		(
			ASSET_GUID				VARCHAR(32),
			EXAM_TYPE_SR_KEY		DECIMAL(9)
		)

		DECLARE @result TABLE
		(
			[Output]	SMALLINT,
			ErrorMsg	VARCHAR(4000)	
		) 
		
		--Parsing the input JSON and gathering the records					
		INSERT INTO #tmpAstExamDtls
		(
			Asset_GUID,
			Exam_Type,
			Exam_Type_ID,
			Exam_ID,
			Exam_Planned_Date,
			Exam_Actual_Date,
			Supplier_Comment,
			CRID,
			JobNumber--Release 2 -US# 38778: Add job number bulk and individually in CES.WORK table  
		)
		SELECT
			dtl.assetGuid,
			dtl.examinationType,
			et.EXAM_TYPE_SR_KEY,
			dtl.examId,
			dtl.plannedExamDate,
			dtl.actualExamDate,
			dtl.otherSupplierComment,
			dtl.crId,
			dtl.jobNumber--Release 2 -US# 38778: Add job number bulk and individually in CES.WORK table  
		FROM
		(
			SELECT
				ast.assetGuid,
				ast.examinationType,
				ast.examId,
				CONVERT(DATE,ast.plannedExamDate,103) AS plannedExamDate,
				CONVERT(DATE,ast.actualExamDate,103) AS actualExamDate,
				ast.otherSupplierComment,
			    ast.crId,
				ast.jobNumber--Release 2 -US# 38778: Add job number bulk and individually in CES.WORK table  
			FROM	OPENJSON(@Input_JSON)
			WITH 
				(
					assetGuid				VARCHAR(32),
					examinationType			VARCHAR(32),
					examId					DECIMAL(18),
					plannedExamDate			VARCHAR(25),
					actualExamDate			VARCHAR(25),
					otherSupplierComment	VARCHAR(2000),
			        crId					VARCHAR(20),
					jobNumber				VARCHAR(8000)--Release 2 -US# 38778: Add job number bulk and individually in CES.WORK table  
				) AS ast
		)dtl
		LEFT JOIN EXAM_TYPE et
		ON et.EXAM_TYPE = dtl.examinationType


		--- Validation Checks -- Start
		IF EXISTS (	SELECT 1 
					FROM #tmpAstExamDtls t
					LEFT JOIN ASSET ast
					ON t.Asset_GUID = ast.Asset_GUID
					WHERE ast.Asset_GUID IS NULL
				  )
		BEGIN
				SET @ErrorMsg = 'Asset GUID(s) proovided are not valid for some or all records';
				THROW 50000,@ErrorMsg,1;
		END

		IF EXISTS (	SELECT 1 
					FROM #tmpAstExamDtls 
					WHERE Exam_Type_ID IS NULL
				  )
		BEGIN
				SET @ErrorMsg = 'Exam Type(s) provided are not valid for some or all records';
				THROW 50000,@ErrorMsg,1;
		END
			
		IF EXISTS (	SELECT 1 
					FROM #tmpAstExamDtls t
					LEFT JOIN EXAM e
					ON t.Exam_ID = e.Exam_ID
					WHERE e.EXAM_SR_KEY IS NULL
				  )
		BEGIN
				SET @ErrorMsg = 'Exam ID(s) provided are not valid for some or all records';
				THROW 50000,@ErrorMsg,1;
		END

		IF EXISTS (	SELECT 1 
					FROM #tmpAstExamDtls t
					LEFT JOIN EXAM e
					ON t.Exam_ID = e.Exam_ID
					AND t.Asset_GUID = e.Asset_GUID
					AND t.Exam_Type_ID = e.EXAM_TYPE_SR_KEY
					WHERE e.EXAM_SR_KEY IS NULL
				  )
		BEGIN
				SET @ErrorMsg = 'The combination of AssetGUID, Exam Type and Exam ID provided are not valid for some or all records';
				THROW 50000,@ErrorMsg,1;
		END

		IF EXISTS (	SELECT 1 
					FROM #tmpAstExamDtls
					WHERE Exam_Planned_Date < CONVERT(DATE,@CurrentDate,103))
		BEGIN
				SET @ErrorMsg = 'The planned date cannot be in the past';
				THROW 50000,@ErrorMsg,1;
		END

		IF EXISTS (	SELECT 1 
					FROM #tmpAstExamDtls
					WHERE Exam_Actual_Date > CONVERT(DATE,@CurrentDate,103))
		BEGIN
				SET @ErrorMsg = 'The exam date cannot be greater than current date';
				THROW 50000,@ErrorMsg,1;
		END

		IF EXISTS (	SELECT 1 
					FROM #tmpAstExamDtls
					WHERE Exam_Actual_Date IS NULL AND Exam_Planned_Date IS NULL)
		BEGIN
				SET @ErrorMsg = 'Both the planned and exam dates are missing for some or all records';
				THROW 50000,@ErrorMsg,1;
		END

		IF EXISTS (	SELECT 1 
					FROM #tmpAstExamDtls t
					LEFT JOIN EXAM e
					ON t.Exam_ID = e.Exam_ID
					AND e.SUPPLIER_SR_KEY = @Supplier_ID
					WHERE e.EXAM_SR_KEY IS NULL)
		BEGIN
				SET @ErrorMsg = 'The Exam ID mentioned is not assigned against the supplier';
				THROW 50000,@ErrorMsg,1;
		END

		--- Validation Checks -- End

		SELECT @SupplierName = SUPPLIER_NAME 
		FROM CES.SUPPLIER
		WHERE SUPPLIER_SR_KEY = @Supplier_ID

		INSERT INTO #tmpExamData
			(
				ASSET_GUID,
				EXAM_TYPE_SR_KEY
			)
			SELECT DISTINCT
				t.ASSET_GUID,
				ex.EXAM_TYPE_SR_KEY
			FROM #tmpAstExamDtls t
			INNER JOIN CES.EXAM ex
			ON ex.EXAM_ID = t.Exam_ID
			WHERE (ex.EXAM_ACTUAL_DATE IS NULL AND t.Exam_Actual_Date IS NOT NULL)
			OR (ex.EXAM_ACTUAL_DATE IS NOT NULL AND ex.EXAM_ACTUAL_DATE <> t.Exam_Actual_Date)

	
		--BEGIN TRAN ExamDts
		BEGIN TRAN
			---Update the Exam Date and Planned Date if available
			
			UPDATE ex
			SET 
				EXAM_PLANNED_DATE = ISNULL(t.Exam_Planned_Date,ex.EXAM_PLANNED_DATE),
				EXAM_ACTUAL_DATE = ISNULL(t.Exam_Actual_Date,ex.EXAM_ACTUAL_DATE),
				SUPPLIER_COMMENTS = t.Supplier_Comment,
			    CHANGE_REQ_ID = t.crid,				
				UPDATED_USER = ISNULL(@SupplierName,'CES'),
				UPDATED_DATE = @CurrentDate
			FROM #tmpAstExamDtls t
			INNER JOIN CES.EXAM ex
			ON ex.EXAM_ID = t.Exam_ID

			--Release 2 -US# 38778: Add job number bulk and individually in CES.WORK table  start
			IF @Role_Name IS NULL OR @Role_Name='CEFA PM' OR @Role_Name='Super User' OR @Role_Name='Supplier Planner' 
			BEGIN
				UPDATE w
				SET 					
					JOB_NUMBER = t.JobNumber,							
					UPDATED_USER = ISNULL(@SupplierName,'CES'),
					UPDATED_DATE = @CurrentDate
				FROM #tmpAstExamDtls t
				INNER JOIN CES.EXAM ex
				ON ex.EXAM_ID = t.Exam_ID
				INNER JOIN CES.WORK w
				ON ex.WORK_SR_KEY = w.WORK_SR_KEY 
			END
			--Release 2 -US# 38778: Add job number bulk and individually in CES.WORK table  End

			--This table will be used by child SP [sp_Update_EXAM_ISLASTFLG] called later				
			-- SP to update IsLast Exam flag
			INSERT INTO @result([Output],ErrorMsg)
			EXEC [CES].[sp_Update_EXAM_ISLASTFLG] @SupplierName 
		 
		 --COMMIT TRAN ExamDts
		 COMMIT TRAN

		 SET @Output = 1

		 SELECT @Output AS SaveStatus,NULL AS ErrorMsg;
	END TRY

	BEGIN CATCH	
		IF (@@TRANCOUNT > 0)
			BEGIN
				--print @@TRANCOUNT
				--ROLLBACK TRAN ExamDts
				ROLLBACK TRAN 
			END
	--IF (@@TRANCOUNT >0)
	--	IF EXISTS (SELECT [name] FROM sys.dm_tran_active_transactions WHERE name = 'ExamDts')            
	--		ROLLBACK TRAN ExamDts            
		
		IF @ErrorMsg IS NULL
			SET @ErrorMsg = ERROR_MESSAGE() 
		
		SET @ErrorDescription = @ErrorMsg + 
							' Line Num:' + CONVERT(VARCHAR(5), ERROR_LINE()) + 
							',ErrorNum:' + CONVERT(VARCHAR(5), ERROR_NUMBER()) + 
							',Severity:' + CONVERT(VARCHAR(5), ERROR_SEVERITY()) + 
							',State:' + CONVERT(VARCHAR(10), ERROR_STATE()) + 
							',Procedure:' + CONVERT(VARCHAR(25), OBJECT_NAME(@@procid)) +
							',Procedure:' + CONVERT(VARCHAR(25), ERROR_PROCEDURE())

		SET @Output = 0;
		SELECT @Output AS SaveStatus,@ErrorMsg AS ErrorMsg;

		DROP TABLE IF EXISTS #tmpAstExamDtls;
		DROP TABLE IF EXISTS #tmpExamData;
		THROW 50000,@ErrorDescription,1;
	END CATCH

	DROP TABLE IF EXISTS #tmpAstExamDtls;
	DROP TABLE IF EXISTS #tmpExamData;
	SET NOCOUNT OFF
  END