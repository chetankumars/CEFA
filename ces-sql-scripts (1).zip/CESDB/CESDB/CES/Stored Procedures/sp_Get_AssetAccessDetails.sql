﻿


/***************************************************************************************************************************************            
* Name						: sp_Get_AssetAccessDetails          
* Created By				: Cognizant            
* Date Created				: 30-March-2021           
* Description				: This stored procedure retrieves the access and compliance details for assets. 
* Input Parameters			: JSON (asset GUID array)     
* Output Parameters			: Temp Table (to be declared in calling SP)            
* Return Value				: N/A            
* Assumptions				: None    
* Execution Statement		: Exec [CES].[sp_Get_AssetAccessDetails] '["43D8F3AC626A12A2E0440017084CC843"]'
*								
* Modified Date     Modified By   Revision Number  Modifications            
  16-Jul-2021       Cognizant	  2.0			   Release 2 -US# 37568 - AccessData - Added 'COMMENTS' field
*******************************************************************************************************************************************/ 



CREATE PROCEDURE [CES].[sp_Get_AssetAccessDetails]
	@Input_JSON		NVARCHAR(MAX)
AS
BEGIN
	SET NOCOUNT ON
	BEGIN TRY

		DECLARE
				@ErrorMsg					VARCHAR(250),
				@result						NVARCHAR(MAX),
				@current_date				DATE = DATEADD(dd, DATEDIFF(dd, 0, GETDATE()), 0)

		DROP TABLE IF EXISTS #ast_guid_tbl_astdtls;
		DROP TABLE IF EXISTS #tbl_ComplianceStatus;
		CREATE TABLE #tbl_ComplianceStatus
		(
			asset_guid				VARCHAR(32),
			dtl_compliance			VARCHAR(100),
			dtl_risk_status			VARCHAR(100),
			dtl_frequency			VARCHAR(60),
			dtl_exam_type_id		DECIMAL(18),
			dtl_comp_date			DATE,
			dtl_exam_planned_date	DATE,
			dtl_exam_actual_date	DATE,			
			dtl_supplier			VARCHAR(64),

			ve_compliance			VARCHAR(100),
			ve_risk_status			VARCHAR(100),
			ve_frequency			VARCHAR(60),
			ve_exam_type_id			DECIMAL(18),
			ve_comp_date			DATE,
			ve_exam_planned_date	DATE,
			ve_exam_actual_date		DATE,			
			ve_supplier				VARCHAR(64),

			uw_compliance			VARCHAR(100),
			uw_risk_status			VARCHAR(100),
			uw_frequency			VARCHAR(60),
			uw_exam_type_id			DECIMAL(18),
			uw_comp_date			DATE,
			uw_exam_planned_date	DATE,
			uw_exam_actual_date		DATE,			
			uw_supplier				VARCHAR(64)
		)

		--Release 2 -US# 37568 - AccessData -Modified to add 'COMMENTS' field --start
		--To get asset guid from input 
		CREATE TABLE #ast_guid_tbl_astdtls 
		(	
			asset_guid			VARCHAR(32),
			exam_type_sr_key	DECIMAL(18),
			exam_type			VARCHAR(32)
		)
			
		INSERT INTO #ast_guid_tbl_astdtls (asset_guid,exam_type_sr_key,exam_type)
		SELECT t.[value] ,et.exam_type_sr_key, et.exam_type
		FROM OPENJSON(@Input_JSON) t
		CROSS APPLY CES.EXAM_TYPE et
		WHERE et.EXAM_TYPE IN ('Detailed','Visual','Underwater')
		AND et.ISACTIVE = 1 ;
		--Release 2 -US# 37568 - AccessData -Modified to add 'COMMENTS' field --END
		
		--Retrieving the compliance status for the asset
		INSERT INTO #tbl_ComplianceStatus
		(
			asset_guid,
			dtl_compliance,
			dtl_risk_status,
			dtl_frequency,
			dtl_exam_type_id,
			dtl_comp_date,
			dtl_exam_planned_date,
			dtl_exam_actual_date,			
			dtl_supplier,

			ve_compliance,
			ve_risk_status,
			ve_frequency,
			ve_exam_type_id,
			ve_comp_date,
			ve_exam_planned_date,
			ve_exam_actual_date,			
			ve_supplier,

			uw_compliance,
			uw_risk_status,
			uw_frequency,
			uw_exam_type_id,
			uw_comp_date,
			uw_exam_planned_date,
			uw_exam_actual_date,			
			uw_supplier
		)
		EXEC [CES].[sp_Get_Asset_Compliance_Risk_Status] @Input_JSON,@current_date
		
		---Please remember to declare the temp table #tbl_AssetAccessDtls within teh calling SP, so that it can be re-used in teh same scope
		-- This is to avoid issue for using more than one nested insert exec in sql server
		
		--Final result data to be returned 
		INSERT INTO #tbl_AssetAccessDtls
		(
				region,
				route,
				area,
				elr,
				asset_guid,
				railway_id,
				asset_group,
				asset_type,
				start_mileage,
				end_mileage,
				primary_material,
				owning_party,
				gps_start,
				gps_end,
				structure_carries,
				structure_over,
				hce_flag,
				cmi_score,
				tenanted_flg,
				exam_type, 
				comp_status,
				possession,
				rrv,
				ladder,
				confined_space,
				[3rd_party],
				line_block,
				mewp,
				scaffold,
				water_permit,
				traffic_mngt,
				rope_access,
				cctv,
				safety_boat,
				comments--Release 2 -US# 37568 - AccessData -Modified to add 'COMMENTS' field --END
		)		
		SELECT
				o.REGION AS region,
				o.[ROUTE] AS [route],
				ar.AREA_NAME AS area,
				elr.[ELR_CODE] AS elr,
				ast.ASSET_GUID AS asset_guid,
				ast.RAILWAY_ID AS railway_id,
				ag.ASSET_GROUP_DESC AS asset_group,
				at.ASSET_TYPE_DESC AS asset_type,
				(ast.START_MILES + ast.START_YARDS/1760) AS start_mileage,
			    (ast.END_MILES + ast.END_YARDS/1760) AS end_mileage,
				pm.REF_VALUE as primary_material,
				ast.OWNING_PARTY as owning_party,
				NULL AS gps_start,
				NULL gps_end,
				ast.STRUCTURE_CARRIES AS structure_carries,
				ast.STRUCTURE_OVER AS structure_over,
				IIF(HCE_FLAG = 'Y','Yes', 'No') AS hce_flag,
				ast.CMI_SCORE AS cmi_score,
			    CASE WHEN ast.TENANTED_FLG = 'Y' THEN 'Yes'
						WHEN ast.TENANTED_FLG = 'N' THEN 'No'
						ELSE 'N/A'
					END AS tenanted_flg,
				astid.exam_type ,
				cst.comp_status,
				acs.[POSSESSION] AS possession,
				acs.[RRV] AS rrv,
				acs.[LADDER] AS ladder,
				acs.[CONFINED_SPACE] AS confined_space,
				acs.[3RD_PARTY] AS [3rd_party],
				acs.[LINE_BLOCK] AS line_block,
				acs.[MEWP] AS mewp,
				acs.[SCAFFOLD] AS scaffold,
				acs.[WATER_PERMIT] AS water_permit,
				acs.[TRAFFIC_MNGT] AS traffic_mngt,
				acs.[ROPE_ACCESS] AS rope_access,
				acs.[CCTV] AS cctv,
				acs.[SAFETY_BOAT] AS saftey_boat,
				acs.[COMMENTS] AS comments--Release 2 -US# 37568 - AccessData -Modified to add 'COMMENTS' field --END

		FROM [CES].ASSET AS ast
		INNER JOIN #ast_guid_tbl_astdtls astid ON astid.asset_guid=ast.ASSET_GUID--Release 2 -US# 37568 - AccessData -Modified to add 'COMMENTS' field --END
		
		INNER JOIN [CES].ORG AS o 
		ON ast.ORG_SR_KEY=o.ORG_SR_KEY
		INNER JOIN [CES].AREA AS ar 
		ON ast.AREA_SR_KEY=ar.AREA_SR_KEY
		INNER JOIN [CES].ASSET_TYPE AS at 
		ON ast.ASSET_TYPE_SR_KEY=at.ASSET_TYPE_SR_KEY
		INNER JOIN [CES].ASSET_GROUP AS ag 
		ON ast.ASSET_GROUP_SR_KEY=ag.ASSET_GROUP_SR_KEY
		INNER JOIN [CES].ENGINE_LINE_REF elr
		ON ast.ENG_LINE_REF = elr.ELR_SR_KEY
		LEFT JOIN [CES].[REFERENCE_VALUE] pm
		ON pm.REF_VAL_SR_KEY = ast.PRIMARY_MATERIAL
		AND pm.ISACTIVE = 1
		--INNER JOIN [CES].EXAM_TYPE AS et
		LEFT JOIN [CES].[ACCESS] AS acs
		ON acs.ASSET_GUID = ast.ASSET_GUID
		AND astid.exam_type_sr_key = acs.EXAM_TYPE_SR_KEY
		AND acs.ISACTIVE = 1
		
		--INNER JOIN
		LEFT JOIN--Release 2 -US# 37568 - AccessData -Modified to add 'COMMENTS' field --END
			(
				SELECT
					asset_guid,
					dtl_exam_type_id AS exam_type_id,
					dtl_compliance AS comp_status
				FROM #tbl_ComplianceStatus 

				UNION ALL
				SELECT
					asset_guid,
					ve_exam_type_id AS exam_type_id,
					ve_compliance AS comp_status
				FROM #tbl_ComplianceStatus 

				UNION ALL
				SELECT
					asset_guid,
					uw_exam_type_id AS exam_type_id,
					uw_compliance AS comp_status
				FROM #tbl_ComplianceStatus 

			) AS cst
		ON cst.ASSET_GUID = ast.ASSET_GUID
		AND astid.exam_type_sr_key = cst.exam_type_id
								
		WHERE o.ISACTIVE = 1
		AND ar.ISACTIVE = 1
		AND elr.ISACTIVE = 1
		AND at.ISACTIVE = 1
		AND ag.ISACTIVE = 1
		AND ast.ISACTIVE = 1
		--AND et.ISACTIVE = 1--Release 2 -US# 37568 - AccessData -Modified to add 'COMMENTS' field --END
		
		--SELECT * FROM #tbl_AssetAccessDtls		
		
		
	END TRY
	BEGIN CATCH

		SET @ErrorMsg = ' Line Num:' + CONVERT(VARCHAR(5), ERROR_LINE()) + 
						',ErrorNum:' + CONVERT(VARCHAR(5), ERROR_NUMBER()) + 
						',Severity:' + CONVERT(VARCHAR(5), ERROR_SEVERITY()) + 
						',State:' + CONVERT(VARCHAR(10), ERROR_STATE()) + 
						',Procedure:' + CONVERT(VARCHAR(25), OBJECT_NAME(@@procid)) +
						',Procedure:' + CONVERT(VARCHAR(25), ERROR_PROCEDURE()) +
						',Message:' + ERROR_MESSAGE();  
		
		
		DROP TABLE IF EXISTS #ast_guid_tbl_astdtls;
		DROP TABLE IF EXISTS #tbl_ComplianceStatus;

		THROW 50000,@ErrorMsg,1;
	END CATCH
 
	DROP TABLE IF EXISTS #ast_guid_tbl_astdtls;
	DROP TABLE IF EXISTS #tbl_ComplianceStatus;	
		
	SET NOCOUNT OFF
END