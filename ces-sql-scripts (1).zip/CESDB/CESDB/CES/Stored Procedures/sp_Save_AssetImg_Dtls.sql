﻿/***************************************************************************************************************************************            
* Name						: sp_Save_AssetImg_Dtls       
* Created By				: Cognizant            
* Date Created				: 06-April-2021           
* Description				: This stored procedure saves the Individual Asset photo Details.  
* Input Parameters			: JSON, Asset_guid, Asset_img_name and Asset_img_path   
* Output Parameters			: Returns 1 for succesful save, else 0            
* Return Value				: N/A            
* Assumptions				: None    
* Execution Statement		: EXEC CES.sp_Save_AssetImg_Dtls '0C8ADBDB3763A31FE050E70A83866DA7','Assetimg','imgpath','abcdef';

*								
* Modified Date     Modified By   Revision Number  Modifications            

*******************************************************************************************************************************************/ 



CREATE PROCEDURE [CES].[sp_Save_AssetImg_Dtls]
		@asset_guid		    VARCHAR(32),
		@asset_img_name     VARCHAR(200), 
		@asset_img_path     VARCHAR(500),
		@user_id            VARCHAR(64)
	
AS 

BEGIN
	SET NOCOUNT ON
    BEGIN TRY
		DECLARE
				@ErrorMsg			VARCHAR(250),
				@ErrorDescription	VARCHAR(4000),
				@Updated_date		DATETIME = GETDATE(),
				@Output				BIT = 0
		
		CREATE TABLE #tmpAssetImg_Dtls
		(
			asset_guid		   VARCHAR(32),
			asset_img_name     VARCHAR(200), 
		    asset_img_path     VARCHAR(500)
		)

		INSERT INTO #tmpAssetImg_Dtls
		(
			asset_guid,
			asset_img_name,
			asset_img_path
		)
		SELECT
			@asset_guid,
			@asset_img_name,
			@asset_img_path
		

		--- Validation Checks -- Start
				
		IF EXISTS (SELECT 1 FROM #tmpAssetImg_Dtls WHERE asset_guid IS NULL OR asset_img_name IS NULL OR asset_img_path IS NULL)

		BEGIN
			SET @ErrorMsg = 'Mandatory Input parameter value(s) is missing';
			THROW 50000,@ErrorMsg,1;
		END

		--- Validation Checks -- End  

		BEGIN TRAN
					UPDATE [CES].[ASSET]
					SET 
					  ASSET_IMAGE_NAME = t.asset_img_name, 
					  ASSET_IMAGE_LINK = t.asset_img_path,
					  UPDATED_USER = @user_id,
					  UPDATED_DATE = @Updated_date

					FROM #tmpAssetImg_Dtls AS t
					INNER JOIN  [CES].[ASSET] AS ast
					ON ast.ASSET_GUID = t.ASSET_GUID
		            WHERE ast.ASSET_GUID = t.asset_guid

		COMMIT TRAN

		SET @Output = 1
		DROP TABLE IF EXISTS #tmpAssetImg_Dtls;

		SELECT @Output AS SaveStatus,NULL AS ErrorMsg;
	END TRY

	BEGIN CATCH
		IF (@@TRANCOUNT >0)
			ROLLBACK TRAN
		
		IF @ErrorMsg IS NULL
			SET @ErrorMsg = ERROR_MESSAGE() 
		
		SET @ErrorDescription = @ErrorMsg + 
							' Line Num:' + CONVERT(VARCHAR(5), ERROR_LINE()) + 
							',ErrorNum:' + CONVERT(VARCHAR(5), ERROR_NUMBER()) + 
							',Severity:' + CONVERT(VARCHAR(5), ERROR_SEVERITY()) + 
							',State:' + CONVERT(VARCHAR(10), ERROR_STATE()) + 
							',Procedure:' + CONVERT(VARCHAR(25), OBJECT_NAME(@@procid)) +
							',Procedure:' + CONVERT(VARCHAR(25), ERROR_PROCEDURE())

		SET @Output = 0;
		DROP TABLE IF EXISTS #tmpAssetImg_Dtls;
		SELECT @Output AS SaveStatus,@ErrorMsg AS ErrorMsg;

		THROW 50000,@ErrorDescription,1;
	END CATCH

	SET NOCOUNT OFF
  END