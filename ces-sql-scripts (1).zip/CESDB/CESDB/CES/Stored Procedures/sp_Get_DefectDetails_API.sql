﻿/***************************************************************************************************************************************            
* Name						: sp_Get_DefectDetails_API            
* Created By				: Cognizant            
* Date Created				: 18-Feb-2021           
* Description				: This stored procedure retrive defect list Details API. 
* Input Parameters			: JSON      
* Output Parameters			: N/A            
* Return Value				: N/A            
* Assumptions				: None    
* Execution Statement		: Exec [CES].sp_Get_DefectDetails_API '{
																	"region_name":"Southern",
																	"route_name":"Kent",
																	"pageno": 1,
																	"rowsperpage": 100
																}'
*								
* Modified Date     Modified By   Revision Number  Modifications            
* 19-Jul-2021		Cognizant	  2.0			   Release 2 -US# 37567: Change in Open/CLose Defect count logic as per the new column IS_DEFECT_CLOSED in CES.DEFECT table          

*******************************************************************************************************************************************/ 



CREATE PROCEDURE [CES].[sp_Get_DefectDetails_API]
	@Input_JSON		NVARCHAR(MAX)
AS
BEGIN
	SET NOCOUNT ON
	BEGIN TRY
		DECLARE
				@ErrorMsg					VARCHAR(250),
				@result						NVARCHAR(MAX),
				@supplier_name				VARCHAR(64),
				@region_name				VARCHAR(64),
				@route_name					VARCHAR(64),
				@elr_id						VARCHAR(4),
				@asset_guid					VARCHAR(32),
				@railway_id					VARCHAR(64),
				@total_defects     			DECIMAL(18),
				@open_defects 				DECIMAL(18),
				@highest_open_defect_score	DECIMAL(18),
				@defect_id					DECIMAL(18),
				@description				VARCHAR(256),
				@location					VARCHAR(250),
				@loc_major					VARCHAR(250),
				@loc_minor					VARCHAR(250),
				@exam_actual_date			DATE,
				@exam_id					DECIMAL(18),
				@access_granted				VARCHAR(5),
				@exam_type					VARCHAR(32),
				@recommendation_number		VARCHAR(5),
				@risk_score					VARCHAR(10),
				@access_required			VARCHAR(5),
				@deterioration				VARCHAR(64),
				@repaired					VARCHAR(5),
				@closure_flg				VARCHAR(5),
				@Recommendation_Comments	VARCHAR(1000),
				@isexporttodoc				VARCHAR(1),
				@sortcolumn					VARCHAR(30),
				@sortorder					VARCHAR(5),
				@pageno						DECIMAL(18),
				@rowsperpage				DECIMAL(18),
				@totalresultcnt				INT,
				@ErrorDescription			VARCHAR(4000)
				
           
		DECLARE @tbl_org TABLE
		(
			ORG_SR_KEY	DECIMAL(18)
		)

		CREATE TABLE #tbl_Asset
		(
			ASSET_GUID		VARCHAR(32),
			ELR_CODE		VARCHAR(4),
			RAILWAY_ID		VARCHAR(64),
			totalcount		INT
		)
				
  
		CREATE TABLE #tbl_DefectSearchResultAPI
		(
				elr							VARCHAR(4),
				asset_guid					VARCHAR(32),
				railway_id					VARCHAR(64),
				total_defects     			DECIMAL(18),
				open_defects 				DECIMAL(18),
				highest_open_defect_score	DECIMAL(18),
				defect_id					DECIMAL(18),
				[description]				VARCHAR(256),
				[location]					VARCHAR(250),
				loc_major					VARCHAR(250),
				loc_minor					VARCHAR(250),
				exam_date					DATE,
				exam_id						DECIMAL(18),
				access_gained				VARCHAR(5),
				exam_type					VARCHAR(32),
				recommendation_number		VARCHAR(5),
				risk_score					VARCHAR(10),
				access_required				VARCHAR(5),
				deterioration				VARCHAR(64),
				repaired					VARCHAR(5),
				closure_flg					VARCHAR(5),
				recommendation_comments		VARCHAR(1000)
		)

		SELECT 
			@region_name = COALESCE(@region_name,CASE LOWER([key]) WHEN 'region_name' THEN [value] ELSE NULL END),
			@route_name = COALESCE(@route_name,CASE LOWER([key]) WHEN 'route_name' THEN [value] ELSE NULL END),
			@pageno = COALESCE(@pageno,CASE LOWER([key]) WHEN 'pageno' THEN [value] ELSE NULL END),
			@rowsperpage = COALESCE(@rowsperpage,CASE LOWER([key]) WHEN 'rowsperpage' THEN [value] ELSE NULL END)

		FROM	OPENJSON(@Input_JSON);


		-- Validation start

		IF (@region_name IS NULL OR @pageno IS NULL OR @rowsperpage IS NULL)
		BEGIN

			SET @ErrorMsg = 'Mandatory Input value is missing';
			DROP TABLE IF EXISTS #tbl_DefectSearchResultAPI;
			DROP TABLE IF EXISTS #tbl_Asset;
			THROW 50000,@ErrorMsg,1;
		END

		IF (@rowsperpage > 100)
		BEGIN
			SET @ErrorMsg = 'Maximum number of assets can be returned is 100.';
			DROP TABLE IF EXISTS #tbl_AssetAccessDtlsAPI;
			THROW 50000,@ErrorMsg,1;
		END
		
		INSERT INTO @tbl_org (ORG_SR_KEY)
		SELECT ORG_SR_KEY
		FROM CES.ORG
		WHERE REGION = @region_name
		AND (@route_name IS NULL OR (@route_name IS NOT NULL AND [ROUTE] = @route_name))
		AND ISACTIVE = 1 

		IF NOT EXISTS (SELECT 1 FROM @tbl_org)
		BEGIN
			SET @ErrorMsg = 'Region /Route Information passed in input is incorrect';
			DROP TABLE IF EXISTS #tbl_DefectSearchResultAPI;
			DROP TABLE IF EXISTS #tbl_Asset;
			THROW 50000,@ErrorMsg,1;
		END

		-- Validation End 

		INSERT INTO #tbl_Asset
		(ASSET_GUID,
		 ELR_CODE,
		 RAILWAY_ID,
		 totalcount)
		SELECT
			t.ASSET_GUID,
			elr.ELR_CODE,
			t.RAILWAY_ID,
			t.totalcount
		FROM
		(
			SELECT
				ASSET_GUID,
				ENG_LINE_REF,
				RAILWAY_ID,
				ROW_NUMBER() OVER (ORDER BY ASSET_GUID) rnk, 
				(DENSE_RANK() OVER (ORDER BY ASSET_GUID)
				+ DENSE_RANK() OVER (ORDER BY ASSET_GUID DESC)
				-1) totalcount
			FROM ASSET a
			INNER JOIN @tbl_org o
			ON o.ORG_SR_KEY = a.ORG_SR_KEY
			WHERE --EXISTS (SELECT 1 FROM @tbl_org WHERE  ORG_SR_KEY = a.ORG_SR_KEY)
			 a.ISACTIVE =1
			 AND EXISTS (SELECT 1 FROM CES.DEFECT WHERE ASSET_GUID = a.ASSET_GUID AND ISACTIVE =1)
			GROUP BY
				ASSET_GUID,
				ENG_LINE_REF,
				RAILWAY_ID	
		)t
		INNER JOIN [CES].ENGINE_LINE_REF AS elr
		ON elr.ELR_SR_KEY = t.ENG_LINE_REF
		AND elr.ISACTIVE = 1
			
		WHERE t.rnk BETWEEN ((@pageno - 1) * @rowsperpage +1) AND (@pageno * @rowsperpage)
		

		INSERT INTO #tbl_DefectSearchResultAPI
	   (
				elr,
				asset_guid,
				railway_id,
				total_defects,
				open_defects,
				highest_open_defect_score,
				defect_id,
				[description],
				[location],
				loc_major,
				loc_minor,
				exam_date,
				exam_id,
				access_gained,
				exam_type,
				recommendation_number,
				risk_score,
				access_required,
				deterioration,
				repaired,
				closure_flg,
				recommendation_Comments
		)
		SELECT
			ast.ELR_CODE AS elr
			,df.ASSET_GUID AS asset_guid
			,ast.RAILWAY_ID AS railway_id
			,dtl.total_defects  AS total_defects
			,dtl.open_defects AS open_defects
			,dtl.highest_open_defect_score AS highest_open_defect_score
			,df.DEFECT_ID  AS defect_id
			,df.[DESCRIPTION] AS [description]
			,df.[LOCATION] AS [location]
			,df.LOCATION_MAJOR AS loc_major
			,df.LOCATION_MINOR AS loc_minor
			,ex.[EXAM_ACTUAL_DATE] AS exam_date
			,ex.[EXAM_ID] AS exam_id
			,COALESCE(df.ACCESS_GAINED,'Y','Yes','N','No',df.ACCESS_GAINED) AS access_gained
			,et.[EXAM_TYPE] AS exam_type
			,df.RECOMMEND_RAISED AS recommendation_number
			,df.[RISK_SCORE] AS risk_score
			,COALESCE(df.ACCESS_REQUIRED,'Y','Yes','N','No',df.ACCESS_REQUIRED) AS access_required
			,df.[DETERIORATION] AS deterioration
			,COALESCE(df.REPAIRED,'Y','Yes','N','No',df.REPAIRED) AS repaired
			,COALESCE(df.FLAG_FOR_CLOSURE,'Y','Yes','N','No') AS closure_flg
			,df.ENGINEER_COMMENTS AS recommendation_Comments
			
		FROM #tbl_Asset AS ast
		INNER JOIN [CES].EXAM AS ex
		ON ast.ASSET_GUID = ex.ASSET_GUID
		INNER JOIN [CES].DEFECT AS df
		ON	df.EXAM_SR_KEY = ex.EXAM_SR_KEY
		INNER JOIN CES.EXAM_TYPE AS et
		ON et.EXAM_TYPE_SR_KEY = ex.EXAM_TYPE_SR_KEY
		OUTER APPLY
			(
				SELECT 
					COUNT(DISTINCT df.DEFECT_ID) AS total_defects,
					COUNT(DISTINCT CASE WHEN df.IS_DEFECT_CLOSED = 'N' THEN df.DEFECT_ID ELSE NULL END) AS open_defects, --Release 2 -US# 37567: Modified to make the logic dependent on new column IS_DEFECT_CLOSED --END
					MAX(CASE WHEN df.IS_DEFECT_CLOSED = 'N' THEN IIF(RISK_SCORE='N/A',0,RISK_SCORE) ELSE 0 END) AS highest_open_defect_score  --Release 2 -US# 37567: Modified to make the logic dependent on new column IS_DEFECT_CLOSED --END
												 
				FROM [CES].DEFECT df
				WHERE df.ISACTIVE = 1
				AND df.ASSET_GUID = ast.ASSET_GUID
				
			)dtl

		WHERE ex.ISACTIVE= 1
		AND df.ISACTIVE= 1
		AND et.ISACTIVE = 1

		SELECT TOP 1 @totalresultcnt = totalcount FROM #tbl_Asset 

		--If no records are returned in search result
		IF  ISNULL(@totalresultcnt,0)=0 
		BEGIN
			SET @result=
					(
						SELECT 
							JSON_QUERY(
										(
											select
												@pageno AS currentpage,
												@totalresultcnt AS totalcount,
												0 AS totalpages
											FOR JSON PATH,WITHOUT_ARRAY_WRAPPER
										)
							) searchdatacount,
							JSON_QUERY('[]') searchresult
						
						FOR JSON PATH,WITHOUT_ARRAY_WRAPPER, INCLUDE_NULL_VALUES
				)
		END	

		--If at least 1 record is returned in search result
		ELSE
		BEGIN

	
				SET @result=
				(
					SELECT 
						JSON_QUERY(
									(
											SELECT
													@pageno AS currentpage,
													@totalresultcnt AS totalcount,
													CEILING(@totalresultcnt/@rowsperpage) AS totalpages
											FOR JSON PATH,WITHOUT_ARRAY_WRAPPER
									)
							) searchdatacount,
							(
								SELECT 									
									elr
									,asset_guid
									,railway_id
									,open_defects
									,total_defects
									,highest_open_defect_score
									, defectresult= (SELECT 
														tb.defect_id
														,tb.[description]
														,tb.[location]
														,tb.loc_major
														,tb.loc_minor
			 											,defectdtls =( SELECT		
																		t.exam_date
																		,t.exam_id
																		,t.access_gained
																		,t.exam_type
																		,t.recommendation_number
																		,t.risk_score
																		,t.access_required
																		,t.deterioration
																		,t.repaired
																		,t.closure_flg
																		,t.recommendation_comments
																	  FROM #tbl_DefectSearchResultAPI AS t
																	  WHERE t.defect_id = tb.defect_id
																	  AND t.asset_guid = tb.asset_guid
																	  FOR JSON PATH, INCLUDE_NULL_VALUES)
														FROM #tbl_DefectSearchResultAPI tb
														WHERE tb.asset_guid = sr.asset_guid
														
														GROUP BY tb.asset_guid
																,tb.defect_id
																 ,tb.[description]
																,tb.[location]
																,tb.loc_major
																,tb.loc_minor
														FOR JSON PATH, INCLUDE_NULL_VALUES
													 )									
								FROM #tbl_DefectSearchResultAPI AS sr
								GROUP BY elr
										,asset_guid
										,railway_id
										,open_defects
										,total_defects
										,highest_open_defect_score
								
								FOR JSON PATH, INCLUDE_NULL_VALUES
							  ) defectsearchresult
							FOR JSON PATH, INCLUDE_NULL_VALUES, WITHOUT_ARRAY_WRAPPER
					    )
	
		END

		--PRINT @result
		SELECT @result AS response, NULL AS ErrorMsg

	END TRY
	BEGIN CATCH

		IF @ErrorMsg IS NULL
			SET @ErrorMsg = ERROR_MESSAGE() 

		SET @ErrorDescription = @ErrorMsg + 
						' Line Num:' + CONVERT(VARCHAR(5), ERROR_LINE()) + 
						',ErrorNum:' + CONVERT(VARCHAR(5), ERROR_NUMBER()) + 
						',Severity:' + CONVERT(VARCHAR(5), ERROR_SEVERITY()) + 
						',State:' + CONVERT(VARCHAR(10), ERROR_STATE()) + 
						',Procedure:' + CONVERT(VARCHAR(25), OBJECT_NAME(@@procid)) +
						',Procedure:' + CONVERT(VARCHAR(25), ERROR_PROCEDURE());  
		
		SET @result=
					(
						SELECT 
							JSON_QUERY(
										(
											select
												@pageno AS currentpage,
												@totalresultcnt AS totalcount,
												0 AS totalpages
											FOR JSON PATH,WITHOUT_ARRAY_WRAPPER
										)
							) searchdatacount,
							JSON_QUERY('[]') searchresult
						
						FOR JSON PATH,WITHOUT_ARRAY_WRAPPER, INCLUDE_NULL_VALUES
				)

		SELECT @result AS response, @ErrorMsg AS ErrorMsg

		DROP TABLE IF EXISTS #tbl_DefectSearchResultAPI;
		DROP TABLE IF EXISTS #tbl_Asset;
		THROW 50000,@ErrorMsg,1;

		
	END CATCH
	
	DROP TABLE IF EXISTS #tbl_DefectSearchResultAPI;
	DROP TABLE IF EXISTS #tbl_Asset;
	
	SET NOCOUNT OFF
END