﻿




/***************************************************************************************************************************************            
* Name						: sp_Get_AssetSearch_SearchResult            
* Created By				: Cognizant            
* Date Created				: 11-Dec-2020           
* Description				: This stored procedure provides the search result for asset basic and advanced search.  
* Input Parameters			: JSON      
* Output Parameters			: @OUT_ErrorNo            
* Return Value				: N/A            
* Assumptions				: None    
* Execution Statement		: Exec [CES].sp_Get_AssetSearch_SearchResult '{
																		"region_name": "Southern",
																		"route_id": 0,
																		"area_id": 0,
																		"elr_id": [0],	
																		"start_mileage_from": -1,
																		"start_mileage_to": 99999,
																		"railway_id": null,
																		"ast_grp_id": 0,
																		"ast_typ_id": [0],
																		"opstat_id": [0],
																		"ownparty_name": null,
																		"asset_desc": null,
																		"mattyp_id": [0],
																		"hceflg_name": "All",
																		"cmi_score_from": -1,
																		"cmi_score_to": 99999,
																		"strccarries_name": null,
																		"strcover_name": null,
																		"outsideparty_name": null,
																		"isexporttodoc": "Y",
																		"sortcolumn": "StartMileage",
																		"sortorder": "asc",
																		"pageno": 1,
																		"rowsperpage": 25
																	}'

* Sample input values												"elr_id": [106,159,288]
																	"opstat_id": [552,556,557,562]
																	"mattyp_id": [397,409,397,409,416,418,420,431]																
																	"ownparty_name": ["Outside Party","Atkins Rail (FI)", "Network Rail (CE-Struct)"]
																	"outsideparty_name": ["Bexhill Corporation","British Gas South East","East Sussex County Council","Highways Agency","Kent County Council","Kent County Council / National Grid plc","London Borough of Bromley","London Borough of Lambeth","Medway & Chatham Dock Company","National Grid plc","South East Water","Southern Water","The Admiralty","Tonbridge & Malling District Council"]
																	"strccarries_name": ["Rail","Road Pub","Foot","Land","Path","Road NP","unknown","Disused","Side Access","Services","Station Building(s)","Water"]
																	"strcover_name":  ["Tenant","Road Pub","Yard","Rail","Foot","Disused","Road NP","Path","Water","Land","unknown","Services","DYKE","Various","Cess"]
*
*									
* Modified Date     Modified By   Revision Number  Modifications            
  16-Jul-2021       Cognizant	  2.0			   Release 2 -US# 37568 - AccessData - Added 'COMMENTS' field
  27-Jul-2021		Cognizant	  2.1			   Multi select option enabled for following fields "opstat_id", "mattyp_id", "ownparty_name", "outsideparty_name", "strccarries_name", "strcover_name" 
												   User Story # 22846
*******************************************************************************************************************************************/ 



CREATE PROCEDURE [CES].[sp_Get_AssetSearch_SearchResult]
	@Input_JSON		NVARCHAR(MAX)
AS
BEGIN
	SET NOCOUNT ON
	SET ANSI_WARNINGS OFF;
	BEGIN TRY
		DECLARE
				@ErrorMsg			VARCHAR(250),
				@result				NVARCHAR(MAX),
				@region_name		VARCHAR(64),
				@route_id			DECIMAL(18),
				@area_id			DECIMAL(18),
				@elr_id				NVARCHAR(MAX),
				@start_mileage_from	DECIMAL(18,4),
				@start_mileage_to	DECIMAL(18,4),
				@railway_id			VARCHAR(64),
				@ast_grp_id			DECIMAL(18),
				@opstat_id			NVARCHAR(MAX),
				@ownparty_name		NVARCHAR(MAX),
				@asset_desc			VARCHAR(200),
				@mattyp_id			NVARCHAR(MAX),
				@hceflg_name		VARCHAR(4),
				@cmi_score_from		DECIMAL(18),
				@cmi_score_to		DECIMAL(18),
				@strccarries_name	NVARCHAR(MAX),
				@strcover_name		NVARCHAR(MAX),
				@isexporttodoc		VARCHAR(1),
				@sortcolumn			VARCHAR(30),
				@sortorder			VARCHAR(5),
				@pageno				DECIMAL(18),
				@rowsperpage		DECIMAL(18),
				@ast_typ_array		NVARCHAR(MAX),
				@isasttypselected	CHAR(1) = 'N',
				@isbasicsearch		CHAR(1) = 'Y',
				@totalresultcnt		INT,
				@current_date		DATE = GETDATE(),
				@dtl_exam_typ_id	DECIMAL(18),
				@vis_exam_typ_id	DECIMAL(18),
				@outsideparty_name	NVARCHAR(MAX),
				@iselrselected		CHAR(1) = 'N',
				@ast_guids			NVARCHAR(MAX),
				@ismatselected		CHAR(1) = 'N',
				@isopsstatselected		CHAR(1) = 'N',
				@isownpartyselected		CHAR(1) = 'N',
				@isoutpartyselected		CHAR(1) = 'N',
				@isstrccarriesselected		CHAR(1) = 'N',
				@isstrcoverselected		CHAR(1) = 'N'

		DECLARE @ast_typ TABLE
		(
			ast_typ_id DECIMAL(18)
		)

		CREATE TABLE #tbl_SearchResult
		(
				asset_guid			VARCHAR(32),
				region				VARCHAR(64),
				route				VARCHAR(64),
				elr					VARCHAR(4),
				start_mileage		DECIMAL(18,4),
				--end_mileage			DECIMAL(18,4),
				railway_id			VARCHAR(64),
				asset_desc			VARCHAR(200),
				asset_grp			VARCHAR(64),
				asset_type			VARCHAR(64),
				operation_status	VARCHAR(500),
				owning_party		VARCHAR(64),
				primary_material	VARCHAR(500),
				last_Dtl_Exam		DATE,
				--dtl_exam_freq		VARCHAR(20),
				last_vis_exam		DATE,
				outside_party		VARCHAR(64),
				structure_carries	VARCHAR(64),
				structure_over		VARCHAR(64),
				hce_flg				VARCHAR(4),
				cmi_score			DECIMAL(3),
				tenanted_flg		VARCHAR(4)
		)

		DECLARE @elr_id_array TABLE
		(
			elr_id DECIMAL(18)
		)
		
		DECLARE @mat_id_array TABLE
		(
			mat_id DECIMAL(18)
		)

		DECLARE @ops_stat_id_array TABLE
		(
			ops_stat_id DECIMAL(18)
		)

		DECLARE @own_party_array TABLE
		(
			own_party VARCHAR(64)
		)

		DECLARE @out_party_array TABLE
		(
			out_party VARCHAR(64)
		)

		DECLARE @struc_carries_array TABLE
		(
			struc_carries VARCHAR(64)
		)

		DECLARE @struc_over_array TABLE
		(
			struc_over VARCHAR(64)
		)

		CREATE TABLE #tbl_AssetAccessDtls
		(
				region					VARCHAR(64),
				route					VARCHAR(64),
				area					VARCHAR(64),
				elr						VARCHAR(4),
				asset_guid				VARCHAR(32),
				railway_id				VARCHAR(64),
				asset_group				VARCHAR(64),
				asset_type				VARCHAR(64),
				start_mileage			DECIMAL(18,5),
				end_mileage				DECIMAL(18,5),
				primary_material		VARCHAR(64),
				owning_party			VARCHAR(64),
				gps_start				VARCHAR(64),
				gps_end					VARCHAR(64),
				structure_carries		VARCHAR(64),
				structure_over			VARCHAR(64),
				hce_flag				VARCHAR(4),
				cmi_score				DECIMAL(3),
				tenanted_flg			VARCHAR(4),
				exam_type				VARCHAR(32), 
				comp_status				VARCHAR(100),
				possession				VARCHAR(32),
				rrv						VARCHAR(32),
				ladder					VARCHAR(32),
				confined_space			VARCHAR(32),
				[3rd_party]				VARCHAR(32),
				line_block				VARCHAR(32),
				mewp					VARCHAR(32),
				scaffold				VARCHAR(32),
				water_permit			VARCHAR(32),
				traffic_mngt			VARCHAR(32),
				rope_access				VARCHAR(32),
				cctv					VARCHAR(32),
				safety_boat				VARCHAR(32),
				comments				VARCHAR(8000)--Release 2 -US# 37568 - AccessData -Modified to add 'COMMENTS' field --END
				--Comments column length updated to 8000 in access table
		)

		SELECT 
			@region_name = COALESCE(@region_name,CASE LOWER([key]) WHEN 'region_name' THEN [value] ELSE NULL END),
			@route_id = COALESCE(@route_id,CASE LOWER([key]) WHEN 'route_id' THEN [value] ELSE NULL END),
			@area_id = COALESCE(@area_id,CASE LOWER([key]) WHEN 'area_id' THEN [value] ELSE NULL END),
			@elr_id = COALESCE(@elr_id,CASE LOWER([key]) WHEN 'elr_id' THEN [value] ELSE NULL END),
			@start_mileage_from = COALESCE(@start_mileage_from,CASE LOWER([key]) WHEN 'start_mileage_from' THEN [value] ELSE NULL END),
			@start_mileage_to = COALESCE(@start_mileage_to,CASE LOWER([key]) WHEN 'start_mileage_to' THEN [value] ELSE NULL END),
			@railway_id = COALESCE(@railway_id,CASE LOWER([key]) WHEN 'railway_id' THEN [value] ELSE NULL END),
			@ast_grp_id = COALESCE(@ast_grp_id,CASE LOWER([key]) WHEN 'ast_grp_id' THEN [value] ELSE NULL END),
			@ast_typ_array = COALESCE(@ast_typ_array,CASE LOWER([key]) WHEN 'ast_typ_id' THEN [value] ELSE NULL END),
			@opstat_id = COALESCE(@opstat_id,CASE LOWER([key]) WHEN 'opstat_id' THEN [value] ELSE NULL END),
			@ownparty_name = COALESCE(@ownparty_name,CASE LOWER([key]) WHEN 'ownparty_name' THEN [value] ELSE NULL END),
			@asset_desc = COALESCE(@asset_desc,CASE LOWER([key]) WHEN 'asset_desc' THEN [value] ELSE NULL END),
			@mattyp_id = COALESCE(@mattyp_id,CASE LOWER([key]) WHEN 'mattyp_id' THEN [value] ELSE NULL END),
			@hceflg_name = COALESCE(@hceflg_name,CASE LOWER([key]) WHEN 'hceflg_name' THEN [value] ELSE NULL END),
			@cmi_score_from = COALESCE(@cmi_score_from,CASE LOWER([key]) WHEN 'cmi_score_from' THEN [value] ELSE NULL END),
			@cmi_score_to = COALESCE(@cmi_score_to,CASE LOWER([key]) WHEN 'cmi_score_to' THEN [value] ELSE NULL END),
			@strccarries_name = COALESCE(@strccarries_name,CASE LOWER([key]) WHEN 'strccarries_name' THEN [value] ELSE NULL END),
			@strcover_name = COALESCE(@strcover_name,CASE LOWER([key]) WHEN 'strcover_name' THEN [value] ELSE NULL END),
			@outsideparty_name = COALESCE(@outsideparty_name,CASE LOWER([key]) WHEN 'outsideparty_name' THEN [value] ELSE NULL END),
			@isexporttodoc = COALESCE(@isexporttodoc,CASE LOWER([key]) WHEN 'isexporttodoc' THEN [value] ELSE NULL END),
			@sortcolumn = COALESCE(@sortcolumn,CASE LOWER([key]) WHEN 'sortcolumn' THEN [value] ELSE NULL END),
			@sortorder = COALESCE(@sortorder,CASE LOWER([key]) WHEN 'sortorder' THEN [value] ELSE NULL END),
			@pageno = COALESCE(@pageno,CASE LOWER([key]) WHEN 'pageno' THEN [value] ELSE NULL END),
			@rowsperpage = COALESCE(@rowsperpage,CASE LOWER([key]) WHEN 'rowsperpage' THEN [value] ELSE NULL END)

		FROM	OPENJSON(@Input_JSON);



		IF (@region_name IS NULL)
		BEGIN

			SET @ErrorMsg = 'Region cannot be NULL';
			DROP TABLE IF EXISTS #tbl_SearchResult;
			THROW 50000,@ErrorMsg,1;
		END


		IF @ast_typ_array IS NOT NULL 
		BEGIN
			INSERT INTO @ast_typ (ast_typ_id)
			SELECT[value] FROM OPENJSON(@ast_typ_array);

			IF EXISTS (SELECT 1 FROM @ast_typ WHERE ast_typ_id=0)
				SET @isasttypselected = 'N'
			ELSE
				SET @isasttypselected = 'Y'
		END 

		IF @elr_id IS NOT NULL 
		BEGIN
			INSERT INTO @elr_id_array (elr_id)
			SELECT[value] FROM OPENJSON(@elr_id);

			IF EXISTS (SELECT 1 FROM @elr_id_array WHERE elr_id=0)
				SET @iselrselected = 'N'
			ELSE
				SET @iselrselected = 'Y'
		END 
		
		IF @mattyp_id IS NOT NULL 
		BEGIN
			INSERT INTO @mat_id_array (mat_id)
			SELECT[value] FROM OPENJSON(@mattyp_id);

			IF EXISTS (SELECT 1 FROM @mat_id_array WHERE mat_id=0)
				SET @ismatselected = 'N'
			ELSE
				SET @ismatselected = 'Y'
		END 

		IF @opstat_id IS NOT NULL 
		BEGIN
			INSERT INTO @ops_stat_id_array (ops_stat_id)
			SELECT[value] FROM OPENJSON(@opstat_id);

			IF EXISTS (SELECT 1 FROM @ops_stat_id_array WHERE ops_stat_id=0)
				SET @isopsstatselected = 'N'
			ELSE
				SET @isopsstatselected = 'Y'
		END 

		IF @ownparty_name IS NOT NULL 
		BEGIN
			INSERT INTO @own_party_array (own_party)
			SELECT[value] FROM OPENJSON(@ownparty_name);

			IF (SELECT count(own_party) FROM @own_party_array)>0
				SET @isownpartyselected = 'Y'
			ELSE
				SET @isownpartyselected = 'N'
		END 

		IF @outsideparty_name IS NOT NULL 
		BEGIN
			INSERT INTO @out_party_array (out_party)
			SELECT[value] FROM OPENJSON(@outsideparty_name);

			IF (SELECT count(out_party) FROM @out_party_array)>0
				SET @isoutpartyselected = 'Y'
			ELSE
				SET @isoutpartyselected = 'N'
		END 

		IF @strccarries_name IS NOT NULL 
		BEGIN
			INSERT INTO @struc_carries_array (struc_carries)
			SELECT[value] FROM OPENJSON(@strccarries_name);

			IF (SELECT count(struc_carries) FROM @struc_carries_array)>0
				SET @isstrccarriesselected = 'Y'
			ELSE
				SET @isstrccarriesselected = 'N'
		END 

		IF @strcover_name IS NOT NULL 
		BEGIN
			INSERT INTO @struc_over_array (struc_over)
			SELECT[value] FROM OPENJSON(@strcover_name);

			IF (SELECT count(struc_over) FROM @struc_over_array)>0
				SET @isstrcoverselected = 'Y'
			ELSE
				SET @isstrcoverselected = 'N'
		END 

		--IF (@iselrselected = 'N' AND @start_mileage_from = -1 AND @start_mileage_to = 99999 AND @railway_id IS NULL AND @ast_grp_id = 0 AND @isasttypselected = 'N' AND @opstat_id = 0 AND @ownparty_name IS NULL
		--	AND @asset_desc IS NULL AND @mattyp_id = 0 AND @hceflg_name = 'All' AND @cmi_score_from = -1 AND @cmi_score_to = 99999 AND @strccarries_name IS NULL AND
		--	@strcover_name IS NULL AND @outsideparty_name IS NULL)
		IF (@iselrselected = 'N' AND @start_mileage_from = -1 AND @start_mileage_to = 99999 AND @railway_id IS NULL AND @ast_grp_id = 0 AND @isasttypselected = 'N' AND  @isopsstatselected = 'N' AND @isownpartyselected = 'N'
			AND @asset_desc IS NULL AND @ismatselected = 'N' AND @hceflg_name = 'All' AND @cmi_score_from = -1 AND @cmi_score_to = 99999 AND @isstrccarriesselected = 'N' AND
			@isstrcoverselected = 'N' AND @isoutpartyselected = 'N')
				
			SET @isbasicsearch = 'Y'
		ELSE
			SET @isbasicsearch = 'N'
		
		SELECT @dtl_exam_typ_id = EXAM_TYPE_SR_KEY FROM CES.EXAM_TYPE WHERE EXAM_TYPE = 'Detailed' AND ISACTIVE = 1
		SELECT @vis_exam_typ_id = EXAM_TYPE_SR_KEY FROM CES.EXAM_TYPE WHERE EXAM_TYPE = 'Visual' AND ISACTIVE = 1

		IF @isbasicsearch = 'N'		-- Advanced Search
		BEGIN
			
				
				INSERT INTO #tbl_SearchResult
				(
						asset_guid,
						region,
						route,
						elr,
						start_mileage,
						--end_mileage,
						railway_id,
						asset_desc,
						asset_grp,
						asset_type,
						operation_status,
						owning_party,
						primary_material,
						last_Dtl_Exam,
						--dtl_exam_freq,
						last_vis_exam,
						outside_party,
						structure_carries,
						structure_over,
						hce_flg,
						cmi_score,
						tenanted_flg
				)
				SELECT 
					ast.ASSET_GUID AS asset_guid,
					o.REGION AS region,
					o.ROUTE AS route,
					elr.ELR_CODE AS elr,
					(ast.START_MILES + ast.START_YARDS/1760) AS start_mileage,
					--(ast.END_MILES + ast.END_YARDS/1760) AS end_mileage,
					ast.RAILWAY_ID AS railway_id,
					ast.ASSET_NAME AS asset_desc,
					asg.ASSET_GROUP_DESC AS asset_grp,
					asp.ASSET_TYPE_DESC AS asset_type,
					ops.REF_VALUE AS operation_status,
					ast.OWNING_PARTY AS owning_party,
					mat.REF_VALUE AS primary_material,
					CASE WHEN exdt.last_dtl_exam = CONVERT(DATE,'1/1/1900',103) THEN NULL ELSE exdt.last_dtl_exam END AS last_dtl_exam,
					--dtl.dtl_exam_freq,
					CASE WHEN exdt.last_vis_exam = CONVERT(DATE,'1/1/1900',103) THEN NULL ELSE exdt.last_vis_exam END AS last_vis_exam, 
					ast.outside_party,
					ast.structure_carries,
					ast.structure_over,
					IIF(ast.HCE_FLAG='Y','Yes','No') AS hce_flg,
					ast.cmi_score,
					CASE WHEN ast.TENANTED_FLG = 'Y' THEN 'Yes'
						 WHEN ast.TENANTED_FLG = 'N' THEN 'No'
						 ELSE 'N/A'
					END AS tenanted_flg
												
				FROM [CES].ASSET ast
				INNER JOIN [CES].ORG o
				ON ast.ORG_SR_KEY = o.ORG_SR_KEY
				INNER JOIN [CES].AREA a
				ON a.AREA_SR_KEY = ast.AREA_SR_KEY
				INNER JOIN [CES].ENGINE_LINE_REF elr
				ON elr.ELR_SR_KEY = ast.ENG_LINE_REF
				AND elr.ORG_SR_KEY = ast.ORG_SR_KEY
				AND elr.AREA_SR_KEY = ast.AREA_SR_KEY
				INNER JOIN [CES].ASSET_GROUP asg
				ON asg.ASSET_GROUP_SR_KEY = ast.ASSET_GROUP_SR_KEY
				INNER JOIN [CES].ASSET_TYPE asp
				ON asp.ASSET_TYPE_SR_KEY = ast.ASSET_TYPE_SR_KEY
				LEFT JOIN [CES].REFERENCE_VALUE ops
				ON ops.REF_VAL_SR_KEY = ast.OPERATIONAL_STATUS
				AND ops.ISACTIVE = 1
				LEFT JOIN [CES].REFERENCE_VALUE mat
				ON mat.REF_VAL_SR_KEY = ast.PRIMARY_MATERIAL
				AND mat.ISACTIVE = 1
				OUTER APPLY
					--(
					--	SELECT
					--		tmp.last_dtl_exam,
					--		tmp.dtl_exam_freq
					--	FROM 
					--	(
					--		SELECT 
					--			CONVERT(VARCHAR,ec.LAST_EXAM_DATE,103) last_dtl_exam,
					--			CAST (ec.INTERVAL_DAYS AS VARCHAR(5))+ 'y '+CAST (ec.INTERVAL_MONTHS AS VARCHAR(5))+ 'm '+CAST (ec.INTERVAL_DAYS AS VARCHAR(5))+'d' AS dtl_exam_freq,
					--			ROW_NUMBER() OVER (PARTITION BY ec.ASSET_GUID ,ec.EXAM_TYPE_SR_KEY  ORDER BY ec.EFFECTIVE_FROM_DT DESC) rnk
					--		FROM [CES].EXAM_CYCLE ec
					--		WHERE ec.ASSET_GUID = ast.ASSET_GUID
					--		AND ec.EXAM_TYPE_SR_KEY = @dtl_exam_typ_id
					--		AND ec.ISACTIVE = 1
					--		AND @current_date BETWEEN EFFECTIVE_FROM_DT AND ISNULL(EFFECTIVE_TO_DT,'12/31/9999')
					--	)tmp
					--	WHERE tmp.rnk=1
					--)dtl
					(
						SELECT 
							MAX(CASE WHEN EXAM_TYPE_SR_KEY = @dtl_exam_typ_id THEN ISNULL(EXAM_ACTUAL_DATE,CONVERT(DATE,'1/1/1900',103)) 
								ELSE CONVERT(DATE,'1/1/1900',103)
							END) AS last_dtl_exam,
							MAX(CASE WHEN EXAM_TYPE_SR_KEY = @vis_exam_typ_id THEN ISNULL(EXAM_ACTUAL_DATE,CONVERT(DATE,'1/1/1900',103)) 
								ELSE CONVERT(DATE,'1/1/1900',103)
							END) AS last_vis_exam
						FROM	CES.EXAM
						WHERE   ASSET_GUID = ast.ASSET_GUID
						AND 	EXAM_TYPE_SR_KEY IN (@dtl_exam_typ_id,@vis_exam_typ_id )
						AND		IS_LAST_EXAM = 'Y'
						AND 	ISACTIVE = 1
					)exdt

				WHERE
					ast.ISACTIVE= 1
				AND o.ISACTIVE = 1
				AND elr.ISACTIVE = 1
				AND asg.ISACTIVE = 1
				AND asp.ISACTIVE = 1
				AND o.REGION = @region_name
				AND ( @route_id =0 OR (@route_id <> 0 AND o.ORG_SR_KEY = @route_id))
				AND	( @area_id =0 OR (@area_id <> 0 AND a.AREA_SR_KEY = @area_id))
				AND ( @iselrselected = 'N' OR (@iselrselected = 'Y' AND ast.ENG_LINE_REF IN (SELECT elr_id FROM @elr_id_array)) )
				AND ( (ast.START_MILES + ast.START_YARDS/1760) BETWEEN @start_mileage_from AND @start_mileage_to)
				--AND ( @railway_id IS NULL OR (@railway_id IS NOT NULL AND ast.RAILWAY_ID = @railway_id))
				AND ( @railway_id IS NULL OR (@railway_id IS NOT NULL AND ast.RAILWAY_ID LIKE ('%' + @railway_id + '%')))
				AND ( @ast_grp_id =0 OR (@ast_grp_id <> 0 AND asg.ASSET_GROUP_SR_KEY = @ast_grp_id))
				AND ( @isasttypselected = 'N' OR (@isasttypselected = 'Y' AND asp.ASSET_TYPE_SR_KEY IN (SELECT ast_typ_id FROM @ast_typ)) )
				--AND	( @opstat_id =0 OR (@opstat_id <> 0 AND ops.REF_VAL_SR_KEY = @opstat_id))
				AND ( @isopsstatselected = 'N' OR (@isopsstatselected = 'Y' AND ops.REF_VAL_SR_KEY IN (SELECT ops_stat_id FROM @ops_stat_id_array)) )
				--AND	( @ownparty_name IS NULL OR (@ownparty_name IS NOT NULL AND ast.OWNING_PARTY = @ownparty_name))
				AND	( @isownpartyselected ='N' OR  (@isownpartyselected = 'Y' AND ast.OWNING_PARTY IN (SELECT own_party FROM @own_party_array)))
				--AND	( @asset_desc IS NULL OR (@asset_desc IS NOT NULL AND ast.ASSET_NAME LIKE (@asset_desc + '%') ))
				AND	( @asset_desc IS NULL OR (@asset_desc IS NOT NULL AND ast.ASSET_NAME LIKE ( '%' + @asset_desc + '%') ))
				--AND ( @mattyp_id =0 OR (@mattyp_id <> 0 AND mat.REF_VAL_SR_KEY = @mattyp_id))
				AND ( @ismatselected = 'N' OR (@ismatselected = 'Y' AND mat.REF_VAL_SR_KEY IN (SELECT mat_id FROM @mat_id_array)) )
				AND ( @hceflg_name ='All' OR (@hceflg_name = 'Yes' AND ast.HCE_FLAG = 'Y') OR (@hceflg_name = 'No' AND ast.HCE_FLAG = 'N') )
				AND ( ISNULL(ast.CMI_SCORE,0) BETWEEN  @cmi_score_from AND @cmi_score_to)
				--AND ( @strccarries_name IS NULL OR (@strccarries_name IS NOT NULL AND ast.STRUCTURE_CARRIES = @strccarries_name))
				AND	( @isstrccarriesselected ='N' OR  (@isstrccarriesselected = 'Y' AND ast.STRUCTURE_CARRIES IN (SELECT struc_carries FROM @struc_carries_array)))
				--AND ( @strcover_name IS NULL OR (@strcover_name IS NOT NULL AND ast.STRUCTURE_OVER = @strcover_name))
				AND	( @isstrcoverselected ='N' OR  (@isstrcoverselected = 'Y' AND ast.STRUCTURE_OVER IN (SELECT struc_over FROM @struc_over_array)))
				--AND	( @outsideparty_name IS NULL OR (@outsideparty_name IS NOT NULL AND ast.OUTSIDE_PARTY = @outsideparty_name))
				AND	( @isoutpartyselected ='N' OR  (@isoutpartyselected = 'Y' AND ast.OUTSIDE_PARTY IN (SELECT out_party FROM @out_party_array)))

		END

		ELSE	--Basic search
		BEGIN
		
				INSERT INTO #tbl_SearchResult
				(
						asset_guid,
						region,
						route,
						elr,
						start_mileage,
						--end_mileage,
						railway_id,
						asset_desc,
						asset_grp,
						asset_type,
						operation_status,
						owning_party,
						primary_material,
						last_Dtl_Exam,
						--dtl_exam_freq,
						last_vis_exam,
						outside_party,
						structure_carries,
						structure_over,
						hce_flg,
						cmi_score,
						tenanted_flg
				)
				SELECT 
					ast.ASSET_GUID AS asset_guid,
					o.REGION AS region,
					o.ROUTE AS route,
					elr.ELR_CODE AS elr,
					(ast.START_MILES + ast.START_YARDS/1760) AS start_mileage,
					--(ast.END_MILES + ast.END_YARDS/1760) AS end_mileage,
					ast.RAILWAY_ID AS railway_id,
					ast.ASSET_NAME AS asset_desc,
					asg.ASSET_GROUP_DESC AS asset_grp,
					asp.ASSET_TYPE_DESC AS asset_type,
					ops.REF_VALUE AS operation_status,
					ast.OWNING_PARTY AS owning_party,
					mat.REF_VALUE AS primary_material,
					CASE WHEN exdt.last_dtl_exam = CONVERT(DATE,'1/1/1900',103) THEN NULL ELSE exdt.last_dtl_exam END AS last_dtl_exam,
					--dtl.dtl_exam_freq,
					CASE WHEN exdt.last_vis_exam = CONVERT(DATE,'1/1/1900',103) THEN NULL ELSE exdt.last_vis_exam END AS last_vis_exam, 
					ast.outside_party,
					ast.structure_carries,
					ast.structure_over,
					IIF(ast.HCE_FLAG='Y','Yes','No') AS hce_flg,
					ast.cmi_score,
					CASE WHEN ast.TENANTED_FLG = 'Y' THEN 'Yes'
						 WHEN ast.TENANTED_FLG = 'N' THEN 'No'
						 ELSE 'N/A'
					END AS tenanted_flg
												
				FROM [CES].ASSET ast
				INNER JOIN [CES].ORG o
				ON ast.ORG_SR_KEY = o.ORG_SR_KEY
				INNER JOIN [CES].AREA a
				ON a.AREA_SR_KEY = ast.AREA_SR_KEY
				INNER JOIN [CES].ENGINE_LINE_REF elr
				ON elr.ELR_SR_KEY = ast.ENG_LINE_REF
				INNER JOIN [CES].ASSET_GROUP asg
				ON asg.ASSET_GROUP_SR_KEY = ast.ASSET_GROUP_SR_KEY
				INNER JOIN [CES].ASSET_TYPE asp
				ON asp.ASSET_TYPE_SR_KEY = ast.ASSET_TYPE_SR_KEY
				LEFT JOIN [CES].REFERENCE_VALUE ops
				ON ops.REF_VAL_SR_KEY = ast.OPERATIONAL_STATUS
				AND ops.ISACTIVE = 1
				LEFT JOIN [CES].REFERENCE_VALUE mat
				ON mat.REF_VAL_SR_KEY = ast.PRIMARY_MATERIAL
				AND mat.ISACTIVE = 1
				OUTER APPLY
					--(
					--	SELECT
					--		tmp.last_dtl_exam,
					--		tmp.dtl_exam_freq
					--	FROM 
					--	(
					--		SELECT 
					--			CONVERT(VARCHAR,ec.LAST_EXAM_DATE,103) last_dtl_exam,
					--			CAST (ec.INTERVAL_DAYS AS VARCHAR(5))+ 'y '+CAST (ec.INTERVAL_MONTHS AS VARCHAR(5))+ 'm '+CAST (ec.INTERVAL_DAYS AS VARCHAR(5))+'d' AS dtl_exam_freq,
					--			ROW_NUMBER() OVER (PARTITION BY ec.ASSET_GUID ,ec.EXAM_TYPE_SR_KEY  ORDER BY ec.EFFECTIVE_FROM_DT DESC) rnk
					--		FROM [CES].EXAM_CYCLE ec
					--		WHERE ec.ASSET_GUID = ast.ASSET_GUID
					--		AND ec.EXAM_TYPE_SR_KEY = @dtl_exam_typ_id
					--		AND ec.ISACTIVE = 1
					--		AND @current_date BETWEEN EFFECTIVE_FROM_DT AND ISNULL(EFFECTIVE_TO_DT,'12/31/9999')
					--	)tmp
					--	WHERE tmp.rnk=1
					--)dtl
					
					(
						SELECT 
							MAX(CASE WHEN EXAM_TYPE_SR_KEY = @dtl_exam_typ_id THEN ISNULL(EXAM_ACTUAL_DATE,CONVERT(DATE,'1/1/1900',103)) 
								ELSE CONVERT(DATE,'1/1/1900',103)
							END) AS last_dtl_exam,
							MAX(CASE WHEN EXAM_TYPE_SR_KEY = @vis_exam_typ_id THEN ISNULL(EXAM_ACTUAL_DATE,CONVERT(DATE,'1/1/1900',103)) 
								ELSE CONVERT(DATE,'1/1/1900',103)
							END) AS last_vis_exam
						FROM	CES.EXAM
						WHERE   ASSET_GUID = ast.ASSET_GUID
						AND 	EXAM_TYPE_SR_KEY IN (@dtl_exam_typ_id,@vis_exam_typ_id )
						AND		IS_LAST_EXAM = 'Y'
						AND 	ISACTIVE = 1
					)exdt


				WHERE
					ast.ISACTIVE= 1
				AND o.ISACTIVE = 1
				AND elr.ISACTIVE = 1
				AND asg.ISACTIVE = 1
				AND asp.ISACTIVE = 1
				AND o.REGION = @region_name
				AND ( @route_id =0 OR (@route_id <> 0 AND o.ORG_SR_KEY = @route_id))
				AND	( @area_id =0 OR (@area_id <> 0 AND a.AREA_SR_KEY = @area_id))

				
		END
		
		--Total count of records
		SELECT @totalresultcnt = COUNT(1) FROM #tbl_SearchResult


		--If no records are returned in search result
		IF  @totalresultcnt=0 
		BEGIN
			SET @result=
					(
						SELECT 
							JSON_QUERY(
										(
											select
												@pageno AS currentpage,
												@totalresultcnt AS totalcount,
												0 AS totalpages
											FOR JSON PATH,WITHOUT_ARRAY_WRAPPER
										)
							) searchdatacount,
							JSON_QUERY('[]') searchresult
						
						FOR JSON PATH,WITHOUT_ARRAY_WRAPPER, INCLUDE_NULL_VALUES
				)
		END	
		--If alt least 1 record is returned in search result
		ELSE
		BEGIN
			IF @isexporttodoc = 'Y' --Export to Excel
			BEGIN
			
					/*IF @sortorder = 'asc' 
					BEGIN
				
						SET @result=
						(
							SELECT 
								JSON_QUERY(
											(
												select
													@pageno AS currentpage,
													@totalresultcnt AS totalcount,
													CEILING(@totalresultcnt/@rowsperpage) AS totalpages
												FOR JSON PATH,WITHOUT_ARRAY_WRAPPER
											)
								) searchdatacount,
							(
								SELECT
									asset_guid,
									region,
									route,
									elr,
									start_mileage,
									--end_mileage,
									railway_id,
									asset_desc,
									asset_grp,
									asset_type,
									operation_status,
									owning_party,
									primary_material,
									last_Dtl_Exam,
									--dtl_exam_freq,
									last_vis_exam,
									outside_party,
									structure_carries,
									structure_over,
									hce_flg,
									cmi_score,
									tenanted_flg
								FROM
								(
									SELECT
											asset_guid,
											region,
											route,
											elr,
											start_mileage,
											--end_mileage,
											railway_id,
											asset_desc,
											asset_grp,
											asset_type,
											operation_status,
											owning_party,
											primary_material,
											last_Dtl_Exam,
											--dtl_exam_freq,
											last_vis_exam,
											outside_party,
											structure_carries,
											structure_over,
											hce_flg,
											cmi_score,
											tenanted_flg,
											ROW_NUMBER() OVER (ORDER BY 
																		CASE WHEN @sortcolumn = 'Region' THEN region ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'Route' THEN route  ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'ELR' THEN elr  ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'StartMileage' THEN start_mileage ELSE NULL END ASC, 
																			 --WHEN @sortcolumn = 'EndMileage' THEN end_mileage ELSE NULL END, 
																		CASE WHEN @sortcolumn = 'RailwayID' THEN railway_id ELSE NULL END ASC, 
																		CASE WHEN @sortcolumn = 'AssetDescription' THEN asset_desc ELSE NULL END ASC, 
																		CASE WHEN @sortcolumn = 'AssetGroup' THEN asset_grp ELSE NULL END ASC, 
																		CASE WHEN @sortcolumn = 'AssetType' THEN asset_type ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'Operationstatus' THEN operation_status ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'OwningParty' THEN owning_party ELSE NULL END ASC, 
																		CASE WHEN @sortcolumn = 'PrimaryMaterial' THEN primary_material ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'LastDetailedExam' THEN last_Dtl_Exam ELSE NULL END ASC,
																			 --WHEN @sortcolumn = 'DetailedExamFrequency' THEN dtl_exam_freq ELSE NULL END,
																		CASE WHEN @sortcolumn = 'LastVisualExam' THEN last_vis_exam ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'OutsideParty' THEN outside_party ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'StructCarries' THEN structure_carries ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'StructOver' THEN structure_over ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'HCEFlg' THEN hce_flg ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'CMIScore' THEN cmi_score ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'TenantedFlg' THEN tenanted_flg ELSE NULL END ASC
																	
																	) AS ordrnk

									FROM #tbl_SearchResult
								)sr
								ORDER BY ordrnk
								FOR JSON AUTO, INCLUDE_NULL_VALUES
							)searchresult
							FOR JSON PATH,WITHOUT_ARRAY_WRAPPER, INCLUDE_NULL_VALUES
						)
					END
					ELSE IF @sortorder = 'desc' 
					BEGIN
					
						SET @result=
						(
							SELECT 
								JSON_QUERY(
											(
												select
													@pageno AS currentpage,
													@totalresultcnt AS totalcount,
													CEILING(@totalresultcnt/@rowsperpage) AS totalpages
												FOR JSON PATH,WITHOUT_ARRAY_WRAPPER
											)
								) searchdatacount,
							(
								SELECT
									asset_guid,
									region,
									route,
									elr,
									start_mileage,
									--end_mileage,
									railway_id,
									asset_desc,
									asset_grp,
									asset_type,
									operation_status,
									owning_party,
									primary_material,
									last_Dtl_Exam,
									--dtl_exam_freq,
									last_vis_exam,
									outside_party,
									structure_carries,
									structure_over,
									hce_flg,
									cmi_score,
									tenanted_flg
								FROM
								(
									SELECT
											asset_guid,
											region,
											route,
											elr,
											start_mileage,
											--end_mileage,
											railway_id,
											asset_desc,
											asset_grp,
											asset_type,
											operation_status,
											owning_party,
											primary_material,
											last_Dtl_Exam,
											--dtl_exam_freq,
											last_vis_exam,
											outside_party,
											structure_carries,
											structure_over,
											hce_flg,
											cmi_score,
											tenanted_flg,
											ROW_NUMBER() OVER (ORDER BY 
																		CASE WHEN @sortcolumn = 'Region' THEN region ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'Route' THEN route  ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'ELR' THEN elr  ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'StartMileage' THEN start_mileage ELSE NULL END DESC, 
																			 --WHEN @sortcolumn = 'EndMileage' THEN end_mileage ELSE NULL END, 
																		CASE WHEN @sortcolumn = 'RailwayID' THEN railway_id ELSE NULL END DESC, 
																		CASE WHEN @sortcolumn = 'AssetDescription' THEN asset_desc ELSE NULL END DESC, 
																		CASE WHEN @sortcolumn = 'AssetGroup' THEN asset_grp ELSE NULL END DESC, 
																		CASE WHEN @sortcolumn = 'AssetType' THEN asset_type ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'Operationstatus' THEN operation_status ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'OwningParty' THEN owning_party ELSE NULL END DESC, 
																		CASE WHEN @sortcolumn = 'PrimaryMaterial' THEN primary_material ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'LastDetailedExam' THEN last_Dtl_Exam ELSE NULL END DESC,
																			 --WHEN @sortcolumn = 'DetailedExamFrequency' THEN dtl_exam_freq ELSE NULL END,
																		CASE WHEN @sortcolumn = 'LastVisualExam' THEN last_vis_exam ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'OutsideParty' THEN outside_party ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'StructCarries' THEN structure_carries ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'StructOver' THEN structure_over ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'HCEFlg' THEN hce_flg ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'CMIScore' THEN cmi_score ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'TenantedFlg' THEN tenanted_flg ELSE NULL END ASC
																	
																	) AS ordrnk

									FROM #tbl_SearchResult
								)sr
								ORDER BY ordrnk
								FOR JSON AUTO, INCLUDE_NULL_VALUES
							)searchresult
							FOR JSON PATH,WITHOUT_ARRAY_WRAPPER, INCLUDE_NULL_VALUES
						)
					END*/

					--Creating the array of asset guids 
					set @ast_guids =  (SELECT CONCAT('[', '"' + (SELECT distinct STRING_AGG(STRING_ESCAPE(asset_guid, 'json'), '","') FROM #tbl_SearchResult) + '"', ']'))
					--Select @ast_guids
					--Retrieving the asset access details for the selected assets
					EXEC [CES].[sp_Get_AssetAccessDetails] @ast_guids

					SELECT @totalresultcnt = COUNT(1) FROM #tbl_AssetAccessDtls -- Added to set the result count when export doc option 

					SET @result=
						(
							SELECT 
								JSON_QUERY(
											(
												select
													1 AS currentpage,
													@totalresultcnt AS totalcount,
													1 AS totalpages
												FOR JSON PATH,WITHOUT_ARRAY_WRAPPER
											)
								) searchdatacount,
								(
									SELECT 									
													region,
													route,
													area,
													elr,
													asset_guid,
													railway_id,
													asset_group,
													asset_type,
													start_mileage,
													end_mileage,
													primary_material,
													owning_party,
													gps_start,
													gps_end,
													structure_carries,
													structure_over,
													hce_flag,
													cmi_score,
													tenanted_flg,
													exam_type, 
													comp_status,
													possession,
													rrv,
													ladder,
													confined_space,
													[3rd_party],
													line_block,
													mewp,
													scaffold,
													water_permit,
													traffic_mngt,
													rope_access,
													cctv,
													safety_boat,
													comments--Release 2 -US# 37568 - AccessData -Modified to add 'COMMENTS' field --END
																	
									FROM #tbl_AssetAccessDtls
									ORDER BY asset_guid, exam_type 										
									FOR JSON PATH, INCLUDE_NULL_VALUES
								) searchresult
							FOR JSON PATH, INCLUDE_NULL_VALUES, WITHOUT_ARRAY_WRAPPER
						)
						--print len(@result)
						--print @result
						
			END
			ELSE IF @isexporttodoc = 'N' --Screen output
			BEGIN
				IF @sortorder = 'asc' 
					BEGIN
			
						SET @result=
						(
							SELECT 
								JSON_QUERY(
											(
												select
													@pageno AS currentpage,
													@totalresultcnt AS totalcount,
													CEILING(@totalresultcnt/@rowsperpage) AS totalpages
												FOR JSON PATH,WITHOUT_ARRAY_WRAPPER
											)
								) searchdatacount,
							(
								SELECT
									asset_guid,
									region,
									route,
									elr,
									start_mileage,
									--end_mileage,
									railway_id,
									asset_desc,
									asset_grp,
									asset_type,
									operation_status,
									owning_party,
									primary_material,
									last_Dtl_Exam,
									--dtl_exam_freq,
									last_vis_exam,
									outside_party,
									structure_carries,
									structure_over,
									hce_flg,
									cmi_score,
									tenanted_flg
								FROM
								(
									SELECT
											asset_guid,
											region,
											route,
											elr,
											start_mileage,
											--end_mileage,
											railway_id,
											asset_desc,
											asset_grp,
											asset_type,
											operation_status,
											owning_party,
											primary_material,
											last_Dtl_Exam,
											--dtl_exam_freq,
											last_vis_exam,
											outside_party,
											structure_carries,
											structure_over,
											hce_flg,
											cmi_score,
											tenanted_flg,
											ROW_NUMBER() OVER (ORDER BY 
																		CASE WHEN @sortcolumn = 'Region' THEN region ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'Route' THEN route  ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'ELR' THEN elr  ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'StartMileage' THEN start_mileage ELSE NULL END ASC, 
																			 --WHEN @sortcolumn = 'EndMileage' THEN end_mileage ELSE NULL END, 
																		CASE WHEN @sortcolumn = 'RailwayID' THEN railway_id ELSE NULL END ASC, 
																		CASE WHEN @sortcolumn = 'AssetDescription' THEN asset_desc ELSE NULL END ASC, 
																		CASE WHEN @sortcolumn = 'AssetGroup' THEN asset_grp ELSE NULL END ASC, 
																		CASE WHEN @sortcolumn = 'AssetType' THEN asset_type ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'Operationstatus' THEN operation_status ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'OwningParty' THEN owning_party ELSE NULL END ASC, 
																		CASE WHEN @sortcolumn = 'PrimaryMaterial' THEN primary_material ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'LastDetailedExam' THEN last_Dtl_Exam ELSE NULL END ASC,
																			 --WHEN @sortcolumn = 'DetailedExamFrequency' THEN dtl_exam_freq ELSE NULL END,
																		CASE WHEN @sortcolumn = 'LastVisualExam' THEN last_vis_exam ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'OutsideParty' THEN outside_party ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'StructCarries' THEN structure_carries ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'StructOver' THEN structure_over ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'HCEFlg' THEN hce_flg ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'CMIScore' THEN cmi_score ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'TenantedFlg' THEN tenanted_flg ELSE NULL END ASC
																	
																	
																	) AS ordrnk

									FROM #tbl_SearchResult
								)sr
								WHERE sr.ordrnk BETWEEN ((@pageno - 1) * @rowsperpage +1) AND (@pageno * @rowsperpage)
								
								ORDER BY ordrnk
								FOR JSON AUTO, INCLUDE_NULL_VALUES
							)searchresult
							FOR JSON PATH,WITHOUT_ARRAY_WRAPPER, INCLUDE_NULL_VALUES
						)
					END
				
					ELSE IF @sortorder = 'desc' 
					BEGIN
				
						SET @result=
						(
							SELECT 
								JSON_QUERY(
											(
												select
													@pageno AS currentpage,
													@totalresultcnt AS totalcount,
													CEILING(@totalresultcnt/@rowsperpage) AS totalpages
												FOR JSON PATH,WITHOUT_ARRAY_WRAPPER
											)
								) searchdatacount,
							(
								SELECT
									asset_guid,
									region,
									route,
									elr,
									start_mileage,
									--end_mileage,
									railway_id,
									asset_desc,
									asset_grp,
									asset_type,
									operation_status,
									owning_party,
									primary_material,
									last_Dtl_Exam,
									--dtl_exam_freq,
									last_vis_exam,
									outside_party,
									structure_carries,
									structure_over,
									hce_flg,
									cmi_score,
									tenanted_flg
								FROM
								(
									SELECT
											asset_guid,
											region,
											route,
											elr,
											start_mileage,
											--end_mileage,
											railway_id,
											asset_desc,
											asset_grp,
											asset_type,
											operation_status,
											owning_party,
											primary_material,
											last_Dtl_Exam,
											--dtl_exam_freq,
											last_vis_exam,
											outside_party,
											structure_carries,
											structure_over,
											hce_flg,
											cmi_score,
											tenanted_flg,
											ROW_NUMBER() OVER (ORDER BY 
																		CASE WHEN @sortcolumn = 'Region' THEN region ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'Route' THEN route  ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'ELR' THEN elr  ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'StartMileage' THEN start_mileage ELSE NULL END DESC, 
																			 --WHEN @sortcolumn = 'EndMileage' THEN end_mileage ELSE NULL END, 
																		CASE WHEN @sortcolumn = 'RailwayID' THEN railway_id ELSE NULL END DESC, 
																		CASE WHEN @sortcolumn = 'AssetDescription' THEN asset_desc ELSE NULL END DESC, 
																		CASE WHEN @sortcolumn = 'AssetGroup' THEN asset_grp ELSE NULL END DESC, 
																		CASE WHEN @sortcolumn = 'AssetType' THEN asset_type ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'Operationstatus' THEN operation_status ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'OwningParty' THEN owning_party ELSE NULL END DESC, 
																		CASE WHEN @sortcolumn = 'PrimaryMaterial' THEN primary_material ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'LastDetailedExam' THEN last_Dtl_Exam ELSE NULL END DESC,
																			 --WHEN @sortcolumn = 'DetailedExamFrequency' THEN dtl_exam_freq ELSE NULL END,
																		CASE WHEN @sortcolumn = 'LastVisualExam' THEN last_vis_exam ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'OutsideParty' THEN outside_party ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'StructCarries' THEN structure_carries ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'StructOver' THEN structure_over ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'HCEFlg' THEN hce_flg ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'CMIScore' THEN cmi_score ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'TenantedFlg' THEN tenanted_flg ELSE NULL END DESC
																	
																	
																	) AS ordrnk

									FROM #tbl_SearchResult
								)sr
								WHERE sr.ordrnk BETWEEN ((@pageno - 1) * @rowsperpage +1) AND (@pageno * @rowsperpage)
								
								ORDER BY ordrnk
								FOR JSON AUTO, INCLUDE_NULL_VALUES
							)searchresult
							FOR JSON PATH,WITHOUT_ARRAY_WRAPPER, INCLUDE_NULL_VALUES
						)
					END
		
			END
		END
		--PRINT @result
		SELECT @result

		
	END TRY
	BEGIN CATCH
		SET @ErrorMsg = ERROR_MESSAGE() + 
						' Line Num:' + CONVERT(VARCHAR(5), ERROR_LINE()) + 
						',ErrorNum:' + CONVERT(VARCHAR(5), ERROR_NUMBER()) + 
						',Severity:' + CONVERT(VARCHAR(5), ERROR_SEVERITY()) + 
						',State:' + CONVERT(VARCHAR(10), ERROR_STATE()) + 
						',Procedure:' + CONVERT(VARCHAR(25), ERROR_PROCEDURE());  

		THROW 50000,@ErrorMsg,1;

		
	END CATCH

	DROP TABLE IF EXISTS #tbl_SearchResult;
	SET NOCOUNT OFF
END