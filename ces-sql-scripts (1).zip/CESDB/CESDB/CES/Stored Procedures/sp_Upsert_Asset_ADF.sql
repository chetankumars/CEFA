﻿
/***************************************************************************************************************************************            
* Name						: sp_Upsert_Asset_ADF     
* Created By				: Cognizant            
* Date Created				: 07-Apr-2021           
* Description				: This stored procedure Upsert the Asset table through ADF.  
* Input Parameters			: JSON   
* Output Parameters			: Returns 1 for succesful save, else 0            
* Return Value				: N/A            
* Assumptions				: None    
* Execution Statement		: EXEC CES.sp_Upsert_Asset_ADF ''	


*								
* Modified Date     Modified By   Revision Number  Modifications            

*******************************************************************************************************************************************/ 

CREATE PROCEDURE [CES].[sp_Upsert_Asset_ADF]
	@Input_JSON		NVARCHAR(MAX)

AS 

BEGIN
	SET NOCOUNT ON
    BEGIN TRY
		DECLARE
				@ErrorMsg			VARCHAR(250),
				@ErrorDescription   VARCHAR(4000),
				@Output				BIT = 0,
				@CurrentDate		DATETIME  = GETDATE(),
				@User				VARCHAR(16) = 'CARRS'
		
		DROP TABLE IF EXISTS #tmpAsAsset_ADF
		
		CREATE TABLE #tmpAsAsset_ADF
		(
			ASSET_GUID				varchar(32),
			TENANTED_FLG			varchar(1),
			OUTSIDE_PARTY			varchar(64),
			PARENT_ASSET_GUID		varchar(32),
			ASSET_NAME				varchar(200),
			ASSET_TYPE_SR_KEY		decimal(9),
			ASSET_GROUP_SR_KEY		decimal(9),
			ORG_SR_KEY				decimal(9),
			AREA_SR_KEY				decimal(9),
			ENG_LINE_REF			decimal(9),
			RAILWAY_ID				varchar(64),
			START_MILES				decimal(5),
			START_YARDS				decimal(5),			
			END_MILES				decimal(5),
			END_YARDS				decimal(5),
			PRIMARY_MATERIAL		decimal(9),
			SECONDARY_MATERIAL		decimal(9),
			OPERATIONAL_STATUS		decimal(9),
			STRUCTURAL_FORM			decimal(9),
			OWNING_PARTY			varchar(64),
			START_OS_GRID_REF		varchar(16),
			END_OS_GRID_REF			varchar(16),
			HCE_FLAG				varchar(1),
			CMI_SCORE				decimal(5),
			CMI_DATE				date,
			ISACTIVE				bit
		)
		
		--Parsing the input JSON and gathering the records					
		INSERT INTO #tmpAsAsset_ADF
		(
			ASSET_GUID,
			TENANTED_FLG,
			OUTSIDE_PARTY,
			PARENT_ASSET_GUID,
			ASSET_NAME,
			ASSET_TYPE_SR_KEY,
			ASSET_GROUP_SR_KEY,
			ORG_SR_KEY,
			AREA_SR_KEY,
			ENG_LINE_REF,
			RAILWAY_ID,
			START_MILES,
			START_YARDS,			
			END_MILES,
			END_YARDS,
			PRIMARY_MATERIAL,
			SECONDARY_MATERIAL,
			OPERATIONAL_STATUS,
			STRUCTURAL_FORM,
			OWNING_PARTY,
			START_OS_GRID_REF,
			END_OS_GRID_REF,
			HCE_FLAG,
			CMI_SCORE,
			CMI_DATE,
			ISACTIVE
		)
		SELECT				
			ast.ASSET_GUID,
			ast.TENANTED_FLG,
			ast.OUTSIDE_PARTY,
			ast.PARENT_ASSET_GUID,
			ast.ASSET_NAME,
			ast.ASSET_TYPE_SR_KEY,
			ast.ASSET_GROUP_SR_KEY,
			ast.ORG_SR_KEY,
			ast.AREA_SR_KEY,
			ast.ENG_LINE_REF,
			ast.RAILWAY_ID,
			ast.START_MILES,
			ast.START_YARDS,			
			ast.END_MILES,
			ast.END_YARDS,
			ast.PRIMARY_MATERIAL,
			ast.SECONDARY_MATERIAL,
			ast.OPERATIONAL_STATUS,
			ast.STRUCTURAL_FORM,
			ast.OWNING_PARTY,
			ast.START_OS_GRID_REF,
			ast.END_OS_GRID_REF,
			ast.HCE_FLAG,
			ast.CMI_SCORE,
			ast.CMI_DATE,
			CASE
			 WHEN ast.DELETED_FLG = 'Y' THEN 0
			 WHEN ast.DELETED_FLG = 'N' THEN 1
			END AS ISACTIVE
		FROM	OPENJSON(@Input_JSON)
		WITH 
			(
				ASSET_GUID				varchar(32),
				TENANTED_FLG			varchar(1),
				OUTSIDE_PARTY			varchar(64),
				PARENT_ASSET_GUID		varchar(32),
				ASSET_NAME				varchar(200),
				ASSET_TYPE_SR_KEY		decimal(9),
				ASSET_GROUP_SR_KEY		decimal(9),
				ORG_SR_KEY				decimal(9),
				AREA_SR_KEY				decimal(9),
				ENG_LINE_REF			decimal(9),
				RAILWAY_ID				varchar(64),
				START_MILES				decimal(5),
				START_YARDS				decimal(5),			
				END_MILES				decimal(5),
				END_YARDS				decimal(5),
				PRIMARY_MATERIAL		decimal(9),
				SECONDARY_MATERIAL		decimal(9),
				OPERATIONAL_STATUS		decimal(9),
				STRUCTURAL_FORM			decimal(9),
				OWNING_PARTY			varchar(64),
				START_OS_GRID_REF		varchar(16),
				END_OS_GRID_REF			varchar(16),
				HCE_FLAG				varchar(1),
				CMI_SCORE				decimal(5),
				CMI_DATE				date,
				DELETED_FLG				char(1)
			) AS ast

		--- Validation Checks -- Start

		BEGIN TRAN

		MERGE CES.ASSET AS TARGET
		USING #tmpAsAsset_ADF As SOURCE
		ON (TARGET.ASSET_GUID = SOURCE.ASSET_GUID)
		WHEN MATCHED 
		   THEN UPDATE SET 
			TARGET.PARENT_ASSET_GUID = SOURCE.PARENT_ASSET_GUID,
			TARGET.ASSET_NAME = SOURCE.ASSET_NAME,
			TARGET.ASSET_TYPE_SR_KEY = SOURCE.ASSET_TYPE_SR_KEY,
			TARGET.ASSET_GROUP_SR_KEY = SOURCE.ASSET_GROUP_SR_KEY,
			TARGET.ORG_SR_KEY = SOURCE.ORG_SR_KEY,
			TARGET.AREA_SR_KEY = SOURCE.AREA_SR_KEY,
			TARGET.ENG_LINE_REF = SOURCE.ENG_LINE_REF,
			TARGET.RAILWAY_ID = SOURCE.RAILWAY_ID,
			TARGET.START_MILES = SOURCE.START_MILES,
			TARGET.START_YARDS = SOURCE.START_YARDS,
			TARGET.END_MILES = SOURCE.END_MILES,
			TARGET.END_YARDS = SOURCE.END_YARDS,
			TARGET.PRIMARY_MATERIAL = SOURCE.PRIMARY_MATERIAL,
			TARGET.SECONDARY_MATERIAL = SOURCE.SECONDARY_MATERIAL,
			TARGET.OPERATIONAL_STATUS = SOURCE.OPERATIONAL_STATUS,
			TARGET.STRUCTURAL_FORM = SOURCE.STRUCTURAL_FORM,
			TARGET.OWNING_PARTY = SOURCE.OWNING_PARTY,
			TARGET.START_OS_GRID_REF = SOURCE.START_OS_GRID_REF,
			TARGET.END_OS_GRID_REF = SOURCE.END_OS_GRID_REF,
			TARGET.CMI_SCORE = SOURCE.CMI_SCORE,
			TARGET.CMI_DATE = SOURCE.CMI_DATE,
			TARGET.TENANTED_FLG = SOURCE.TENANTED_FLG,
			TARGET.OUTSIDE_PARTY = SOURCE.OUTSIDE_PARTY,
			TARGET.ISACTIVE = SOURCE.ISACTIVE, 
			UPDATED_USER = @User, 
			UPDATED_DATE = @CurrentDate
		WHEN NOT MATCHED BY TARGET AND (SOURCE.ISACTIVE = 1)
		   THEN INSERT (ASSET_GUID,
			TENANTED_FLG,
			OUTSIDE_PARTY,
			PARENT_ASSET_GUID,
			ASSET_NAME,
			ASSET_TYPE_SR_KEY,
			ASSET_GROUP_SR_KEY,
			ORG_SR_KEY,
			AREA_SR_KEY,
			ENG_LINE_REF,
			RAILWAY_ID,
			START_MILES,
			START_YARDS,			
			END_MILES,
			END_YARDS,
			PRIMARY_MATERIAL,
			SECONDARY_MATERIAL,
			OPERATIONAL_STATUS,
			STRUCTURAL_FORM,
			OWNING_PARTY,
			START_OS_GRID_REF,
			END_OS_GRID_REF,
			HCE_FLAG,
			CMI_SCORE,
			CMI_DATE,
			CREATED_USER, 
			CREATED_DATE) 
		VALUES(
			SOURCE.ASSET_GUID,
			SOURCE.TENANTED_FLG,
			SOURCE.OUTSIDE_PARTY,
			SOURCE.PARENT_ASSET_GUID,
			SOURCE.ASSET_NAME,
			SOURCE.ASSET_TYPE_SR_KEY,
			SOURCE.ASSET_GROUP_SR_KEY,
			SOURCE.ORG_SR_KEY,
			SOURCE.AREA_SR_KEY,
			SOURCE.ENG_LINE_REF,
			SOURCE.RAILWAY_ID,
			SOURCE.START_MILES,
			SOURCE.START_YARDS,			
			SOURCE.END_MILES,
			SOURCE.END_YARDS,
			SOURCE.PRIMARY_MATERIAL,
			SOURCE.SECONDARY_MATERIAL,
			SOURCE.OPERATIONAL_STATUS,
			SOURCE.STRUCTURAL_FORM,
			SOURCE.OWNING_PARTY,
			SOURCE.START_OS_GRID_REF,
			SOURCE.END_OS_GRID_REF,
			SOURCE.HCE_FLAG,
			SOURCE.CMI_SCORE,
			SOURCE.CMI_DATE,
			@User, 
			@CurrentDate);		
		COMMIT TRAN
		SET @Output = 1

		 SELECT @Output AS SaveStatus,NULL AS ErrorMsg;
	END TRY

	BEGIN CATCH
		IF (@@TRANCOUNT >0)
			ROLLBACK TRAN
		
		IF @ErrorMsg IS NULL
			SET @ErrorMsg = ERROR_MESSAGE() 
		
		SET @ErrorDescription = @ErrorMsg + 
							' Line Num:' + CONVERT(VARCHAR(5), ERROR_LINE()) + 
							',ErrorNum:' + CONVERT(VARCHAR(5), ERROR_NUMBER()) + 
							',Severity:' + CONVERT(VARCHAR(5), ERROR_SEVERITY()) + 
							',State:' + CONVERT(VARCHAR(10), ERROR_STATE()) + 
							',Procedure:' + CONVERT(VARCHAR(25), OBJECT_NAME(@@procid)) +
							',Procedure:' + CONVERT(VARCHAR(25), ERROR_PROCEDURE())

		SET @Output = 0;
		SELECT @Output AS SaveStatus,@ErrorMsg AS ErrorMsg;

		THROW 50000,@ErrorDescription,1;
	END CATCH

	DROP TABLE IF EXISTS #tmpAsAsset_ADF;
	SET NOCOUNT OFF
  END