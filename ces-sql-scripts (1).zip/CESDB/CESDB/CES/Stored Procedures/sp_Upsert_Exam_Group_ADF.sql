﻿

/***************************************************************************************************************************************            
* Name						: sp_Upsert_Exam_Group_ADF     
* Created By				: Cognizant            
* Date Created				: 12-April-2021           
* Description				: This stored procedure Upsert the Exam_Group table through ADF.  
* Input Parameters			: JSON   
* Output Parameters			: Returns 1 for succesful save, else 0            
* Return Value				: N/A            
* Assumptions				: None    
* Execution Statement		: EXEC CES.sp_Upsert_Exam_Group_ADF '[
        {
            "CARRS_EXAM_GROUP_ID": 27131,
            "START_DATE": "2010-01-02T00:00:00Z",
            "END_DATE": null,
            "DELETED_FLG": "N",
            "LOC_AT_ASSET_GUID": "3978559C311045D9E04400306E4AD01A"
        },
        {
            "CARRS_EXAM_GROUP_ID": 41571,
            "START_DATE": "2010-01-02T00:00:00Z",
            "END_DATE": null,
            "DELETED_FLG": "N",
            "LOC_AT_ASSET_GUID": "3978559D34D845D9E04400306E4AD01A"
        },
        {
            "CARRS_EXAM_GROUP_ID": 22366,
            "START_DATE": "2010-01-02T00:00:00Z",
            "END_DATE": null,
            "DELETED_FLG": "N",
            "LOC_AT_ASSET_GUID": "3978559D55B945D9E04400306E4AD01A"
        }
    ]'	


*								
* Modified Date     Modified By   Revision Number  Modifications            

*******************************************************************************************************************************************/ 

CREATE PROCEDURE [CES].[sp_Upsert_Exam_Group_ADF]
	@Input_JSON		NVARCHAR(MAX)

AS 

BEGIN
	SET NOCOUNT ON
    BEGIN TRY
		DECLARE
				@ErrorMsg			VARCHAR(250),
				@ErrorDescription   VARCHAR(4000),
				@Output				BIT = 0,
				@CurrentDate		DATETIME  = GETDATE(),
				@User				VARCHAR(16) = 'CARRS'
		
		DROP TABLE IF EXISTS #tmpAsExam_Group_ADF
		
		CREATE TABLE #tmpAsExam_Group_ADF
		(
			CARRS_EXAM_GROUP_ID decimal(18),
            [START_DATE]  date,
            END_DATE date,
            ISACTIVE char,
            LOC_AT_ASSET_GUID varchar(32)
		)
		
		--Parsing the input JSON and gathering the records					
		INSERT INTO #tmpAsExam_Group_ADF
		(
			CARRS_EXAM_GROUP_ID,
            [START_DATE],
            END_DATE,
            ISACTIVE,
            LOC_AT_ASSET_GUID
		)
		SELECT				
			egt.CARRS_EXAM_GROUP_ID,
            egt.[START_DATE],
            egt.END_DATE,
            CASE
			 WHEN egt.DELETED_FLG = 'Y' THEN 0
			 WHEN egt.DELETED_FLG = 'N' THEN 1
			END AS ISACTIVE,
			egt.LOC_AT_ASSET_GUID
		FROM	OPENJSON(@Input_JSON)
		WITH 
			(
				CARRS_EXAM_GROUP_ID decimal(18),
				[START_DATE]  date,
				END_DATE date,
				DELETED_FLG char,
				LOC_AT_ASSET_GUID varchar(32)
			) AS egt
		INNER JOIN [CES].[ASSET] E ON E.ASSET_GUID = egt.LOC_AT_ASSET_GUID
		WHERE egt.[START_DATE] is not null
		--- Validation Checks -- Start
		SELECT * FROM #tmpAsExam_Group_ADF

		BEGIN TRAN

		MERGE CES.EXAM_GROUP AS TARGET
		USING #tmpAsExam_Group_ADF As SOURCE
		ON (TARGET.CARRS_EXAM_GROUP_ID = SOURCE.CARRS_EXAM_GROUP_ID AND TARGET.LOC_AT_ASSET_GUID = SOURCE.LOC_AT_ASSET_GUID)
		WHEN MATCHED 
		   THEN UPDATE SET TARGET.[START_DATE]=SOURCE.[START_DATE], TARGET.END_DATE=SOURCE.END_DATE,TARGET.ISACTIVE = SOURCE.ISACTIVE, 
		   TARGET.UPDATED_USER = @User, TARGET.UPDATED_DATE = @CurrentDate
		WHEN NOT MATCHED BY TARGET AND (SOURCE.ISACTIVE = 1)
		   THEN INSERT (CARRS_EXAM_GROUP_ID, LOC_AT_ASSET_GUID, [START_DATE], END_DATE, CREATED_USER, CREATED_DATE) 
		   VALUES(SOURCE.CARRS_EXAM_GROUP_ID, SOURCE.LOC_AT_ASSET_GUID, SOURCE.[START_DATE], SOURCE.END_DATE, @User, @CurrentDate);		
		COMMIT TRAN
		SET @Output = 1

		 SELECT @Output AS SaveStatus,NULL AS ErrorMsg;
	END TRY

	BEGIN CATCH
		IF (@@TRANCOUNT >0)
			ROLLBACK TRAN
		
		IF @ErrorMsg IS NULL
			SET @ErrorMsg = ERROR_MESSAGE() 
		
		SET @ErrorDescription = @ErrorMsg + 
							' Line Num:' + CONVERT(VARCHAR(5), ERROR_LINE()) + 
							',ErrorNum:' + CONVERT(VARCHAR(5), ERROR_NUMBER()) + 
							',Severity:' + CONVERT(VARCHAR(5), ERROR_SEVERITY()) + 
							',State:' + CONVERT(VARCHAR(10), ERROR_STATE()) + 
							',Procedure:' + CONVERT(VARCHAR(25), OBJECT_NAME(@@procid)) +
							',Procedure:' + CONVERT(VARCHAR(25), ERROR_PROCEDURE())

		SET @Output = 0;
		SELECT @Output AS SaveStatus,@ErrorMsg AS ErrorMsg;

		THROW 50000,@ErrorDescription,1;
	END CATCH

	DROP TABLE IF EXISTS #tmpAsExam_Group_ADF;
	SET NOCOUNT OFF
  END