﻿

/***************************************************************************************************************************************            
* Name						: sp_Update_IsLatest_Risk_Assessment_Migration_ADF     
* Created By				: Cognizant            
* Date Created				: 01-Mar-2021           
* Description				: This stored procedure updates the Risk_Assessment Table ISLATEST flag through ADF.  
* Input Parameters			: NIL   
* Output Parameters			: Returns 1 for succesful save, else 0            
* Return Value				: N/A            
* Assumptions				: None    
* Execution Statement		: EXEC CES.sp_Update_IsLatest_Risk_Assessment_Migration_ADF 						
* Modified Date     Modified By   Revision Number  Modifications            

*******************************************************************************************************************************************/ 

CREATE PROCEDURE [CES].[sp_Update_IsLatest_Risk_Assessment_Migration_ADF]
	
AS 
BEGIN
	SET NOCOUNT ON
    BEGIN TRY
		DECLARE
				@ErrorMsg			VARCHAR(250),
				@ErrorDescription   VARCHAR(4000),
				@Output				BIT = 0
	BEGIN TRAN
		
		--Update CES.RISK_ASSESSMENT SET ISLATEST = 'Y' WHERE RISK_SR_KEY IN(
		--Select RISK_SR_KEY FROM CES.RISK_ASSESSMENT RA
		--INNER JOIN
		--(Select ASSET_GUID, EXAM_TYPE_SR_KEY, MAX(ASSESSMENT_DATE) AS ASSESSMENT_DATE from CES.RISK_ASSESSMENT
		--GROUP BY ASSET_GUID, EXAM_TYPE_SR_KEY) A ON A.ASSET_GUID = RA.ASSET_GUID and A.EXAM_TYPE_SR_KEY = RA.EXAM_TYPE_SR_KEY AND A.ASSESSMENT_DATE = RA.ASSESSMENT_DATE
		--);
		

		Update  RAS
		SET ISLATEST = 'Y'
		FROM CES.RISK_ASSESSMENT RAS
		INNER JOIN
			(
				SELECT RISK_SR_KEY
				FROM
					(
						Select
							RISK_SR_KEY, 
							 DENSE_RANK() OVER (PARTITION BY ASSET_GUID, EXAM_TYPE_SR_KEY ORDER BY ISNULL(ASSESSMENT_DATE, GETDATE()) DESC,BRIDGE_RA_ID DESC) rnk
							 FROM CES.RISK_ASSESSMENT
					)t
					WHERE t.rnk = 1
			)RA
		ON RAS.RISK_SR_KEY = RA.RISK_SR_KEY

	COMMIT TRAN
	END TRY
BEGIN CATCH
		IF (@@TRANCOUNT >0)
			ROLLBACK TRAN
		
		IF @ErrorMsg IS NULL
			SET @ErrorMsg = ERROR_MESSAGE() 
		
		SET @ErrorDescription = @ErrorMsg + 
							' Line Num:' + CONVERT(VARCHAR(5), ERROR_LINE()) + 
							',ErrorNum:' + CONVERT(VARCHAR(5), ERROR_NUMBER()) + 
							',Severity:' + CONVERT(VARCHAR(5), ERROR_SEVERITY()) + 
							',State:' + CONVERT(VARCHAR(10), ERROR_STATE()) + 
							',Procedure:' + CONVERT(VARCHAR(25), OBJECT_NAME(@@procid)) +
							',Procedure:' + CONVERT(VARCHAR(25), ERROR_PROCEDURE())

		SET @Output = 0;
		SELECT @Output AS SaveStatus,@ErrorMsg AS ErrorMsg;

		THROW 50000,@ErrorDescription,1;
	END CATCH

	SET NOCOUNT OFF
  END