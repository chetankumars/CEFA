﻿

/***************************************************************************************************************************************            
* Name						: sp_Save_Compliance_ADF     
* Created By				: Cognizant            
* Date Created				: 31-May-2021           
* Description				: This stored procedure saves the Compliance Table updated through ADF.  
* Input Parameters			: JSON   
* Output Parameters			: Returns 1 for succesful save, else 0            
* Return Value				: N/A            
* Assumptions				: None    
* Execution Statement		: EXEC CES.sp_Save_Compliance_ADF '[ 
																	{ 
																	"CAI_GUID": "3978559C3BF045D9E04400306E4AD01A", 
																	"EXAM_TYPE_SR_KEY": 1, 
																	"COMPLIANCE_REQUIRE_DATE": 
																	"2020-12-26T00:00:00Z", 
																	"EFF_FROM_DATE": "2000-01-01T00:00:00Z", 
																	"EFF_TO_DATE": null, 
																	"ISACTIVE": 1, 
																	"CREATED_USER": "CARRS", 
																	"CREATED_DATE": "2021-02-24T10:23:51.552Z", 
																	"COMPLIANCE_SR_KEY": 35666 }, 
																	{ 
																	"CAI_GUID": "3978559C3BF945D9E04400306E4AD01A", 
																	"EXAM_TYPE_SR_KEY": 1,
																	 "COMPLIANCE_REQUIRE_DATE": "2020-12-26T00:00:00Z", 
																	"EFF_FROM_DATE": "2000-01-01T00:00:00Z", 
																	"EFF_TO_DATE": null, 
																	"ISACTIVE": 1, 
																	"CREATED_USER": "CARRS", 
																	"CREATED_DATE": "2021-02-24T10:23:51.552Z",
																	"COMPLIANCE_SR_KEY": 27741 
																	 } 
																]	


*								
* Modified Date     Modified By   Revision Number  Modifications            

*******************************************************************************************************************************************/ 

CREATE PROCEDURE [CES].[sp_Save_Compliance_ADF]
	AS 

BEGIN
	SET NOCOUNT ON
    BEGIN TRY
		DECLARE
				@ErrorMsg			VARCHAR(250),
				@ErrorDescription   VARCHAR(4000),
				@Output				BIT = 0,
				@CurrentDate		DATETIME  = GETDATE(),
				@User				VARCHAR(16) = 'CARRS'
	
		DROP TABLE IF EXISTS #tmpAsComplianceDtls_ADF

		--CREATE TABLE #tmpAsComplianceDtls_ADF
		--(
		--	ASSET_GUID				varchar(32),
		--	EXAM_TYPE_KEY			decimal(9),
		--	COMP_DATE				DATE,
		--	EFFECTIVE_FROM_DT		DATE,
		--	EFFECTIVE_TO_DT			DATE,
		--	Isactive				BIT,
		--	COMP_SR_KEY				decimal(9),
		--	INTERVAL_DAYS           decimal(3),
		--	INTERVAL_MONTHS			decimal(3),
		--	INTERVAL_YEARS			decimal(3)
		--)
		
		----Parsing the input JSON and gathering the records					
		--INSERT INTO #tmpAsComplianceDtls_ADF
		--(
		--	ASSET_GUID,
		--	EXAM_TYPE_KEY,
		--	COMP_DATE,
		--	EFFECTIVE_FROM_DT,
		--	EFFECTIVE_TO_DT,
		--	Isactive,
		--	COMP_SR_KEY,
		--	INTERVAL_DAYS,
		--	INTERVAL_MONTHS,
		--	INTERVAL_YEARS
		--)
		--SELECT				
		--	ast.CAI_GUID,
		--	ast.EXAM_TYPE_SR_KEY,
		--	CONVERT(DATE,ast.COMPLIANCE_REQUIRE_DATE,103) AS COMPLIANCE_REQUIRE_DATE,
		--	CONVERT(DATE,ast.EFF_FROM_DATE,103) AS EFF_FROM_DATE,
		--	CONVERT(DATE,ast.EFF_TO_DATE,103) AS EFF_TO_DATE,
		--	ISACTIVE,
		--	COMPLIANCE_SR_KEY,
		--	INTERVAL_DAYS,
		--	INTERVAL_MONTHS,
		--	INTERVAL_YEARS
		--FROM	OPENJSON(@Input_JSON)
		--WITH 
		--	(
		--		CAI_GUID				varchar(32),
		--		EXAM_TYPE_SR_KEY		decimal(9),
		--		COMPLIANCE_REQUIRE_DATE	DATE,
		--		EFF_FROM_DATE			DATE,
		--		EFF_TO_DATE				DATE,
		--		ISACTIVE				BIT,
		--		COMPLIANCE_SR_KEY		decimal(9),
		--		INTERVAL_DAYS			decimal(3),
		--		INTERVAL_MONTHS			decimal(3),
		--		INTERVAL_YEARS			decimal(3)
		--	) AS ast

		--- Validation Checks -- Start

		BEGIN TRAN

		MERGE CES.Compliance AS TARGET
		USING CES.Compliance_STG As SOURCE
		ON (TARGET.ASSET_GUID = SOURCE.ASSET_GUID AND TARGET.EXAM_TYPE_SR_KEY = SOURCE.EXAM_TYPE_SR_KEY
			AND TARGET.COMP_DATE = SOURCE.COMP_DATE AND TARGET.EFFECTIVE_FROM_DT = SOURCE.EFFECTIVE_FROM_DT)
		WHEN MATCHED 
		   THEN UPDATE SET TARGET.EFFECTIVE_TO_DT = SOURCE.EFFECTIVE_TO_DT, TARGET.ISACTIVE = SOURCE.ISACTIVE,
		   UPDATED_USER = @User, UPDATED_DATE = @CurrentDate, TARGET.INTERVAL_DAYS = SOURCE.INTERVAL_DAYS, TARGET.INTERVAL_MONTHS = SOURCE.INTERVAL_MONTHS, TARGET.INTERVAL_YEARS = SOURCE.INTERVAL_YEARS
		WHEN NOT MATCHED BY TARGET
		   THEN INSERT (ASSET_GUID,EXAM_TYPE_SR_KEY,COMP_DATE,EFFECTIVE_FROM_DT,EFFECTIVE_TO_DT,CREATED_USER,CREATED_DATE,INTERVAL_DAYS,INTERVAL_MONTHS,INTERVAL_YEARS) VALUES(SOURCE.ASSET_GUID, SOURCE.EXAM_TYPE_SR_KEY, SOURCE.COMP_DATE, SOURCE.EFFECTIVE_FROM_DT, SOURCE.EFFECTIVE_TO_DT, @User, @CurrentDate, SOURCE.INTERVAL_DAYS,SOURCE.INTERVAL_MONTHS,SOURCE.INTERVAL_YEARS);		
		COMMIT TRAN
		SET @Output = 1

		 SELECT @Output AS SaveStatus,NULL AS ErrorMsg;
	END TRY

	BEGIN CATCH
		IF (@@TRANCOUNT >0)
			ROLLBACK TRAN
		
		IF @ErrorMsg IS NULL
			SET @ErrorMsg = ERROR_MESSAGE() 
		
		SET @ErrorDescription = @ErrorMsg + 
							' Line Num:' + CONVERT(VARCHAR(5), ERROR_LINE()) + 
							',ErrorNum:' + CONVERT(VARCHAR(5), ERROR_NUMBER()) + 
							',Severity:' + CONVERT(VARCHAR(5), ERROR_SEVERITY()) + 
							',State:' + CONVERT(VARCHAR(10), ERROR_STATE()) + 
							',Procedure:' + CONVERT(VARCHAR(25), OBJECT_NAME(@@procid)) +
							',Procedure:' + CONVERT(VARCHAR(25), ERROR_PROCEDURE())

		SET @Output = 0;
		SELECT @Output AS SaveStatus,@ErrorMsg AS ErrorMsg;

		THROW 50000,@ErrorDescription,1;
	END CATCH

	DROP TABLE IF EXISTS #tmpAsComplianceDtls_ADF;
	SET NOCOUNT OFF
  END