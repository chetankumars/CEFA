﻿/***************************************************************************************************************************************            
* Name						: sp_Get_Admin_UserRRAInfo         
* Created By				: Cognizant            
* Date Created				: 10-Mar-2021           
* Description				: This stored procedure used to get list of Region, Route, and Area for selected user.
* Input Parameters			: JSON      
* Output Parameters			: @OUT_ErrorNo            
* Return Value				: N/A            
* Assumptions				: None    
* Execution Statement		: Exec [CES].sp_Get_Admin_UserRRAInfo '10'		
							  Exec [CES].sp_Get_Admin_UserRRAInfo 'user_id'
															         
*								
* Modified Date     Modified By   Revision Number  Modifications            

*******************************************************************************************************************************************/ 



CREATE PROCEDURE [CES].[sp_Get_Admin_UserRRAInfo]
	@User_Id		DECIMAL(18)
AS 
BEGIN
	SET NOCOUNT ON
	
	
	BEGIN TRY
		DECLARE
				@ErrorMsg				VARCHAR(250),
				@result					NVARCHAR(MAX),
				@supplier_name          VARCHAR(50),
				@supplier_id            DECIMAL(18),
				@rra_default			NVARCHAR(MAX),
				@rra_All				NVARCHAR(MAX)
				
		
		--DROP TABLE IF EXISTS #tblUserDefaultRRA_Get;
		--DROP TABLE IF EXISTS #tblUserRRA_Get;						
		--CREATE TABLE #tblUserDefaultRRA_Get
		--(
		--	region_name VARCHAR(64),
		--	route_id DECIMAL(18),
		--	route_name  VARCHAR(64),
		--	area_id DECIMAL(18),
		--	area_name VARCHAR(64),			
		--)

		--CREATE TABLE #tblUserRRA_Get
		--(
		--	region_name VARCHAR(64),
		--	route_id DECIMAL(18),
		--	route_name  VARCHAR(64),
		--	area_id DECIMAL(18),
		--	area_name VARCHAR(64),
		--)	

		  
		-- Validation start

		IF (@User_Id IS NULL)
		BEGIN
			SET @ErrorMsg = 'User Id value is missing';
			DROP TABLE IF EXISTS #tblUserDefaultRRA_Get;
			DROP TABLE IF EXISTS #tblUserRRA_Get;
			THROW 50000,@ErrorMsg,1;
		END
	   -- Validation End
	   
	   --GET SUPPLIER DETAILS
	   SET @supplier_id=(SELECT TOP 1 SUPPLIER_SR_KEY FROM CES.[ENTITLEMENT] WHERE USER_SR_KEY=@User_Id AND ISACTIVE=1)
	   IF @supplier_id IS NULL 
			SET @supplier_name=NULL
	   ELSE 
			SELECT @supplier_name=SUPPLIER_NAME FROM CES.[SUPPLIER] WHERE SUPPLIER_SR_KEY=@supplier_id AND ISACTIVE=1
	  
	   --GET DEFAULT REGION, ROUTE, AREA DETAILS
	  -- IF EXISTS (SELECT 1 FROM CES.[ENTITLEMENT] WHERE USER_SR_KEY=@User_Id AND ISDEFAULT=1 AND ISACTIVE=1)
	  -- BEGIN
		 ----  INSERT INTO #tblUserDefaultRRA_Get
		 ----  (
			----	region_name,
			----	route_id,
			----	route_name,
			----	area_id,
			----	area_name
			----)

			--SELECT @rra_default =
			--(
			--	SELECT O.REGION,O.ORG_SR_KEY,O.ROUTE,A.AREA_SR_KEY,A.AREA_NAME 
			--	FROM CES.ENTITLEMENT EN 
			--	INNER JOIN CES.ORG O ON EN.ORG_SR_KEY=O.ORG_SR_KEY AND O.ISACTIVE=1
			--	LEFT JOIN CES.AREA A ON EN.AREA_SR_KEY=A.AREA_SR_KEY AND EN.ORG_SR_KEY=A.ORG_SR_KEY AND A.ISACTIVE=1
			--	WHERE EN.USER_SR_KEY=@User_Id AND EN.ISACTIVE=1 AND EN.ISDEFAULT=1
			--)
	  -- END
	  -- ELSE
	  -- BEGIN
			--INSERT INTO #tblUserDefaultRRA_Get
			--(
			--	region_name,
			--	route_id,
			--	route_name,
			--	area_id,
			--	area_name
			--)
			--(SELECT '',NULL,'',NULL,'')
	  -- END
	   
	  -- --GET REGION, ROUTE, AREA DETAILS
	  -- IF EXISTS (SELECT 1 FROM CES.[ENTITLEMENT] WHERE USER_SR_KEY=@User_Id  AND ISACTIVE=1)
	  -- BEGIN
		 --  INSERT INTO #tblUserRRA_Get
		 --  (
			--	region_name,
			--	route_id,
			--	route_name,
			--	area_id,
			--	area_name
			--)
			--(
			--	SELECT O.REGION,O.ORG_SR_KEY,O.ROUTE,A.AREA_SR_KEY,A.AREA_NAME 
			--	FROM CES.ENTITLEMENT EN 
			--	INNER JOIN CES.ORG O ON EN.ORG_SR_KEY=O.ORG_SR_KEY AND O.ISACTIVE=1
			--	LEFT JOIN CES.AREA A ON EN.AREA_SR_KEY=A.AREA_SR_KEY AND EN.ORG_SR_KEY=A.ORG_SR_KEY AND A.ISACTIVE=1
			--	WHERE EN.USER_SR_KEY=@User_Id AND EN.ISACTIVE=1 --AND EN.ISDEFAULT=0
			--)
	  -- END
	  -- ELSE
	  -- BEGIN
			--INSERT INTO #tblUserRRA_Get
			--(
			--	region_name,
			--	route_id,
			--	route_name,
			--	area_id,
			--	area_name
			--)
			--(SELECT '',NULL,'',NULL,'')
	  -- END	
	
	IF EXISTS (SELECT 1 FROM CES.[ENTITLEMENT] WHERE USER_SR_KEY=@User_Id  AND ISACTIVE=1)
	BEGIN	
	SET @result=
	(
		SELECT 
			@supplier_id AS supplier_id,
			@supplier_name AS supplier_name,							
			(
					SELECT 
						regions.region_id,
						regions.REGION AS region_name,
						routes.ORG_SR_KEY AS route_id,
						routes.ROUTE AS route_name,
						areas.AREA_SR_KEY AS area_id,
						areas.AREA_NAME AS area_name
					FROM 
						(
							SELECT 
								ROW_NUMBER() OVER (ORDER BY REGION) region_id,
								REGION 
							FROM
							(
								SELECT DISTINCT REGION 
								FROM [CES].ORG
								WHERE ISACTIVE = 1
							)r
						) regions
					INNER JOIN [CES].ORG routes
					ON regions.REGION  = routes.REGION
					LEFT JOIN [CES].AREA areas
					ON routes.ORG_SR_KEY = areas.ORG_SR_KEY
					AND areas.ISACTIVE = 1
					WHERE  routes.ISACTIVE = 1
					AND	EXISTS (SELECT 1 FROM [CES].ENTITLEMENT ent
								WHERE ent.ORG_SR_KEY = routes.ORG_SR_KEY
								AND ISNULL(ent.AREA_SR_KEY,0) = ISNULL(areas.AREA_SR_KEY,0)
								AND ent.USER_SR_KEY = @User_ID
								AND ent.ISACTIVE = 1
								AND ent.ISDEFAULT =1
								)
					
							
					ORDER BY 
						regions.region,
						routes.ROUTE,
						areas.AREA_NAME
					FOR JSON AUTO, INCLUDE_NULL_VALUES
			) user_default_rra,
			(
				SELECT 
					regions.region_id,
					regions.REGION AS region_name,
					routes.ORG_SR_KEY AS route_id,
					routes.ROUTE AS route_name,
					areas.AREA_SR_KEY AS area_id,
					areas.AREA_NAME AS area_name
				FROM 
					(
						SELECT 
							ROW_NUMBER() OVER (ORDER BY REGION) region_id,
							REGION 
						FROM
						(
							SELECT DISTINCT REGION 
							FROM [CES].ORG
							WHERE ISACTIVE = 1
						)r
					) regions
				INNER JOIN [CES].ORG routes
				ON regions.REGION  = routes.REGION
				LEFT JOIN [CES].AREA areas
				ON routes.ORG_SR_KEY = areas.ORG_SR_KEY
				AND areas.ISACTIVE = 1
				WHERE  routes.ISACTIVE = 1
				AND	EXISTS (SELECT 1 FROM [CES].ENTITLEMENT ent
							WHERE ent.ORG_SR_KEY = routes.ORG_SR_KEY
							AND ISNULL(ent.AREA_SR_KEY,0) = ISNULL(areas.AREA_SR_KEY,0)
							AND ent.USER_SR_KEY = @User_ID
							AND ent.ISACTIVE = 1)
							
							
				ORDER BY 
					regions.region,
					routes.ROUTE,
					areas.AREA_NAME
				FOR JSON AUTO, INCLUDE_NULL_VALUES
			) user_associated_rra
			FOR JSON PATH, INCLUDE_NULL_VALUES, WITHOUT_ARRAY_WRAPPER
		)	

	END
	ELSE
	BEGIN
		SET @result=
		(
			SELECT 
				@supplier_id AS supplier_id,
				@supplier_name AS supplier_name,
				JSON_QUERY('[]') AS user_default_rra,
				JSON_QUERY('[]') AS user_associated_rra
			FOR JSON PATH, INCLUDE_NULL_VALUES, WITHOUT_ARRAY_WRAPPER
		)
	END	
		
	SELECT @result
		
	END TRY
	BEGIN CATCH
		SET @ErrorMsg = ERROR_MESSAGE() + 
						' Line Num:' + CONVERT(VARCHAR(5), ERROR_LINE()) + 
						',ErrorNum:' + CONVERT(VARCHAR(5), ERROR_NUMBER()) + 
						',Severity:' + CONVERT(VARCHAR(5), ERROR_SEVERITY()) + 
						',State:' + CONVERT(VARCHAR(10), ERROR_STATE()) + 
						',Procedure:' + CONVERT(VARCHAR(25), ERROR_PROCEDURE());  
		
		--DROP TABLE IF EXISTS #tblUserDefaultRRA_Get;
		--DROP TABLE IF EXISTS #tblUserRRA_Get;	
		THROW 50000,@ErrorMsg,1;

		
	END CATCH
	--DROP TABLE IF EXISTS #tblUserDefaultRRA_Get;
	--DROP TABLE IF EXISTS #tblUserRRA_Get;
	SET NOCOUNT OFF
END