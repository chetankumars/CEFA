﻿
/***************************************************************************************************************************************            
* Name						: sp_Upsert_ReferenceValue_ADF     
* Created By				: Cognizant            
* Date Created				: 08-Mar-2021           
* Description				: This stored procedure Upsert the Reference table through ADF.  
* Input Parameters			: JSON   
* Output Parameters			: Returns 1 for succesful save, else 0            
* Return Value				: N/A            
* Assumptions				: None    
* Execution Statement		: EXEC CES.sp_Upsert_ReferenceValue_ADF '[ 
																	{ 
																	"RV_VALUE": "xxxxx", 
																	"REF_TYP_SR_KEY": 1, 
																	"DELETED_FLG": 1
																	 }, 
																	{ 
																	"RV_VALUE": "yyyy", 
																	"REF_TYP_SR_KEY": 2, 
																	"DELETED_FLG": 1 
																	 } 
																]'	


*								
* Modified Date     Modified By   Revision Number  Modifications            

*******************************************************************************************************************************************/ 

CREATE PROCEDURE [CES].[sp_Upsert_ReferenceValue_ADF]
	@Input_JSON		NVARCHAR(MAX)

AS 

BEGIN
	SET NOCOUNT ON
    BEGIN TRY
		DECLARE
				@ErrorMsg			VARCHAR(250),
				@ErrorDescription   VARCHAR(4000),
				@Output				BIT = 0,
				@CurrentDate		DATETIME  = GETDATE(),
				@User				VARCHAR(16) = 'CARRS'
		
		DROP TABLE IF EXISTS #tmpAsReferenceValue_ADF

		CREATE TABLE #tmpAsReferenceValue_ADF
		(
			REF_VALUE				varchar(500),
			REF_TYP_SR_KEY			decimal(9),
			ISACTIVE				char
		)
		
		--Parsing the input JSON and gathering the records					
		INSERT INTO #tmpAsReferenceValue_ADF
		(
			REF_VALUE,
			REF_TYP_SR_KEY,
			ISACTIVE
		)
		SELECT				
			ast.RV_VALUE,
			ast.REF_TYP_SR_KEY,
			CASE
			 WHEN ast.DELETED_FLG = 'Y' THEN 0
			 WHEN ast.DELETED_FLG = 'N' THEN 1
			END AS ISACTIVE
		FROM	OPENJSON(@Input_JSON)
		WITH 
			(
				RV_VALUE				varchar(500),
				REF_TYP_SR_KEY			decimal(9),
				DELETED_FLG				char
			) AS ast

		--- Validation Checks -- Start

		BEGIN TRAN

		MERGE CES.REFERENCE_VALUE AS TARGET
		USING #tmpAsReferenceValue_ADF As SOURCE
		ON (TARGET.REF_TYP_SR_KEY = SOURCE.REF_TYP_SR_KEY AND TARGET.REF_VALUE = SOURCE.REF_VALUE)
		WHEN MATCHED 
		   THEN UPDATE SET TARGET.ISACTIVE = SOURCE.ISACTIVE, UPDATED_USER = @User, UPDATED_DATE = @CurrentDate
		WHEN NOT MATCHED BY TARGET AND (SOURCE.ISACTIVE = 1)
		   THEN INSERT (REF_TYP_SR_KEY, REF_VALUE, CREATED_USER, CREATED_DATE) VALUES(SOURCE.REF_TYP_SR_KEY, SOURCE.REF_VALUE, @User, @CurrentDate);		
		COMMIT TRAN
		SET @Output = 1

		 SELECT @Output AS SaveStatus,NULL AS ErrorMsg;
	END TRY

	BEGIN CATCH
		IF (@@TRANCOUNT >0)
			ROLLBACK TRAN
		
		IF @ErrorMsg IS NULL
			SET @ErrorMsg = ERROR_MESSAGE() 
		
		SET @ErrorDescription = @ErrorMsg + 
							' Line Num:' + CONVERT(VARCHAR(5), ERROR_LINE()) + 
							',ErrorNum:' + CONVERT(VARCHAR(5), ERROR_NUMBER()) + 
							',Severity:' + CONVERT(VARCHAR(5), ERROR_SEVERITY()) + 
							',State:' + CONVERT(VARCHAR(10), ERROR_STATE()) + 
							',Procedure:' + CONVERT(VARCHAR(25), OBJECT_NAME(@@procid)) +
							',Procedure:' + CONVERT(VARCHAR(25), ERROR_PROCEDURE())

		SET @Output = 0;
		SELECT @Output AS SaveStatus,@ErrorMsg AS ErrorMsg;

		THROW 50000,@ErrorDescription,1;
	END CATCH

	DROP TABLE IF EXISTS #tmpAsReferenceValue_ADF;
	SET NOCOUNT OFF
  END