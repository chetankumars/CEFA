﻿

/***************************************************************************************************************************************            
* Name						: sp_update_ADF_FILE_PROCESS_LOG            
* Created By				: Cognizant            
* Date Created				: 29-Jan-2021           
* Description				: This stored procedure updates the File_Process_Log on success/failure of the file processsing through ADF.  
* Input Parameters			: 
								@File_Process_Date		DATETIME,			--File processing date
								@File_Process_Status	VARCHAR(50),		--Succeded/Failed
								@Error_Description		VARCHAR(4000),		--Error description on failure
								@Error_File_Location	VARCHAR(2000),		--Error file location in Datalake
								@Updated_User			VARCHAR(64),		--User updating the file process state
								@Updated_Date			DATETIME,			--Timestamp of update
								@Source_File_Location	VARCHAR(2000),		--Source file location in Datalake
								@File_Name				VARCHAR(500)		--Name of the file being processed
* Output Parameters			: N/A            
* Return Value				: N/A            
* Assumptions				: None    
* Execution Statement		: Exec [CES].[sp_update_ADF_FILE_PROCESS_LOG]  '1'
*								
* Modified Date     Modified By   Revision Number  Modifications            

*******************************************************************************************************************************************/ 

CREATE PROCEDURE [CES].[sp_update_ADF_FILE_PROCESS_LOG] 
( 
	@File_Process_Date		DATETIME,     
	@File_Process_Status	VARCHAR(50),
	@Error_Description		VARCHAR(4000),
	@Error_File_Location	VARCHAR(2000),
	@Updated_User			VARCHAR(64), 
	@Updated_Date			DATETIME,
	@Source_File_Location	VARCHAR(2000),
	@File_Name				VARCHAR(500)
)
AS
BEGIN
	SET NOCOUNT ON;
		UPDATE [CES].[FILE_PROCESS_LOG] 
		SET 
			FILE_PROCESS_DATE= @File_Process_Date, 
			FILE_PROCESS_STATUS = @File_Process_Status,
			ERROR_DESCRIPTION = @Error_Description, 
			ERROR_FILE_LOCATION = @Error_File_Location, 
			UPDATED_USER = @Updated_User,
			UPDATED_DATE = @Updated_Date, 
			SOURCE_FILE_LOCATION = @Source_File_Location
		WHERE [FILE_NAME]=@File_Name

	SET NOCOUNT OFF;
END