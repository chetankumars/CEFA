﻿
/***************************************************************************************************************************************            
* Name						: sp_Save_TasklistStatus      
* Created By				: Cognizant            
* Date Created				: 04-Feb-2021           
* Description				: This stored procedure saves the work status of Task list.  
* Input Parameters			:	@Input_JSON -- send the exam_sr_key,task_list_id,task_list_stat combination as part of JSON
                                @Role_Name -- It should be like CEFA PM/Asset Engineer or Supplier roles
								@User_Key --64 bit object key of the user pressed the Save button   
* Output Parameters			: Returns 1 for succesful save, else 0            
* Return Value				: N/A            
* Assumptions				: None    
* Execution Statement		: Exec [CES].sp_Save_TasklistStatus '[{
																	"exam_sr_key": "104703",
																	"task_list_id": "1060",
																	"task_list_stat": "1596"
																}]','Supplier Planner','03c2d593-24ed-4494-a25c-377d9e915891';
*												
* Modified Date     Modified By   Revision Number  Modifications            

*******************************************************************************************************************************************/ 



CREATE PROCEDURE [CES].[sp_Save_TasklistStatus]
	@Input_JSON		NVARCHAR(MAX),
	@Role_Name		VARCHAR(50),
	@User_Key		VARCHAR(64)

AS
BEGIN

	SET NOCOUNT ON
	BEGIN TRY
		DECLARE
				@ErrorMsg						VARCHAR(250),
				@ErrorDescription				VARCHAR(4000),
				@REF_VALUE						VARCHAR(500),
				@Tasklst_Stat_CEFAPMRvw_ID		DECIMAL(18),
				@Tasklst_Stat_Issue_ID			DECIMAL(18),
				@Tasklst_Stat_NRAgree_ID		DECIMAL(18),
				@Tasklst_Stat_Agree_ID			DECIMAL(18),
				@Exm_Re_Stat_Planned_ID			DECIMAL(18),
				@Exm_Re_Stat_Requested_ID		DECIMAL(18),
				@Exm_Re_Stat_Scheduled_ID		DECIMAL(18),
				@Output							BIT = 0,
				@Supplier_JSON					NVARCHAR(MAX),
				@PDF_JSON						NVARCHAR(MAX),
				@Current_Date					DATE = GETDATE(),
				@Tasklst_Stat_Accepted_ID		DECIMAL(18),
				@end_dt_default					DATE = CONVERT(DATE,'31/12/9999',103)

			CREATE TABLE #tbl_TaskDtls
			(
				exam_sr_key		DECIMAL(18),
				task_list_id	DECIMAL(18),
				task_list_stat	DECIMAL(18)
			)

			CREATE TABLE  #tbl_ExamUpdate
			(
				exam_sr_key		DECIMAL(18),
				task_list_id	DECIMAL(18),
				supplier_id		DECIMAL(18)
			)


			--Parsing the input JSON
			INSERT INTO #tbl_TaskDtls
			(
				exam_sr_key,
				task_list_id,
				task_list_stat
			)
			SELECT 
				td.exam_sr_key,
				td.task_list_id,
				td.task_list_stat
			FROM	OPENJSON(@Input_JSON)
			WITH
				(
					exam_sr_key		DECIMAL(18),
					task_list_id	DECIMAL(18),
					task_list_stat	DECIMAL(18)
				) AS td;

			--Finding the task list IDs
			SELECT 
				@Tasklst_Stat_CEFAPMRvw_ID = MAX(CASE WHEN ts.REF_VALUE = 'Ready for CEFA PM Review' THEN ts.REF_VAL_SR_KEY ELSE 0 END),
				@Tasklst_Stat_Issue_ID = MAX(CASE WHEN ts.REF_VALUE = 'Issued' THEN ts.REF_VAL_SR_KEY ELSE 0 END),
				@Tasklst_Stat_NRAgree_ID = MAX(CASE WHEN ts.REF_VALUE = 'Ready for NR Agreement' THEN ts.REF_VAL_SR_KEY ELSE 0 END),
				@Tasklst_Stat_Agree_ID = MAX(CASE WHEN ts.REF_VALUE = 'Agreed' THEN ts.REF_VAL_SR_KEY ELSE 0 END),
				@Tasklst_Stat_Accepted_ID = MAX(CASE WHEN ts.REF_VALUE = 'Accepted' THEN ts.REF_VAL_SR_KEY ELSE 0 END)
            FROM [CES].[REFERENCE_VALUE] AS ts
			INNER JOIN [CES].[REFERENCE_TYPE] AS rt
			ON ts.REF_TYP_SR_KEY=rt.REF_TYP_SR_KEY
			WHERE rt.REF_TYP_CODE = 'TLS'
			
			--Finding the Exam Status IDs
			SELECT 
				@Exm_Re_Stat_Planned_ID = MAX(CASE WHEN ts.REF_VALUE = 'Planned' THEN ts.REF_VAL_SR_KEY ELSE 0 END),
				@Exm_Re_Stat_Requested_ID = MAX(CASE WHEN ts.REF_VALUE = 'Requested' THEN ts.REF_VAL_SR_KEY ELSE 0 END),
				@Exm_Re_Stat_Scheduled_ID = MAX(CASE WHEN ts.REF_VALUE = 'Scheduled' THEN ts.REF_VAL_SR_KEY ELSE 0 END)

            FROM [CES].[REFERENCE_VALUE] AS ts
			INNER JOIN [CES].[REFERENCE_TYPE] AS rt
			ON ts.REF_TYP_SR_KEY=rt.REF_TYP_SR_KEY
			WHERE REF_TYP_CODE = 'ERS'
			
			
			--- Validation Checks -- Start
				
			IF NOT EXISTS (SELECT 1 FROM #tbl_TaskDtls)
			BEGIN
				SET @ErrorMsg = 'Input parameter value is missing';
				THROW 50000,@ErrorMsg,1;
			END

			IF (@Role_Name NOT IN ('CEFA PM','Asset Engineer','Supplier Planner','Super User') )
			BEGIN
				SET @ErrorMsg = 'User does not have permission to save/submit for next level';
				THROW 50000,@ErrorMsg,1;
			END
			--- Validation Checks -- End

		---Update the Task List Status

		IF (@Role_Name = 'CEFA PM')
		BEGIN


			IF NOT EXISTS (SELECT 1 FROM #tbl_TaskDtls WHERE task_list_stat IN (@Tasklst_Stat_NRAgree_ID,@Tasklst_Stat_CEFAPMRvw_ID,@Tasklst_Stat_Accepted_ID))
			BEGIN
				SET @ErrorMsg = 'No record(s) saved for the next level.';
				THROW 50000,@ErrorMsg,1;
			END
			ELSE
			BEGIN
			
				--CEFA PM can change the Task list status to Issued from Ready for CEFA PM review
				--Exam Status will also be changed to Requested
			 
				IF EXISTS (SELECT 1 FROM #tbl_TaskDtls WHERE task_list_stat = @Tasklst_Stat_CEFAPMRvw_ID)
				BEGIN
					BEGIN TRAN

						UPDATE ex
						SET
						   EXAM_REQ_STATUS = @Exm_Re_Stat_Requested_ID,    --'Requested'
						   UPDATED_USER = @User_Key,
						   UPDATED_DATE = @Current_Date
						OUTPUT INSERTED.EXAM_SR_KEY, INSERTED.WORK_SR_KEY, INSERTED.SUPPLIER_SR_KEY INTO #tbl_ExamUpdate
						FROM [CES].EXAM AS ex
						INNER JOIN #tbl_TaskDtls tsk
						ON ex.EXAM_SR_KEY = tsk.exam_sr_key
						WHERE tsk.task_list_stat = @Tasklst_Stat_CEFAPMRvw_ID
						AND ex.EXAM_REQ_STATUS = @Exm_Re_Stat_Planned_ID

					
						IF EXISTS (SELECT 1 FROM #tbl_ExamUpdate)
						BEGIN

							---Inserting current status of task list record is history table for record
							INSERT INTO [CES].[WORK_HIST]
								([WORK_SR_KEY]
								,[WORK_YEAR_KEY]
								,[WORK_YR_START_DT]
								,[WORK_YR_END_DT]
								,[ORG_SR_KEY]
								,[ASSET_GUID]
								,[EXAM_TYPE_SR_KEY]
								,[EXAM_DUE_DATE]
								,[WORK_STATUS]
								,[SPECIFIC_EXAM_REQ]
								,[NR_INTERNAL_NOTES]
								,[COMMENTS_TO_SEC]
								,[JOB_NUMBER]
								,[ISACTIVE]
								,[CREATED_USER]
								,[CREATED_DATE]
								,[UPDATED_USER]
								,[UPDATED_DATE])
							SELECT
								[WORK_SR_KEY]
								,[WORK_YEAR_KEY]
								,[WORK_YR_START_DT]
								,[WORK_YR_END_DT]
								,[ORG_SR_KEY]
								,[ASSET_GUID]
								,[EXAM_TYPE_SR_KEY]
								,[EXAM_DUE_DATE]
								,[WORK_STATUS]
								,[SPECIFIC_EXAM_REQ]
								,[NR_INTERNAL_NOTES]
								,[COMMENTS_TO_SEC]
								,[JOB_NUMBER]
								,[ISACTIVE]
								,[CREATED_USER]
								,[CREATED_DATE]
								,[UPDATED_USER]
								,[UPDATED_DATE]
							FROM [CES].[WORK] AS w
							INNER JOIN #tbl_ExamUpdate tsk
							ON w.WORK_SR_KEY = tsk.task_list_id

							WHERE w.WORK_STATUS = @Tasklst_Stat_CEFAPMRvw_ID

							---Updating task list record current status from CEFA PM Review to Issued
							UPDATE w
							SET
							   WORK_STATUS = @Tasklst_Stat_Issue_ID,    --'Issued'
							   UPDATED_USER = @User_Key,
							   UPDATED_DATE = @Current_Date
							FROM [CES].WORK AS w
							INNER JOIN #tbl_ExamUpdate tsk
							ON w.WORK_SR_KEY = tsk.task_list_id

							WHERE w.WORK_STATUS = @Tasklst_Stat_CEFAPMRvw_ID
						END	
					COMMIT TRAN

					IF @@ERROR = 0
						SET @Output = 1

					SELECT @PDF_JSON = JSON_QUERY('[]')
				END
				--CEFA PM can also change the Task list status to Agreed from Accepted
				--Exam Status will also be changed to Scheduled, Baseline Exam date will be freezed to Planned date then
				ELSE IF EXISTS (SELECT 1 FROM #tbl_TaskDtls WHERE task_list_stat = @Tasklst_Stat_Accepted_ID)
				BEGIN
					--DELETE FROM #tbl_ExamUpdate

					BEGIN TRAN
						UPDATE ex
						SET
						   EXAM_REQ_STATUS = @Exm_Re_Stat_Scheduled_ID,    --'Scheduled'
						   EXAM_BASELINE_DATE = EXAM_PLANNED_DATE,
						   UPDATED_USER = @User_Key,
						   UPDATED_DATE = @Current_Date
						OUTPUT INSERTED.EXAM_SR_KEY, INSERTED.WORK_SR_KEY, INSERTED.SUPPLIER_SR_KEY INTO #tbl_ExamUpdate
						FROM [CES].EXAM AS ex
						INNER JOIN #tbl_TaskDtls tsk
						ON ex.EXAM_SR_KEY = tsk.exam_sr_key
						WHERE tsk.task_list_stat = @Tasklst_Stat_Accepted_ID
						AND ex.EXAM_REQ_STATUS = @Exm_Re_Stat_Requested_ID

				
						IF EXISTS (SELECT 1 FROM #tbl_ExamUpdate)
						BEGIN

							---Inserting current status of task list record in history table for record
							INSERT INTO [CES].[WORK_HIST]
								([WORK_SR_KEY]
								,[WORK_YEAR_KEY]
								,[WORK_YR_START_DT]
								,[WORK_YR_END_DT]
								,[ORG_SR_KEY]
								,[ASSET_GUID]
								,[EXAM_TYPE_SR_KEY]
								,[EXAM_DUE_DATE]
								,[WORK_STATUS]
								,[SPECIFIC_EXAM_REQ]
								,[NR_INTERNAL_NOTES]
								,[COMMENTS_TO_SEC]
								,[JOB_NUMBER]
								,[ISACTIVE]
								,[CREATED_USER]
								,[CREATED_DATE]
								,[UPDATED_USER]
								,[UPDATED_DATE])
							SELECT
								[WORK_SR_KEY]
								,[WORK_YEAR_KEY]
								,[WORK_YR_START_DT]
								,[WORK_YR_END_DT]
								,[ORG_SR_KEY]
								,[ASSET_GUID]
								,[EXAM_TYPE_SR_KEY]
								,[EXAM_DUE_DATE]
								,[WORK_STATUS]
								,[SPECIFIC_EXAM_REQ]
								,[NR_INTERNAL_NOTES]
								,[COMMENTS_TO_SEC]
								,[JOB_NUMBER]
								,[ISACTIVE]
								,[CREATED_USER]
								,[CREATED_DATE]
								,[UPDATED_USER]
								,[UPDATED_DATE]
							FROM [CES].[WORK]AS w
							INNER JOIN #tbl_ExamUpdate tsk
							ON w.WORK_SR_KEY = tsk.task_list_id

							WHERE w.WORK_STATUS = @Tasklst_Stat_Accepted_ID

							---Updating task list record current status from NR Review to Agreed
							UPDATE w
							SET
							   WORK_STATUS = @Tasklst_Stat_Agree_ID,    --'Agreed'
							   UPDATED_USER = @User_Key,
							   UPDATED_DATE = @Current_Date
							FROM [CES].WORK AS w
							INNER JOIN #tbl_ExamUpdate tsk
							ON w.WORK_SR_KEY = tsk.task_list_id
							WHERE w.WORK_STATUS = @Tasklst_Stat_Accepted_ID
						END
				
					COMMIT TRAN

					IF @@ERROR = 0
						SET @Output = 1

					IF EXISTS (SELECT 1 FROM #tbl_ExamUpdate)
					BEGIN

							-- PDF Generation output
							SELECT @PDF_JSON =
							(
									SELECT
										final.region,
										final.route,
										final.area,
										final.elr,
										final.railway_id,
										final.mileage_from,
										final.mileage_to,
										final.asset_grp,
										final.asset_type,
										final.asset_desc,
										final.asset_guid,
										final.exam_id,
										final.job_number,
										final.hce_flg,
										final.bcmi_required,
										final.specific_exam_req,
										final.nr_internal_note,
										final.tenanted_arch,
										final.exam_frequency,
										CASE WHEN final.exam_type IN ('Visual','Detailed','Enhanced') 
											THEN CONVERT(DATE, DATEADD( week, (0- ct.SITE_TOLERANCE_WEEKS), final.due_dt),103) 
											WHEN final.exam_type IN ('Underwater', 'Line Of Route' ) OR final.exam_type LIKE '%Additional%'
											THEN final.WORK_YR_START_DT 
											ELSE NULL
										END AS due_date_earliest,
										final.due_dt,
										CASE WHEN final.exam_type IN ('Visual','Detailed','Enhanced') 
											THEN CONVERT(DATE, DATEADD( week, ct.SITE_TOLERANCE_WEEKS, final.due_dt),103) 
											WHEN final.exam_type IN ('Underwater', 'Line Of Route' ) OR final.exam_type LIKE '%Additional%'
											THEN final.WORK_YR_END_DT 
											ELSE NULL
										END AS due_date_latest,
										--CONVERT(DATE, DATEADD( week, ct.REVIEW_TOLERANCE_WEEKS, final.due_dt),103) AS max_tolerance_date,
										CONVERT(DATE, DATEADD( week, ISNULL(ct.REVIEW_TOLERANCE_WEEKS,0),
											CASE WHEN final.exam_type IN ('Visual','Detailed','Enhanced') 
												THEN CONVERT(DATE, DATEADD( week, ct.SITE_TOLERANCE_WEEKS, final.due_dt),103) 
												WHEN final.exam_type IN ('Underwater', 'Line Of Route' ) OR final.exam_type LIKE '%Additional%'
												THEN final.WORK_YR_END_DT 
												ELSE NULL
											END
										),103) AS max_tolerance_date,
										final.task_list_stat,
										final.exam_req_stat,
										final.exam_rpt_stat,
										final.exam_planned_date,
										final.exam_actual_date,
										final.other_supplier_comment,
										final.change_req_id,
										final.exam_baseline_plan_dt
									FROM
									(
										SELECT 
											o.REGION AS region,
											o.ROUTE AS route,
											a.AREA_NAME AS area,
											elr.ELR_CODE AS elr,
											ast.RAILWAY_ID AS railway_id,
											(ast.START_MILES + ast.START_YARDS/1760) AS mileage_from,
											(ast.END_MILES + ast.END_YARDS/1760) AS mileage_to,
											asg.ASSET_GROUP_DESC AS asset_grp,
											asp.ASSET_TYPE_DESC AS asset_type,
											ast.ASSET_NAME AS asset_desc,
											ast.ASSET_GUID AS asset_guid,
											ex.exam_id,
											wrk.job_number,
											CASE WHEN ast.hce_flag = 'Y' THEN 'Yes' ELSE 'No' END AS hce_flg,
											NULL AS bcmi_required,
											ex.EXAM_REQUIREMENT AS specific_exam_req,
											ex.INTERNAL_NOTES AS nr_internal_note,
											CASE WHEN ast.TENANTED_FLG = 'Y' THEN 'Yes'
												 WHEN ast.TENANTED_FLG = 'N' THEN 'No'
												 ELSE 'N/A'
											END AS tenanted_arch,
											(CAST(ISNULL(ef.INTERVAL_YEARS,0) AS VARCHAR) + 'y '+CAST(ISNULL(ef.INTERVAL_MONTHS,0) AS VARCHAR)+ 'm '+CAST(ISNULL(ef.INTERVAL_DAYS,0) AS VARCHAR)+ 'd') AS exam_frequency,
											--NULL AS due_date_earliest,
											wrk.EXAM_DUE_DATE AS due_dt,
											--NULL AS due_date_latest,
											--NULL AS max_tolerance_date,
											ws.REF_VALUE AS task_list_stat,
											eqs.REF_VALUE AS exam_req_stat,
											ers.REF_VALUE AS exam_rpt_stat,
											ex.EXAM_PLANNED_DATE AS exam_planned_date,
											ex.EXAM_ACTUAL_DATE AS exam_actual_date,
											ex.SUPPLIER_COMMENTS AS other_supplier_comment,
											ex.change_req_id,
											ex.EXAM_BASELINE_DATE AS exam_baseline_plan_dt,
											( (ISNULL(INTERVAL_YEARS,0)*12) + (ISNULL(INTERVAL_MONTHS,0)) + (ISNULL(INTERVAL_DAYS,0)/30) ) AS exam_freq_in_months,
											ex.EXAM_TYPE_SR_KEY,
											wrk.WORK_YR_START_DT,
											wrk.WORK_YR_END_DT,
											et.EXAM_TYPE

										FROM [CES].ASSET ast
										INNER JOIN [CES].ORG o
										ON ast.ORG_SR_KEY = o.ORG_SR_KEY
										INNER JOIN [CES].AREA a
										ON a.AREA_SR_KEY = ast.AREA_SR_KEY
										INNER JOIN [CES].ENGINE_LINE_REF elr
										ON elr.ELR_SR_KEY = ast.ENG_LINE_REF
										INNER JOIN [CES].ASSET_GROUP asg
										ON asg.ASSET_GROUP_SR_KEY = ast.ASSET_GROUP_SR_KEY
										INNER JOIN [CES].ASSET_TYPE asp
										ON asp.ASSET_TYPE_SR_KEY = ast.ASSET_TYPE_SR_KEY
										INNER JOIN [CES].EXAM ex
										ON ex.ASSET_GUID = ast.ASSET_GUID
										INNER JOIN #tbl_ExamUpdate eu
										ON eu.EXAM_SR_KEY = ex.EXAM_SR_KEY
										INNER JOIN [CES].WORK wrk
										ON wrk.WORK_SR_KEY = ex.WORK_SR_KEY
										AND wrk.ISACTIVE = 1
										INNER JOIN [CES].EXAM_TYPE et
										ON et.EXAM_TYPE_SR_KEY = ex.EXAM_TYPE_SR_KEY
										INNER JOIN [CES].SUPPLIER s
										ON s.SUPPLIER_SR_KEY = ex.SUPPLIER_SR_KEY
										LEFT JOIN [CES].REFERENCE_VALUE ws
										ON ws.REF_VAL_SR_KEY = wrk.WORK_STATUS
										LEFT JOIN [CES].REFERENCE_VALUE ers
										ON ers.REF_VAL_SR_KEY = ex.EXAM_REPORT_STATUS
										LEFT JOIN [CES].REFERENCE_VALUE eqs
										ON eqs.REF_VAL_SR_KEY = ex.EXAM_REQ_STATUS
										--OUTER APPLY (
										--					SELECT 
										--							ASSET_GUID,
										--							EXAM_TYPE_SR_KEY,
										--							INTERVAL_YEARS,
										--							INTERVAL_MONTHS,
										--							INTERVAL_DAYS,
										--							specific_exam_req
										--					FROM
										--					(
										--						SELECT
										--							ASSET_GUID,
										--							EXAM_TYPE_SR_KEY,
										--							INTERVAL_YEARS,
										--							INTERVAL_MONTHS,
										--							INTERVAL_DAYS,
										--							EXAM_REQUIREMENT AS specific_exam_req,
										--							ROW_NUMBER() OVER (PARTITION BY ASSET_GUID,EXAM_TYPE_SR_KEY ORDER BY EFFECTIVE_FROM_DT DESC) rnk
										--						FROM CES.EXAM_CYCLE
										--						WHERE ISACTIVE =1
										--						AND @current_date BETWEEN EFFECTIVE_FROM_DT AND ISNULL(EFFECTIVE_TO_DT,CONVERT(DATE,'31/12/9999',103))
										--						AND ASSET_GUID = ex.ASSET_GUID
										--						AND EXAM_TYPE_SR_KEY = ex.EXAM_TYPE_SR_KEY
										--					)t
										--					WHERE rnk = 1
										--				) ef
										OUTER APPLY
										(
											SELECT
												INTERVAL_YEARS,
												INTERVAL_MONTHS,
												INTERVAL_DAYS
											FROM 
											(
												SELECT 
													INTERVAL_YEARS,
													INTERVAL_MONTHS,
													INTERVAL_DAYS,
													ROW_NUMBER() OVER (ORDER BY EFFECTIVE_FROM_DT DESC) rnk
												FROM CES.COMPLIANCE c
												WHERE ASSET_GUID = ex.ASSET_GUID
												AND EXAM_TYPE_SR_KEY = ex.EXAM_TYPE_SR_KEY
												AND @current_date BETWEEN EFFECTIVE_FROM_DT AND ISNULL(EFFECTIVE_TO_DT,@end_dt_default)
												AND c.ISACTIVE = 1
											)c
											WHERE rnk = 1
										) ef
										WHERE
											ast.ISACTIVE= 1
										AND o.ISACTIVE = 1
										AND a.ISACTIVE = 1
										AND elr.ISACTIVE = 1
										AND asg.ISACTIVE = 1
										AND asp.ISACTIVE = 1
										AND ex.ISACTIVE = 1
										--AND et.ISACTIVE = 1
										AND s.ISACTIVE = 1
									)final
									INNER JOIN [CES].COMPLIANCE_TOLERANCE ct
									ON ct.EXAM_TYPE_SR_KEY = final.EXAM_TYPE_SR_KEY
									AND ct.ISACTIVE = 1
									AND final.exam_freq_in_months BETWEEN ct.FREQ_INTERVAL_MONTHS_FROM AND ct.FREQ_INTERVAL_MONTHS_TO
									FOR JSON PATH, INCLUDE_NULL_VALUES
							)
					END
				END
				
				--CEFA PM can also change the Task list status to Accepted from Ready for NR review
				ELSE IF EXISTS (SELECT 1 FROM #tbl_TaskDtls WHERE task_list_stat = @Tasklst_Stat_NRAgree_ID)
				BEGIN
					BEGIN TRAN

						---Inserting current status of task list record in history table for record
						INSERT INTO [CES].[WORK_HIST]
							([WORK_SR_KEY]
							,[WORK_YEAR_KEY]
							,[WORK_YR_START_DT]
							,[WORK_YR_END_DT]
							,[ORG_SR_KEY]
							,[ASSET_GUID]
							,[EXAM_TYPE_SR_KEY]
							,[EXAM_DUE_DATE]
							,[WORK_STATUS]
							,[SPECIFIC_EXAM_REQ]
							,[NR_INTERNAL_NOTES]
							,[COMMENTS_TO_SEC]
							,[JOB_NUMBER]
							,[ISACTIVE]
							,[CREATED_USER]
							,[CREATED_DATE]
							,[UPDATED_USER]
							,[UPDATED_DATE])
						SELECT
							[WORK_SR_KEY]
							,[WORK_YEAR_KEY]
							,[WORK_YR_START_DT]
							,[WORK_YR_END_DT]
							,[ORG_SR_KEY]
							,[ASSET_GUID]
							,[EXAM_TYPE_SR_KEY]
							,[EXAM_DUE_DATE]
							,[WORK_STATUS]
							,[SPECIFIC_EXAM_REQ]
							,[NR_INTERNAL_NOTES]
							,[COMMENTS_TO_SEC]
							,[JOB_NUMBER]
							,[ISACTIVE]
							,[CREATED_USER]
							,[CREATED_DATE]
							,[UPDATED_USER]
							,[UPDATED_DATE]
						FROM [CES].[WORK] AS w
						INNER JOIN #tbl_TaskDtls tsk
						ON w.WORK_SR_KEY = tsk.task_list_id
						AND w.WORK_STATUS = tsk.task_list_stat
						
						WHERE w.WORK_STATUS = @Tasklst_Stat_NRAgree_ID

						---Updating task list record current status from Ready for NR Review to Accepted
						UPDATE w
						SET
						   WORK_STATUS = @Tasklst_Stat_Accepted_ID,    --'Accepted'
						   UPDATED_USER = @User_Key,
						   UPDATED_DATE = @Current_Date
						FROM [CES].WORK AS w
						INNER JOIN #tbl_TaskDtls tsk
						ON w.WORK_SR_KEY = tsk.task_list_id
						AND w.WORK_STATUS = tsk.task_list_stat

						WHERE w.WORK_STATUS = @Tasklst_Stat_NRAgree_ID
							
					COMMIT TRAN

					IF @@ERROR = 0
						SET @Output = 1

					SELECT @PDF_JSON = JSON_QUERY('[]')
				END
				
				
				--Required to send the supplier Ids so that UI can send the mail notification
				IF EXISTS (SELECT 1 FROM #tbl_ExamUpdate)
				BEGIN
					SELECT @Supplier_JSON = 
						(
							SELECT DISTINCT Supplier_Id
							FROM #tbl_ExamUpdate 
							FOR JSON AUTO, INCLUDE_NULL_VALUES
						)
						
				END
				ELSE 
				BEGIN
					IF NOT EXISTS (SELECT 1 FROM #tbl_TaskDtls WHERE task_list_stat = @Tasklst_Stat_NRAgree_ID)
					BEGIN
							SET @ErrorMsg = 'No record(s) saved for the next level.';
							THROW 50000,@ErrorMsg,1;
					END
					ELSE
						SET @Supplier_JSON = JSON_QUERY('[]')
				END
			END


		END
		
		--Asset Engineer can change the Task list status to Agreed from Accepted
		--Exam Status will also be changed to Scheduled, Baseline Exam date will be freezed to Planned date then

		IF (@Role_Name IN ('Asset Engineer','Super User') )
		BEGIN
			IF EXISTS (SELECT 1 FROM #tbl_TaskDtls WHERE task_list_stat = @Tasklst_Stat_Accepted_ID)
			BEGIN
				BEGIN TRAN
						UPDATE ex
						SET
						   EXAM_REQ_STATUS = @Exm_Re_Stat_Scheduled_ID,    --'Scheduled'
						   EXAM_BASELINE_DATE = EXAM_PLANNED_DATE,
						   UPDATED_USER = @User_Key,
						   UPDATED_DATE = @Current_Date
						OUTPUT INSERTED.EXAM_SR_KEY, INSERTED.WORK_SR_KEY, INSERTED.SUPPLIER_SR_KEY INTO #tbl_ExamUpdate
						FROM [CES].EXAM AS ex
						INNER JOIN #tbl_TaskDtls tsk
						ON ex.EXAM_SR_KEY = tsk.exam_sr_key
						WHERE tsk.task_list_stat = @Tasklst_Stat_Accepted_ID
						AND ex.EXAM_REQ_STATUS = @Exm_Re_Stat_Requested_ID
						
						IF EXISTS (SELECT 1 FROM #tbl_ExamUpdate)
						BEGIN

							---Inserting current status of task list record in history table for record
							INSERT INTO [CES].[WORK_HIST]
								([WORK_SR_KEY]
								,[WORK_YEAR_KEY]
								,[WORK_YR_START_DT]
								,[WORK_YR_END_DT]
								,[ORG_SR_KEY]
								,[ASSET_GUID]
								,[EXAM_TYPE_SR_KEY]
								,[EXAM_DUE_DATE]
								,[WORK_STATUS]
								,[SPECIFIC_EXAM_REQ]
								,[NR_INTERNAL_NOTES]
								,[COMMENTS_TO_SEC]
								,[JOB_NUMBER]
								,[ISACTIVE]
								,[CREATED_USER]
								,[CREATED_DATE]
								,[UPDATED_USER]
								,[UPDATED_DATE])
							SELECT
								[WORK_SR_KEY]
								,[WORK_YEAR_KEY]
								,[WORK_YR_START_DT]
								,[WORK_YR_END_DT]
								,[ORG_SR_KEY]
								,[ASSET_GUID]
								,[EXAM_TYPE_SR_KEY]
								,[EXAM_DUE_DATE]
								,[WORK_STATUS]
								,[SPECIFIC_EXAM_REQ]
								,[NR_INTERNAL_NOTES]
								,[COMMENTS_TO_SEC]
								,[JOB_NUMBER]
								,[ISACTIVE]
								,[CREATED_USER]
								,[CREATED_DATE]
								,[UPDATED_USER]
								,[UPDATED_DATE]
							FROM [CES].[WORK]AS w
							INNER JOIN #tbl_ExamUpdate tsk
							ON w.WORK_SR_KEY = tsk.task_list_id

							WHERE w.WORK_STATUS = @Tasklst_Stat_Accepted_ID

							---Updating task list record current status from NR Review to Agreed
							UPDATE w
							SET
							   WORK_STATUS = @Tasklst_Stat_Agree_ID,    --'Agreed'
							   UPDATED_USER = @User_Key,
							   UPDATED_DATE = @Current_Date
							FROM [CES].WORK AS w
							INNER JOIN #tbl_ExamUpdate tsk
							ON w.WORK_SR_KEY = tsk.task_list_id
							WHERE w.WORK_STATUS = @Tasklst_Stat_Accepted_ID
						END
						
				
					COMMIT TRAN

					
					IF EXISTS (SELECT 1 FROM #tbl_ExamUpdate)
					BEGIN

						SET @Output = 1

						SELECT @Supplier_JSON = 
							(
								SELECT DISTINCT Supplier_Id
								FROM #tbl_ExamUpdate 
								FOR JSON AUTO, INCLUDE_NULL_VALUES
							)

						-- PDF Generation output
						SELECT @PDF_JSON =
						(
									SELECT
										final.region,
										final.route,
										final.area,
										final.elr,
										final.railway_id,
										final.mileage_from,
										final.mileage_to,
										final.asset_grp,
										final.asset_type,
										final.asset_desc,
										final.asset_guid,
										final.exam_id,
										final.job_number,
										final.hce_flg,
										final.bcmi_required,
										final.specific_exam_req,
										final.nr_internal_note,
										final.tenanted_arch,
										final.exam_frequency,
										CASE WHEN final.exam_type IN ('Visual','Detailed','Enhanced') 
											THEN CONVERT(DATE, DATEADD( week, (0- ct.SITE_TOLERANCE_WEEKS), final.due_dt),103) 
											WHEN final.exam_type IN ('Underwater', 'Line Of Route' ) OR final.exam_type LIKE '%Additional%'
											THEN final.WORK_YR_START_DT 
											ELSE NULL
										END AS due_date_earliest,
										final.due_dt,
										CASE WHEN final.exam_type IN ('Visual','Detailed','Enhanced') 
											THEN CONVERT(DATE, DATEADD( week, ct.SITE_TOLERANCE_WEEKS, final.due_dt),103) 
											WHEN final.exam_type IN ('Underwater', 'Line Of Route' ) OR final.exam_type LIKE '%Additional%'
											THEN final.WORK_YR_END_DT 
											ELSE NULL
										END AS due_date_latest,
										--CONVERT(DATE, DATEADD( week, ct.REVIEW_TOLERANCE_WEEKS, final.due_dt),103) AS max_tolerance_date,
										CONVERT(DATE, DATEADD( week, ISNULL(ct.REVIEW_TOLERANCE_WEEKS,0),
											CASE WHEN final.exam_type IN ('Visual','Detailed','Enhanced') 
												THEN CONVERT(DATE, DATEADD( week, ct.SITE_TOLERANCE_WEEKS, final.due_dt),103) 
												WHEN final.exam_type IN ('Underwater', 'Line Of Route' ) OR final.exam_type LIKE '%Additional%'
												THEN final.WORK_YR_END_DT 
												ELSE NULL
											END
										),103) AS max_tolerance_date,
										final.task_list_stat,
										final.exam_req_stat,
										final.exam_rpt_stat,
										final.exam_planned_date,
										final.exam_actual_date,
										final.other_supplier_comment,
										final.change_req_id,
										final.exam_baseline_plan_dt
									FROM
									(
										SELECT 
												o.REGION AS region,
												o.ROUTE AS route,
												a.AREA_NAME AS area,
												elr.ELR_CODE AS elr,
												ast.RAILWAY_ID AS railway_id,
												(ast.START_MILES + ast.START_YARDS/1760) AS mileage_from,
												(ast.END_MILES + ast.END_YARDS/1760) AS mileage_to,
												asg.ASSET_GROUP_DESC AS asset_grp,
												asp.ASSET_TYPE_DESC AS asset_type,
												ast.ASSET_NAME AS asset_desc,
												ast.ASSET_GUID AS asset_guid,
												ex.exam_id,
												wrk.job_number,
												CASE WHEN ast.hce_flag = 'Y' THEN 'Yes' ELSE 'No' END AS hce_flg,
												NULL AS bcmi_required,
												ex.EXAM_REQUIREMENT AS specific_exam_req,
												ex.INTERNAL_NOTES AS nr_internal_note,
												CASE WHEN ast.TENANTED_FLG = 'Y' THEN 'Yes'
													 WHEN ast.TENANTED_FLG = 'N' THEN 'No'
													 ELSE 'N/A'
												END AS tenanted_arch,
												(CAST(ISNULL(ef.INTERVAL_YEARS,0) AS VARCHAR) + 'y '+CAST(ISNULL(ef.INTERVAL_MONTHS,0) AS VARCHAR)+ 'm '+CAST(ISNULL(ef.INTERVAL_DAYS,0) AS VARCHAR)+ 'd') AS exam_frequency,
												--NULL AS due_date_earliest,
												wrk.EXAM_DUE_DATE AS due_dt,
												--NULL AS due_date_latest,
												--NULL AS max_tolerance_date,
												ws.REF_VALUE AS task_list_stat,
												eqs.REF_VALUE AS exam_req_stat,
												ers.REF_VALUE AS exam_rpt_stat,
												ex.EXAM_PLANNED_DATE AS exam_planned_date,
												ex.EXAM_ACTUAL_DATE AS exam_actual_date,
												ex.SUPPLIER_COMMENTS AS other_supplier_comment,
												ex.change_req_id,
												ex.EXAM_BASELINE_DATE AS exam_baseline_plan_dt,
												( (ISNULL(INTERVAL_YEARS,0)*12) + (ISNULL(INTERVAL_MONTHS,0)) + (ISNULL(INTERVAL_DAYS,0)/30) ) AS exam_freq_in_months,
												ex.EXAM_TYPE_SR_KEY,
												wrk.WORK_YR_START_DT,
												wrk.WORK_YR_END_DT,
												et.EXAM_TYPE
						
											FROM [CES].ASSET ast
											INNER JOIN [CES].ORG o
											ON ast.ORG_SR_KEY = o.ORG_SR_KEY
											INNER JOIN [CES].AREA a
											ON a.AREA_SR_KEY = ast.AREA_SR_KEY
											INNER JOIN [CES].ENGINE_LINE_REF elr
											ON elr.ELR_SR_KEY = ast.ENG_LINE_REF
											INNER JOIN [CES].ASSET_GROUP asg
											ON asg.ASSET_GROUP_SR_KEY = ast.ASSET_GROUP_SR_KEY
											INNER JOIN [CES].ASSET_TYPE asp
											ON asp.ASSET_TYPE_SR_KEY = ast.ASSET_TYPE_SR_KEY
											INNER JOIN [CES].EXAM ex
											ON ex.ASSET_GUID = ast.ASSET_GUID
											INNER JOIN #tbl_ExamUpdate eu
											ON eu.EXAM_SR_KEY = ex.EXAM_SR_KEY
											INNER JOIN [CES].WORK wrk
											ON wrk.WORK_SR_KEY = ex.WORK_SR_KEY
											AND wrk.ISACTIVE = 1
											INNER JOIN [CES].EXAM_TYPE et
											ON et.EXAM_TYPE_SR_KEY = ex.EXAM_TYPE_SR_KEY
											INNER JOIN [CES].SUPPLIER s
											ON s.SUPPLIER_SR_KEY = ex.SUPPLIER_SR_KEY
											LEFT JOIN [CES].REFERENCE_VALUE ws
											ON ws.REF_VAL_SR_KEY = wrk.WORK_STATUS
											LEFT JOIN [CES].REFERENCE_VALUE ers
											ON ers.REF_VAL_SR_KEY = ex.EXAM_REPORT_STATUS
											LEFT JOIN [CES].REFERENCE_VALUE eqs
											ON eqs.REF_VAL_SR_KEY = ex.EXAM_REQ_STATUS
											--OUTER APPLY (
											--					SELECT 
											--							ASSET_GUID,
											--							EXAM_TYPE_SR_KEY,
											--							INTERVAL_YEARS,
											--							INTERVAL_MONTHS,
											--							INTERVAL_DAYS,
											--							specific_exam_req
											--					FROM
											--					(
											--						SELECT
											--							ASSET_GUID,
											--							EXAM_TYPE_SR_KEY,
											--							INTERVAL_YEARS,
											--							INTERVAL_MONTHS,
											--							INTERVAL_DAYS,
											--							EXAM_REQUIREMENT AS specific_exam_req,
											--							ROW_NUMBER() OVER (PARTITION BY ASSET_GUID,EXAM_TYPE_SR_KEY ORDER BY EFFECTIVE_FROM_DT DESC) rnk
											--						FROM CES.EXAM_CYCLE
											--						WHERE ISACTIVE =1
											--						AND @current_date BETWEEN EFFECTIVE_FROM_DT AND ISNULL(EFFECTIVE_TO_DT,CONVERT(DATE,'31/12/9999',103))
											--						AND ASSET_GUID = ex.ASSET_GUID
											--						AND EXAM_TYPE_SR_KEY = ex.EXAM_TYPE_SR_KEY
											--					)t
											--					WHERE rnk = 1
											--				) ef
											OUTER APPLY
											(
												SELECT
													INTERVAL_YEARS,
													INTERVAL_MONTHS,
													INTERVAL_DAYS
												FROM 
												(
													SELECT 
														INTERVAL_YEARS,
														INTERVAL_MONTHS,
														INTERVAL_DAYS,
														ROW_NUMBER() OVER (ORDER BY EFFECTIVE_FROM_DT DESC) rnk
													FROM CES.COMPLIANCE c
													WHERE ASSET_GUID = ex.ASSET_GUID
													AND EXAM_TYPE_SR_KEY = ex.EXAM_TYPE_SR_KEY
													AND @current_date BETWEEN EFFECTIVE_FROM_DT AND ISNULL(EFFECTIVE_TO_DT,@end_dt_default)
													AND c.ISACTIVE = 1
												)c
												WHERE rnk = 1
											) ef
							
											WHERE
												ast.ISACTIVE= 1
											AND o.ISACTIVE = 1
											AND a.ISACTIVE = 1
											AND elr.ISACTIVE = 1
											AND asg.ISACTIVE = 1
											AND asp.ISACTIVE = 1
											AND ex.ISACTIVE = 1
											--AND et.ISACTIVE = 1
											AND s.ISACTIVE = 1
									)final
									INNER JOIN [CES].COMPLIANCE_TOLERANCE ct
									ON ct.EXAM_TYPE_SR_KEY = final.EXAM_TYPE_SR_KEY
									AND ct.ISACTIVE = 1
									AND final.exam_freq_in_months BETWEEN ct.FREQ_INTERVAL_MONTHS_FROM AND ct.FREQ_INTERVAL_MONTHS_TO

									FOR JSON PATH, INCLUDE_NULL_VALUES

						)
					END
					ELSE
					BEGIN
						SET @ErrorMsg = 'No record(s) saved for the next level.';
						THROW 50000,@ErrorMsg,1;
					END

					
			END
			
			--AE can also change the Task list status to Accepted from Ready for NR review
			ELSE IF EXISTS (SELECT 1 FROM #tbl_TaskDtls WHERE task_list_stat = @Tasklst_Stat_NRAgree_ID)
			BEGIN
				BEGIN TRAN

					---Inserting current status of task list record in history table for record
					INSERT INTO [CES].[WORK_HIST]
						([WORK_SR_KEY]
						,[WORK_YEAR_KEY]
						,[WORK_YR_START_DT]
						,[WORK_YR_END_DT]
						,[ORG_SR_KEY]
						,[ASSET_GUID]
						,[EXAM_TYPE_SR_KEY]
						,[EXAM_DUE_DATE]
						,[WORK_STATUS]
						,[SPECIFIC_EXAM_REQ]
						,[NR_INTERNAL_NOTES]
						,[COMMENTS_TO_SEC]
						,[JOB_NUMBER]
						,[ISACTIVE]
						,[CREATED_USER]
						,[CREATED_DATE]
						,[UPDATED_USER]
						,[UPDATED_DATE])
					SELECT
						[WORK_SR_KEY]
						,[WORK_YEAR_KEY]
						,[WORK_YR_START_DT]
						,[WORK_YR_END_DT]
						,[ORG_SR_KEY]
						,[ASSET_GUID]
						,[EXAM_TYPE_SR_KEY]
						,[EXAM_DUE_DATE]
						,[WORK_STATUS]
						,[SPECIFIC_EXAM_REQ]
						,[NR_INTERNAL_NOTES]
						,[COMMENTS_TO_SEC]
						,[JOB_NUMBER]
						,[ISACTIVE]
						,[CREATED_USER]
						,[CREATED_DATE]
						,[UPDATED_USER]
						,[UPDATED_DATE]
					FROM [CES].[WORK] AS w
					INNER JOIN #tbl_TaskDtls tsk
					ON w.WORK_SR_KEY = tsk.task_list_id
					AND w.WORK_STATUS = tsk.task_list_stat
					
					WHERE w.WORK_STATUS = @Tasklst_Stat_NRAgree_ID

					---Updating task list record current status from Ready for NR Review to Accepted
					UPDATE w
					SET
					   WORK_STATUS = @Tasklst_Stat_Accepted_ID,    --'Accepted'
					   UPDATED_USER = @User_Key,
					   UPDATED_DATE = @Current_Date
					FROM [CES].WORK AS w
					INNER JOIN #tbl_TaskDtls tsk
					ON w.WORK_SR_KEY = tsk.task_list_id
					AND w.WORK_STATUS = tsk.task_list_stat

					WHERE w.WORK_STATUS = @Tasklst_Stat_NRAgree_ID
						
				COMMIT TRAN

				IF @@ERROR = 0
					SET @Output = 1

				SELECT @PDF_JSON = JSON_QUERY('[]'),
					   @Supplier_JSON = JSON_QUERY('[]')
			END
				
			ELSE
			BEGIN
				SET @ErrorMsg = 'No record(s) saved for the next level.';
				THROW 50000,@ErrorMsg,1;
			END
		END

		--Supplier Planner can change the Task list status to Ready for NR Review from Issued
		
		IF (@Role_Name = 'Supplier Planner')
		BEGIN
			IF EXISTS (SELECT 1 FROM #tbl_TaskDtls WHERE task_list_stat = @Tasklst_Stat_Issue_ID)
			BEGIN
				BEGIN TRAN

						---Inserting current status of task list record in history table for record
						INSERT INTO [CES].[WORK_HIST]
							([WORK_SR_KEY]
							,[WORK_YEAR_KEY]
							,[WORK_YR_START_DT]
							,[WORK_YR_END_DT]
							,[ORG_SR_KEY]
							,[ASSET_GUID]
							,[EXAM_TYPE_SR_KEY]
							,[EXAM_DUE_DATE]
							,[WORK_STATUS]
							,[SPECIFIC_EXAM_REQ]
							,[NR_INTERNAL_NOTES]
							,[COMMENTS_TO_SEC]
							,[JOB_NUMBER]
							,[ISACTIVE]
							,[CREATED_USER]
							,[CREATED_DATE]
							,[UPDATED_USER]
							,[UPDATED_DATE])
						SELECT
							[WORK_SR_KEY]
							,[WORK_YEAR_KEY]
							,[WORK_YR_START_DT]
							,[WORK_YR_END_DT]
							,[ORG_SR_KEY]
							,[ASSET_GUID]
							,[EXAM_TYPE_SR_KEY]
							,[EXAM_DUE_DATE]
							,[WORK_STATUS]
							,[SPECIFIC_EXAM_REQ]
							,[NR_INTERNAL_NOTES]
							,[COMMENTS_TO_SEC]
							,[JOB_NUMBER]
							,[ISACTIVE]
							,[CREATED_USER]
							,[CREATED_DATE]
							,[UPDATED_USER]
							,[UPDATED_DATE]
						FROM [CES].[WORK]AS w
						INNER JOIN #tbl_TaskDtls tsk
						ON w.WORK_SR_KEY = tsk.task_list_id
						AND w.WORK_STATUS = tsk.task_list_stat
						WHERE tsk.task_list_stat = @Tasklst_Stat_Issue_ID

						---Updating task list record current status from Issued to NR Review
						UPDATE w
						SET
						   WORK_STATUS = @Tasklst_Stat_NRAgree_ID,    --'Ready for NR Review'
						   UPDATED_USER = @User_Key,
						   UPDATED_DATE = @Current_Date
						FROM [CES].WORK AS w
						INNER JOIN #tbl_TaskDtls tsk
						ON w.WORK_SR_KEY = tsk.task_list_id
						AND w.WORK_STATUS = tsk.task_list_stat
						WHERE tsk.task_list_stat = @Tasklst_Stat_Issue_ID
				
										
					COMMIT TRAN

					IF @@ERROR = 0
						SET @Output = 1

					SELECT @Supplier_JSON = JSON_QUERY('[]')
					SELECT @PDF_JSON = JSON_QUERY('[]')
						
			END
			ELSE
			BEGIN
				SET @ErrorMsg = 'No record(s) saved for the next level.';
				THROW 50000,@ErrorMsg,1;
			END
		END

	   	IF @Output <>0 		
			SELECT @Output AS SaveStatus,NULL AS ErrorMsg,@Supplier_JSON AS Supplier_dtls,@PDF_JSON AS PDF_dtls;

		DROP TABLE IF EXISTS #tbl_TaskDtls;
		DROP TABLE IF EXISTS #tbl_ExamUpdate;
					
	END TRY

	BEGIN CATCH
		IF (@@TRANCOUNT >0)
			ROLLBACK TRAN
		
		IF @ErrorMsg IS NULL
			SET @ErrorMsg = ERROR_MESSAGE() 
		
		SET @ErrorDescription = @ErrorMsg + 
							' Line Num:' + CONVERT(VARCHAR(5), ERROR_LINE()) + 
							',ErrorNum:' + CONVERT(VARCHAR(5), ERROR_NUMBER()) + 
							',Severity:' + CONVERT(VARCHAR(5), ERROR_SEVERITY()) + 
							',State:' + CONVERT(VARCHAR(10), ERROR_STATE()) + 
							',Procedure:' + CONVERT(VARCHAR(25), OBJECT_NAME(@@procid)) +
							',Procedure:' + CONVERT(VARCHAR(25), ERROR_PROCEDURE())

		SET @Output = 0;
		SELECT @Output AS SaveStatus,@ErrorMsg AS ErrorMsg, JSON_QUERY('[]') AS Supplier_dtls, JSON_QUERY('[]') AS PDF_dtls;

		DROP TABLE IF EXISTS #tbl_TaskDtls;
		DROP TABLE IF EXISTS #tbl_ExamUpdate;
					
		THROW 50000,@ErrorDescription,1;
	END CATCH

	SET NOCOUNT OFF
  END