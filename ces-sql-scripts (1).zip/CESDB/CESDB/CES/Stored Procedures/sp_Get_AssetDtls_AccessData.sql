﻿


/***************************************************************************************************************************************            
* Name						: sp_get_assetdtls_accessdata            
* Created By				: Cognizant            
* Date Created				: 14-Dec-2020           
* Description				: This stored procedure gets the for asset Accessdata.  
* Input Parameters			: Asset GUID      
* Output Parameters			: N/A            
* Return Value				: N/A            
* Assumptions				: None    
* Execution Statement		: EXEC [CES].[sp_Get_AssetDtls_AccessData]  @Asset_GUID='43D8F3AC61A712A2E0440017084CC843'
*								
* Modified Date     Modified By   Revision Number  Modifications            
  16/07/2021        Cognizant	  2.0			   User Story: 37568 - AccessData - Added 'COMMENTS' field
*******************************************************************************************************************************************/ 



CREATE PROCEDURE [CES].[sp_Get_AssetDtls_AccessData] 

     @Asset_GUID VARCHAR (32)

AS 


BEGIN
	SET NOCOUNT ON

  BEGIN TRY
		DECLARE
				@ErrorMsg	VARCHAR(250)

		IF EXISTS (SELECT 1 FROM [CES].[ACCESS] WHERE ASSET_GUID = @Asset_GUID)
		BEGIN
			SELECT 
				acs.[POSSESSION] AS possession,
				acs.[RRV] AS rrv,
				acs.[LADDER] AS ladder,
				acs.[CONFINED_SPACE] AS confined_space,
				acs.[3RD_PARTY] AS [3rd_party],
				acs.[LINE_BLOCK] AS line_block,
				acs.[MEWP] AS mewp,
				acs.[SCAFFOLD] AS scaffold,
				acs.[WATER_PERMIT] AS water_permit,
				acs.[TRAFFIC_MNGT] AS traffic_mngt,
				acs.[ROPE_ACCESS] AS rope_access,
				acs.[CCTV] AS cctv,
				acs.[SAFETY_BOAT] AS saftey_boat,
				acs.[COMMENTS] AS comments,
				et.exam_type

		
			FROM [CES].[ACCESS] AS acs
			INNER JOIN [CES].[EXAM_TYPE] et
			ON acs.EXAM_TYPE_SR_KEY = et.EXAM_TYPE_SR_KEY
			WHERE acs.[ASSET_GUID] = @Asset_GUID

			FOR JSON PATH,INCLUDE_NULL_VALUES 
		END 
		ELSE
		BEGIN
			SELECT 
				'[]' access_dtls
		END

		

	END TRY

	BEGIN CATCH
		SET @ErrorMsg = ERROR_MESSAGE() + 
						' Line Num:' + CONVERT(VARCHAR(5), ERROR_LINE()) + 
						',ErrorNum:' + CONVERT(VARCHAR(5), ERROR_NUMBER()) + 
						',Severity:' + CONVERT(VARCHAR(5), ERROR_SEVERITY()) + 
						',State:' + CONVERT(VARCHAR(10), ERROR_STATE()) + 
						',Procedure:' + CONVERT(VARCHAR(25), OBJECT_NAME(@@procid)) +
						',Procedure:' + CONVERT(VARCHAR(25), ERROR_PROCEDURE());  

		THROW 50000,@ErrorMsg,1;
	END CATCH
	SET NOCOUNT OFF
END
