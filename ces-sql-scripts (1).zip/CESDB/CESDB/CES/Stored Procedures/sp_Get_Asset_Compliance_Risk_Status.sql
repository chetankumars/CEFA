﻿/***************************************************************************************************************************************            
* Name						: sp_Get_Asset_Compliance_Risk_Status            
* Created By				: Cognizant            
* Date Created				: 18-Feb-2021           
* Description				: This stored procedure provides the compliance and risk status for assets.  
* Input Parameters			: JSON      
* Output Parameters			: @OUT_ErrorNo            
* Return Value				: N/A            
* Assumptions				: None
* Execution Statement		: Exec [CES].sp_Get_Asset_Compliance_Risk_Status '["3978559C3DD145D9E04400306E4AD01A",
"3978559C3DD345D9E04400306E4AD01A","3978559C3DD445D9E04400306E4AD01A","3978559C3DD545D9E04400306E4AD01A",
"3978559C3DD645D9E04400306E4AD01A","3978559C3DD745D9E04400306E4AD01A","3978559C3DD845D9E04400306E4AD01A",
"3978559C3DD945D9E04400306E4AD01A","3978559C3E2145D9E04400306E4AD01A","3978559C3E2245D9E04400306E4AD01A"]', '7/3/2021' 
 			
		Exec [CES].sp_Get_Asset_Compliance_Risk_Status '["3978559C34E345D9E04400306E4AD01A","3978559E3C6745D9E04400306E4AD01A","3978559C300A45D9E04400306E4AD01A"]', '10/5/2021', 'ComplianceSearch'			
									 Exec [CES].sp_Get_Asset_Compliance_Risk_Status '["3978559D380945D9E04400306E4AD01A"]', '10/5/2021'								
*
* Modified Date     Modified By     Revision Number      Modifications
  13-Jul-2021       Cognizant        2.0                 Add @Execution parameter to send different set of output,
														 Add Mitigation Date to output from Risk Assessment table
														 Add the required fields for reporting calculation
														 User Stories #7085,#7093,#37084

							

*******************************************************************************************************************************************/ 



CREATE PROCEDURE [CES].[sp_Get_Asset_Compliance_Risk_Status]
	@Input_JSON				NVARCHAR(MAX),
	@ret_reference_date		DATE,
	@Execution		VARCHAR(20) = 'Default'
AS 
BEGIN
	SET NOCOUNT ON
	SET ANSI_WARNINGS OFF  --Required for suppressing the warning message from aggregate function (limitation from API)

	BEGIN TRY
		DECLARE
				@ErrorMsg			VARCHAR(250),
				@reference_date     Date,
				@dtl_exam_typ_id		DECIMAL(18),
				@ve_exam_type_id		DECIMAL(18),
				@uw_exam_type_id		DECIMAL(18),
				@exam_report_status_rejected_id DECIMAL(18),
				--@exam_req_status_scheduled_id DECIMAL(18),
				@risk_assessed_status_id DECIMAL(18)
				
		CREATE TABLE #ast_guid_tbl 
		(
			asset_guid VARCHAR(32)
		)

		
			
		INSERT INTO #ast_guid_tbl (asset_guid)
		SELECT[value] FROM OPENJSON(@Input_JSON);

		

		IF @ret_reference_date IS NOT NULL
			SET @reference_date = CONVERT(date,@ret_reference_date, 103)
		ELSE
			SET @reference_date = DATEADD(dd, DATEDIFF(dd, 0, GETDATE()), 0)


		DROP TABLE IF EXISTS #tbl_ComplianceTolerance_sub;
		DROP TABLE IF EXISTS #tbl_ComplianceRiskStatus_sub;

		CREATE TABLE #tbl_ComplianceRiskStatus_sub
		(
			cr_asset_guid			VARCHAR(32),
			cr_exam_type_id			DECIMAL(18),
			cr_freq					VARCHAR(64),		
			cr_compliance_status	VARCHAR(200),
			cr_risk_status			VARCHAR(200),
			cr_comp_date			DATE,
			cr_comp_st_rt_date		DATE,
			cr_comp_st_date			DATE,
			cr_exam_planned_date	DATE,
			cr_exam_actual_date		DATE,			
			cr_supplier				VARCHAR(64),
			ra_mitigation_date		DATE
		)
			
		CREATE TABLE #tbl_ComplianceTolerance_sub
		(
			ct_exam_type_id			    DECIMAL(18),
			ct_interval_months_from		DECIMAL(5),
			ct_interval_months_to		DECIMAL(5),
			ct_site_tolerance_weeks		DECIMAL(5),
			ct_review_tolerance_weeks	DECIMAL(5)
		)

		SELECT @dtl_exam_typ_id = EXAM_TYPE_SR_KEY FROM CES.EXAM_TYPE WHERE EXAM_TYPE = 'Detailed' AND ISACTIVE = 1
		SELECT @ve_exam_type_id = EXAM_TYPE_SR_KEY FROM CES.EXAM_TYPE WHERE EXAM_TYPE = 'Visual' AND ISACTIVE = 1
		SELECT @uw_exam_type_id = EXAM_TYPE_SR_KEY FROM CES.EXAM_TYPE WHERE EXAM_TYPE = 'Underwater' AND ISACTIVE = 1
		SELECT @exam_report_status_rejected_id = REF_VAL_SR_KEY FROM CES.REFERENCE_VALUE WHERE REF_TYP_SR_KEY=(SELECT REF_TYP_SR_KEY FROM CES.REFERENCE_TYPE WHERE REF_TYP_NAME='Exam Report Status') AND REF_VALUE='Rejected'
		--SELECT @exam_req_status_scheduled_id = REF_VAL_SR_KEY FROM CES.REFERENCE_VALUE WHERE REF_TYP_SR_KEY=(SELECT REF_TYP_SR_KEY FROM CES.REFERENCE_TYPE WHERE REF_TYP_NAME='Exam Request Status') AND REF_VALUE='Scheduled'
		SELECT @risk_assessed_status_id = REF_VAL_SR_KEY FROM CES.REFERENCE_VALUE WHERE REF_TYP_SR_KEY=(SELECT REF_TYP_SR_KEY FROM CES.REFERENCE_TYPE WHERE REF_TYP_NAME='Risk Assessment Status') AND REF_VALUE='Completed (Data)'

		INSERT INTO #tbl_ComplianceTolerance_sub (
			ct_exam_type_id,
			ct_interval_months_from,
			ct_interval_months_to,
			ct_site_tolerance_weeks,
			ct_review_tolerance_weeks
			)
			(SELECT EXAM_TYPE_SR_KEY,FREQ_INTERVAL_MONTHS_FROM,FREQ_INTERVAL_MONTHS_TO,SITE_TOLERANCE_WEEKS,REVIEW_TOLERANCE_WEEKS
				FROM [CES].[COMPLIANCE_TOLERANCE] WHERE ISACTIVE=1 )

		INSERT INTO #tbl_ComplianceRiskStatus_sub
			(
				cr_asset_guid,
				cr_exam_type_id,
				cr_freq,
				cr_compliance_status,
				cr_risk_status,
				cr_comp_date,
				cr_comp_st_rt_date,
				cr_comp_st_date,
				cr_exam_planned_date,
				cr_exam_actual_date,			
				cr_supplier,
				ra_mitigation_date
			)
		(
		SELECT ASSET_GUID,EXAM_TYPE_SR_KEY,FREQ,
		ISNULL(COMPLIANCE_STATUS,' '),
			ISNULL(CASE --need to check if the compliant is blank
				WHEN LTRIM(RTRIM(UPPER(COMPLIANCE_STATUS))) = '' THEN '' --WHEN COMPLIANT IS BLANK THEN RISK STATUS ALSO BLANK
				WHEN LTRIM(RTRIM(UPPER(COMPLIANCE_STATUS))) = 'COMPLIANT' THEN 'Not Required' -- COMPLIANCE STATUS IS COMPLIANT
				--NEED TO CHECK
				WHEN LTRIM(RTRIM(UPPER(COMPLIANCE_STATUS))) = 'NON-COMPLIANT AWAITING SIGN-OFF' THEN 'Not Required' -- COMPLIANCE STATUS IS NOT COMPLIANT FOR RECOMMENDATION REVIEW (SIGN OFF)
				WHEN LTRIM(RTRIM(UPPER(COMPLIANCE_STATUS))) = 'NON-COMPLIANT ON-SITE' OR  LTRIM(RTRIM(UPPER(COMPLIANCE_STATUS))) = 'NON-COMPLIANT FOR SUBMISSION' THEN  -- COMPLIANCE STATUS IS COMPLIANTNON-COMPLIANT ON SITE OR NON-COMPLIANT FOR SUBMISSION
				CASE WHEN RA_REVIEW_DATE IS NOT NULL THEN  -- RA REVIEW DATE AVAILABLE YES 
					CASE WHEN @reference_date<RA_EXPIRY_DATE THEN  -- REFERENCE DATE < RA EXPIRY DATE 
						CASE WHEN @reference_date<RA_REVIEW_DATE THEN -- REFERENCE DATE < RA REVIEW DATE 
							CASE WHEN RA_RISK_ASSESS_STATUS=@risk_assessed_status_id THEN 'Completed (Data)' --RA STATUS IS Completed (Data)
							ELSE --RA STATUS IS NOT Completed (Data)
								CASE WHEN LTRIM(RTRIM(UPPER(RA_RISK_SCORE)))='HIGH' THEN 'Complete (result: Higher)' --RISK ASSESSMENT IS HIGHER 
								ELSE 'Complete (result: Lower)'--RISK ASSESSMENT IS LOWER 
								END
							END
						ELSE 'Review Required' -- REFERENCE DATE >= RA REVIEW DATE 
						END
					ELSE 'Not Compliant (CIV/021)' -- REFERENCE DATE >= RA EXPIRY DATE 
					END
				ELSE  -- RA REVIEW DATE NOT AVAILABLE
					CASE WHEN @reference_date<DATEADD(WEEK, 1, CMP_D_ST) THEN 'Awaiting Risk Assessment' --REFERENCE DATE <SITE TOLERANCE + 1 WEEK
					ELSE 'Required' --REFERENCE DATE >=SITE TOLERANCE + 1 WEEK
					END
				END

			END,
			' ')
			AS RISK_STATUS
			,COMP_DATE,CMP_D_ST_RT,CMP_D_ST, EXAM_PLANNED_DATE, EXAM_ACTUAL_DATE, SUPPLIER, RA_MITIGATION_DATE
			FROM
			(
				SELECT 
				EXAM_TYPE_SR_KEY,
				ASSET_GUID,FREQ,
				CMP_D_ST,LAE_D_FRE_ST,CMP_D_ST_RT,
				CASE WHEN COMP_DATE IS NULL THEN '' --COMPLIANT IS BLANK
				ELSE 
					CASE 
						WHEN @reference_date>CMP_D_ST THEN  -- REFERENCE DATE > COMPLIANCE DATE + SITE TOLERANCE						
						CASE 
						WHEN LAE_D_FRE_ST IS NULL THEN 'Non-compliant on-site' 
						WHEN @reference_date>LAE_D_FRE_ST THEN 'Non-compliant on-site' -- REFERENCE DATE > LAST ACTUAL EXAM DATE + FREQ + SITE TOLERANCE
						ELSE  --REFERENCE DATE <= LAST ACTUAL EXAM DATE + FREQ + SITE TOLERANCE
							CASE WHEN EXAM_SUBMISSION_DATE IS NOT NULL THEN -- SUBMISSION FOR THAT EXAM ID OF THE LATEST ACTUAL EXAM DATE EXISTS
								CASE WHEN EXAM_REPORT_STATUS = @exam_report_status_rejected_id THEN -- EXAM REJECTED YES
									CASE 
									WHEN CMP_D_ST_RT IS NULL THEN 'Non-compliant for submission'
									WHEN @reference_date>CMP_D_ST_RT THEN 'Non-compliant for submission' -- REFERENCE DATE > COMPLANCE DATE + SITE TOLERANCE + REVIEW TOLERANCE
									ELSE 'Compliant' -- REFERENCE DATE <= COMPLANCE DATE + SITE TOLERANCE + REVIEW TOLERANCE 
									END
								ELSE -- EXAM REJECTED NO
									CASE WHEN EXAM_SIGNOFF_DATE IS NOT NULL THEN 'Compliant'  -- EXAM SIGN OFF DATE RECORDED YES
									ELSE -- EXAM SIGN OFF DATE RECORDED NO
										CASE 
										WHEN CMP_D_ST_RT IS NULL THEN 'Non-compliant awaiting sign-off' 
										WHEN @reference_date>CMP_D_ST_RT THEN 'Non-compliant awaiting sign-off'  -- REFERENCE DATE > COMPLANCE DATE + SITE TOLERANCE + REVIEW TOLERANCE
										ELSE 'Compliant'  -- REFERENCE DATE <= COMPLANCE DATE + SITE TOLERANCE + REVIEW TOLERANCE
										END
									END
								END
							ELSE -- SUBMISSION FOR THAT EXAM ID OF THE LATEST ACTUAL EXAM DATE NOT EXISTS
								CASE 
								WHEN CMP_D_ST_RT IS NULL THEN  'Non-compliant for submission'
								WHEN @reference_date>CMP_D_ST_RT THEN 'Non-compliant for submission' -- REFERENCE DATE > COMPLANCE DATE + SITE TOLERANCE + REVIEW TOLERANCE
								ELSE 'Compliant' END -- REFERENCE DATE <= COMPLANCE DATE + SITE TOLERANCE + REVIEW TOLERANCE
							END 
						END 
					ELSE 'Compliant'  -- REFERENCE DATE <= COMPLIANCE DATE + SITE TOLERANCE
					END
				END AS Compliance_Status
				,RA_REVIEW_DATE,RA_EXPIRY_DATE,RA_RISK_SCORE,RA_RISK_ASSESS_STATUS
				,COMP_DATE, EXAM_PLANNED_DATE, EXAM_ACTUAL_DATE, SUPPLIER,RA_MITIGATION_DATE
				 FROM (
						SELECT 
						
						ast.asset_guid AS ASSET_GUID,EX.EXAM_TYPE_SR_KEY,
						CAST (ISNULL(CMP.INTERVAL_YEARS,0) AS VARCHAR(5))+ 'y '+CAST (ISNULL(CMP.INTERVAL_MONTHS,0) AS VARCHAR(5))+ 'm '+CAST (ISNULL(CMP.INTERVAL_DAYS,0) AS VARCHAR(5))+'d'
						AS FREQ,
						EX.EXAM_PLANNED_DATE,EX.EXAM_ACTUAL_DATE,EX.EXAM_SIGNOFF_DATE,EX.EXAM_REQ_STATUS,EX.EXAM_REPORT_STATUS,EX.EXAM_SUBMISSION_DATE,
						CMP.COMP_DATE,						
						Case when EX.EXAM_TYPE_SR_KEY=@ve_exam_type_id then CASE WHEN CMP.COMP_DATE IS NOT NULL THEN DATEADD(WEEK, (SELECT ct_site_tolerance_weeks FROM #tbl_ComplianceTolerance_sub WHERE ct_exam_type_id=@ve_exam_type_id AND ISNULL(((CASE WHEN CMP.INTERVAL_DAYS IS NULL THEN 0 ELSE (CMP.INTERVAL_DAYS/30)END) +ISNULL(CMP.INTERVAL_MONTHS,0)+(ISNULL(CMP.INTERVAL_YEARS,0)*12)),0) BETWEEN ct_interval_months_from AND ct_interval_months_to), CMP.COMP_DATE) ELSE NULL END 
							when EX.EXAM_TYPE_SR_KEY=@dtl_exam_typ_id then CASE WHEN CMP.COMP_DATE IS NOT NULL THEN DATEADD(WEEK, (SELECT ct_site_tolerance_weeks FROM #tbl_ComplianceTolerance_sub WHERE ct_exam_type_id=@dtl_exam_typ_id AND ISNULL(((CASE WHEN CMP.INTERVAL_DAYS IS NULL THEN 0 ELSE (CMP.INTERVAL_DAYS/30)END) +ISNULL(CMP.INTERVAL_MONTHS,0)+(ISNULL(CMP.INTERVAL_YEARS,0)*12)),0) BETWEEN ct_interval_months_from AND ct_interval_months_to), CMP.COMP_DATE) ELSE NULL END 
							--when EX.EXAM_TYPE_SR_KEY=@uw_exam_type_id then CASE WHEN EX.EXAM_PLANNED_DATE IS NOT NULL THEN CONVERT(DATE,CONCAT('31-03-',CASE WHEN (MONTH(EX.EXAM_PLANNED_DATE)) <= 3 THEN YEAR(EX.EXAM_PLANNED_DATE) ELSE YEAR(EX.EXAM_PLANNED_DATE)+1 END),103) ELSE NULL END 
							when EX.EXAM_TYPE_SR_KEY=@uw_exam_type_id then CASE WHEN CMP.COMP_DATE IS NOT NULL THEN CONVERT(DATE,CONCAT('31-03-',CASE WHEN (MONTH(CMP.COMP_DATE)) <= 3 THEN YEAR(CMP.COMP_DATE) ELSE YEAR(CMP.COMP_DATE)+1 END),103) ELSE NULL END 
						End AS CMP_D_ST, 						
						Case when EX.EXAM_TYPE_SR_KEY=@ve_exam_type_id then CASE WHEN EX.EXAM_ACTUAL_DATE IS NOT NULL THEN DATEADD(WEEK, (SELECT ct_site_tolerance_weeks FROM #tbl_ComplianceTolerance_sub WHERE ct_exam_type_id=@ve_exam_type_id AND ISNULL(((CASE WHEN CMP.INTERVAL_DAYS IS NULL THEN 0 ELSE (CMP.INTERVAL_DAYS/30)END) +ISNULL(CMP.INTERVAL_MONTHS,0)+(ISNULL(CMP.INTERVAL_YEARS,0)*12)),0) BETWEEN ct_interval_months_from AND ct_interval_months_to), DATEADD(DAY, ISNULL(CMP.INTERVAL_DAYS,0), DATEADD(MONTH, ISNULL(CMP.INTERVAL_MONTHS,0), DATEADD(YEAR, ISNULL(CMP.INTERVAL_YEARS,0), EX.EXAM_ACTUAL_DATE)))) ELSE NULL END 
							when EX.EXAM_TYPE_SR_KEY=@dtl_exam_typ_id then CASE WHEN EX.EXAM_ACTUAL_DATE IS NOT NULL THEN DATEADD(WEEK, (SELECT ct_site_tolerance_weeks FROM #tbl_ComplianceTolerance_sub WHERE ct_exam_type_id=@dtl_exam_typ_id AND ISNULL(((CASE WHEN CMP.INTERVAL_DAYS IS NULL THEN 0 ELSE (CMP.INTERVAL_DAYS/30)END) +ISNULL(CMP.INTERVAL_MONTHS,0)+(ISNULL(CMP.INTERVAL_YEARS,0)*12)),0) BETWEEN ct_interval_months_from AND ct_interval_months_to), DATEADD(DAY, ISNULL(CMP.INTERVAL_DAYS,0), DATEADD(MONTH, ISNULL(CMP.INTERVAL_MONTHS,0), DATEADD(YEAR, ISNULL(CMP.INTERVAL_YEARS,0), EX.EXAM_ACTUAL_DATE)))) ELSE NULL END 
							when EX.EXAM_TYPE_SR_KEY=@uw_exam_type_id then  CASE WHEN EX.EXAM_ACTUAL_DATE IS NOT NULL THEN DATEADD(DAY, ISNULL(CMP.INTERVAL_DAYS,0), DATEADD(MONTH, ISNULL(CMP.INTERVAL_MONTHS,0), DATEADD(YEAR, ISNULL(CMP.INTERVAL_YEARS,0), EX.EXAM_ACTUAL_DATE))) ELSE NULL END 
							--(CASE WHEN EX.EXAM_PLANNED_DATE IS NOT NULL THEN CONVERT(DATE,CONCAT('31-03-',CASE WHEN (MONTH(EX.EXAM_PLANNED_DATE)) <= 3 THEN YEAR(EX.EXAM_PLANNED_DATE) ELSE YEAR(EX.EXAM_PLANNED_DATE)+1 END),103) ELSE NULL END)  - NEED TO CONFIRM ON THE SITE TOLERANCE FOR UNDERWATER
							-- +frequency
						End 
						AS LAE_D_FRE_ST,
						Case when EX.EXAM_TYPE_SR_KEY=@ve_exam_type_id then CASE WHEN CMP.COMP_DATE IS NOT NULL THEN DATEADD(WEEK, (SELECT ct_site_tolerance_weeks+ct_review_tolerance_weeks FROM #tbl_ComplianceTolerance_sub WHERE ct_exam_type_id=@ve_exam_type_id AND ISNULL(((CASE WHEN CMP.INTERVAL_DAYS IS NULL THEN 0 ELSE (CMP.INTERVAL_DAYS/30)END) +ISNULL(CMP.INTERVAL_MONTHS,0)+(ISNULL(CMP.INTERVAL_YEARS,0)*12)),0) BETWEEN ct_interval_months_from AND ct_interval_months_to), CMP.COMP_DATE)  ELSE NULL END 
							 when EX.EXAM_TYPE_SR_KEY=@dtl_exam_typ_id then CASE WHEN CMP.COMP_DATE IS NOT NULL THEN DATEADD(WEEK, (SELECT ct_site_tolerance_weeks+ct_review_tolerance_weeks FROM #tbl_ComplianceTolerance_sub WHERE ct_exam_type_id=@dtl_exam_typ_id AND ISNULL(((CASE WHEN CMP.INTERVAL_DAYS IS NULL THEN 0 ELSE (CMP.INTERVAL_DAYS/30)END) +ISNULL(CMP.INTERVAL_MONTHS,0)+(ISNULL(CMP.INTERVAL_YEARS,0)*12)),0) BETWEEN ct_interval_months_from AND ct_interval_months_to), CMP.COMP_DATE)  ELSE NULL END 
							 --when EX.EXAM_TYPE_SR_KEY=@uw_exam_type_id then CASE WHEN EX.EXAM_PLANNED_DATE IS NOT NULL THEN DATEADD(WEEK, (SELECT ct_review_tolerance_weeks FROM #tbl_ComplianceTolerance_sub WHERE ct_exam_type_id=@uw_exam_type_id AND ISNULL(((CASE WHEN CMP.INTERVAL_DAYS IS NULL THEN 0 ELSE (CMP.INTERVAL_DAYS/30)END) +ISNULL(CMP.INTERVAL_MONTHS,0)+(ISNULL(CMP.INTERVAL_YEARS,0)*12)),0) BETWEEN ct_interval_months_from AND ct_interval_months_to), CONVERT(DATE,CONCAT('31-03-',CASE WHEN (MONTH(EX.EXAM_PLANNED_DATE)) <= 3 THEN YEAR(EX.EXAM_PLANNED_DATE) ELSE YEAR(EX.EXAM_PLANNED_DATE)+1 END),103) ) ELSE NULL END
							 when EX.EXAM_TYPE_SR_KEY=@uw_exam_type_id then CASE WHEN CMP.COMP_DATE IS NOT NULL THEN DATEADD(WEEK, (SELECT ct_review_tolerance_weeks FROM #tbl_ComplianceTolerance_sub WHERE ct_exam_type_id=@uw_exam_type_id AND ISNULL(((CASE WHEN CMP.INTERVAL_DAYS IS NULL THEN 0 ELSE (CMP.INTERVAL_DAYS/30)END) +ISNULL(CMP.INTERVAL_MONTHS,0)+(ISNULL(CMP.INTERVAL_YEARS,0)*12)),0) BETWEEN ct_interval_months_from AND ct_interval_months_to), CONVERT(DATE,CONCAT('31-03-',CASE WHEN (MONTH(CMP.COMP_DATE)) <= 3 THEN YEAR(CMP.COMP_DATE) ELSE YEAR(CMP.COMP_DATE)+1 END),103) ) ELSE NULL END
						End 						
						--CASE WHEN EX.EXAM_PLANNED_DATE IS NOT NULL THEN DATEADD(WEEK, (SELECT ct_review_tolerance_weeks FROM #tbl_ComplianceTolerance_sub WHERE ct_exam_type_id=EX.EXAM_TYPE_SR_KEY AND ISNULL(((CASE WHEN CMP.INTERVAL_DAYS IS NULL THEN 0 ELSE (CMP.INTERVAL_DAYS/30)END) +ISNULL(CMP.INTERVAL_MONTHS,0)+(ISNULL(CMP.INTERVAL_YEARS,0)*12)),0) BETWEEN ct_interval_months_from AND ct_interval_months_to), CONVERT(DATE,CONCAT('31-03-',CASE WHEN (MONTH(EX.EXAM_PLANNED_DATE)) <= 3 THEN YEAR(EX.EXAM_PLANNED_DATE) ELSE YEAR(EX.EXAM_PLANNED_DATE)+1 END),103) ) ELSE NULL END
						AS CMP_D_ST_RT, -- 31st Mar + review tolerance
						
						RA.ASSESSMENT_DATE AS RA_ASSESSMENT_DATE,RA.REVIEW_DATE AS RA_REVIEW_DATE,
						RA.EXPIRY_DATE AS RA_EXPIRY_DATE,RA.RISK_SCORE AS RA_RISK_SCORE,RA.RISK_ASSESS_STATUS AS RA_RISK_ASSESS_STATUS,RA.MITIGATION_DATE AS RA_MITIGATION_DATE
						,S.SUPPLIER_NAME AS SUPPLIER
						FROM 
						 #ast_guid_tbl ast
						INNER JOIN CES.EXAM EX ON EX.ASSET_GUID=ast.asset_guid AND UPPER(EX.IS_LAST_EXAM)='Y' AND EX.ISACTIVE=1
						--INNER JOIN CES.COMPLIANCE CMP ON CMP.ASSET_GUID=ast.asset_guid AND CMP.EXAM_TYPE_SR_KEY=EX.EXAM_TYPE_SR_KEY AND CMP.ISACTIVE=1 AND @reference_date BETWEEN CMP.EFFECTIVE_FROM_DT AND ISNULL(CMP.EFFECTIVE_TO_DT,CONVERT(DATE,'31/12/9999',103)) 
						OUTER APPLY
							(
								SELECT
									tmp1.COMP_DATE,
									tmp1.INTERVAL_DAYS,
									tmp1.INTERVAL_MONTHS,
									tmp1.INTERVAL_YEARS
								FROM 
								(
									SELECT 
										--CONVERT(VARCHAR,CMP.LAST_EXAM_DATE,103) last_dtl_exam,			
										CM.COMP_DATE as COMP_DATE,
										CM.INTERVAL_DAYS,
										CM.INTERVAL_MONTHS,
										CM.INTERVAL_YEARS,
										ROW_NUMBER() OVER (PARTITION BY CM.ASSET_GUID ,CM.EXAM_TYPE_SR_KEY  ORDER BY CM.EFFECTIVE_FROM_DT DESC) Crnk
									FROM [CES].COMPLIANCE CM
									WHERE CM.ASSET_GUID = ast.ASSET_GUID and EX.EXAM_TYPE_SR_KEY=CM.EXAM_TYPE_SR_KEY					
									AND CM.ISACTIVE = 1
									AND @reference_date BETWEEN CM.EFFECTIVE_FROM_DT AND ISNULL(CM.EFFECTIVE_TO_DT,'12/31/9999')
								)tmp1
								WHERE tmp1.Crnk=1
							)CMP
						--OUTER APPLY
						--	(
						--		SELECT
						--			tmp.INTERVAL_DAYS AS INTERVAL_DAYS,
						--			tmp.INTERVAL_MONTHS AS INTERVAL_MONTHS,
						--			tmp.INTERVAL_YEARS AS INTERVAL_YEARS
						--		FROM 
						--		(
						--			SELECT 
						--				ISNULL(exc.INTERVAL_DAYS,0) AS INTERVAL_DAYS,
						--				ISNULL(exc.INTERVAL_MONTHS,0) AS INTERVAL_MONTHS,
						--				ISNULL(exc.INTERVAL_YEARS,0) AS INTERVAL_YEARS,
						--				ROW_NUMBER() OVER (PARTITION BY exc.ASSET_GUID ,exc.EXAM_TYPE_SR_KEY  ORDER BY exc.EFFECTIVE_FROM_DT DESC) Ernk
						--			FROM [CES].EXAM_CYCLE exc
						--			WHERE exc.ASSET_GUID = ast.ASSET_GUID
						--			AND exc.EXAM_TYPE_SR_KEY = EX.EXAM_TYPE_SR_KEY
						--			AND exc.ISACTIVE = 1
						--			AND @reference_date BETWEEN exc.EFFECTIVE_FROM_DT AND ISNULL(exc.EFFECTIVE_TO_DT,'12/31/9999')
						--		)tmp
						--		WHERE tmp.Ernk=1
						--	)EC
						LEFT JOIN CES.RISK_ASSESSMENT RA ON RA.ASSET_GUID = ast.asset_guid AND RA.EXAM_TYPE_SR_KEY = EX.EXAM_TYPE_SR_KEY AND RA.ISACTIVE=1 AND UPPER(RA.ISLATEST)='Y' 
						-- ast inner join exam inner join comp left join ex_cy left join RA
						--where EX.EXAM_TYPE_SR_KEY=3
						LEFT JOIN CES.SUPPLIER S ON EX.SUPPLIER_SR_KEY = S.SUPPLIER_SR_KEY AND S.ISACTIVE = 1
						WHERE EX.EXAM_TYPE_SR_KEY IN (@dtl_exam_typ_id,@ve_exam_type_id,@uw_exam_type_id)

					) RS --WHERE Ernk = 1 AND Crnk = 1

				) RARS		
		)
		
	--select * from #tbl_ComplianceRiskStatus_sub	
	
	--to check the reporting data population procedure call
	IF (@Execution = 'Reporting')
	BEGIN
	SELECT 
			CR.cr_asset_guid AS asset_guid,
			MAX(CASE WHEN CR.cr_exam_type_id=@dtl_exam_typ_id THEN ISNULL(CR.cr_compliance_status,' ') END) AS dtl_compliance,
			MAX(CASE WHEN CR.cr_exam_type_id=@dtl_exam_typ_id THEN ISNULL(CR.cr_risk_status,' ') END) AS dtl_risk_status,
			MAX(CASE WHEN CR.cr_exam_type_id=@dtl_exam_typ_id THEN ISNULL(CR.cr_freq,' ') END) AS dtl_frequency,
			@dtl_exam_typ_id AS dtl_exam_type_id,
			MAX(CASE WHEN CR.cr_exam_type_id=@dtl_exam_typ_id THEN CR.cr_comp_date END) AS dtl_compliance_date,
			MAX(CASE WHEN CR.cr_exam_type_id=@dtl_exam_typ_id THEN CR.cr_comp_st_rt_date END) AS dtl_compliance_st_rt_date,
			MAX(CASE WHEN CR.cr_exam_type_id=@dtl_exam_typ_id THEN CR.cr_comp_st_date END) AS dtl_compliance_st_date,

			MAX(CASE WHEN CR.cr_exam_type_id=@dtl_exam_typ_id THEN CR.cr_exam_planned_date END) AS dtl_planned_date,
			MAX(CASE WHEN CR.cr_exam_type_id=@dtl_exam_typ_id THEN CR.cr_exam_actual_date END) AS dtl_latest_actual_ex_date,
			MAX(CASE WHEN CR.cr_exam_type_id=@dtl_exam_typ_id THEN ISNULL(CR.cr_supplier,' ') END) AS dtl_supplier,
			
			MAX(CASE WHEN CR.cr_exam_type_id=@ve_exam_type_id THEN ISNULL(CR.cr_compliance_status,' ') END) AS ve_compliance,
			MAX(CASE WHEN CR.cr_exam_type_id=@ve_exam_type_id THEN ISNULL(CR.cr_risk_status,' ') END) AS ve_risk_status,
			MAX(CASE WHEN CR.cr_exam_type_id=@ve_exam_type_id THEN ISNULL(CR.cr_freq,' ') END) AS ve_frequency,
			@ve_exam_type_id AS ve_exam_type_id,
			MAX(CASE WHEN CR.cr_exam_type_id=@ve_exam_type_id THEN CR.cr_comp_date END) AS ve_compliance_date,
			MAX(CASE WHEN CR.cr_exam_type_id=@ve_exam_type_id THEN CR.cr_comp_st_rt_date END) AS ve_compliance_st_rt_date,
			MAX(CASE WHEN CR.cr_exam_type_id=@ve_exam_type_id THEN CR.cr_comp_st_date END) AS ve_compliance_st_date,
			MAX(CASE WHEN CR.cr_exam_type_id=@ve_exam_type_id THEN CR.cr_exam_planned_date END) AS ve_planned_date,
			MAX(CASE WHEN CR.cr_exam_type_id=@ve_exam_type_id THEN CR.cr_exam_actual_date END) AS ve_latest_actual_ex_date,
			MAX(CASE WHEN CR.cr_exam_type_id=@ve_exam_type_id THEN ISNULL(CR.cr_supplier,' ') END) AS ve_supplier,
			
			MAX(CASE WHEN CR.cr_exam_type_id=@uw_exam_type_id THEN ISNULL(CR.cr_compliance_status,' ') END) AS uw_compliance,
			MAX(CASE WHEN CR.cr_exam_type_id=@uw_exam_type_id THEN ISNULL(CR.cr_risk_status,' ') END) AS uw_risk_status,
			MAX(CASE WHEN CR.cr_exam_type_id=@uw_exam_type_id THEN ISNULL(CR.cr_freq,' ') END) AS uw_frequency,
			@uw_exam_type_id AS uw_exam_type_id,
			MAX(CASE WHEN CR.cr_exam_type_id=@uw_exam_type_id THEN CR.cr_comp_date END) AS uw_compliance_date,
			MAX(CASE WHEN CR.cr_exam_type_id=@uw_exam_type_id THEN CR.cr_comp_st_rt_date END) AS uw_compliance_st_rt_date,
			MAX(CASE WHEN CR.cr_exam_type_id=@uw_exam_type_id THEN CR.cr_comp_st_date END) AS uw_compliance_st_date,
			MAX(CASE WHEN CR.cr_exam_type_id=@uw_exam_type_id THEN CR.cr_exam_planned_date END) AS uw_planned_date,
			MAX(CASE WHEN CR.cr_exam_type_id=@uw_exam_type_id THEN CR.cr_exam_actual_date END) AS uw_latest_actual_ex_date,
			MAX(CASE WHEN CR.cr_exam_type_id=@uw_exam_type_id THEN ISNULL(CR.cr_supplier,' ') END) AS uw_supplier
			

		FROM #tbl_ComplianceRiskStatus_sub CR
		GROUP BY
			CR.cr_asset_guid

	END
	ELSE IF (@Execution = 'ComplianceSearch') -- to send Compliance search results SP
	BEGIN

		SELECT 
			CR.cr_asset_guid AS asset_guid,
			MAX(CASE WHEN CR.cr_exam_type_id=@dtl_exam_typ_id THEN ISNULL(CR.cr_compliance_status,' ') END) AS dtl_compliance,
			MAX(CASE WHEN CR.cr_exam_type_id=@dtl_exam_typ_id THEN ISNULL(CR.cr_risk_status,' ') END) AS dtl_risk_status,
			MAX(CASE WHEN CR.cr_exam_type_id=@dtl_exam_typ_id THEN ISNULL(CR.cr_freq,' ') END) AS dtl_frequency,
			@dtl_exam_typ_id AS dtl_exam_type_id,
			MAX(CASE WHEN CR.cr_exam_type_id=@dtl_exam_typ_id THEN CR.cr_comp_date END) AS dtl_compliance_date,
			MAX(CASE WHEN CR.cr_exam_type_id=@dtl_exam_typ_id THEN CR.cr_exam_planned_date END) AS dtl_planned_date,
			MAX(CASE WHEN CR.cr_exam_type_id=@dtl_exam_typ_id THEN CR.cr_exam_actual_date END) AS dtl_latest_actual_ex_date,
			MAX(CASE WHEN CR.cr_exam_type_id=@dtl_exam_typ_id THEN ISNULL(CR.cr_supplier,' ') END) AS dtl_supplier,
			MAX(CASE WHEN CR.cr_exam_type_id=@dtl_exam_typ_id THEN CR.ra_mitigation_date END) AS dtl_mitigation_date,
			
			MAX(CASE WHEN CR.cr_exam_type_id=@ve_exam_type_id THEN ISNULL(CR.cr_compliance_status,' ') END) AS ve_compliance,
			MAX(CASE WHEN CR.cr_exam_type_id=@ve_exam_type_id THEN ISNULL(CR.cr_risk_status,' ') END) AS ve_risk_status,
			MAX(CASE WHEN CR.cr_exam_type_id=@ve_exam_type_id THEN ISNULL(CR.cr_freq,' ') END) AS ve_frequency,
			@ve_exam_type_id AS ve_exam_type_id,
			MAX(CASE WHEN CR.cr_exam_type_id=@ve_exam_type_id THEN CR.cr_comp_date END) AS ve_compliance_date,
			MAX(CASE WHEN CR.cr_exam_type_id=@ve_exam_type_id THEN CR.cr_exam_planned_date END) AS ve_planned_date,
			MAX(CASE WHEN CR.cr_exam_type_id=@ve_exam_type_id THEN CR.cr_exam_actual_date END) AS ve_latest_actual_ex_date,
			MAX(CASE WHEN CR.cr_exam_type_id=@ve_exam_type_id THEN ISNULL(CR.cr_supplier,' ') END) AS ve_supplier,
			MAX(CASE WHEN CR.cr_exam_type_id=@ve_exam_type_id THEN CR.ra_mitigation_date END) AS ve_mitigation_date,
			
			MAX(CASE WHEN CR.cr_exam_type_id=@uw_exam_type_id THEN ISNULL(CR.cr_compliance_status,' ') END) AS uw_compliance,
			MAX(CASE WHEN CR.cr_exam_type_id=@uw_exam_type_id THEN ISNULL(CR.cr_risk_status,' ') END) AS uw_risk_status,
			MAX(CASE WHEN CR.cr_exam_type_id=@uw_exam_type_id THEN ISNULL(CR.cr_freq,' ') END) AS uw_frequency,
			@uw_exam_type_id AS uw_exam_type_id,
			MAX(CASE WHEN CR.cr_exam_type_id=@uw_exam_type_id THEN CR.cr_comp_date END) AS uw_compliance_date,
			MAX(CASE WHEN CR.cr_exam_type_id=@uw_exam_type_id THEN CR.cr_exam_planned_date END) AS uw_planned_date,
			MAX(CASE WHEN CR.cr_exam_type_id=@uw_exam_type_id THEN CR.cr_exam_actual_date END) AS uw_latest_actual_ex_date,
			MAX(CASE WHEN CR.cr_exam_type_id=@uw_exam_type_id THEN ISNULL(CR.cr_supplier,' ') END) AS uw_supplier,
			MAX(CASE WHEN CR.cr_exam_type_id=@uw_exam_type_id THEN CR.ra_mitigation_date END) AS uw_mitigation_date
			

		FROM #tbl_ComplianceRiskStatus_sub CR
		GROUP BY
			CR.cr_asset_guid
	END
	ELSE
	BEGIN

		SELECT 
			CR.cr_asset_guid AS asset_guid,
			MAX(CASE WHEN CR.cr_exam_type_id=@dtl_exam_typ_id THEN ISNULL(CR.cr_compliance_status,' ') END) AS dtl_compliance,
			MAX(CASE WHEN CR.cr_exam_type_id=@dtl_exam_typ_id THEN ISNULL(CR.cr_risk_status,' ') END) AS dtl_risk_status,
			MAX(CASE WHEN CR.cr_exam_type_id=@dtl_exam_typ_id THEN ISNULL(CR.cr_freq,' ') END) AS dtl_frequency,
			@dtl_exam_typ_id AS dtl_exam_type_id,
			MAX(CASE WHEN CR.cr_exam_type_id=@dtl_exam_typ_id THEN CR.cr_comp_date END) AS dtl_compliance_date,
			MAX(CASE WHEN CR.cr_exam_type_id=@dtl_exam_typ_id THEN CR.cr_exam_planned_date END) AS dtl_planned_date,
			MAX(CASE WHEN CR.cr_exam_type_id=@dtl_exam_typ_id THEN CR.cr_exam_actual_date END) AS dtl_latest_actual_ex_date,
			MAX(CASE WHEN CR.cr_exam_type_id=@dtl_exam_typ_id THEN ISNULL(CR.cr_supplier,' ') END) AS dtl_supplier,
			
			MAX(CASE WHEN CR.cr_exam_type_id=@ve_exam_type_id THEN ISNULL(CR.cr_compliance_status,' ') END) AS ve_compliance,
			MAX(CASE WHEN CR.cr_exam_type_id=@ve_exam_type_id THEN ISNULL(CR.cr_risk_status,' ') END) AS ve_risk_status,
			MAX(CASE WHEN CR.cr_exam_type_id=@ve_exam_type_id THEN ISNULL(CR.cr_freq,' ') END) AS ve_frequency,
			@ve_exam_type_id AS ve_exam_type_id,
			MAX(CASE WHEN CR.cr_exam_type_id=@ve_exam_type_id THEN CR.cr_comp_date END) AS ve_compliance_date,
			MAX(CASE WHEN CR.cr_exam_type_id=@ve_exam_type_id THEN CR.cr_exam_planned_date END) AS ve_planned_date,
			MAX(CASE WHEN CR.cr_exam_type_id=@ve_exam_type_id THEN CR.cr_exam_actual_date END) AS ve_latest_actual_ex_date,
			MAX(CASE WHEN CR.cr_exam_type_id=@ve_exam_type_id THEN ISNULL(CR.cr_supplier,' ') END) AS ve_supplier,
			
			MAX(CASE WHEN CR.cr_exam_type_id=@uw_exam_type_id THEN ISNULL(CR.cr_compliance_status,' ') END) AS uw_compliance,
			MAX(CASE WHEN CR.cr_exam_type_id=@uw_exam_type_id THEN ISNULL(CR.cr_risk_status,' ') END) AS uw_risk_status,
			MAX(CASE WHEN CR.cr_exam_type_id=@uw_exam_type_id THEN ISNULL(CR.cr_freq,' ') END) AS uw_frequency,
			@uw_exam_type_id AS uw_exam_type_id,
			MAX(CASE WHEN CR.cr_exam_type_id=@uw_exam_type_id THEN CR.cr_comp_date END) AS uw_compliance_date,
			MAX(CASE WHEN CR.cr_exam_type_id=@uw_exam_type_id THEN CR.cr_exam_planned_date END) AS uw_planned_date,
			MAX(CASE WHEN CR.cr_exam_type_id=@uw_exam_type_id THEN CR.cr_exam_actual_date END) AS uw_latest_actual_ex_date,
			MAX(CASE WHEN CR.cr_exam_type_id=@uw_exam_type_id THEN ISNULL(CR.cr_supplier,' ') END) AS uw_supplier
			

		FROM #tbl_ComplianceRiskStatus_sub CR
		GROUP BY
			CR.cr_asset_guid
	END
	END TRY
	BEGIN CATCH
	
		SET @ErrorMsg = ERROR_MESSAGE() + 
						' Line Num:' + CONVERT(VARCHAR(5), ERROR_LINE()) + 
						',ErrorNum:' + CONVERT(VARCHAR(5), ERROR_NUMBER()) + 
						',Severity:' + CONVERT(VARCHAR(5), ERROR_SEVERITY()) + 
						',State:' + CONVERT(VARCHAR(10), ERROR_STATE()) + 
						',Procedure:' + CONVERT(VARCHAR(25), ERROR_PROCEDURE());  
		
		DROP TABLE IF EXISTS #ast_guid_tbl;
		DROP TABLE IF EXISTS #tbl_ComplianceRiskStatus_sub;	
		DROP TABLE IF EXISTS #tbl_ComplianceTolerance_sub;
		THROW 50000,@ErrorMsg,1;

		
	END CATCH

	DROP TABLE IF EXISTS #ast_guid_tbl;
	DROP TABLE IF EXISTS #tbl_ComplianceRiskStatus_sub;	
	DROP TABLE IF EXISTS #tbl_ComplianceTolerance_sub;

	SET ANSI_WARNINGS ON
	SET NOCOUNT OFF
END