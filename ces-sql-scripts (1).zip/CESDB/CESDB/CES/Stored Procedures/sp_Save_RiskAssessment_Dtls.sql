﻿/***************************************************************************************************************************************            
* Name						: sp_Save_RiskAssessment_Dtls       
* Created By				: Cognizant            
* Date Created				: 10-Feb-2021           
* Description				: This stored procedure saves the Risk Assessment Details.  
* Input Parameters			: JSON, Supplier ID   
* Output Parameters			: Returns 1 for succesful save, else 0            
* Return Value				: N/A            
* Assumptions				: None    
* Execution Statement		: EXEC CES.sp_Save_RiskAssessment_Dtls '{
																		"asset_guid":"3978559C2FDC45D9E04400306E4AD01A",
																		"exam_type_id":3,
																		"assessment_date":"12/12/2020",
																		"review_date":"12/12/2020",
																		"expiry_date":"12/10/2021",
																		"risk_score":"low",
																		"mitigation_comment": "abcd",
																		"risk_user_key":"fdfdfdfdf",
																		"question_01":"q1",
																		"question_01_ans":"YES",
																		"question_01_cmt":"c1",
																		"question_02":"q2",
																		"question_02_ans":"YES",
																		"question_02_cmt":"c2",
																		"question_03":"q3",
																		"question_03_ans":"YES",
																		"question_03_cmt":"c3",
																		"question_04":"q4",
																		"question_04_ans":"YES",
																		"question_04_cmt":"c4",
																		"mitigation_action_01": "", 
																		"mitigation_action_01_selection": "",
																		"mitigation_action_02": "",
																		"mitigation_action_02_selection": "",
																		"mitigation_action_03": "",
																		"mitigation_action_03_selection": "", 
																		"mitigation_action_04": "",
																		"mitigation_action_04_selection": "", 
																		"mitigation_action_05": "",
																		"mitigation_action_05_selection": "", 
																		"mitigation_action_06": "",
																		"mitigation_action_06_selection": "", 
																		"mitigation_action_07": "", 
																		"mitigation_action_07_selection": "",
																		"mitigation_date": ""

																		
																	}'


*								
* Modified Date     Modified By   Revision Number  Modifications            

*******************************************************************************************************************************************/ 



CREATE PROCEDURE [CES].[sp_Save_RiskAssessment_Dtls]
	@Input_JSON		NVARCHAR(MAX)
	
AS 

BEGIN
	SET NOCOUNT ON
    BEGIN TRY
		DECLARE
				@ErrorMsg			VARCHAR(250),
				@ErrorDescription	VARCHAR(4000),
				@Output				BIT = 0
		
		CREATE TABLE #tmpRADtls
		(
			asset_guid							VARCHAR(32),
			exam_type_id						DECIMAL(18),
			assessment_date						DATE,
			review_date							DATE,
			[expiry_date]						DATE,
			risk_score							VARCHAR(10),
			mitigation_comment					VARCHAR(1000),
			risk_user_key						VARCHAR(64),
			question_01							VARCHAR(256),
			question_01_ans						VARCHAR(1),
			question_01_cmt						VARCHAR(1000),
			question_02							VARCHAR(256),
			question_02_ans						VARCHAR(1),
			question_02_cmt						VARCHAR(1000),
			question_03							VARCHAR(256),
			question_03_ans						VARCHAR(1),
			question_03_cmt						VARCHAR(1000),
			question_04							VARCHAR(256),
			question_04_ans						VARCHAR(1),
			question_04_cmt						VARCHAR(1000),
			mitigation_action_01				VARCHAR(100), 
			mitigation_action_01_selection		VARCHAR(1),
			mitigation_action_02				VARCHAR(100),
			mitigation_action_02_selection		VARCHAR(1),
			mitigation_action_03				VARCHAR(100),
			mitigation_action_03_selection		VARCHAR(1), 
			mitigation_action_04				VARCHAR(100),
			mitigation_action_04_selection		VARCHAR(1), 
			mitigation_action_05				VARCHAR(100),
			mitigation_action_05_selection		VARCHAR(1), 
			mitigation_action_06				VARCHAR(100),
			mitigation_action_06_selection		VARCHAR(1), 
			mitigation_action_07				VARCHAR(100), 
			mitigation_action_07_selection		VARCHAR(1),
			mitigation_date						DATE
		)

		INSERT INTO #tmpRADtls
		(
			asset_guid,
			exam_type_id,
			assessment_date,
			review_date,
			[expiry_date],
			risk_score,
			mitigation_comment,
			risk_user_key,
			question_01	,
			question_01_ans,
			question_01_cmt	,
			question_02,
			question_02_ans,
			question_02_cmt,
			question_03,
			question_03_ans,
			question_03_cmt,
			question_04,
			question_04_ans,
			question_04_cmt,
			mitigation_action_01, 
			mitigation_action_01_selection,
			mitigation_action_02,
			mitigation_action_02_selection,
			mitigation_action_03,
			mitigation_action_03_selection, 
			mitigation_action_04,
			mitigation_action_04_selection, 
			mitigation_action_05,
			mitigation_action_05_selection, 
			mitigation_action_06,
			mitigation_action_06_selection, 
			mitigation_action_07, 
			mitigation_action_07_selection,
			mitigation_date
		)
		SELECT
			asset_guid,
			exam_type_id,
			assessment_date,
			review_date,
			[expiry_date],
			risk_score,
			mitigation_comment,
			risk_user_key,
			question_01	,
			question_01_ans,
			question_01_cmt	,
			question_02,
			question_02_ans,
			question_02_cmt,
			question_03,
			question_03_ans,
			question_03_cmt,
			question_04,
			question_04_ans,
			question_04_cmt,
			mitigation_action_01, 
			mitigation_action_01_selection,
			mitigation_action_02,
			mitigation_action_02_selection,
			mitigation_action_03,
			mitigation_action_03_selection, 
			mitigation_action_04,
			mitigation_action_04_selection, 
			mitigation_action_05,
			mitigation_action_05_selection, 
			mitigation_action_06,
			mitigation_action_06_selection, 
			mitigation_action_07, 
			mitigation_action_07_selection,
			NULLIF(mitigation_date,'')
		FROM	OPENJSON(@Input_JSON)
		WITH (
				asset_guid							VARCHAR(32),
				exam_type_id						DECIMAL(18),
				assessment_date						DATE,
				review_date							DATE,
				[expiry_date]						DATE,
				risk_score							VARCHAR(10),
				mitigation_comment					VARCHAR(1000),
				risk_user_key						VARCHAR(64),
				question_01							VARCHAR(256),
				question_01_ans						VARCHAR(1),
				question_01_cmt						VARCHAR(1000),
				question_02							VARCHAR(256),
				question_02_ans						VARCHAR(1),
				question_02_cmt						VARCHAR(1000),
				question_03							VARCHAR(256),
				question_03_ans						VARCHAR(1),
				question_03_cmt						VARCHAR(1000),
				question_04							VARCHAR(256),
				question_04_ans						VARCHAR(1),
				question_04_cmt						VARCHAR(1000),
				mitigation_action_01				VARCHAR(100), 
				mitigation_action_01_selection		VARCHAR(1),
				mitigation_action_02				VARCHAR(100),
				mitigation_action_02_selection		VARCHAR(1),
				mitigation_action_03				VARCHAR(100),
				mitigation_action_03_selection		VARCHAR(1), 
				mitigation_action_04				VARCHAR(100),
				mitigation_action_04_selection		VARCHAR(1), 
				mitigation_action_05				VARCHAR(100),
				mitigation_action_05_selection		VARCHAR(1), 
				mitigation_action_06				VARCHAR(100),
				mitigation_action_06_selection		VARCHAR(1), 
				mitigation_action_07				VARCHAR(100), 
				mitigation_action_07_selection		VARCHAR(1),
				mitigation_date						DATE
			 )

		--- Validation Checks -- Start
				
		IF EXISTS (SELECT 1 FROM #tmpRADtls WHERE asset_guid IS NULL OR exam_type_id IS NULL OR assessment_date IS NULL OR review_date IS NULL
		 OR expiry_date IS NULL)

		BEGIN
			SET @ErrorMsg = 'Mandatory Input parameter value(s) is missing';
			THROW 50000,@ErrorMsg,1;
		END

		--- Validation Checks -- End  

		BEGIN TRAN
					UPDATE ra
					SET ISLATEST = 'N'
					FROM [CES].[RISK_ASSESSMENT] ra
					INNER JOIN #tmpRADtls t
					ON ra.ASSET_GUID = t.ASSET_GUID
					AND ra.EXAM_TYPE_SR_KEY = t.exam_type_id
					WHERE ISLATEST = 'Y'

					INSERT INTO [CES].[RISK_ASSESSMENT]
					(
					    ASSET_GUID,
						EXAM_TYPE_SR_KEY,
						ASSESSMENT_DATE,
						REVIEW_DATE,					
						[EXPIRY_DATE],
						RISK_SCORE,
						MITIGATION_COMMENT,
						RISK_USER,
						QUESTION_01,
						QUESTION_01_ANS,
						QUESTION_01_CMT,
						QUESTION_02,
						QUESTION_02_ANS,
						QUESTION_02_CMT,
						QUESTION_03,
						QUESTION_03_ANS,
						QUESTION_03_CMT,
						QUESTION_04,
						QUESTION_04_ANS,
						QUESTION_04_CMT,
						MITIGATION_ACTION_01,
						MITIGATION_ACTION_01_SELECTION,
						MITIGATION_ACTION_02,
						MITIGATION_ACTION_02_SELECTION,
						MITIGATION_ACTION_03,
						MITIGATION_ACTION_03_SELECTION,
						MITIGATION_ACTION_04,
						MITIGATION_ACTION_04_SELECTION,
						MITIGATION_ACTION_05,
						MITIGATION_ACTION_05_SELECTION,
						MITIGATION_ACTION_06,
						MITIGATION_ACTION_06_SELECTION,
						MITIGATION_ACTION_07,
						MITIGATION_ACTION_07_SELECTION,
						MITIGATION_DATE,
						ISLATEST,
						CREATED_USER,
						CREATED_DATE
					)
					SELECT
						asset_guid,
						exam_type_id,
						assessment_date,
						review_date,
						[expiry_date],
						risk_score,
						mitigation_comment,
						risk_user_key,
						question_01	,
						question_01_ans,
						question_01_cmt	,
						question_02,
						question_02_ans,
						question_02_cmt,
						question_03,
						question_03_ans,
						question_03_cmt,
						question_04,
						question_04_ans,
						question_04_cmt,
						mitigation_action_01,
						mitigation_action_01_selection,
						mitigation_action_02,
						mitigation_action_02_selection,
						mitigation_action_03,
						mitigation_action_03_selection,
						mitigation_action_04,
						mitigation_action_04_selection,
						mitigation_action_05,
						mitigation_action_05_selection,
						mitigation_action_06,
						mitigation_action_06_selection,
						mitigation_action_07,
						mitigation_action_07_selection,
						mitigation_date,
						'Y',
						risk_user_key,
						GETDATE()
					FROM	#tmpRADtls
		COMMIT TRAN

		SET @Output = 1
		DROP TABLE IF EXISTS #tmpRADtls;

		SELECT @Output AS SaveStatus,NULL AS ErrorMsg;
	END TRY

	BEGIN CATCH
		IF (@@TRANCOUNT >0)
			ROLLBACK TRAN
		
		IF @ErrorMsg IS NULL
			SET @ErrorMsg = ERROR_MESSAGE() 
		
		SET @ErrorDescription = @ErrorMsg + 
							' Line Num:' + CONVERT(VARCHAR(5), ERROR_LINE()) + 
							',ErrorNum:' + CONVERT(VARCHAR(5), ERROR_NUMBER()) + 
							',Severity:' + CONVERT(VARCHAR(5), ERROR_SEVERITY()) + 
							',State:' + CONVERT(VARCHAR(10), ERROR_STATE()) + 
							',Procedure:' + CONVERT(VARCHAR(25), OBJECT_NAME(@@procid)) +
							',Procedure:' + CONVERT(VARCHAR(25), ERROR_PROCEDURE())

		SET @Output = 0;
		DROP TABLE IF EXISTS #tmpRADtls;
		SELECT @Output AS SaveStatus,@ErrorMsg AS ErrorMsg;

		THROW 50000,@ErrorDescription,1;
	END CATCH

	SET NOCOUNT OFF
  END