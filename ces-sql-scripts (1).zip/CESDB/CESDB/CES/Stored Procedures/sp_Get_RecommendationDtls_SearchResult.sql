﻿
/***************************************************************************************************************************************            
* Name						: sp_Get_RecommendationDtls_SearchResult          
* Created By				: Cognizant            
* Date Created				: 13-Jan-2021           
* Description				: This stored procedure provides the search result for Recommendations details screen.  
* Input Parameters			: Asset_GUID      
* Output Parameters			: N/A            
* Return Value				: N/A            
* Assumptions				: None    
* Execution Statement		: Exec [CES].sp_Get_RecommendationDtls_SearchResult '3978559E7C1845D9E04400306E4AD01A',45160;
*								
* Modified Date     Modified By   Revision Number  Modifications            

*******************************************************************************************************************************************/ 



CREATE PROCEDURE [CES].[sp_Get_RecommendationDtls_SearchResult]
	@Asset_GUID		VARCHAR(32),
	@Exam_Key        VARCHAR(18) = NULL   -- Optional parameter, required mainly for Recommendation popup from Exam ID of Defect Details screen

AS
BEGIN
	SET NOCOUNT ON
	BEGIN TRY
		DECLARE
				@ErrorMsg				VARCHAR(250),
				@result					NVARCHAR(MAX),
				@totalresultcnt			SMALLINT

		CREATE TABLE #tbl_SearchResult
		(
			exam_actual_date	DATE,
			exam_type			VARCHAR(32),
			exam_id				DECIMAL(18),
			highest_risk_score	VARCHAR(5),
			[description]		VARCHAR(1000),
			[location]			VARCHAR(128),
			work_category		VARCHAR(64),
			quantity_units		VARCHAR(45),
			risk_score			VARCHAR(5),
			rcmn_status			VARCHAR(64),
			action_change		VARCHAR(3),
			rcmn_key			DECIMAL(18)

		)

		--Recommendation popup screen from Defect Details page
		IF (@Exam_Key IS NOT NULL)
		BEGIN

				INSERT INTO #tbl_SearchResult
				(
					exam_actual_date,
					exam_type,
					exam_id,
					highest_risk_score,
					[description],
					[location],
					work_category,
					quantity_units,
					risk_score,
					rcmn_status,
					action_change,
					rcmn_key
				)
				SELECT
					ex.EXAM_Actual_Date,
					et.EXAM_TYPE,
					ex.EXAM_ID,
					MAX(CONVERT(SMALLINT,r.RISK_SCORE)) OVER (PARTITION BY ex.EXAM_ID) AS Highest_risk_score,
					r.[DESCRIPTION] AS description,
					r.[LOCATION] AS location,
					wc.REF_VALUE AS work_category,
					(CAST(r.QUANTITY AS VARCHAR(18)) + ' '+ r.QUANTITY_UNIT) AS quantity_units,
					r.RISK_SCORE AS risk_score,
					rs.REF_VALUE AS [status],
					(
						SELECT
							CASE WHEN
								ac.DESCRIPTION = r.DESCRIPTION AND
								ac.LOCATION = r.LOCATION AND
								ac.RISK_SCORE = r.RISK_SCORE THEN 'No'
							ELSE 'Yes'
						END
						FROM CES.ACTION ac
						WHERE ac.RECOMMEND_SR_KEY = r.RECOMMEND_SR_KEY
						AND ac.ISACTIVE = 1
					)action_change,
					r.RECOMMEND_SR_KEY AS rcmn_key

				FROM [CES].EXAM  ex
				INNER JOIN [CES].RECOMMENDATION  r
				on r.exam_sr_key=ex.exam_sr_key
				INNER JOIN CES.EXAM_TYPE et
				ON et.EXAM_TYPE_SR_KEY = ex.EXAM_TYPE_SR_KEY
				LEFT JOIN CES.REFERENCE_VALUE wc
				ON wc.REF_VAL_SR_KEY = r.WORK_CATEGORY
				LEFT JOIN CES.REFERENCE_VALUE rs
				ON rs.REF_VAL_SR_KEY = r.RCMN_STATUS

				WHERE ex.EXAM_SR_KEY = @Exam_Key
				AND	ex.ISACTIVE = 1
				AND	r.ISACTIVE = 1

		END

		--Recommendation screen screen from Asset Details page
		ELSE
		BEGIN

				INSERT INTO #tbl_SearchResult
				(
					exam_actual_date,
					exam_type,
					exam_id,
					highest_risk_score,
					[description],
					[location],
					work_category,
					quantity_units,
					risk_score,
					rcmn_status,
					action_change,
					rcmn_key
				)
				SELECT
					ex.EXAM_Actual_Date,
					et.EXAM_TYPE,
					ex.EXAM_ID,
					MAX(CONVERT(SMALLINT,r.RISK_SCORE)) OVER (PARTITION BY ex.EXAM_ID) AS Highest_risk_score,
					r.[DESCRIPTION] AS description,
					r.[LOCATION] AS location,
					wc.REF_VALUE AS work_category,
					(CAST(r.QUANTITY AS VARCHAR(18)) + ' '+ r.QUANTITY_UNIT) AS quantity_units,
					r.RISK_SCORE AS risk_score,
					rs.REF_VALUE AS [status],
					(
						SELECT
							CASE WHEN
								ac.DESCRIPTION = r.DESCRIPTION AND
								ac.LOCATION = r.LOCATION AND
								ac.RISK_SCORE = r.RISK_SCORE THEN 'No'
							ELSE 'Yes'
						END
						FROM CES.ACTION ac
						WHERE ac.RECOMMEND_SR_KEY = r.RECOMMEND_SR_KEY
						AND ac.ISACTIVE = 1
					)action_change,
					r.RECOMMEND_SR_KEY AS rcmn_key

				FROM [CES].EXAM  ex
				INNER JOIN [CES].RECOMMENDATION  r
				on r.exam_sr_key=ex.exam_sr_key
				INNER JOIN CES.EXAM_TYPE et
				ON et.EXAM_TYPE_SR_KEY = ex.EXAM_TYPE_SR_KEY
				LEFT JOIN CES.REFERENCE_VALUE wc
				ON wc.REF_VAL_SR_KEY = r.WORK_CATEGORY
				LEFT JOIN CES.REFERENCE_VALUE rs
				ON rs.REF_VAL_SR_KEY = r.RCMN_STATUS

				WHERE ex.ASSET_GUID = @Asset_GUID
				AND	ex.ISACTIVE = 1
				AND	r.ISACTIVE = 1
				
		END

		--For Recommendation popup screen from Defect Details page, count will be no of recommendations returned for that exam
		IF (@Exam_Key IS NOT NULL)
			SELECT @totalresultcnt = COUNT(1) FROM #tbl_SearchResult

		--For Recommendation screen from Asset Details page, count will be no of exams returned for the asset which have recommendations
		ELSE
			SELECT @totalresultcnt = COUNT(DISTINCT EXAM_ID) FROM #tbl_SearchResult

		--If no records are returned in search result
		IF  @totalresultcnt=0 
		BEGIN
			SET @result=
					(
						SELECT 
							JSON_QUERY(
										(
											select
												@totalresultcnt AS totalcount
											FOR JSON PATH,WITHOUT_ARRAY_WRAPPER
										)
							) searchdatacount,
							JSON_QUERY('[]') searchresult
						
						FOR JSON PATH,WITHOUT_ARRAY_WRAPPER, INCLUDE_NULL_VALUES
				)
		END	
		--If alt least 1 record is returned in search result
		ELSE
		BEGIN
				
				SET @result=
				(
					SELECT 
						JSON_QUERY(
									(
										select
											@totalresultcnt AS totalcount
										FOR JSON PATH,WITHOUT_ARRAY_WRAPPER
									)
							) searchdatacount,
							(
								SELECT
									elr.ELR_CODE AS elr,
									ast.railway_id,
									asg.asset_group_desc AS asset_grp,
									astp.asset_type_desc AS asset_type
								FROM [CES].ASSET  ast
								INNER JOIN [CES].ASSET_GROUP asg
								ON	ast.ASSET_GROUP_SR_KEY = asg.ASSET_GROUP_SR_KEY
								INNER JOIN [CES].ASSET_TYPE astp
								ON  ast.ASSET_TYPE_SR_KEY = astp.ASSET_TYPE_SR_KEY
								INNER JOIN [CES].ENGINE_LINE_REF elr
								ON elr.ELR_SR_KEY = ast.eng_line_ref
								WHERE 
									ast.ASSET_GUID = @Asset_GUID
									AND ast.ISACTIVE = 1
									AND asg.ISACTIVE = 1
									AND astp.ISACTIVE = 1
									AND elr.ISACTIVE = 1
								FOR JSON PATH, INCLUDE_NULL_VALUES
							  )assetdtls,

							  (
									SELECT
										exam_id,
										exam_actual_date,
										exam_type,
										highest_risk_score,
										details = (			SELECT
																[description] AS rcmn_desc,
																[location],
																work_category,
																quantity_units,
																risk_score,
																rcmn_status AS [status],
																action_change,
																rcmn_key

															FROM #tbl_SearchResult t
															WHERE t.exam_id = sr.exam_id
															order by rcmn_key desc
															FOR JSON PATH, INCLUDE_NULL_VALUES)
									FROM #tbl_SearchResult sr
									GROUP BY exam_id, exam_actual_date, exam_type, highest_risk_score
									FOR JSON PATH, INCLUDE_NULL_VALUES
							  )searchresult
							FOR JSON PATH, INCLUDE_NULL_VALUES, WITHOUT_ARRAY_WRAPPER

					)
		END


		--PRINT @result
		SELECT @result
	END TRY
	BEGIN CATCH
		SET @ErrorMsg = ERROR_MESSAGE() + 
						' Line Num:' + CONVERT(VARCHAR(5), ERROR_LINE()) + 
						',ErrorNum:' + CONVERT(VARCHAR(5), ERROR_NUMBER()) + 
						',Severity:' + CONVERT(VARCHAR(5), ERROR_SEVERITY()) + 
						',State:' + CONVERT(VARCHAR(10), ERROR_STATE()) + 
						',Procedure:' + CONVERT(VARCHAR(25), OBJECT_NAME(@@procid)) +
						',Procedure:' + CONVERT(VARCHAR(25), ERROR_PROCEDURE());  

		THROW 50000,@ErrorMsg,1;

		
	END CATCH

	DROP TABLE IF EXISTS #tbl_SearchResult;
	SET NOCOUNT OFF
END
