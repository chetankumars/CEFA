﻿/****** Object:  StoredProcedure [CES].[sp_Get_Structures_Report]    Script Date: 6/15/2021 5:51:33 AM ******/
--SET ANSI_NULLS ON
--GO
--SET QUOTED_IDENTIFIER ON
--GO

/***************************************************************************************************************************************            
* Name						: sp_Get_Structures_Report           
* Created By				: Cognizant            
* Date Created				: 09-Apr-2021           
* Description				: This stored procedure is to get the structure report data from CES DB based on non compliance exams count for Detailed, Visual, and Under water exams.   
* Input Parameters			: N/A      
* Output Parameters			: N/A            
* Return Value				: N/A            
* Assumptions				: None    
* Execution Statement		: EXEC [CES].[sp_Get_Structures_Report]	'{	
																		"route_id": 0,
																		"period_id": 0
																	}'
*								
* Modified Date     Modified By   Revision Number  Modifications            

*******************************************************************************************************************************************/ 



CREATE PROCEDURE [CES].[sp_Get_Structures_Report] 
    @Input_JSON	NVARCHAR(MAX)
AS 


BEGIN
	SET NOCOUNT ON
    BEGIN TRY
		-- declare variables
		DECLARE
			@ErrorMsg		VARCHAR(250),
			@result			VARCHAR(MAX),
			@route_id		DECIMAL(18),
			@period_id		DECIMAL(18),
			@period_key		DECIMAL(18, 0),
			@year_id		DECIMAL(18, 0),
			@year			VARCHAR(30),
			@DATE			DATETIME = GETDATE(),
			@current_date	DATETIME = GETDATE(),
			@current_year	VARCHAR(30),
			@Report1_Title			VARCHAR(20) = 'StructuresReport',
			@year_start_dt			DATE,
			@start_dt_default		DATE  = CONVERT(DATE,'1/1/1900',103),
			@is_history_year	CHAR(1) = 'N'

			--retrieve input values from input Json 
			SELECT 
			@route_id = COALESCE(@route_id,CASE LOWER([key]) WHEN 'route_id' THEN [value] ELSE NULL END),
			@period_id = COALESCE(@period_id,CASE LOWER([key]) WHEN 'period_id' THEN [value] ELSE NULL END)
			FROM OPENJSON(@Input_JSON);		
			
			--Temporary table drop if exists
			DROP TABLE IF EXISTS #SR_KPI;
			
			CREATE TABLE #SR_KPI 
			(
				kpi					VARCHAR(64),
				kpi_key				DECIMAL(18),
				report_section_key	DECIMAL(18)
			)

			--get period key and current year
			SET @current_year = CASE WHEN MONTH(@current_date)<=3 THEN CONCAT(YEAR(@current_date)-1,'/',YEAR(@current_date)) ELSE CONCAT(YEAR(@current_date),'/',YEAR(@current_date)+1) END
			SELECT @year_start_dt = CASE WHEN MONTH(@current_date)<=3 THEN Convert(DATETIME, CONCAT(YEAR(@current_date)-1,'/04','/01')) ELSE Convert(DATETIME, CONCAT(YEAR(@current_date),'/04','/01')) END
			SELECT  @period_key = [PERIOD_SR_KEY] FROM CES.[PERIOD] WHERE ISACTIVE=1 AND (( DATEDIFF(DAY, @year_start_dt, @current_date))+1 BETWEEN PERIOD_DAYS_FROM AND PERIOD_DAYS_TO )
			
			--Validation steps and setting default values for parameters if it is empty or null, this is to get national level current period results
			IF @period_id IS NULL
				SET @period_id = @period_key
			ELSE IF (@period_id IS NOT NULL)
				IF (@period_id >0)
					BEGIN
						IF NOT EXISTS (SELECT 1 FROM CES.[PERIOD] WHERE PERIOD_SR_KEY=@period_id AND ISACTIVE=1)
						BEGIN
							SET @ErrorMsg = 'Invalid period provided';
							--Temporary table drop if exists
							DROP TABLE IF EXISTS #SR_KPI;
							THROW 50000,@ErrorMsg,1;
						END						
					END
				ELSE
					SET @period_id = @period_key

			IF @route_id IS NULL  
				SET @route_id = 0
			ELSE 
				IF @route_id > 0
					BEGIN
							IF NOT EXISTS (SELECT 1 FROM CES.[ORG] WHERE ORG_SR_KEY=@route_id AND ISACTIVE=1)
							BEGIN
								SET @ErrorMsg = 'Invalid route provided';
								--Temporary table drop if exists
								DROP TABLE IF EXISTS #SR_KPI;
								THROW 50000,@ErrorMsg,1;
							END						
						END
					
			--populate KPI table
			INSERT INTO #SR_KPI(kpi,kpi_key,report_section_key)(
			SELECT DISTINCT KPI_VALUE,KPI_KEY,REPORT_SECTION_KEY FROM [CES].[REPORTING] WHERE
			--PERIOD_SR_KEY=@period_id AND 
			REPORT_NAME=@Report1_Title
			)
			

		-- Get required results set for structures report
			IF (@period_id=@period_key) -- To get current period report 
			BEGIN	
			
				SET @result=
				(
					SELECT 												
							(--updated query
							SELECT 
							RS1.kpi AS kpi,
							CONVERT(INT,RS1.dtl_exams) AS dtl_exams,
							CONVERT(INT,RS1.ve_exams) AS ve_exams,
							CONVERT(INT,RS1.uw_exams) AS uw_exams,
							CONVERT(INT,RS1.total_row_exams) AS total_row_exams
							FROM (
									SELECT K.kpi,
									ISNULL(SUM(CS.DETAILED_EXAMS),0) AS  dtl_exams,
									ISNULL(SUM(CS.VISUAL_EXAMS),0) AS ve_exams,
									ISNULL(SUM(CS.UNDERWATER_EXAMS),0) AS uw_exams,
									(ISNULL(SUM(CS.DETAILED_EXAMS),0)+ISNULL(SUM(CS.VISUAL_EXAMS),0)+ISNULL(SUM(CS.UNDERWATER_EXAMS),0)) AS total_row_exams
									FROM #SR_KPI K LEFT JOIN CES.REPORTING CS
									ON K.kpi = CS.KPI_VALUE 
									AND CS.PERIOD_SR_KEY=@period_key 
									AND CS.REPORT_NAME=@Report1_Title 
									AND CS.REPORT_SECTION_KEY=1 
									AND ( @route_id =0 OR (@route_id <> 0 AND CS.org_sr_key = @route_id))
									WHERE K.report_section_key=1 AND K.kpi<>'Previous Years' 					
									GROUP BY K.kpi,K.report_section_key,K.kpi_key
									--ORDER BY K.report_section_key ASC, K.kpi_key ASC
									UNION ALL 
									SELECT 'Total' AS kpi,
									ISNULL(SUM(CS.DETAILED_EXAMS),0) AS  dtl_exams,
									ISNULL(SUM(CS.VISUAL_EXAMS),0) AS ve_exams,
									ISNULL(SUM(CS.UNDERWATER_EXAMS),0) AS uw_exams,
									(ISNULL(SUM(CS.DETAILED_EXAMS),0)+ISNULL(SUM(CS.VISUAL_EXAMS),0)+ISNULL(SUM(CS.UNDERWATER_EXAMS),0)) AS total_row_exams
									FROM #SR_KPI K LEFT JOIN CES.REPORTING CS
									ON K.kpi = CS.KPI_VALUE 
									AND CS.PERIOD_SR_KEY=@period_key 
									AND CS.REPORT_NAME=@Report1_Title 
									AND CS.REPORT_SECTION_KEY=1 
									AND ( @route_id =0 OR (@route_id <> 0 AND CS.org_sr_key = @route_id))
									WHERE K.report_section_key=1  AND K.kpi<>'Previous Years' 					
									GROUP BY K.report_section_key
									--ORDER BY K.report_section_key ASC, K.kpi_key ASC
								)RS1
								FOR JSON AUTO, INCLUDE_NULL_VALUES
						) section_1_report,					 												
						(
							SELECT 
							RS2.kpi AS kpi,
							CONVERT(INT,RS2.dtl_exams) AS dtl_exams,
							CONVERT(INT,RS2.ve_exams) AS ve_exams,
							CONVERT(INT,RS2.uw_exams) AS uw_exams,
							CONVERT(INT,RS2.total_row_exams) AS total_row_exams
							FROM (
									SELECT K.kpi,
									ISNULL(SUM(CS.DETAILED_EXAMS),0) AS  dtl_exams,
									ISNULL(SUM(CS.VISUAL_EXAMS),0) AS ve_exams,
									ISNULL(SUM(CS.UNDERWATER_EXAMS),0) AS uw_exams,
									(ISNULL(SUM(CS.DETAILED_EXAMS),0)+ISNULL(SUM(CS.VISUAL_EXAMS),0)+ISNULL(SUM(CS.UNDERWATER_EXAMS),0)) AS total_row_exams
									FROM #SR_KPI K LEFT JOIN CES.REPORTING CS
									ON K.kpi = CS.KPI_VALUE 
									AND CS.PERIOD_SR_KEY=@period_key 
									AND CS.REPORT_NAME=@Report1_Title 
									AND CS.REPORT_SECTION_KEY=2 
									AND ( @route_id =0 OR (@route_id <> 0 AND CS.org_sr_key = @route_id))
									WHERE K.report_section_key=2 AND K.kpi<>'Previous Years' 					
									GROUP BY K.kpi,K.report_section_key,K.kpi_key
									--ORDER BY K.report_section_key ASC, K.kpi_key ASC
									UNION ALL 
									SELECT 'Total' AS kpi,
									ISNULL(SUM(CS.DETAILED_EXAMS),0) AS  dtl_exams,
									ISNULL(SUM(CS.VISUAL_EXAMS),0) AS ve_exams,
									ISNULL(SUM(CS.UNDERWATER_EXAMS),0) AS uw_exams,
									(ISNULL(SUM(CS.DETAILED_EXAMS),0)+ISNULL(SUM(CS.VISUAL_EXAMS),0)+ISNULL(SUM(CS.UNDERWATER_EXAMS),0)) AS total_row_exams
									FROM #SR_KPI K LEFT JOIN CES.REPORTING CS
									ON K.kpi = CS.KPI_VALUE 
									AND CS.PERIOD_SR_KEY=@period_key 
									AND CS.REPORT_NAME=@Report1_Title 
									AND CS.REPORT_SECTION_KEY=2 
									AND ( @route_id =0 OR (@route_id <> 0 AND CS.org_sr_key = @route_id))
									WHERE K.report_section_key=2  AND K.kpi<>'Previous Years' 					
									GROUP BY K.report_section_key
									--ORDER BY K.report_section_key ASC, K.kpi_key ASC
								)RS2
								FOR JSON AUTO, INCLUDE_NULL_VALUES
						) section_2_report,
						(
							SELECT 
							RS3.kpi AS kpi,
							CONVERT(INT,RS3.dtl_exams) AS dtl_exams,
							CONVERT(INT,RS3.ve_exams) AS ve_exams,
							CONVERT(INT,RS3.uw_exams) AS uw_exams,
							CONVERT(INT,RS3.total_row_exams) AS total_row_exams
							FROM (
									SELECT K.kpi,
									ISNULL(SUM(CS.DETAILED_EXAMS),0) AS  dtl_exams,
									ISNULL(SUM(CS.VISUAL_EXAMS),0) AS ve_exams,
									ISNULL(SUM(CS.UNDERWATER_EXAMS),0) AS uw_exams,
									(ISNULL(SUM(CS.DETAILED_EXAMS),0)+ISNULL(SUM(CS.VISUAL_EXAMS),0)+ISNULL(SUM(CS.UNDERWATER_EXAMS),0)) AS total_row_exams
									FROM #SR_KPI K LEFT JOIN CES.REPORTING CS
									ON K.kpi = CS.KPI_VALUE 
									AND CS.PERIOD_SR_KEY=@period_key 
									AND CS.REPORT_NAME=@Report1_Title 
									AND CS.REPORT_SECTION_KEY=3 
									AND ( @route_id =0 OR (@route_id <> 0 AND CS.org_sr_key = @route_id))
									WHERE K.report_section_key=3 AND K.kpi<>'Previous Years' 					
									GROUP BY K.kpi,K.report_section_key,K.kpi_key
									--ORDER BY K.report_section_key ASC, K.kpi_key ASC
									UNION ALL 
									SELECT 'Total' AS kpi,
									ISNULL(SUM(CS.DETAILED_EXAMS),0) AS  dtl_exams,
									ISNULL(SUM(CS.VISUAL_EXAMS),0) AS ve_exams,
									ISNULL(SUM(CS.UNDERWATER_EXAMS),0) AS uw_exams,
									(ISNULL(SUM(CS.DETAILED_EXAMS),0)+ISNULL(SUM(CS.VISUAL_EXAMS),0)+ISNULL(SUM(CS.UNDERWATER_EXAMS),0)) AS total_row_exams
									FROM #SR_KPI K LEFT JOIN CES.REPORTING CS
									ON K.kpi = CS.KPI_VALUE 
									AND CS.PERIOD_SR_KEY=@period_key 
									AND CS.REPORT_NAME=@Report1_Title 
									AND CS.REPORT_SECTION_KEY=3 
									AND ( @route_id =0 OR (@route_id <> 0 AND CS.org_sr_key = @route_id))
									WHERE K.report_section_key=3  AND K.kpi<>'Previous Years' 					
									GROUP BY K.report_section_key
									--ORDER BY K.report_section_key ASC, K.kpi_key ASC
								)RS3
								FOR JSON AUTO, INCLUDE_NULL_VALUES
						) section_3_report,							
						JSON_QUERY(
										(
											SELECT 
											RST.kpi AS kpi,
											CONVERT(INT,RST.dtl_exams) AS dtl_exams,
											CONVERT(INT,RST.ve_exams) AS ve_exams,
											CONVERT(INT,RST.uw_exams) AS uw_exams,
											CONVERT(INT,RST.total_row_exams) AS total_row_exams
											FROM (
													SELECT 'Total no. of non-compliant exams (ORR Reportable)' AS kpi,ISNULL(SUM(CS.DETAILED_EXAMS),0) AS  dtl_exams,ISNULL(SUM(CS.VISUAL_EXAMS),0) AS ve_exams,ISNULL(SUM(CS.UNDERWATER_EXAMS),0) AS uw_exams
													,(ISNULL(SUM(CS.DETAILED_EXAMS),0)+ISNULL(SUM(CS.VISUAL_EXAMS),0)+ISNULL(SUM(CS.UNDERWATER_EXAMS),0)) AS total_row_exams
													FROM CES.REPORTING CS			
													WHERE
													CS.PERIOD_SR_KEY=@period_key 
													AND CS.REPORT_NAME=@Report1_Title
													AND CS.KPI_VALUE<>'Previous Years' 	
													AND ( @route_id =0 OR (@route_id <> 0 AND CS.org_sr_key = @route_id))
												)RST 
												FOR JSON PATH,WITHOUT_ARRAY_WRAPPER
										)
								) Total_non_compliant					
						FOR JSON PATH, INCLUDE_NULL_VALUES, WITHOUT_ARRAY_WRAPPER
					)	

			END
			ELSE  --- To  get history report 
			BEGIN 
				SET @period_key = @period_id
				set @is_history_year = 'Y'

				
				SET @result=
				(
					SELECT 												
							(
							SELECT 
							RS1.kpi AS kpi,
							CONVERT(INT,RS1.dtl_exams) AS dtl_exams,
							CONVERT(INT,RS1.ve_exams) AS ve_exams,
							CONVERT(INT,RS1.uw_exams) AS uw_exams,
							CONVERT(INT,RS1.total_row_exams) AS total_row_exams
							FROM (
									SELECT K.kpi,
									ISNULL(SUM(CS.DETAILED_EXAMS),0) AS  dtl_exams,
									ISNULL(SUM(CS.VISUAL_EXAMS),0) AS ve_exams,
									ISNULL(SUM(CS.UNDERWATER_EXAMS),0) AS uw_exams,
									(ISNULL(SUM(CS.DETAILED_EXAMS),0)+ISNULL(SUM(CS.VISUAL_EXAMS),0)+ISNULL(SUM(CS.UNDERWATER_EXAMS),0)) AS total_row_exams
									FROM #SR_KPI K LEFT JOIN CES.REPORTING_HISTORY CS
									ON K.kpi = CS.KPI_VALUE 
									AND CS.PERIOD_SR_KEY=@period_key 
									AND CS.REPORT_NAME=@Report1_Title 
									AND CS.REPORT_SECTION_KEY=1 
									AND ( @route_id =0 OR (@route_id <> 0 AND CS.org_sr_key = @route_id))
									WHERE K.report_section_key=1 AND K.kpi<>'Previous Years' 					
									GROUP BY K.kpi,K.report_section_key,K.kpi_key
									--ORDER BY K.report_section_key ASC, K.kpi_key ASC
									UNION ALL 
									SELECT 'Total' AS kpi,
									ISNULL(SUM(CS.DETAILED_EXAMS),0) AS  dtl_exams,
									ISNULL(SUM(CS.VISUAL_EXAMS),0) AS ve_exams,
									ISNULL(SUM(CS.UNDERWATER_EXAMS),0) AS uw_exams,
									(ISNULL(SUM(CS.DETAILED_EXAMS),0)+ISNULL(SUM(CS.VISUAL_EXAMS),0)+ISNULL(SUM(CS.UNDERWATER_EXAMS),0)) AS total_row_exams
									FROM #SR_KPI K LEFT JOIN CES.REPORTING_HISTORY CS
									ON K.kpi = CS.KPI_VALUE 
									AND CS.PERIOD_SR_KEY=@period_key 
									AND CS.REPORT_NAME=@Report1_Title 
									AND CS.REPORT_SECTION_KEY=1 
									AND ( @route_id =0 OR (@route_id <> 0 AND CS.org_sr_key = @route_id))
									WHERE K.report_section_key=1  AND K.kpi<>'Previous Years' 					
									GROUP BY K.report_section_key
									--ORDER BY K.report_section_key ASC, K.kpi_key ASC
									
								)RS1
								FOR JSON AUTO, INCLUDE_NULL_VALUES
						) section_1_report,					 												
						(
							SELECT 
							RS2.kpi AS kpi,
							CONVERT(INT,RS2.dtl_exams) AS dtl_exams,
							CONVERT(INT,RS2.ve_exams) AS ve_exams,
							CONVERT(INT,RS2.uw_exams) AS uw_exams,
							CONVERT(INT,RS2.total_row_exams) AS total_row_exams
							FROM (
									SELECT K.kpi,
									ISNULL(SUM(CS.DETAILED_EXAMS),0) AS  dtl_exams,
									ISNULL(SUM(CS.VISUAL_EXAMS),0) AS ve_exams,
									ISNULL(SUM(CS.UNDERWATER_EXAMS),0) AS uw_exams,
									(ISNULL(SUM(CS.DETAILED_EXAMS),0)+ISNULL(SUM(CS.VISUAL_EXAMS),0)+ISNULL(SUM(CS.UNDERWATER_EXAMS),0)) AS total_row_exams
									FROM #SR_KPI K LEFT JOIN CES.REPORTING_HISTORY CS
									ON K.kpi = CS.KPI_VALUE 
									AND CS.PERIOD_SR_KEY=@period_key 
									AND CS.REPORT_NAME=@Report1_Title 
									AND CS.REPORT_SECTION_KEY=2 
									AND ( @route_id =0 OR (@route_id <> 0 AND CS.org_sr_key = @route_id))
									WHERE K.report_section_key=2 AND K.kpi<>'Previous Years' 					
									GROUP BY K.kpi,K.report_section_key,K.kpi_key
									--ORDER BY K.report_section_key ASC, K.kpi_key ASC
									UNION ALL 
									SELECT 'Total' AS kpi,
									ISNULL(SUM(CS.DETAILED_EXAMS),0) AS  dtl_exams,
									ISNULL(SUM(CS.VISUAL_EXAMS),0) AS ve_exams,
									ISNULL(SUM(CS.UNDERWATER_EXAMS),0) AS uw_exams,
									(ISNULL(SUM(CS.DETAILED_EXAMS),0)+ISNULL(SUM(CS.VISUAL_EXAMS),0)+ISNULL(SUM(CS.UNDERWATER_EXAMS),0)) AS total_row_exams
									FROM #SR_KPI K LEFT JOIN CES.REPORTING_HISTORY CS
									ON K.kpi = CS.KPI_VALUE 
									AND CS.PERIOD_SR_KEY=@period_key 
									AND CS.REPORT_NAME=@Report1_Title 
									AND CS.REPORT_SECTION_KEY=2 
									AND ( @route_id =0 OR (@route_id <> 0 AND CS.org_sr_key = @route_id))
									WHERE K.report_section_key=2  AND K.kpi<>'Previous Years' 					
									GROUP BY K.report_section_key
									--ORDER BY K.report_section_key ASC, K.kpi_key ASC
								)RS2
								FOR JSON AUTO, INCLUDE_NULL_VALUES
						) section_2_report,
						(
							SELECT 
							RS3.kpi AS kpi,
							CONVERT(INT,RS3.dtl_exams) AS dtl_exams,
							CONVERT(INT,RS3.ve_exams) AS ve_exams,
							CONVERT(INT,RS3.uw_exams) AS uw_exams,
							CONVERT(INT,RS3.total_row_exams) AS total_row_exams
							FROM (
									SELECT K.kpi,
									ISNULL(SUM(CS.DETAILED_EXAMS),0) AS  dtl_exams,
									ISNULL(SUM(CS.VISUAL_EXAMS),0) AS ve_exams,
									ISNULL(SUM(CS.UNDERWATER_EXAMS),0) AS uw_exams,
									(ISNULL(SUM(CS.DETAILED_EXAMS),0)+ISNULL(SUM(CS.VISUAL_EXAMS),0)+ISNULL(SUM(CS.UNDERWATER_EXAMS),0)) AS total_row_exams
									FROM #SR_KPI K LEFT JOIN CES.REPORTING_HISTORY CS
									ON K.kpi = CS.KPI_VALUE 
									AND CS.PERIOD_SR_KEY=@period_key 
									AND CS.REPORT_NAME=@Report1_Title 
									AND CS.REPORT_SECTION_KEY=3 
									AND ( @route_id =0 OR (@route_id <> 0 AND CS.org_sr_key = @route_id))
									WHERE K.report_section_key=3 AND K.kpi<>'Previous Years' 					
									GROUP BY K.kpi,K.report_section_key,K.kpi_key
									--ORDER BY K.report_section_key ASC, K.kpi_key ASC
									UNION ALL 
									SELECT 'Total' AS kpi,
									ISNULL(SUM(CS.DETAILED_EXAMS),0) AS  dtl_exams,
									ISNULL(SUM(CS.VISUAL_EXAMS),0) AS ve_exams,
									ISNULL(SUM(CS.UNDERWATER_EXAMS),0) AS uw_exams,
									(ISNULL(SUM(CS.DETAILED_EXAMS),0)+ISNULL(SUM(CS.VISUAL_EXAMS),0)+ISNULL(SUM(CS.UNDERWATER_EXAMS),0)) AS total_row_exams
									FROM #SR_KPI K LEFT JOIN CES.REPORTING_HISTORY CS
									ON K.kpi = CS.KPI_VALUE 
									AND CS.PERIOD_SR_KEY=@period_key 
									AND CS.REPORT_NAME=@Report1_Title 
									AND CS.REPORT_SECTION_KEY=3 
									AND ( @route_id =0 OR (@route_id <> 0 AND CS.org_sr_key = @route_id))
									WHERE K.report_section_key=3  AND K.kpi<>'Previous Years' 					
									GROUP BY K.report_section_key
									--ORDER BY K.report_section_key ASC, K.kpi_key ASC
								)RS3
								FOR JSON AUTO, INCLUDE_NULL_VALUES
						) section_3_report,							
						JSON_QUERY(
										(
											SELECT 
											RST.kpi AS kpi,
											CONVERT(INT,RST.dtl_exams) AS dtl_exams,
											CONVERT(INT,RST.ve_exams) AS ve_exams,
											CONVERT(INT,RST.uw_exams) AS uw_exams,
											CONVERT(INT,RST.total_row_exams) AS total_row_exams
											FROM (
													SELECT 'Total no. of non-compliant exams (ORR Reportable)' AS kpi,ISNULL(SUM(CS.DETAILED_EXAMS),0) AS  dtl_exams,ISNULL(SUM(CS.VISUAL_EXAMS),0) AS ve_exams,ISNULL(SUM(CS.UNDERWATER_EXAMS),0) AS uw_exams
													,(ISNULL(SUM(CS.DETAILED_EXAMS),0)+ISNULL(SUM(CS.VISUAL_EXAMS),0)+ISNULL(SUM(CS.UNDERWATER_EXAMS),0)) AS total_row_exams
													FROM CES.REPORTING_HISTORY CS			
													WHERE
													CS.PERIOD_SR_KEY=@period_key AND CS.REPORT_NAME=@Report1_Title 		
													AND CS.KPI_VALUE<>'Previous Years' 	
													AND ( @route_id =0 OR (@route_id <> 0 AND CS.org_sr_key = @route_id))
												)RST 
												FOR JSON PATH,WITHOUT_ARRAY_WRAPPER
										)
								) Total_non_compliant					
						FOR JSON PATH, INCLUDE_NULL_VALUES, WITHOUT_ARRAY_WRAPPER
					)	
				
			END		
			--To return empty json
			--ELSE
			--BEGIN
			--	SET @result=
			--	(
			--		SELECT 
			--			JSON_QUERY('[]')  AS section_1_report,
			--			JSON_QUERY('[]')  AS section_2_report,
			--			JSON_QUERY('[]') AS section_3_report,
			--			JSON_QUERY('[]') AS Total_non_compliant
			--		FOR JSON PATH, INCLUDE_NULL_VALUES, WITHOUT_ARRAY_WRAPPER
			--	)
			--END	
		
			--Return json
			SELECT @result 
	END TRY

	BEGIN CATCH
		SET @ErrorMsg = ERROR_MESSAGE() + 
						' Line Num:' + CONVERT(VARCHAR(5), ERROR_LINE()) + 
						',ErrorNum:' + CONVERT(VARCHAR(5), ERROR_NUMBER()) + 
						',Severity:' + CONVERT(VARCHAR(5), ERROR_SEVERITY()) + 
						',State:' + CONVERT(VARCHAR(10), ERROR_STATE()) + 
						',Procedure:' + CONVERT(VARCHAR(25), OBJECT_NAME(@@procid)) +
						',Procedure:' + CONVERT(VARCHAR(25), ERROR_PROCEDURE());  
		--Temporary table drop if exists
		DROP TABLE IF EXISTS #SR_KPI;

		THROW 50000,@ErrorMsg,1;
	END CATCH
	--Temporary table drop if exists
	DROP TABLE IF EXISTS #SR_KPI;

	SET NOCOUNT OFF
  END