﻿/***************************************************************************************************************************************            
* Name						: sp_Save_NewDefect_Dtls        
* Created By				: Cognizant            
* Date Created				: 23-Dec-2020           
* Description				: This stored procedure fetches the dropdown to load for Add defect/Ad row to defect screen and generates a defect ID for the former.  
* Input Parameters			: JSON    
* Output Parameters			: Returns 1 for succesful save, else 0            
* Return Value				: N/A            
* Assumptions				: None    
* Execution Statement		: EXEC CES.sp_Get_NewDefect_DisplayDtls 'Y'
*								
* Modified Date     Modified By   Revision Number  Modifications            

*******************************************************************************************************************************************/ 



CREATE PROCEDURE [CES].[sp_Get_NewDefect_DisplayDtls]
	@isnewdefect		CHAR(1)
AS 
	
BEGIN
	SET NOCOUNT ON
    BEGIN TRY
		
		DECLARE
				@ErrorMsg			VARCHAR(250),
				@defect_id			DECIMAL(18) = NULL,
				@result				NVARCHAR(MAX)

		IF (@isnewdefect = 'Y')
			SELECT @defect_id = NEXT VALUE FOR [CES].[SEQ_DEFECT_ID];

		SET @result=
		(
			SELECT
			(
					SELECT
						EXAM_TYPE_SR_KEY AS exam_type_id,
						EXAM_TYPE	AS exam_type_val
					FROM	[CES].EXAM_TYPE
					ORDER BY EXAM_TYPE_SR_KEY
					FOR JSON AUTO
				)exam_type,

				@defect_id AS defect_id	
			
			FOR JSON PATH,WITHOUT_ARRAY_WRAPPER, INCLUDE_NULL_VALUES
		)

		SELECT @result
	END TRY
	BEGIN CATCH
		SET @ErrorMsg = ERROR_MESSAGE() + 
						' Line Num:' + CONVERT(VARCHAR(5), ERROR_LINE()) + 
						',ErrorNum:' + CONVERT(VARCHAR(5), ERROR_NUMBER()) + 
						',Severity:' + CONVERT(VARCHAR(5), ERROR_SEVERITY()) + 
						',State:' + CONVERT(VARCHAR(10), ERROR_STATE()) + 
						',Procedure:' + CONVERT(VARCHAR(25), OBJECT_NAME(@@procid)) +
						',Procedure:' + CONVERT(VARCHAR(25), ERROR_PROCEDURE());  
		
		THROW 50000,@ErrorMsg,1;
	END CATCH

	SET NOCOUNT OFF


END