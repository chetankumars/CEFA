﻿




/***************************************************************************************************************************************            
* Name						: sp_Get_AssetDtls_API          
* Created By				: Cognizant            
* Date Created				: 30-March-2021           
* Description				: This stored procedure retrive Asset Details API. 
* Input Parameters			: JSON      
* Output Parameters			: JSON           
* Return Value				: N/A            
* Assumptions				: None    
* Execution Statement		: Exec [CES].sp_Get_AssetDtls_API '{
																"region_name":"Southern",
																"route_name": "Kent",
																"pageno": 3,
																"rowsperpage": 100
																}'
*								
* Modified Date     Modified By   Revision Number  Modifications            
  16/07/2021        Cognizant	  2.0			   User Story: 37568 - AccessData - Added 'COMMENTS' field
*******************************************************************************************************************************************/ 



CREATE PROCEDURE [CES].[sp_Get_AssetDtls_API]
	@Input_JSON		NVARCHAR(MAX)
AS
BEGIN
	SET NOCOUNT ON
	BEGIN TRY
		DECLARE
				@ErrorMsg					VARCHAR(250),
				@result						NVARCHAR(MAX),
				@region_name	            VARCHAR(64),
				@route_name                 VARCHAR(64),
				@pageno						DECIMAL(18),
				@rowsperpage				DECIMAL(18),
				@totalresultcnt				INT,
				@totalresultreturned		INT,
				@ErrorDescription			VARCHAR(4000),
				@ast_guids					NVARCHAR(MAX)
			
			
		DECLARE @tbl_org TABLE
		(
			ORG_SR_KEY	DECIMAL(18)
		)

		
		CREATE TABLE #tbl_AssetAccessDtls
		(
				region					VARCHAR(64),
				route					VARCHAR(64),
				area					VARCHAR(64),
				elr						VARCHAR(4),
				asset_guid				VARCHAR(32),
				railway_id				VARCHAR(64),
				asset_group				VARCHAR(64),
				asset_type				VARCHAR(64),
				start_mileage			DECIMAL(18,5),
				end_mileage				DECIMAL(18,5),
				primary_material		VARCHAR(64),
				owning_party			VARCHAR(64),
				gps_start				VARCHAR(64),
				gps_end					VARCHAR(64),
				structure_carries		VARCHAR(64),
				structure_over			VARCHAR(64),
				hce_flag				VARCHAR(4),
				cmi_score				DECIMAL(3),
				tenanted_flg			VARCHAR(4),
				exam_type				VARCHAR(32), 
				comp_status				VARCHAR(100),
				possession				VARCHAR(32),
				rrv						VARCHAR(32),
				ladder					VARCHAR(32),
				confined_space			VARCHAR(32),
				[3rd_party]				VARCHAR(32),
				line_block				VARCHAR(32),
				mewp					VARCHAR(32),
				scaffold				VARCHAR(32),
				water_permit			VARCHAR(32),
				traffic_mngt			VARCHAR(32),
				rope_access				VARCHAR(32),
				cctv					VARCHAR(32),
				safety_boat				VARCHAR(32),
				comments				VARCHAR(8000)
				--Comments column length updated to 8000 in access table
		)
		
		
	    SELECT 
			@region_name = COALESCE(@region_name,CASE LOWER([key]) WHEN 'region_name' THEN [value] ELSE NULL END),
			@route_name = COALESCE(@route_name,CASE LOWER([key]) WHEN 'route_name' THEN [value] ELSE NULL END),
			@pageno = COALESCE(@pageno,CASE LOWER([key]) WHEN 'pageno' THEN [value] ELSE NULL END),
			@rowsperpage = COALESCE(@rowsperpage,CASE LOWER([key]) WHEN 'rowsperpage' THEN [value] ELSE NULL END)

		FROM	OPENJSON(@Input_JSON);


		-- Validation start

		IF (@region_name IS NULL OR @pageno IS NULL OR @rowsperpage IS NULL)
		BEGIN

			SET @ErrorMsg = 'Mandatory Input value is missing';
			DROP TABLE IF EXISTS #tbl_AssetAccessDtlsAPI;
			THROW 50000,@ErrorMsg,1;
		END

		IF (@rowsperpage > 100)
		BEGIN
			SET @ErrorMsg = 'Maximum number of assets can be returned is 100.';
			DROP TABLE IF EXISTS #tbl_AssetAccessDtlsAPI;
			THROW 50000,@ErrorMsg,1;
		END

		INSERT INTO @tbl_org (ORG_SR_KEY)
		SELECT ORG_SR_KEY
		FROM CES.ORG
		WHERE REGION = @region_name
		AND (@route_name IS NULL OR (@route_name IS NOT NULL AND [ROUTE] = @route_name))
		AND ISACTIVE = 1 

		IF NOT EXISTS (SELECT 1 FROM @tbl_org)
		BEGIN
			SET @ErrorMsg = 'Region /Route Information passed in input is incorrect';
			DROP TABLE IF EXISTS #tbl_AssetAccessDtlsAPI;
			THROW 50000,@ErrorMsg,1;
		END

	   -- Validation end	
	   
		--SET
		--	@ast_guids = 
		--		(SELECT CONCAT('[', '"' + (SELECT distinct STRING_AGG(STRING_ESCAPE(t.ASSET_GUID, 'json'), '","') 
		--					FROM
		--					(
		--						SELECT
		--							ASSET_GUID,
		--							ROW_NUMBER() OVER (ORDER BY ASSET_GUID) rnk, 
		--							(DENSE_RANK() OVER (ORDER BY ASSET_GUID)
		--							+ DENSE_RANK() OVER (ORDER BY ASSET_GUID DESC)
		--							-1) totalcount
		--						FROM CES.ASSET a
		--						INNER JOIN @tbl_org o
		--						ON o.ORG_SR_KEY = a.ORG_SR_KEY
		--						WHERE 
		--						 a.ISACTIVE =1
		--						GROUP BY
		--							ASSET_GUID,
		--							ENG_LINE_REF,
		--							RAILWAY_ID	
		--					)t
				
		--		 WHERE t.rnk BETWEEN ((@pageno - 1) * @rowsperpage +1) AND (@pageno * @rowsperpage) 
		--		) + '"', ']'))


		
			;WITH ast(ASSET_GUID, rnk, totalcount) AS
			(
					SELECT
						ASSET_GUID,
						ROW_NUMBER() OVER (ORDER BY ASSET_GUID) rnk, 
						(DENSE_RANK() OVER (ORDER BY ASSET_GUID)
						+ DENSE_RANK() OVER (ORDER BY ASSET_GUID DESC)
						-1) totalcount
					FROM CES.ASSET a
					INNER JOIN @tbl_org o
					ON o.ORG_SR_KEY = a.ORG_SR_KEY
					WHERE 
						a.ISACTIVE =1
					GROUP BY
						ASSET_GUID,
						ENG_LINE_REF,
						RAILWAY_ID	
							
			)
			SELECT 
				@ast_guids = 
				(SELECT CONCAT('[', '"' + (SELECT distinct STRING_AGG(STRING_ESCAPE(ASSET_GUID, 'json'), '","') 
											FROM ast  
											WHERE rnk BETWEEN ((@pageno - 1) * @rowsperpage +1) AND (@pageno * @rowsperpage) ) + '"', ']')),
				@totalresultcnt = (SELECT TOP 1 totalcount FROM ast)


		--Retrieving the asset access details for the selected assets
		EXEC [CES].[sp_Get_AssetAccessDetails] @ast_guids

		SELECT @totalresultreturned = COUNT(1) FROM #tbl_AssetAccessDtls


		--If no records are returned in search result
		IF  @totalresultreturned=0 
		BEGIN
		
			SET @result=
					(
						SELECT 
							JSON_QUERY(
										(
											select
												@pageno AS currentpage,
												@totalresultcnt AS totalcount,
												CEILING(@totalresultcnt/@rowsperpage) AS totalpages
											FOR JSON PATH,WITHOUT_ARRAY_WRAPPER
										)
							) searchdatacount,
							JSON_QUERY('[]') searchresult
						
						FOR JSON PATH,WITHOUT_ARRAY_WRAPPER, INCLUDE_NULL_VALUES
				)
		END	

		--If at least 1 record is returned in search result
		ELSE
		BEGIN

				SET @result=
				(
					SELECT 
						JSON_QUERY(
									(
											SELECT
													@pageno AS currentpage,
													@totalresultcnt AS totalcount,
													CEILING(@totalresultcnt/@rowsperpage) AS totalpages
											FOR JSON PATH,WITHOUT_ARRAY_WRAPPER
									)
							) searchdatacount,
							(
								SELECT 									
												region,
												route,
												area,
												elr,
												asset_guid,
												railway_id,
												asset_group,
												asset_type,
												start_mileage,
												end_mileage,
												primary_material,
												owning_party,
												gps_start,
												gps_end,
												structure_carries,
												structure_over,
												hce_flag,
												cmi_score,
												tenanted_flg,
												exam_type, 
												comp_status,
												possession,
												rrv,
												ladder,
												confined_space,
												[3rd_party],
												line_block,
												mewp,
												scaffold,
												water_permit,
												traffic_mngt,
												rope_access,
												cctv,
												safety_boat,
												comments
																	
								FROM #tbl_AssetAccessDtls
								ORDER BY asset_guid, exam_type 										
								FOR JSON PATH, INCLUDE_NULL_VALUES
							  ) searchresult
							FOR JSON PATH, INCLUDE_NULL_VALUES, WITHOUT_ARRAY_WRAPPER
					    )

		END

		--PRINT @result
		SELECT @result AS response, NULL AS ErrorMsg

	END TRY
	BEGIN CATCH

		IF @ErrorMsg IS NULL
			SET @ErrorMsg = ERROR_MESSAGE() 

			--select ERROR_MESSAGE()
		SET @ErrorDescription = @ErrorMsg + 
						' Line Num:' + CONVERT(VARCHAR(5), ERROR_LINE()) + 
						',ErrorNum:' + CONVERT(VARCHAR(5), ERROR_NUMBER()) + 
						',Severity:' + CONVERT(VARCHAR(5), ERROR_SEVERITY()) + 
						',State:' + CONVERT(VARCHAR(10), ERROR_STATE()) + 
						',Procedure:' + CONVERT(VARCHAR(25), OBJECT_NAME(@@procid)) +
						',Procedure:' + CONVERT(VARCHAR(25), ERROR_PROCEDURE());  

		
		SET @result=
					(
						SELECT 
							JSON_QUERY(
										(
											select
												@pageno AS currentpage,
												@totalresultcnt AS totalcount,
												0 AS totalpages
											FOR JSON PATH,WITHOUT_ARRAY_WRAPPER
										)
							) searchdatacount,
							JSON_QUERY('[]') searchresult
						
						FOR JSON PATH,WITHOUT_ARRAY_WRAPPER, INCLUDE_NULL_VALUES
				)

		SELECT @result AS response, @ErrorDescription AS ErrorMsg

		DROP TABLE IF EXISTS #tbl_AssetAccessDtls;
	

		THROW 50000,@ErrorDescription,1;

		
	END CATCH

	DROP TABLE IF EXISTS #tbl_AssetAccessDtls;
	SET NOCOUNT OFF
END