﻿


/***************************************************************************************************************************************            
* Name						: sp_Close_Defect            
* Created By				: Cognizant            
* Date Created				: 14-Jul-2021           
* Description				: This stored procedure is used to close the defect based on specific defect id.  
* Input Parameters			: Asset GUID, Exam Type      
* Output Parameters			: N/A            
* Return Value				: N/A            
* Assumptions				: None    
* Execution Statement		: EXEC [CES].[sp_Close_Defect]  '{
																"defect_id": 120,																			
																"current_user_key":  "9725949A-1EB7-497E-B397-A511422AFAFE"
				 											 }'

*								
* Modified Date     Modified By   Revision Number  Modifications            

*******************************************************************************************************************************************/ 



CREATE PROCEDURE [CES].[sp_Close_Defect] 
	@Input_JSON		NVARCHAR(MAX)    
AS 


BEGIN
	SET NOCOUNT ON

  BEGIN TRY
		DECLARE
				@ErrorMsg			VARCHAR(250),
				@result				NVARCHAR(MAX),
				@defect_id		DECIMAL(18,0),				
				@current_user_key	VARCHAR(64),				
				@current_date		DATETIME = GETDATE()

		SELECT 
			@defect_id = COALESCE(@defect_id,CASE LOWER([key]) WHEN 'defect_id' THEN [value] ELSE NULL END),
			@current_user_key = COALESCE(@current_user_key,CASE LOWER([key]) WHEN 'current_user_key' THEN [value] ELSE NULL END)
		FROM OPENJSON(@Input_JSON);

		IF (@defect_id IS NULL)
		BEGIN
			SET @ErrorMsg = 'Defect is blank in input.';
			THROW 50000,@ErrorMsg,1;
		END
		ELSE
		BEGIN
			IF NOT EXISTS (SELECT 1 FROM [CES].DEFECT WHERE DEFECT_ID = @defect_id AND ISACTIVE=1)
				BEGIN
				
					SET @ErrorMsg = 'Defect does not exist. Please check the details again.';
					THROW 50000,@ErrorMsg,1;
			END
		END

		
		IF (@current_user_key IS NULL OR @current_user_key='')
		BEGIN
			SET @ErrorMsg = 'Logged in user key is blank in input.';
			THROW 50000,@ErrorMsg,1;
		END


		BEGIN TRAN			
			UPDATE [CES].[DEFECT] SET IS_DEFECT_CLOSED='Y',DEFECT_CLOSED_BY=@current_user_key,DEFECT_CLOSED_DATE=@current_date WHERE  DEFECT_ID = @defect_id AND ISACTIVE=1
			SET @result= (
							SELECT 1 AS save_status,NULL AS error_msg
							FOR JSON PATH,WITHOUT_ARRAY_WRAPPER, INCLUDE_NULL_VALUES
						)			
		COMMIT TRAN
		 SELECT @result
	END TRY

	BEGIN CATCH
	IF (@@TRANCOUNT >0)
		ROLLBACK TRAN
	IF @ErrorMsg IS NULL
		SET @ErrorMsg = ERROR_MESSAGE() 

		SET @ErrorMsg = ERROR_MESSAGE() + 
						' Line Num:' + CONVERT(VARCHAR(5), ERROR_LINE()) + 
						',ErrorNum:' + CONVERT(VARCHAR(5), ERROR_NUMBER()) + 
						',Severity:' + CONVERT(VARCHAR(5), ERROR_SEVERITY()) + 
						',State:' + CONVERT(VARCHAR(10), ERROR_STATE()) + 
						',Procedure:' + CONVERT(VARCHAR(25), OBJECT_NAME(@@procid)) +
						',Procedure:' + CONVERT(VARCHAR(25), ERROR_PROCEDURE());  

		SET @result= (
						SELECT 0 AS save_status,@ErrorMsg AS error_msg
						FOR JSON PATH,WITHOUT_ARRAY_WRAPPER, INCLUDE_NULL_VALUES
					)
		SELECT @result;

		THROW 50000,@ErrorMsg,1;
	END CATCH
	SET NOCOUNT OFF
END