﻿


/***************************************************************************************************************************************            
* Name						: sp_Save_AssetDtls_AccessData            
* Created By				: Cognizant            
* Date Created				: 14-Jul-2021           
* Description				: This stored procedure is used to save the access data comments for specific asset and exam type.  
* Input Parameters			: Asset GUID, Exam Type      
* Output Parameters			: N/A            
* Return Value				: N/A            
* Assumptions				: None    
* Execution Statement		: EXEC [CES].[sp_Save_AssetDtls_AccessData]  '{
																			"asset_guid": "3978559C379545D9E04400306E4AD01A",
																			"exam_type_id": 2,
																			"comments": "comments to test",
																			"current_user_key":  "9725949A-1EB7-497E-B397-A511422AFAFE"
																		   }'

*								
* Modified Date     Modified By   Revision Number  Modifications            

*******************************************************************************************************************************************/ 



CREATE PROCEDURE [CES].[sp_Save_AssetDtls_AccessData] 
	@Input_JSON		NVARCHAR(MAX)    
AS 


BEGIN
	SET NOCOUNT ON

  BEGIN TRY
		DECLARE
				@ErrorMsg			VARCHAR(250),
				@result				NVARCHAR(MAX),
				@Asset_GUID			VARCHAR (32),
				@Exam_type_id		DECIMAL(18,0),
				@Comments			VARCHAR(8000),
				@current_user_key	VARCHAR(64),				
				@current_date		DATETIME = GETDATE()

		SELECT 
			@Asset_GUID = COALESCE(@Asset_GUID,CASE LOWER([key]) WHEN 'asset_guid' THEN [value] ELSE NULL END),
			@Exam_type_id = COALESCE(@Exam_type_id,CASE LOWER([key]) WHEN 'exam_type_id' THEN [value] ELSE NULL END),
			@current_user_key = COALESCE(@current_user_key,CASE LOWER([key]) WHEN 'current_user_key' THEN [value] ELSE NULL END),
			@Comments = COALESCE(@Comments,CASE LOWER([key]) WHEN 'comments' THEN [value] ELSE NULL END)
		FROM OPENJSON(@Input_JSON);

		IF (@Asset_GUID IS NULL OR @Asset_GUID='')
		BEGIN
			SET @ErrorMsg = 'Asset GUID is blank in input.';
			THROW 50000,@ErrorMsg,1;
		END

		IF (@Exam_type_id IS NULL)
		BEGIN
			SET @ErrorMsg = 'Exam type id is blank in input.';
			THROW 50000,@ErrorMsg,1;
		END

		IF (@current_user_key IS NULL OR @current_user_key='')
		BEGIN
			SET @ErrorMsg = 'Logged in user key is blank in input.';
			THROW 50000,@ErrorMsg,1;
		END
	
			IF EXISTS (SELECT 1 FROM [CES].[ACCESS] WHERE ASSET_GUID = @Asset_GUID AND EXAM_TYPE_SR_KEY=@Exam_type_id AND ISACTIVE=1)
			BEGIN
				BEGIN TRAN
				UPDATE [CES].[ACCESS] SET COMMENTS=@Comments,UPDATED_USER=@current_user_key,UPDATED_DATE=@current_date WHERE ASSET_GUID=@Asset_GUID AND EXAM_TYPE_SR_KEY=@Exam_type_id	
				COMMIT TRAN
				SET @result= (
								SELECT 1 AS save_status,NULL AS error_msg
								FOR JSON PATH,WITHOUT_ARRAY_WRAPPER, INCLUDE_NULL_VALUES
							)
			END 
			ELSE
			BEGIN	
				IF (@Comments IS NULL OR @Comments='')
				BEGIN
					SET @ErrorMsg = 'Comments is blank in input.';
					THROW 50000,@ErrorMsg,1;
				END
				BEGIN TRAN
				INSERT INTO [CES].[ACCESS] (ASSET_GUID,EXAM_TYPE_SR_KEY,COMMENTS,ISACTIVE,CREATED_USER,CREATED_DATE) VALUES (@Asset_GUID,@Exam_type_id,@Comments,1,@current_user_key,@current_date)			
				COMMIT TRAN
				SET @result= (
								SELECT 1 AS save_status,NULL AS error_msg
								FOR JSON PATH,WITHOUT_ARRAY_WRAPPER, INCLUDE_NULL_VALUES
							)
			END
		
		 SELECT @result
	END TRY

	BEGIN CATCH
	IF (@@TRANCOUNT >0)
		ROLLBACK TRAN
	IF @ErrorMsg IS NULL
		SET @ErrorMsg = ERROR_MESSAGE() 

		SET @ErrorMsg = ERROR_MESSAGE() + 
						' Line Num:' + CONVERT(VARCHAR(5), ERROR_LINE()) + 
						',ErrorNum:' + CONVERT(VARCHAR(5), ERROR_NUMBER()) + 
						',Severity:' + CONVERT(VARCHAR(5), ERROR_SEVERITY()) + 
						',State:' + CONVERT(VARCHAR(10), ERROR_STATE()) + 
						',Procedure:' + CONVERT(VARCHAR(25), OBJECT_NAME(@@procid)) +
						',Procedure:' + CONVERT(VARCHAR(25), ERROR_PROCEDURE());  

		SET @result= (
						SELECT 0 AS save_status,@ErrorMsg AS error_msg
						FOR JSON PATH,WITHOUT_ARRAY_WRAPPER, INCLUDE_NULL_VALUES
					)
		SELECT @result;

		THROW 50000,@ErrorMsg,1;
	END CATCH
	SET NOCOUNT OFF
END