﻿
/***************************************************************************************************************************************            
* Name						: sp_Get_AssetDtls_CommonData            
* Created By				: Cognizant            
* Date Created				: 13-Dec-2020           
* Description				: This stored procedure fetches the for Asset Common data in Asset Details page.  
* Input Parameters			: N/A      
* Output Parameters			: N/A            
* Return Value				: N/A            
* Assumptions				: None    
* Execution Statement		: EXEC [CES].sp_Get_AssetDtls_CommonData '028A9FBFE49F152BE050E70A82861787'
*								
* Modified Date     Modified By   Revision Number  Modifications            

*******************************************************************************************************************************************/ 



CREATE PROCEDURE [CES].[sp_Get_AssetDtls_CommonData] 

    @Asset_GUID VARCHAR (32)

AS 


BEGIN
	SET NOCOUNT ON
    BEGIN TRY
		DECLARE
				@ErrorMsg		VARCHAR(250),
				@result			VARCHAR(MAX),
				@asset_input	NVARCHAR(MAX),
				@current_date	DATE = DATEADD(dd, DATEDIFF(dd, 0, GETDATE()), 0),
				@ve_comp_stat	VARCHAR(200),
				@de_comp_stat	VARCHAR(200),
				@uw_comp_stat	VARCHAR(200)

		DECLARE  @tbl_ComplianceStatus TABLE
		(
			asset_guid				VARCHAR(32),
			dtl_compliance			VARCHAR(100),
			dtl_risk_status			VARCHAR(100),
			dtl_frequency			VARCHAR(60),
			dtl_exam_type_id		DECIMAL(18),
			dtl_comp_date			DATE,
			dtl_exam_planned_date	DATE,
			dtl_exam_actual_date	DATE,			
			dtl_supplier			VARCHAR(64),

			ve_compliance			VARCHAR(100),
			ve_risk_status			VARCHAR(100),
			ve_frequency			VARCHAR(60),
			ve_exam_type_id			DECIMAL(18),
			ve_comp_date			DATE,
			ve_exam_planned_date	DATE,
			ve_exam_actual_date		DATE,			
			ve_supplier				VARCHAR(64),

			uw_compliance			VARCHAR(100),
			uw_risk_status			VARCHAR(100),
			uw_frequency			VARCHAR(60),
			uw_exam_type_id			DECIMAL(18),
			uw_comp_date			DATE,
			uw_exam_planned_date	DATE,
			uw_exam_actual_date		DATE,			
			uw_supplier				VARCHAR(64)
		)

		SET @asset_input = '["' + @Asset_GUID + '"]'

		--Retrieving the compliance status for the asset
		INSERT INTO @tbl_ComplianceStatus
		(
			asset_guid,
			dtl_compliance,
			dtl_risk_status,
			dtl_frequency,
			dtl_exam_type_id,
			dtl_comp_date,
			dtl_exam_planned_date,
			dtl_exam_actual_date,			
			dtl_supplier,

			ve_compliance,
			ve_risk_status,
			ve_frequency,
			ve_exam_type_id,
			ve_comp_date,
			ve_exam_planned_date,
			ve_exam_actual_date,			
			ve_supplier,

			uw_compliance,
			uw_risk_status,
			uw_frequency,
			uw_exam_type_id,
			uw_comp_date,
			uw_exam_planned_date,
			uw_exam_actual_date,			
			uw_supplier
		)
		EXEC [CES].[sp_Get_Asset_Compliance_Risk_Status] @asset_input,@current_date

		SELECT
			@ve_comp_stat = ve_compliance,
			@de_comp_stat = dtl_compliance,
			@uw_comp_stat = uw_compliance
		FROM @tbl_ComplianceStatus t

		--Generating the final output
		SELECT  
			o.REGION AS region ,
			ast.ASSET_NAME AS assetdesc,
			o.ROUTE AS route,
			AR.AREA_NAME AS area,
			ast.RAILWAY_ID AS ralway_id,
			at.ASSET_TYPE_DESC AS asset_type,
			ost.REF_VALUE AS op_status,
			elr.ELR_CODE AS elr,
			(ast.START_MILES + ast.START_YARDS/1760) AS start_mileage,
			(ast.END_MILES + ast.END_YARDS/1760) AS end_mileage,
			pm.REF_VALUE as prim_material,
			ast.OWNING_PARTY as owning_party,
			NULL AS gps_start,
			NULL gps_end,
			ast.STRUCTURE_CARRIES AS stuct_carry,
			ast.STRUCTURE_OVER AS struct_over,
			IIF(HCE_FLAG = 'Y','Yes', 'No') AS hce_flag,
			ast.asset_guid,
			df.total_defect_cnt,
			df.open_defect_cnt,
			NULL AS picture_uri,
			ast.CMI_SCORE AS cmi_score,
			@ve_comp_stat AS ve_comp_stat,
			@de_comp_stat AS de_comp_stat,
			@uw_comp_stat AS uw_comp_stat,
			CASE WHEN ast.TENANTED_FLG = 'Y' THEN 'Yes'
				 WHEN ast.TENANTED_FLG = 'N' THEN 'No'
				 ELSE 'N/A'
			END AS tenanted_flg,
			ast.ASSET_IMAGE_NAME AS asset_img_name,
			ast.ASSET_IMAGE_LINK AS asset_img_path
		FROM [CES].ASSET AS ast
		INNER JOIN [CES].ORG AS o 
		ON ast.ORG_SR_KEY=o.ORG_SR_KEY
		INNER JOIN [CES].AREA AS ar 
		ON ast.AREA_SR_KEY=ar.AREA_SR_KEY
		INNER JOIN [CES].ASSET_TYPE AS at 
		ON AST.ASSET_TYPE_SR_KEY=at.ASSET_TYPE_SR_KEY
		INNER JOIN [CES].ENGINE_LINE_REF elr
		ON ast.ENG_LINE_REF = elr.ELR_SR_KEY
		LEFT JOIN [CES].[REFERENCE_VALUE] pm
		ON pm.REF_VAL_SR_KEY = ast.PRIMARY_MATERIAL
		LEFT JOIN [CES].[REFERENCE_VALUE] ost
		ON ost.REF_VAL_SR_KEY = ast.OPERATIONAL_STATUS
		LEFT JOIN 
			(
				SELECT
					ASSET_GUID,
					COUNT(DISTINCT DEFECT_ID) AS total_defect_cnt,
					COUNT(DISTINCT CASE WHEN FLAG_FOR_CLOSURE = 'N' THEN DEFECT_ID ELSE NULL END) AS open_defect_cnt
				FROM [CES].DEFECT  
				WHERE ASSET_GUID = @Asset_GUID
				AND ISACTIVE = 1
				GROUP BY ASSET_GUID
			)df
		ON	ast.ASSET_GUID = df.ASSET_GUID
		WHERE ast.ASSET_GUID = @Asset_GUID
		AND ast.ISACTIVE = 1
		AND o.ISACTIVE = 1
		AND ar.ISACTIVE = 1
		AND at.ISACTIVE = 1
		
		FOR JSON PATH,INCLUDE_NULL_VALUES,WITHOUT_ARRAY_WRAPPER  

	END TRY

	BEGIN CATCH
		SET @ErrorMsg = ERROR_MESSAGE() + 
						' Line Num:' + CONVERT(VARCHAR(5), ERROR_LINE()) + 
						',ErrorNum:' + CONVERT(VARCHAR(5), ERROR_NUMBER()) + 
						',Severity:' + CONVERT(VARCHAR(5), ERROR_SEVERITY()) + 
						',State:' + CONVERT(VARCHAR(10), ERROR_STATE()) + 
						',Procedure:' + CONVERT(VARCHAR(25), OBJECT_NAME(@@procid)) +
						',Procedure:' + CONVERT(VARCHAR(25), ERROR_PROCEDURE());  

		THROW 50000,@ErrorMsg,1;
	END CATCH

	SET NOCOUNT OFF
  END
