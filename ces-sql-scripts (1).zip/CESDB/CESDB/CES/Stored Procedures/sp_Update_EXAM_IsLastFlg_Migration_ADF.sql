﻿
/***************************************************************************************************************************************            
* Name						: sp_Update_EXAM_IsLastFlg_Migration_ADF     
* Created By				: Cognizant            
* Date Created				: 28-Feb-2021           
* Description				: This stored procedure updates the Exam Table ISLAST flag through ADF.  
* Input Parameters			: NIL   
* Output Parameters			: Returns 1 for succesful save, else 0            
* Return Value				: N/A            
* Assumptions				: None    
* Execution Statement		: EXEC CES.sp_Update_EXAM_IsLastFlg_Migration_ADF 						
* Modified Date     Modified By   Revision Number  Modifications            

*******************************************************************************************************************************************/ 

CREATE PROCEDURE [CES].[sp_Update_EXAM_IsLastFlg_Migration_ADF]
	
AS 
BEGIN
	SET NOCOUNT ON
    BEGIN TRY
		DECLARE
				@ErrorMsg			VARCHAR(250),
				@ErrorDescription   VARCHAR(4000),
				@Output				BIT = 0
	
	BEGIN TRAN
		Update CES.EXAM
		SET IS_LAST_EXAM = 'N'

		UPDATE e
		SET IS_LAST_EXAM = 'Y'
		FROM CES.EXAM e
		JOIN (
			SELECT 
				EXAM_SR_KEY
			FROM
				(SELECT EXAM_SR_KEY,
						DENSE_RANK() OVER (PARTITION BY ASSET_GUID, EXAM_TYPE_SR_KEY ORDER BY CASE WHEN RV.REF_VALUE IN ('In Progress','Completed') THEN 1 ELSE 0 END DESC,
						ISNULL(EXAM_ACTUAL_DATE,CONVERT(DATE,'1/1/1900',103)) DESC, EXAM_ID DESC) rnk
				 FROM CES.EXAM EX
				 JOIN CES.REFERENCE_VALUE RV ON EXAM_REQ_STATUS = RV.REF_VAL_SR_KEY
				 WHERE EX.ISACTIVE =1
				)t
			WHERE rnk=1
			)f
		ON e.EXAM_SR_KEY = f.EXAM_SR_KEY

	COMMIT TRAN
	END TRY
BEGIN CATCH
		IF (@@TRANCOUNT >0)
			ROLLBACK TRAN
		
		IF @ErrorMsg IS NULL
			SET @ErrorMsg = ERROR_MESSAGE() 
		
		SET @ErrorDescription = @ErrorMsg + 
							' Line Num:' + CONVERT(VARCHAR(5), ERROR_LINE()) + 
							',ErrorNum:' + CONVERT(VARCHAR(5), ERROR_NUMBER()) + 
							',Severity:' + CONVERT(VARCHAR(5), ERROR_SEVERITY()) + 
							',State:' + CONVERT(VARCHAR(10), ERROR_STATE()) + 
							',Procedure:' + CONVERT(VARCHAR(25), OBJECT_NAME(@@procid)) +
							',Procedure:' + CONVERT(VARCHAR(25), ERROR_PROCEDURE())

		SET @Output = 0;
		SELECT @Output AS SaveStatus,@ErrorMsg AS ErrorMsg;

		THROW 50000,@ErrorDescription,1;
	END CATCH

	SET NOCOUNT OFF
  END