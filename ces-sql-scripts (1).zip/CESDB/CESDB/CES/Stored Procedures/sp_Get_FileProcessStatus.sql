﻿/***************************************************************************************************************************************            
* Name						: sp_Get_FileProcessStatus            
* Created By				: Cognizant            
* Date Created				: 03-Feb-2021           
* Description				: This stored procedure fetches the file processing status of the file submitted by the supplier   
* Input Parameters			: File Name     
* Output Parameters			: JSON            
* Return Value				: N/A            
* Assumptions				: None    
* Execution Statement		: Exec [CES].sp_Get_FileProcessStatus 'CES_ExamData_Amey Rail_20200203123456.xml'
*								
* Modified Date     Modified By   Revision Number  Modifications            

*******************************************************************************************************************************************/ 



CREATE PROCEDURE [CES].[sp_Get_FileProcessStatus]
	@File_Name		VARCHAR(500)

AS
BEGIN

	SET NOCOUNT ON
	BEGIN TRY
		DECLARE
				@ErrorMsg	VARCHAR(250)

		SELECT
			CASE WHEN FILE_PROCESS_STATUS = 'Succeeded' THEN 'Yes'
				WHEN FILE_PROCESS_STATUS = 'Failed' THEN 'No'
				ELSE 'N/A'
			END AS success,
			ERROR_DESCRIPTION AS message
		FROM CES.FILE_PROCESS_LOG
		WHERE [FILE_NAME] = @File_Name
		AND ISACTIVE =1
		FOR JSON AUTO, INCLUDE_NULL_VALUES,WITHOUT_ARRAY_WRAPPER

	END TRY
	BEGIN CATCH

		ROLLBACK TRAN
		SET @ErrorMsg = ERROR_MESSAGE() + 
						' Line Num:' + CONVERT(VARCHAR(5), ERROR_LINE()) + 
						',ErrorNum:' + CONVERT(VARCHAR(5), ERROR_NUMBER()) + 
						',Severity:' + CONVERT(VARCHAR(5), ERROR_SEVERITY()) + 
						',State:' + CONVERT(VARCHAR(10), ERROR_STATE()) + 
						',Procedure:' + CONVERT(VARCHAR(25), OBJECT_NAME(@@procid)) +
						',Procedure:' + CONVERT(VARCHAR(25), ERROR_PROCEDURE());  

		THROW 50000,@ErrorMsg,1;
	END CATCH

	SET NOCOUNT OFF
END