﻿
/***************************************************************************************************************************************            
* Name						: sp_Update_EXAM_POSTEXAMDATA_ADF     
* Created By				: Cognizant            
* Date Created				: 07-july-2021           
* Description				: This stored procedure updates the Exam Table for bulk Upload XML functionality through ADF.  
* Input Parameters			: JSON   
* Output Parameters			: Returns 1 for succesful save, else 0            
* Return Value				: N/A            
* Assumptions				: None    
* Execution Statement		: EXEC CES.sp_Update_EXAM_ISLAST_POSTEXAMDATA_ADF '[
																	{
																	"EXAM_ID":13266366
																	,"ASSET_GUID":"388BD72289388B77E050E70A82864174"
																	,"EXAM_ACTUAL_DATE":"2021-03-15"
																	,"EXAM_TYPE_SR_KEY":1
																	,"SPAN_TEXT":"1"
																	,"EXAM_COMPLETED_IND":"N"
																	,"OBSERVED_UNDER_LOAD":"Yes"
																	,"AT_OR_BETWEEN_STATIONS":"Unknown and Unknown"
																	,"CMI_DATE":"2021-06-11"
																	,"CMI_SCORE":78
																	,"EXAMINER_COMMENT":"examiner comment test"
																	,"REVIEWER_COMMENT":"Comment for test"
																	,"EXAMINER_NAME":"Trevor Strand"
																	,"REVIEWER_NAME":"Peter Tobutt"
																	,"EXAM_SIGNOFF_DATE":"2021-06-11"
																	,"EXAM_SUBMISSION_DATE":"2021-07-19 11:17:22"
																	,"STRUC_DESCRIPTION":"KIRKWOOD ROAD (OP)"
																	,"ERP_der":492
																	,"ERS_der":5
																	,"SUPPLIER_REPORT_FILENAME":"CES_ExamDataUpload_All_20210616061010.pdf"
																	,"SUPPLIER_REPORT_REFERENCE":"https://sacuksnprdiicesdev0001.blob.core.windows.net/ces-adls/ces-adls-data/INC/Raw/PostExamDataRaw/All/YEAR-2021/MONTH-06/DAY-16/HOUR-06/MINUTE-10/SECOND-10"
																	,"SUPPLIER_ZIP_FILENAME":"CES_ExamDataUpload_All_20210616061010.zip"
																	,"UPDATED_USER":"Amey Rail"
																	,"UPDATED_DATE":"2021-07-19 11:17:22"
																	}
																	]'	
*								
* Modified Date     Modified By   Revision Number  Modifications            

*******************************************************************************************************************************************/ 

CREATE  PROCEDURE [CES].[sp_Update_EXAM_POSTEXAMDATA_ADF]
	@Input_JSON		NVARCHAR(MAX)

AS 

BEGIN
	SET NOCOUNT ON
    BEGIN TRY
		DECLARE
				@ErrorMsg			VARCHAR(250),
				@ErrorDescription   VARCHAR(4000),
				@Output				BIT = 0,
				@CurrentDate		DATETIME  = GETDATE(),
				@User				VARCHAR(16) = 'CES'

	
		DROP TABLE IF EXISTS #tmpAsPostExam_ADF

		CREATE TABLE #tmpAsPostExam_ADF
		(
			EXAM_ID					DECIMAL(9),
			ASSET_GUID				VARCHAR(32),
			EXAM_ACTUAL_DATE		date,
			EXAM_TYPE_SR_KEY		DECIMAL(9),
			SPAN_TEXT				VARCHAR(10),
			EXAM_COMPLETED_IND		VARCHAR(5),
			OBSERVED_UNDER_LOAD		bit,
			AT_OR_BETWEEN_STATIONS	VARCHAR(64),
			CMI_DATE				date,
			CMI_SCORE				DECIMAL(9),
			EXAMINER_COMMENT		VARCHAR(4000),
			REVIEWER_COMMENT		VARCHAR(4000),
			EXAMINER_NAME			VARCHAR(64),
			REVIEWER_NAME			VARCHAR(64),
			EXAM_SIGNOFF_DATE		date,
			EXAM_SUBMISSION_DATE	date,
			STRUC_DESCRIPTION		VARCHAR(1000),
			ERP_der					DECIMAL(9),
			ERS_der					DECIMAL(9),
			SUPPLIER_SR_KEY			DECIMAL(9),
			SUPPLIER_REPORT_FILENAME	VARCHAR(200),
			SUPPLIER_REPORT_REFERENCE	VARCHAR(500),
			SUPPLIER_ZIP_FILENAME	VARCHAR(200),
			UPDATED_USER			VARCHAR(64),
			UPDATED_DATE			datetime
		)

		DECLARE @result TABLE
		(
			[Output]	SMALLINT,
			ErrorMsg	VARCHAR(4000)	
		) 

		--Parsing the input JSON and gathering the records					
		INSERT INTO #tmpAsPostExam_ADF
		(
			EXAM_ID,				
			ASSET_GUID,				
			EXAM_ACTUAL_DATE,		
			EXAM_TYPE_SR_KEY,		
			SPAN_TEXT,				
			EXAM_COMPLETED_IND,		
			OBSERVED_UNDER_LOAD,	
			AT_OR_BETWEEN_STATIONS,	
			CMI_DATE,				
			CMI_SCORE,				
			EXAMINER_COMMENT,		
			REVIEWER_COMMENT,		
			EXAMINER_NAME,			
			REVIEWER_NAME,			
			EXAM_SIGNOFF_DATE,		
			EXAM_SUBMISSION_DATE,	
			STRUC_DESCRIPTION,		
			ERP_der,					
			ERS_der,
			SUPPLIER_SR_KEY,
			SUPPLIER_REPORT_FILENAME,
			SUPPLIER_REPORT_REFERENCE,
			SUPPLIER_ZIP_FILENAME,
			UPDATED_USER,		
			UPDATED_DATE
		)
		SELECT				
			exm.EXAM_ID,				
			exm.ASSET_GUID,				
			exm.EXAM_ACTUAL_DATE,		
			exm.EXAM_TYPE_SR_KEY,		
			exm.SPAN_TEXT,				
			exm.EXAM_COMPLETED_IND,		
			CASE WHEN exm.OBSERVED_UNDER_LOAD = 'Yes' THEN 1 ELSE 0 END,	
			exm.AT_OR_BETWEEN_STATIONS,	
			exm.CMI_DATE,				
			exm.CMI_SCORE,				
			exm.EXAMINER_COMMENT,		
			exm.REVIEWER_COMMENT,		
			exm.EXAMINER_NAME,			
			exm.REVIEWER_NAME,			
			exm.EXAM_SIGNOFF_DATE,		
			exm.EXAM_SUBMISSION_DATE,	
			exm.STRUC_DESCRIPTION,		
			exm.ERP_der,					
			exm.ERS_der,
			exm.SUPPLIER_SR_KEY,
			exm.SUPPLIER_REPORT_FILENAME,
			exm.SUPPLIER_REPORT_REFERENCE,
			exm.SUPPLIER_ZIP_FILENAME,
			exm.UPDATED_USER,		
			exm.UPDATED_DATE	
		FROM	OPENJSON(@Input_JSON)
		WITH 
			(
				EXAM_ID					DECIMAL(9),
				ASSET_GUID				VARCHAR(32),
				EXAM_ACTUAL_DATE		date,
				EXAM_TYPE_SR_KEY		DECIMAL(9),
				SPAN_TEXT				VARCHAR(10),
				EXAM_COMPLETED_IND		VARCHAR(5),
				OBSERVED_UNDER_LOAD		VARCHAR(5),
				AT_OR_BETWEEN_STATIONS	VARCHAR(64),
				CMI_DATE				date,
				CMI_SCORE				DECIMAL(9),
				EXAMINER_COMMENT		VARCHAR(4000),
				REVIEWER_COMMENT		VARCHAR(4000),
				EXAMINER_NAME			VARCHAR(64),
				REVIEWER_NAME			VARCHAR(64),
				EXAM_SIGNOFF_DATE		date,
				EXAM_SUBMISSION_DATE	date,
				STRUC_DESCRIPTION		VARCHAR(1000),
				ERP_der					DECIMAL(9),
				ERS_der					DECIMAL(9),
				SUPPLIER_SR_KEY			DECIMAL(9),
				SUPPLIER_REPORT_FILENAME	VARCHAR(200),
				SUPPLIER_REPORT_REFERENCE	VARCHAR(500),
				SUPPLIER_ZIP_FILENAME	VARCHAR(200),
				UPDATED_USER			VARCHAR(64),
				UPDATED_DATE			datetime
			) AS exm

BEGIN TRAN

			UPDATE e1 SET			
			e1.ASSET_GUID= tempExam.ASSET_GUID,			
			e1.EXAM_ACTUAL_DATE= tempExam.EXAM_ACTUAL_DATE,	
			e1.EXAM_SUBMISSION_DATE= tempExam.EXAM_SUBMISSION_DATE,
			e1.EXAM_TYPE_SR_KEY= tempExam.EXAM_TYPE_SR_KEY,	
			e1.EXAM_REQ_STATUS= tempExam.ERS_der,					
			e1.EXAM_COMPLETED_IND= tempExam.EXAM_COMPLETED_IND,
			e1.EXAMINER_NAME= tempExam.EXAMINER_NAME,			
			e1.EXAMINER_COMMENT= tempExam.EXAMINER_COMMENT,	
			e1.REVIEWER_NAME= tempExam.REVIEWER_NAME,
			e1.REVIEWER_COMMENT= tempExam.REVIEWER_COMMENT,
			e1.SUPPLIER_SR_KEY = tempExam.SUPPLIER_SR_KEY,
			e1.SUPPLIER_REPORT_FILENAME = tempExam.SUPPLIER_REPORT_FILENAME,
			e1.SUPPLIER_REPORT_REFERENCE = tempExam.SUPPLIER_REPORT_REFERENCE,
			e1.SUPPLIER_ZIP_FILENAME = tempExam.SUPPLIER_ZIP_FILENAME,
			e1.CMI_SCORE= tempExam.CMI_SCORE,
			e1.CMI_DATE= tempExam.CMI_DATE,
			e1.STRUC_DESCRIPTION= tempExam.STRUC_DESCRIPTION,
			e1.AT_OR_BETWEEN_STATIONS= tempExam.AT_OR_BETWEEN_STATIONS,
			e1.OBSERVED_UNDER_LOAD= tempExam.OBSERVED_UNDER_LOAD,
			e1.SPAN_TEXT= tempExam.SPAN_TEXT,
			e1.EXAM_REPORT_STATUS= tempExam.ERP_der,
			e1.UPDATED_USER= tempExam.UPDATED_USER,	
			e1.UPDATED_DATE= tempExam.UPDATED_DATE
		FROM CES.EXAM e1
		Inner join #tmpAsPostExam_ADF tempExam ON e1.EXAM_ID = tempExam.EXAM_ID

		--Update the Records ISLAST = 'N' for all Asset and Exam Type
		--This table will be used by child SP [sp_Update_EXAM_ISLASTFLG] called later
		DROP TABLE IF EXISTS #tmpExamData

		CREATE TABLE #tmpExamData
		(
			ASSET_GUID				VARCHAR(32),
			EXAM_TYPE_SR_KEY		DECIMAL(9)
			)

		INSERT INTO #tmpExamData
		(
			ASSET_GUID,
			EXAM_TYPE_SR_KEY
		)
		SELECT DISTINCT
			t.ASSET_GUID,
			t.EXAM_TYPE_SR_KEY
		FROM #tmpAsPostExam_ADF t

		DECLARE @userkey varchar(64)
		SET @userkey = (SELECT TOP 1 UPDATED_USER from #tmpAsPostExam_ADF)

		INSERT INTO @result([Output],ErrorMsg)
			EXEC [CES].[sp_Update_EXAM_ISLASTFLG] @userkey

COMMIT TRAN
	SET @Output = 1
	SELECT @Output AS SaveStatus,NULL AS ErrorMsg;
	END TRY
BEGIN CATCH
		IF (@@TRANCOUNT >0)
			ROLLBACK TRAN
		
		IF @ErrorMsg IS NULL
			SET @ErrorMsg = ERROR_MESSAGE() 
		
		SET @ErrorDescription = @ErrorMsg + 
							' Line Num:' + CONVERT(VARCHAR(5), ERROR_LINE()) + 
							',ErrorNum:' + CONVERT(VARCHAR(5), ERROR_NUMBER()) + 
							',Severity:' + CONVERT(VARCHAR(5), ERROR_SEVERITY()) + 
							',State:' + CONVERT(VARCHAR(10), ERROR_STATE()) + 
							',Procedure:' + CONVERT(VARCHAR(25), OBJECT_NAME(@@procid)) +
							',Procedure:' + CONVERT(VARCHAR(25), ERROR_PROCEDURE())

		SET @Output = 0;
		SELECT @Output AS SaveStatus,@ErrorMsg AS ErrorMsg;
		
		THROW 50000,@ErrorDescription,1;
	END CATCH
	SET NOCOUNT OFF
 END