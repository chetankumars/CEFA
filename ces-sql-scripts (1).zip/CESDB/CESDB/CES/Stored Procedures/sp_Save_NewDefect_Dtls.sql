﻿
/***************************************************************************************************************************************            
* Name						: sp_Save_NewDefect_Dtls        
* Created By				: Cognizant            
* Date Created				: 23-Dec-2020           
* Description				: This stored procedure saves the Add row for an existing defect or adds a new defect.  
* Input Parameters			: JSON    
* Output Parameters			: Returns 1 for succesful save, else 0            
* Return Value				: N/A            
* Assumptions				: None    
* Execution Statement		: EXEC CES.sp_Save_NewDefect_Dtls '{
																"defect_id": 6601,
																"user_key": "03c2d593-24ed-4494-a25c-377d9e915891",
																"supplier_id": 0,
																"asset_guid": "3978559C32A945D9E04400306E4AD01A",
																"description" : "Longitudinal fractures",
																"location": "Soffit, 4m and 15m from upside, 4m from downside",
																"loc_major": "",
																"loc_minor": "",
																"exam_dt": "2021-04-03",
																"exam_id": null,	
																"access_req": "Y",
																"exam_type_id": 16,
																"recomm_no": "",
																"risk_score": 2,
																"deterioration_flg": "Y",
																"repaired_flg": "N",
																"closure_flg": "N",
																"accs_grant_flg": "Y",
																"comments": "Test purpose",
																"isnewdefect": "N"
															}'
*								
* Modified Date     Modified By   Revision Number  Modifications            

*******************************************************************************************************************************************/ 



CREATE PROCEDURE [CES].[sp_Save_NewDefect_Dtls]
	@Input_JSON		NVARCHAR(MAX)
	--@Output			BIT OUTPUT
AS 

BEGIN
	SET NOCOUNT ON
    BEGIN TRY
		DECLARE
				@ErrorMsg			VARCHAR(250),
				@ErrorDescription	VARCHAR(4000),
				@result				NVARCHAR(MAX),
				@defect_id			DECIMAL(18),
				@user_key			VARCHAR(64),
				@supplier_id		DECIMAL(18),
				@asset_guid			VARCHAR(32),
				@description		VARCHAR(256),
				@location			VARCHAR(250),
				@loc_major			VARCHAR(250),
				@loc_minor			VARCHAR(250),
				@exam_dt			DATE,
				@exam_id			DECIMAL(18),
				@access_req			VARCHAR(5),
				@exam_type_id		DECIMAL(18),
				@recomm_no			VARCHAR(5),
				@risk_score			VARCHAR(10),
				@deterioration_flg	VARCHAR(64),
				@repaired_flg		VARCHAR(5),
				@closure_flg		CHAR(1),
				@accs_grant_flg		VARCHAR(5),
				@comments			VARCHAR(1000),
				@isnewdefect		CHAR(1),
				@exam_sr_key		DECIMAL(18) = NULL,
				@Output				BIT = 0,
				@exam_completed_ind VARCHAR(5),
				@exam_typ_exception	CHAR(1)

			SELECT 
				@defect_id = COALESCE(@defect_id,CASE LOWER([key]) WHEN 'defect_id' THEN [value] ELSE NULL END),
				@user_key = COALESCE(@user_key,CASE LOWER([key]) WHEN 'user_key' THEN [value] ELSE NULL END),
				@supplier_id = COALESCE(@supplier_id,CASE LOWER([key]) WHEN 'supplier_id' THEN [value] ELSE NULL END),
				@asset_guid = COALESCE(@asset_guid,CASE LOWER([key]) WHEN 'asset_guid' THEN [value] ELSE NULL END),
				@description = COALESCE(@description,CASE LOWER([key]) WHEN 'description' THEN [value] ELSE NULL END),
				@location = COALESCE(@location,CASE LOWER([key]) WHEN 'location' THEN [value] ELSE NULL END),
				@loc_major = COALESCE(@loc_major,CASE LOWER([key]) WHEN 'loc_major' THEN [value] ELSE NULL END),
				@loc_minor = COALESCE(@loc_minor,CASE LOWER([key]) WHEN 'loc_minor' THEN [value] ELSE NULL END),
				@exam_dt = COALESCE(@exam_dt,CASE LOWER([key]) WHEN 'exam_dt' THEN [value] ELSE NULL END),
				@exam_id = COALESCE(@exam_id,CASE LOWER([key]) WHEN 'exam_id' THEN [value] ELSE NULL END),
				@access_req = COALESCE(@access_req,CASE LOWER([key]) WHEN 'access_req' THEN [value] ELSE NULL END),
				@exam_type_id = COALESCE(@exam_type_id,CASE LOWER([key]) WHEN 'exam_type_id' THEN [value] ELSE NULL END),
				@recomm_no = COALESCE(@recomm_no,CASE LOWER([key]) WHEN 'recomm_no' THEN [value] ELSE NULL END),
				@risk_score = COALESCE(@risk_score,CASE LOWER([key]) WHEN 'risk_score' THEN [value] ELSE NULL END),
				@deterioration_flg = COALESCE(@deterioration_flg,CASE LOWER([key]) WHEN 'deterioration_flg' THEN [value] ELSE NULL END),
				@repaired_flg = COALESCE(@repaired_flg,CASE LOWER([key]) WHEN 'repaired_flg' THEN [value] ELSE NULL END),
				@closure_flg = COALESCE(@closure_flg,CASE LOWER([key]) WHEN 'closure_flg' THEN [value] ELSE NULL END),
				@accs_grant_flg = COALESCE(@accs_grant_flg,CASE LOWER([key]) WHEN 'accs_grant_flg' THEN [value] ELSE NULL END),
				@comments = COALESCE(@comments,CASE LOWER([key]) WHEN 'comments' THEN [value] ELSE NULL END),
				@isnewdefect = COALESCE(@isnewdefect,CASE LOWER([key]) WHEN 'isnewdefect' THEN [value] ELSE NULL END)

			FROM	OPENJSON(@Input_JSON);

			IF EXISTS (SELECT 1 FROM CES.EXAM_TYPE WHERE EXAM_TYPE_SR_KEY = @exam_type_id AND EXAM_TYPE IN ('Network Rail Site Visit','Inspection For Assessment') )
				SET @exam_typ_exception = 'Y'
			ELSE
				SET @exam_typ_exception = 'N'

			IF (@defect_id IS NULL AND @user_key IS NULL AND @supplier_id IS NULL AND @asset_guid IS NULL AND 
			@description IS NULL AND @location IS NULL AND @exam_dt IS NULL AND @access_req IS NULL AND 
			@exam_type_id IS NULL AND @risk_score IS NULL AND @deterioration_flg IS NULL AND @repaired_flg IS NULL
			AND @closure_flg IS NULL AND @accs_grant_flg IS NULL AND @isnewdefect IS NULL)

			BEGIN
				SET @ErrorMsg = 'Mandatory Input parameter value(s) is missing';
				THROW 50000,@ErrorMsg,1;
			END

			IF @isnewdefect = 'N'
			BEGIN
				IF NOT EXISTS (SELECT 1 FROM [CES].DEFECT WHERE DEFECT_ID = @defect_id)
				BEGIN
				
					SET @ErrorMsg = 'Defect does not exist. Please check the details again.';
					THROW 50000,@ErrorMsg,1;
				END
			END
			ELSE
			BEGIN
			
				IF EXISTS (SELECT 1 FROM [CES].DEFECT WHERE DEFECT_ID = @defect_id)
				BEGIN
					SET @ErrorMsg = 'Defect already exists. Please check the details again.';
					THROW 50000,@ErrorMsg,1;
				END
			END

			IF (@exam_typ_exception = 'N')  ---Validation required to have a valid exam -defect mapping if it is not a site visit or inspection for assessment
			BEGIN
				SELECT 
					@exam_sr_key = EXAM_SR_KEY,
					@exam_completed_ind = EXAM_COMPLETED_IND
				FROM [CES].EXAM
				WHERE	EXAM_ACTUAL_DATE = @exam_dt
				AND		EXAM_TYPE_SR_KEY = @exam_type_id
				AND		EXAM_ID = ISNULL(@exam_id,EXAM_ID)
				AND		ASSET_GUID = @asset_guid
				AND		ISACTIVE = 1

				IF (@exam_sr_key IS NULL)
				BEGIN
					SET @ErrorMsg = 'The Exam Date or Exam Type combination selected is not valid for an existing exam';
					THROW 50000,@ErrorMsg,1;
				END
				ELSE IF (@exam_completed_ind = 'Y')
				BEGIN
					SET @ErrorMsg = 'The Exam is already in completed status.';
					THROW 50000,@ErrorMsg,1;
				END
			END

			IF @isnewdefect = 'N' -- For adding row to an exising defect check if the user is going to add another defect for same exam
			BEGIN
				IF @exam_typ_exception = 'N'  -- For all other exam types except site visit/inspection check check for existing exam ID
				BEGIN
					IF EXISTS (SELECT 1 FROM [CES].DEFECT WHERE DEFECT_ID = @defect_id 
								AND EXAM_SR_KEY = @exam_sr_key)
					BEGIN
				
						SET @ErrorMsg = 'The Exam ID against this defect already exists.';
						THROW 50000,@ErrorMsg,1;
					END
				END
				ELSE IF @exam_typ_exception = 'Y'  -- For exam types site visit/inspection check check for existing exam date
				BEGIN
					IF EXISTS (SELECT 1 FROM [CES].DEFECT WHERE DEFECT_ID = @defect_id 
								AND EXAM_DATE = @exam_dt AND EXAM_TYPE_SR_KEY = @exam_type_id)
					BEGIN
				
						SET @ErrorMsg = 'Defect already exists for this exam type and asset on the same exam date.';
						THROW 50000,@ErrorMsg,1;
					END
				END
			END
			
			--IF @isnewdefect = 'Y'
			--BEGIN
				BEGIN TRAN

					INSERT INTO [CES].[DEFECT]
					   ([DEFECT_ID]
					   ,[ASSET_GUID]
					   ,[EXAM_SR_KEY]
					   ,[DESCRIPTION]
					   ,[LOCATION]
					   ,[LOCATION_MAJOR]
					   ,[LOCATION_MINOR]
					   ,[RISK_SCORE]
					   ,[DETERIORATION]
					   ,[ACCESS_GAINED]
					   ,[ACCESS_REQUIRED]
					   ,[REPAIRED]
					   ,[RECOMMEND_RAISED]
					   ,[FLAG_FOR_CLOSURE]
					   ,[ENGINEER_COMMENTS]
					   ,[DEFECT_USER]
					   ,[EXAM_DATE]
					   ,[EXAM_TYPE_SR_KEY]
					   ,[CREATED_USER]
					   ,[CREATED_DATE]
					   ,[ISACTIVE])
					VALUES
					(
						@defect_id,
						@asset_guid,
						@exam_sr_key,
						@description,
						@location,
						@loc_major,
						@loc_minor,
						@risk_score,
						@deterioration_flg,
						CASE WHEN @accs_grant_flg = 'Yes' THEN 'Y'
							WHEN @accs_grant_flg = 'No' THEN 'N'
							ELSE @accs_grant_flg
						END,
						CASE WHEN @access_req = 'Yes' THEN 'Y'
							WHEN @access_req = 'No' THEN 'N'
							ELSE @access_req
						END,
						@repaired_flg,
						@recomm_no,
						@closure_flg,
						@comments,
						@user_key,
						CASE WHEN @exam_typ_exception = 'Y' THEN @exam_dt ELSE NULL END,
						CASE WHEN @exam_typ_exception = 'Y' THEN @exam_type_id ELSE NULL END,
						@user_key,
						GETDATE(),
						1
					)

				COMMIT TRAN
				SET @Output = 1

				SELECT @Output AS SaveStatus,NULL AS ErrorMsg;

	END TRY

	BEGIN CATCH
		IF (@@TRANCOUNT >0)
			ROLLBACK TRAN
		
		IF @ErrorMsg IS NULL
			SET @ErrorMsg = ERROR_MESSAGE() 
		
		SET @ErrorDescription = @ErrorMsg + 
							' Line Num:' + CONVERT(VARCHAR(5), ERROR_LINE()) + 
							',ErrorNum:' + CONVERT(VARCHAR(5), ERROR_NUMBER()) + 
							',Severity:' + CONVERT(VARCHAR(5), ERROR_SEVERITY()) + 
							',State:' + CONVERT(VARCHAR(10), ERROR_STATE()) + 
							',Procedure:' + CONVERT(VARCHAR(25), OBJECT_NAME(@@procid)) +
							',Procedure:' + CONVERT(VARCHAR(25), ERROR_PROCEDURE())

		SET @Output = 0;
		SELECT @Output AS SaveStatus,@ErrorMsg AS ErrorMsg;

		THROW 50000,@ErrorDescription,1;
	END CATCH
	
	SET NOCOUNT OFF
  END
