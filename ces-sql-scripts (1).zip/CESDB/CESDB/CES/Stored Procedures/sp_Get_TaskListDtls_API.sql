﻿
/***************************************************************************************************************************************            
* Name						: sp_Get_TaskListDtls_API            
* Created By				: Cognizant            
* Date Created				: 29-Mar-2021           
* Description				: This stored procedure provides the task list details for given input parameters.  
* Input Parameters			: JSON      
* Output Parameters			: @OUT_ErrorNo            
* Return Value				: N/A            
* Assumptions				: None    
* Execution Statement		: Exec CES.sp_Get_TaskListDtls_API '{ 
																  "region":"wales and western",
																  "route":null,
																  "financialyear": "2021/2022",
																  "suppliername": "Amey Rail",
																  "pageNo":  1, 
																  "rowsCount": 100  
																}'
							  
*								
* Modified Date     Modified By   Revision Number  Modifications            

*******************************************************************************************************************************************/ 



CREATE PROCEDURE [CES].[sp_Get_TaskListDtls_API]
	@Input_JSON		NVARCHAR(MAX)
AS 
BEGIN
	SET NOCOUNT ON
	
	
	BEGIN TRY
		DECLARE
				@ErrorMsg			VARCHAR(250),
				@ErrorDescription	VARCHAR(4000),
				@result				NVARCHAR(MAX),
				@region_name		VARCHAR(64),
				@region    			VARCHAR(64),
				@route_name			VARCHAR(64),
				@financial_year		VARCHAR(64),
				@route_id			DECIMAL(18),
				@area_id			DECIMAL(18),
				@elr_id				NVARCHAR(MAX),
				@supplier_name    	VARCHAR(64),
				@supplier_id		DECIMAL(18),
				@totalresultcnt		INT = 0,
				@pageno				INT,
				@rows_count			INT,				
				@tasklist_yr_id		DECIMAL(18),
				@current_date		DATE = GETDATE(),
				@end_dt_default		DATE = CONVERT(DATE,'31/12/9999',103)
				
				DROP TABLE IF EXISTS #tbl_SearchResult;
				DROP TABLE IF EXISTS #tbl_Asset;

		CREATE TABLE #tbl_SearchResult
		(
				asset_guid					VARCHAR(32),
				region						VARCHAR(64),
				route						VARCHAR(64),
				area						VARCHAR(64),
				elr							VARCHAR(4),
				start_mileage				DECIMAL(18,4),
				end_mileage					DECIMAL(18,4),
				railway_id					VARCHAR(64),
				asset_desc					VARCHAR(200),
				asset_grp					VARCHAR(64),
				asset_type					VARCHAR(64),
				exam_id						DECIMAL(18),
				exam_frequency				VARCHAR(20),
				exam_type					VARCHAR(32),
				due_dt						DATE,
				baseline_plan_dt			DATE,
				plan_dt						DATE,
				cr_id						VARCHAR(20),
				job_number					VARCHAR(8000),
				specific_exam_req			VARCHAR(1000),
				task_list_stat				VARCHAR(50),
				comments_to_sec				VARCHAR(4000),
				--task_list_id				DECIMAL(18),
				due_dt_earliest				DATE,
				due_dt_latest				DATE,
				max_tolerance_dt			DATE,
				exam_group_id				DECIMAL(18),
				hce_flg						VARCHAR(5),
				bcmi_required				VARCHAR(20),
				nr_internal_note			VARCHAR(4000),
				tenanted_arch				VARCHAR(5),
				exam_req_stat				VARCHAR(20),
				exam_rpt_stat				VARCHAR(20),		
				exam_date					DATE
		)

		DECLARE @tbl_org TABLE
		(
			ORG_SR_KEY	DECIMAL(18)
		)

		CREATE TABLE #tbl_Asset
		(
			ASSET_GUID			VARCHAR(32),
			ENG_LINE_REF		DECIMAL(18),
			RAILWAY_ID			VARCHAR(64),
			start_mileage		DECIMAL(18,5),
			end_mileage			DECIMAL(18,5),
			asset_desc			VARCHAR(200),
			AREA_SR_KEY			DECIMAL(18),
			ORG_SR_KEY			DECIMAL(18),
			ASSET_GROUP_SR_KEY	DECIMAL(18),
			ASSET_TYPE_SR_KEY	DECIMAL(18),
			hce_flag			CHAR(1),
			tenanted_flg		VARCHAR(1),
			totalcount			INT
		)

		SELECT 
			@region_name = COALESCE(@region_name,CASE LOWER([key]) WHEN 'region' THEN [value] ELSE NULL END),
			@route_name = COALESCE(@route_name,CASE LOWER([key]) WHEN 'route' THEN [value] ELSE NULL END),
			@financial_year = COALESCE(@financial_year,CASE LOWER([key]) WHEN 'financialyear' THEN [value] ELSE NULL END),
			@supplier_name = COALESCE(@supplier_name,CASE LOWER([key]) WHEN 'suppliername' THEN [value] ELSE NULL END),
			@pageno = COALESCE(@pageno,CASE LOWER([key]) WHEN 'pageno' THEN [value] ELSE NULL END),
			@rows_count = COALESCE(@rows_count,CASE LOWER([key]) WHEN 'rowscount' THEN [value] ELSE NULL END)

		FROM	OPENJSON(@Input_JSON);
				
		-- Validation start

		IF (@region_name IS NULL OR @financial_year IS NULL OR @supplier_name IS NULL OR @pageno IS NULL OR @rows_count IS NULL)
		BEGIN

			SET @ErrorMsg = 'Mandatory Input value is missing';
			DROP TABLE IF EXISTS #tbl_SearchResult;
				DROP TABLE IF EXISTS #tbl_Asset;
			THROW 50000,@ErrorMsg,1;
		END

		IF (@rows_count > 100)
		BEGIN
			SET @ErrorMsg = 'Maximum number of assets can be returned is 100.';
			DROP TABLE IF EXISTS #tbl_SearchResult;
			DROP TABLE IF EXISTS #tbl_Asset;
			THROW 50000,@ErrorMsg,1;
		END

		INSERT INTO @tbl_org (ORG_SR_KEY)
		SELECT ORG_SR_KEY
		FROM CES.ORG
		WHERE REGION = @region_name
		AND (@route_name IS NULL OR (@route_name IS NOT NULL AND [ROUTE] = @route_name))
		AND ISACTIVE = 1 

		IF NOT EXISTS (SELECT 1 FROM @tbl_org)
		BEGIN
			SET @ErrorMsg = 'Region /Route Information passed in input is incorrect';
			DROP TABLE IF EXISTS #tbl_SearchResult;
				DROP TABLE IF EXISTS #tbl_Asset;
			THROW 50000,@ErrorMsg,1;
		END

	   
		
				
		SET @tasklist_yr_id = (SELECT RV.REF_VAL_SR_KEY FROM CES.REFERENCE_VALUE RV 
								WHERE  RV.REF_VALUE=@financial_year 
								AND RV.REF_TYP_SR_KEY = 
								(SELECT RT.REF_TYP_SR_KEY FROM CES.REFERENCE_TYPE RT
								WHERE REF_TYP_NAME='Financial Year') )

		IF (@tasklist_yr_id IS NULL)
		BEGIN
			SET @ErrorMsg = 'Financial year in input is not correct. Use format like YYYY/YYYY starting from 2021/2022.';
			DROP TABLE IF EXISTS #tbl_SearchResult;
				DROP TABLE IF EXISTS #tbl_Asset;
			THROW 50000,@ErrorMsg,1;
		END

		-- Validation end

		INSERT INTO #tbl_Asset
		(
			ASSET_GUID,
			ENG_LINE_REF,
			RAILWAY_ID,
			start_mileage,
			end_mileage,
			asset_desc,
			AREA_SR_KEY,
			ORG_SR_KEY,
			ASSET_GROUP_SR_KEY,
			ASSET_TYPE_SR_KEY,
			hce_flag,
			tenanted_flg,
			totalcount
		)
		SELECT
			ASSET_GUID,
			ENG_LINE_REF,
			RAILWAY_ID,
			start_mileage,
			end_mileage,
			asset_desc,
			AREA_SR_KEY,
			ORG_SR_KEY,
			ASSET_GROUP_SR_KEY,
			ASSET_TYPE_SR_KEY,
			hce_flag,
			tenanted_flg,
			totalcount
		FROM
		(
			SELECT
				a.ASSET_GUID,
				ENG_LINE_REF,
				RAILWAY_ID,
				(START_MILES + START_YARDS/1760) AS start_mileage,
				(END_MILES + END_YARDS/1760) AS end_mileage,
				ASSET_NAME AS asset_desc,
				AREA_SR_KEY,
				a.ORG_SR_KEY,
				ASSET_GROUP_SR_KEY,
				ASSET_TYPE_SR_KEY,
				hce_flag,
				tenanted_flg,
				ROW_NUMBER() OVER (ORDER BY a.ASSET_GUID) rnk, 
				(DENSE_RANK() OVER (ORDER BY a.ASSET_GUID)
				+ DENSE_RANK() OVER (ORDER BY a.ASSET_GUID DESC)
				-1) totalcount
			FROM CES.ASSET a
			INNER JOIN @tbl_org o
			ON o.ORG_SR_KEY = a.ORG_SR_KEY
			--INNER JOIN [CES].EXAM ex
			--ON ex.ASSET_GUID = a.ASSET_GUID
			--INNER JOIN [CES].WORK wrk
			--ON wrk.WORK_SR_KEY = ex.WORK_SR_KEY
			--INNER JOIN [CES].SUPPLIER s
			--ON s.SUPPLIER_SR_KEY = ex.SUPPLIER_SR_KEY
			WHERE 
			a.ISACTIVE =1
			AND EXISTS (SELECT 1 FROM
						[CES].EXAM ex
						INNER JOIN [CES].WORK wrk
						ON wrk.WORK_SR_KEY = ex.WORK_SR_KEY
						INNER JOIN [CES].SUPPLIER s
						ON s.SUPPLIER_SR_KEY = ex.SUPPLIER_SR_KEY
						WHERE s.SUPPLIER_NAME = @supplier_name
						AND wrk.WORK_YEAR_KEY = @tasklist_yr_id
						AND  ex.ASSET_GUID = a.ASSET_GUID
						AND ex.ISACTIVE = 1
						AND wrk.ISACTIVE = 1
						AND s.ISACTIVE = 1
						)
			GROUP BY
				a.ASSET_GUID,
				ENG_LINE_REF,
				RAILWAY_ID,
				START_MILES,
				START_YARDS,
				END_MILES,
				END_YARDS,
				ASSET_NAME,
				AREA_SR_KEY,
				a.ORG_SR_KEY,
				ASSET_GROUP_SR_KEY,
				ASSET_TYPE_SR_KEY,
				hce_flag,
				tenanted_flg	
		)t
		WHERE t.rnk BETWEEN ((@pageno - 1) * @rows_count +1) AND (@pageno * @rows_count)

		INSERT INTO #tbl_SearchResult
		(
			asset_guid,
			region,
			route,
			area,
			elr,
			start_mileage,
			end_mileage,
			railway_id,
			asset_desc,
			asset_grp,
			asset_type,
			exam_id,
			exam_frequency,
			exam_type,
			due_dt,
			--baseline_plan_dt,
			plan_dt,
			cr_id,
			job_number,
			specific_exam_req,
			task_list_stat,
			comments_to_sec,
			--task_list_id,
			due_dt_earliest,
			due_dt_latest,
			max_tolerance_dt,
			exam_group_id,
			hce_flg,
			bcmi_required,
			nr_internal_note,
			tenanted_arch,
			exam_req_stat,
			exam_rpt_stat,
			exam_date
		)
					
																
		SELECT 
			final.asset_guid,
			final.region,
			final.route,
			final.area,
			final.elr,
			final.start_mileage,
			final.end_mileage,
			final.railway_id,
			final.asset_desc,
			final.asset_grp,
			final.asset_type,
			final.exam_id,
			final.exam_frequency,
			final.exam_type,
			final.due_dt,
			--final.baseline_plan_dt,
			final.plan_dt,
			final.cr_id,
			final.job_number,
			final.specific_exam_req,
			final.task_list_stat,
			final.comment_to_sec,
			--final.task_list_id,
			CASE WHEN exam_type IN ('Visual','Detailed','Enhanced') 
				THEN CONVERT(DATE, DATEADD( week, (0- ct.SITE_TOLERANCE_WEEKS), final.due_dt),103) 
				WHEN exam_type IN ('Underwater', 'Line Of Route' ) OR exam_type LIKE '%Additional%'
				THEN WORK_YR_START_DT 
				ELSE NULL
			END AS due_dt_earliest,
			CASE WHEN exam_type IN ('Visual','Detailed','Enhanced') 
				THEN CONVERT(DATE, DATEADD( week, ct.SITE_TOLERANCE_WEEKS, final.due_dt),103) 
				WHEN exam_type IN ('Underwater', 'Line Of Route' ) OR exam_type LIKE '%Additional%'
				THEN WORK_YR_END_DT 
				ELSE NULL
			END AS due_dt_latest,
			--CONVERT(DATE, DATEADD( week, ISNULL(ct.REVIEW_TOLERANCE_WEEKS,0), final.due_dt),103) AS max_tolerance_dt,
			CONVERT(DATE, DATEADD( week, ISNULL(ct.REVIEW_TOLERANCE_WEEKS,0),
									CASE WHEN exam_type IN ('Visual','Detailed','Enhanced') 
										THEN CONVERT(DATE, DATEADD( week, ct.SITE_TOLERANCE_WEEKS, final.due_dt),103) 
										WHEN exam_type IN ('Underwater', 'Line Of Route' ) OR exam_type LIKE '%Additional%'
										THEN WORK_YR_END_DT 
										ELSE NULL
									END
								),103) AS max_tolerance_dt,
			exam_group_id,
			hce_flg,
			bcmi_required,
			nr_internal_note,
			tenanted_arch,
			exam_req_stat,
			exam_rpt_stat,
			exam_date
		FROM
		(
				SELECT 
					ast.ASSET_GUID AS asset_guid,
					o.REGION AS region,
					o.ROUTE AS route,
					a.AREA_NAME AS area,
					elr.ELR_CODE AS elr,
					ast.start_mileage,
					ast.end_mileage,
					ast.RAILWAY_ID AS railway_id,
					ast.asset_desc,
					asg.ASSET_GROUP_DESC AS asset_grp,
					asp.ASSET_TYPE_DESC AS asset_type,
					ex.exam_id,
					ef.exam_frequency,
					et.EXAM_TYPE AS exam_type,
					wrk.EXAM_DUE_DATE AS due_dt,
					--ex.EXAM_BASELINE_DATE AS baseline_plan_dt,
					ex.EXAM_PLANNED_DATE AS plan_dt,
					ex.CHANGE_REQ_ID AS cr_id,
					ex.EXAM_REQUIREMENT AS specific_exam_req,
					tls.REF_VALUE AS task_list_stat,
					ex.comment_to_sec,
					--wrk.WORK_SR_KEY AS task_list_id,
					ex.EXAM_TYPE_SR_KEY,
					ISNULL(ef.exam_freq_in_months,0) AS exam_freq_in_months,
					wrk.WORK_YR_START_DT,
					wrk.WORK_YR_END_DT,
					wrk.job_number,
					eg.CARRS_EXAM_GROUP_ID AS exam_group_id,
					CASE WHEN ast.hce_flag = 'Y' THEN 'Yes' ELSE 'No' END AS hce_flg,
					NULL AS bcmi_required,
					ex.INTERNAL_NOTES AS nr_internal_note,
					CASE WHEN ast.TENANTED_FLG = 'Y' THEN 'Yes'
							WHEN ast.TENANTED_FLG = 'N' THEN 'No'
							ELSE 'N/A'
					END AS tenanted_arch,
					ers.REF_VALUE AS exam_req_stat,
					eps.REF_VALUE AS exam_rpt_stat,
					ex.EXAM_ACTUAL_DATE AS exam_date
								
				FROM #tbl_Asset ast
				INNER JOIN [CES].ORG o
				ON ast.ORG_SR_KEY = o.ORG_SR_KEY
				INNER JOIN [CES].AREA a
				ON a.AREA_SR_KEY = ast.AREA_SR_KEY
				INNER JOIN [CES].ENGINE_LINE_REF elr
				ON elr.ELR_SR_KEY = ast.ENG_LINE_REF
				AND elr.ORG_SR_KEY = ast.ORG_SR_KEY
				AND elr.AREA_SR_KEY = ast.AREA_SR_KEY
				INNER JOIN [CES].ASSET_GROUP asg
				ON asg.ASSET_GROUP_SR_KEY = ast.ASSET_GROUP_SR_KEY
				INNER JOIN [CES].ASSET_TYPE asp
				ON asp.ASSET_TYPE_SR_KEY = ast.ASSET_TYPE_SR_KEY
				INNER JOIN [CES].EXAM ex
				ON ex.ASSET_GUID = ast.ASSET_GUID
				INNER JOIN [CES].WORK wrk
				ON wrk.WORK_SR_KEY = ex.WORK_SR_KEY
				AND wrk.ISACTIVE = 1
				INNER JOIN [CES].EXAM_TYPE et
				ON et.EXAM_TYPE_SR_KEY = ex.EXAM_TYPE_SR_KEY
				INNER JOIN [CES].SUPPLIER s
				ON s.SUPPLIER_SR_KEY = ex.SUPPLIER_SR_KEY
				LEFT JOIN CES.EXAM_GROUP eg
				ON ex.EXAM_GROUP_SR_KEY = eg.EXAM_GROUP_SR_KEY
				AND eg.ISACTIVE = 1
				LEFT JOIN [CES].REFERENCE_VALUE ers
				ON ex.EXAM_REQ_STATUS = ers.REF_VAL_SR_KEY
				AND ers.ISACTIVE = 1 
				LEFT JOIN [CES].REFERENCE_VALUE eps
				ON ex.EXAM_REPORT_STATUS = eps.REF_VAL_SR_KEY
				AND eps.ISACTIVE = 1 
				LEFT JOIN [CES].REFERENCE_VALUE tls
				ON wrk.WORK_STATUS = tls.REF_VAL_SR_KEY
				AND tls.ISACTIVE = 1 
				--OUTER APPLY
				--(
				--	SELECT 
				--			specific_exam_req,
				--			( (ISNULL(INTERVAL_YEARS,0)*12) + (ISNULL(INTERVAL_MONTHS,0)) + (ISNULL(INTERVAL_DAYS,0)/30) ) AS exam_freq_in_months,
				--			(CAST(ISNULL(INTERVAL_YEARS,0) AS VARCHAR) + 'y '+CAST(ISNULL(INTERVAL_MONTHS,0) AS VARCHAR)+ 'm '+CAST(ISNULL(INTERVAL_DAYS,0) AS VARCHAR)+ 'd') AS exam_frequency
				--	FROM
				--	(
				--		SELECT
				--			INTERVAL_YEARS,
				--			INTERVAL_MONTHS,
				--			INTERVAL_DAYS,
				--			EXAM_REQUIREMENT AS specific_exam_req,
				--			ROW_NUMBER() OVER (PARTITION BY ASSET_GUID,EXAM_TYPE_SR_KEY ORDER BY EFFECTIVE_FROM_DT DESC) rnk
				--		FROM CES.EXAM_CYCLE
				--		WHERE ISACTIVE =1
				--		AND @current_date BETWEEN EFFECTIVE_FROM_DT AND ISNULL(EFFECTIVE_TO_DT,CONVERT(DATE,'31/12/9999',103))
				--		AND ASSET_GUID = ex.ASSET_GUID
				--		AND EXAM_TYPE_SR_KEY = ex.EXAM_TYPE_SR_KEY
				--	)t
				--	WHERE rnk = 1
				--)ef
				OUTER APPLY
				(
					SELECT
						( (ISNULL(INTERVAL_YEARS,0)*12) + (ISNULL(INTERVAL_MONTHS,0)) + (ISNULL(INTERVAL_DAYS,0)/30) ) AS exam_freq_in_months,
						(CAST(ISNULL(INTERVAL_YEARS,0) AS VARCHAR) + 'y '+CAST(ISNULL(INTERVAL_MONTHS,0) AS VARCHAR)+ 'm '+CAST(ISNULL(INTERVAL_DAYS,0) AS VARCHAR)+ 'd') AS exam_frequency
										
					FROM 
					(
						SELECT 
							INTERVAL_YEARS,
							INTERVAL_MONTHS,
							INTERVAL_DAYS,
							ROW_NUMBER() OVER (ORDER BY EFFECTIVE_FROM_DT DESC) rnk
						FROM CES.COMPLIANCE c
						WHERE ASSET_GUID = ex.ASSET_GUID
						AND EXAM_TYPE_SR_KEY = ex.EXAM_TYPE_SR_KEY
						AND @current_date BETWEEN EFFECTIVE_FROM_DT AND ISNULL(EFFECTIVE_TO_DT,@end_dt_default)
						AND c.ISACTIVE = 1
					)c
					WHERE rnk = 1
				) ef
							
				WHERE
					o.ISACTIVE = 1
				AND a.ISACTIVE = 1
				AND elr.ISACTIVE = 1
				AND asg.ISACTIVE = 1
				AND asp.ISACTIVE = 1
				AND ex.ISACTIVE = 1
				AND et.ISACTIVE = 1
				AND s.ISACTIVE = 1
				AND s.SUPPLIER_NAME = @supplier_name
				AND wrk.WORK_YEAR_KEY = @tasklist_yr_id
							
		)final
		LEFT JOIN [CES].COMPLIANCE_TOLERANCE ct
		ON ct.EXAM_TYPE_SR_KEY = final.EXAM_TYPE_SR_KEY
		AND ct.ISACTIVE = 1
		AND final.exam_freq_in_months BETWEEN ct.FREQ_INTERVAL_MONTHS_FROM AND ct.FREQ_INTERVAL_MONTHS_TO
		
					
		
		--Total count of records
		--SELECT @totalresultcnt = count(distinct asset_guid) FROM #tbl_SearchResult
		SELECT @totalresultcnt = ISNULL(totalcount,0) FROM #tbl_Asset

		--If no records are returned in search result
		IF  @totalresultcnt=0 
		BEGIN
			SET @result=
					(
						
						SELECT 
							JSON_QUERY(
										(
											select												
												@pageno AS currentpage,
												@totalresultcnt AS totalcount,
												0 AS totalpages
											FOR JSON PATH,WITHOUT_ARRAY_WRAPPER
										)
							) searchdatacount,
							JSON_QUERY('[]') data 						
						FOR JSON PATH,WITHOUT_ARRAY_WRAPPER, INCLUDE_NULL_VALUES
				)
		END	
		--If at least 1 record is returned in search result
		ELSE
		BEGIN	

						SET @result=
						(
							SELECT 
							   JSON_QUERY(
											(
												select
													@pageno AS currentpage,
													@totalresultcnt AS totalcount,
													CEILING(@totalresultcnt*1.0/@rows_count) AS totalpages
												FOR JSON PATH,WITHOUT_ARRAY_WRAPPER
											)
								) searchdatacount,
								(
									SELECT
										region AS region,
										route AS route,
										area AS area,
										elr AS elr,
										start_mileage AS startMileage,
										end_mileage AS endMileage,
										railway_id AS railwayId,
										asset_desc AS assetDescription,
										asset_grp AS assetGroup,
										asset_type AS assetType,
										asset_guid AS assetGuid,
										task_list_stat AS taskListStatus,
										exam_type AS examinationType,
										exam_id AS examId,
										exam_frequency AS examFrequency,
										due_dt AS requiredDate,
										due_dt_earliest AS earliestRequiredDate,
										due_dt_latest AS latestRequiredDate,
										max_tolerance_dt AS maxToleranceDate,
										--baseline_plan_dt AS baselinePlannedDate,
										plan_dt AS plannedDate,
										cr_id AS cRID,
										job_number AS jobNumber,
										specific_exam_req AS specificRequirement,
										comments_to_sec AS commentsToSec,
										exam_group_id AS examGroupId,
										hce_flg AS hce,
										bcmi_required AS bcmiRequired,
										nr_internal_note AS nrComment,
										tenanted_arch AS tenantedArches,
										exam_req_stat AS examRequestStatus,
										exam_rpt_stat AS examReportStatus,
										exam_date AS examDate
								
										FROM #tbl_SearchResult t	
								
									ORDER BY asset_guid,
											 due_dt desc
									FOR JSON AUTO, INCLUDE_NULL_VALUES
							)data
							FOR JSON PATH,WITHOUT_ARRAY_WRAPPER, INCLUDE_NULL_VALUES
						)
					END

		--SELECT @result
		SELECT @result AS response, NULL AS ErrorMsg
		
	END TRY
	BEGIN CATCH

	IF @ErrorMsg IS NULL
			SET @ErrorMsg = ERROR_MESSAGE() 

		SET @ErrorDescription = @ErrorMsg + 
						' Line Num:' + CONVERT(VARCHAR(5), ERROR_LINE()) + 
						',ErrorNum:' + CONVERT(VARCHAR(5), ERROR_NUMBER()) + 
						',Severity:' + CONVERT(VARCHAR(5), ERROR_SEVERITY()) + 
						',State:' + CONVERT(VARCHAR(10), ERROR_STATE()) + 
						',Procedure:' + CONVERT(VARCHAR(25), ERROR_PROCEDURE());  
		
		
		SET @result=
					(
						
						SELECT 
							JSON_QUERY(
										(
											select												
												@pageno AS currentpage,
												@totalresultcnt AS totalcount,
												0 AS totalpages
											FOR JSON PATH,WITHOUT_ARRAY_WRAPPER
										)
							) searchdatacount,
							JSON_QUERY('[]') data 						
						FOR JSON PATH,WITHOUT_ARRAY_WRAPPER, INCLUDE_NULL_VALUES
				)
		SELECT @result AS response, @ErrorDescription AS ErrorMsg
		DROP TABLE IF EXISTS #tbl_SearchResult;
		DROP TABLE IF EXISTS #tbl_Asset;
		
		THROW 50000,@ErrorDescription,1;

		
	END CATCH
	DROP TABLE IF EXISTS #tbl_SearchResult;
	DROP TABLE IF EXISTS #tbl_Asset;
	SET NOCOUNT OFF
END