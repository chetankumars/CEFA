﻿/***************************************************************************************************************************************            
* Name						: sp_Get_DefectDetails_SearchResult          
* Created By				: Cognizant            
* Date Created				: 27-Dec-2020           
* Description				: This stored procedure provides the search result for defect details screen.  
* Input Parameters			: Asset_GUID, Flag to denote whether Open defects need to be shown or All Defects      
* Output Parameters			: N/A            
* Return Value				: N/A            
* Assumptions				: None    
* Execution Statement		: Exec [CES].sp_Get_DefectDetails_SearchResult '3978559E4D5445D9E04400306E4AD01A','N'
*								
* Modified Date     Modified By   Revision Number  Modifications            
* 19-Jul-2021		Cognizant	  2.0			   Release 2 -US# 37567: Change in Open/CLose Defect count logic as per the new column IS_DEFECT_CLOSED in CES.DEFECT table          

*******************************************************************************************************************************************/ 



CREATE PROCEDURE [CES].[sp_Get_DefectDetails_SearchResult]
	@Asset_GUID		VARCHAR(32),
	@IsOpenDefect	CHAR(1)

AS
BEGIN
	SET NOCOUNT ON
	BEGIN TRY
		DECLARE
				@ErrorMsg				VARCHAR(250),
				@result					NVARCHAR(MAX),
				@totalresultcnt			SMALLINT

		CREATE TABLE #tbl_SearchResult
		(
			defect_id			DECIMAL(18),
			[description]		VARCHAR(256),
			[location]			VARCHAR(250),
			loc_major			VARCHAR(250),
			loc_minor			VARCHAR(250),
			exam_id				DECIMAL(18),
			exam_actual_date	DATE,
			exam_type			VARCHAR(32),
			risk_score			DECIMAL(10),
			deterioration		VARCHAR(64),
			access_granted		VARCHAR(5),
			access_required		VARCHAR(5),
			repaired			VARCHAR(5),
			closure_flg			VARCHAR(5),
			engineer_comments	VARCHAR(1000),
			exam_key			DECIMAL(18),
			highest_open_risk_score DECIMAL(10),
			recommend_raised	VARCHAR(5),
			rnk_defect_dtl		INT,
			defect_status		VARCHAR(7),
			defect_closed_date		DATE--Release 2 -US# 37567: Modified to make the logic dependent on new column IS_DEFECT_CLOSED 
		)

		INSERT INTO #tbl_SearchResult
		(
			defect_id,
			[description],
			[location],
			loc_major,
			loc_minor,
			exam_id,
			exam_actual_date,
			exam_type,
			risk_score,
			deterioration,
			access_granted,
			access_required,
			repaired,
			closure_flg,
			engineer_comments,
			exam_key,
			--highest_open_risk_score,
			recommend_raised,
			rnk_defect_dtl,
			defect_status,
			defect_closed_date--Release 2 -US# 37567: Modified to make the logic dependent on new column IS_DEFECT_CLOSED 
		)
		SELECT
			df.[DEFECT_ID] AS defect_id
			,df.[DESCRIPTION] AS [description]
			,df.[LOCATION] AS [location]
			,df.LOCATION_MAJOR AS loc_major
			,df.LOCATION_MINOR AS loc_minor
			,ex.[EXAM_ID] AS exam_id
			,ISNULL(ex.[EXAM_ACTUAL_DATE],df.EXAM_DATE) AS exam_actual_date
			,ISNULL(ex.[EXAM_TYPE],etp.EXAM_TYPE) AS exam_type
			,IIF(df.RISK_SCORE='N/A',-999,df.RISK_SCORE) AS risk_score
			,df.[DETERIORATION] AS deterioration
			,CASE WHEN df.ACCESS_GAINED ='Y' THEN 'Yes'
				  WHEN df.ACCESS_GAINED = 'N' THEN 'No'
				  ELSE df.ACCESS_GAINED
			END AS access_granted
			,CASE WHEN df.ACCESS_REQUIRED ='Y' THEN 'Yes'
				  WHEN df.ACCESS_REQUIRED = 'N' THEN 'No'
				  ELSE df.ACCESS_REQUIRED
			END AS access_required
			,CASE WHEN df.REPAIRED ='Y' THEN 'Yes'
				  WHEN df.REPAIRED = 'N' THEN 'No'
				  ELSE df.REPAIRED
			END AS repaired
			,CASE WHEN df.FLAG_FOR_CLOSURE ='Y' THEN 'Yes'
				  WHEN df.FLAG_FOR_CLOSURE = 'N' THEN 'No'
			END AS closure_flg
			,df.ENGINEER_COMMENTS
			,ex.EXAM_SR_KEY AS exam_key
			,df.RECOMMEND_RAISED
			,ROW_NUMBER() OVER (PARTITION BY df.[DEFECT_ID] ORDER BY ISNULL(ex.[EXAM_ACTUAL_DATE],df.EXAM_DATE) DESC, IIF(RISK_SCORE='N/A',-999,RISK_SCORE) DESC) AS rnk_defect_dtl
			
			--Release 2 -US# 37567: Modified to make the logic dependent on new column IS_DEFECT_CLOSED --START
			--,MAX(CASE WHEN df.FLAG_FOR_CLOSURE = 'Y' THEN 'CLOSED'
			--		  WHEN df.FLAG_FOR_CLOSURE ='N' THEN 'OPEN'
			--	 END) OVER (PARTITION BY df.[DEFECT_ID]) AS defect_status
			,MAX(CASE WHEN df.IS_DEFECT_CLOSED = 'Y' THEN 'CLOSED'
					  WHEN df.IS_DEFECT_CLOSED ='N' THEN 'OPEN'
				 END) OVER (PARTITION BY df.[DEFECT_ID]) AS defect_status
			--Release 2 -US# 37567: Modified to make the logic dependent on new column IS_DEFECT_CLOSED --END
			--,MAX(ISNULL(df.DEFECT_CLOSED_DATE,ISNULL(ex.[EXAM_ACTUAL_DATE],df.EXAM_DATE))) OVER (PARTITION BY df.[DEFECT_ID]) AS last_exam_dt
			,df.DEFECT_CLOSED_DATE AS defect_closed_date--Release 2 -US# 37567: Modified to make the logic dependent on new column IS_DEFECT_CLOSED --END
			
		FROM [CES].DEFECT AS df
		LEFT JOIN 
			(	SELECT
					exm.ASSET_GUID,
					exm.EXAM_SR_KEY,
					exm.[EXAM_ID],
					exm.[EXAM_ACTUAL_DATE],
					et.[EXAM_TYPE]
				FROM [CES].EXAM AS exm
				INNER JOIN CES.EXAM_TYPE et
				ON et.EXAM_TYPE_SR_KEY = exm.EXAM_TYPE_SR_KEY
				WHERE exm.ISACTIVE = 1
				AND exm.ASSET_GUID = @Asset_GUID
			)ex
		ON df.ASSET_GUID = ex.ASSET_GUID
		AND df.EXAM_SR_KEY = ex.EXAM_SR_KEY
		LEFT JOIN EXAM_TYPE etp
		ON df.EXAM_TYPE_SR_KEY = etp.EXAM_TYPE_SR_KEY

		WHERE DF.ASSET_GUID = @Asset_GUID
		AND df.ISACTIVE = 1
		AND (
				--Release 2 -US# 37567: Modified to make the logic dependent on new column IS_DEFECT_CLOSED --START
				--(@IsOpenDefect = 'Y' AND df.FLAG_FOR_CLOSURE = 'N') 
				(@IsOpenDefect = 'Y' AND df.IS_DEFECT_CLOSED = 'N') 
				--Release 2 -US# 37567: Modified to make the logic dependent on new column IS_DEFECT_CLOSED --END
				OR @IsOpenDefect = 'N')


		SELECT @totalresultcnt = COUNT(DISTINCT defect_id) FROM #tbl_SearchResult

		--If no records are returned in search result
		IF  @totalresultcnt=0 
		BEGIN
			SET @result=
					(
						SELECT 
							JSON_QUERY(
										(
											select
												@totalresultcnt AS totalcount
											FOR JSON PATH,WITHOUT_ARRAY_WRAPPER
										)
							) searchdatacount,
							JSON_QUERY('[]') searchresult
						
						FOR JSON PATH,WITHOUT_ARRAY_WRAPPER, INCLUDE_NULL_VALUES
				)
		END	
		--If alt least 1 record is returned in search result
		ELSE
		BEGIN

				SET @result=
				(
					SELECT 
						JSON_QUERY(
									(
										select
											@totalresultcnt AS totalcount
										FOR JSON PATH,WITHOUT_ARRAY_WRAPPER
									)
							) searchdatacount,
							(
								SELECT
									ast.ASSET_GUID AS Asset_GUID,
									o.REGION AS region,
									o.ROUTE AS route,
									a.AREA_NAME AS area,
									elr.ELR_CODE AS elr,
									ast.RAILWAY_ID AS railway_id,
									asg.ASSET_GROUP_DESC AS asset_grp,
									atp.ASSET_TYPE_DESC AS asset_type,
									ast.OWNING_PARTY AS owning_party
								FROM CES.ASSET ast
								INNER JOIN CES.ORG o
								ON ast.ORG_SR_KEY = o.ORG_SR_KEY
								INNER JOIN CES.AREA a
								ON a.AREA_SR_KEY = ast.AREA_SR_KEY
								INNER JOIN ENGINE_LINE_REF elr
								ON elr.ELR_SR_KEY = ast.ENG_LINE_REF
								INNER JOIN ASSET_GROUP asg
								ON asg.ASSET_GROUP_SR_KEY = ast.ASSET_GROUP_SR_KEY
								INNER JOIN ASSET_TYPE atp
								ON ast.ASSET_TYPE_SR_KEY = atp.ASSET_TYPE_SR_KEY
								
								WHERE 
									ast.ASSET_GUID = @Asset_GUID
									AND ast.ISACTIVE = 1
									AND o.ISACTIVE = 1
									AND a.ISACTIVE =1
									AND elr.ISACTIVE = 1
									AND asg.ISACTIVE =1
									AND atp.ISACTIVE =1
								FOR JSON PATH, INCLUDE_NULL_VALUES
							  )assetdtls,

							  (
									SELECT
										defect_id,
										[description],
										ISNULL([location],'') AS [location],
										ISNULL(loc_major,'') AS loc_major,
										ISNULL(loc_minor,'') AS loc_minor,
										IIF(risk_score=-999,'N/A',CAST(risk_score AS VARCHAR)) AS highest_open_risk_score,
										defect_status,
										CASE WHEN defect_status = 'CLOSED' THEN defect_closed_date ELSE NULL END defect_closed_date,--Release 2 -US# 37567: Modified to make the logic dependent on new column IS_DEFECT_CLOSED 
										details = (			SELECT
																exam_id,
																exam_actual_date,
																exam_type,
																deterioration,
																IIF(risk_score=-999,'N/A',CAST(risk_score AS VARCHAR)) AS risk_score,
																access_granted,
																access_required,
																repaired,
																closure_flg,
																exam_key,
																engineer_comments,
																recommend_raised
															FROM #tbl_SearchResult t
															WHERE t.defect_id = sr.defect_id
															ORDER BY
																defect_id,
																rnk_defect_dtl
															FOR JSON PATH, INCLUDE_NULL_VALUES)
									FROM #tbl_SearchResult sr
									WHERE rnk_defect_dtl = 1
									
									ORDER BY
										defect_status DESC,  ---OPEN Defects will come first
										risk_score DESC, ---Defects with highest open score should come first then
										exam_actual_date ASC--Release 2 -US# 37567: Modified to make the logic dependent on new column IS_DEFECT_CLOSED
									FOR JSON PATH, INCLUDE_NULL_VALUES
							  )searchresult
							FOR JSON PATH, INCLUDE_NULL_VALUES, WITHOUT_ARRAY_WRAPPER

					)
		END


		--PRINT @result
		SELECT @result
	END TRY
	BEGIN CATCH
		SET @ErrorMsg = ERROR_MESSAGE() + 
						' Line Num:' + CONVERT(VARCHAR(5), ERROR_LINE()) + 
						',ErrorNum:' + CONVERT(VARCHAR(5), ERROR_NUMBER()) + 
						',Severity:' + CONVERT(VARCHAR(5), ERROR_SEVERITY()) + 
						',State:' + CONVERT(VARCHAR(10), ERROR_STATE()) + 
						',Procedure:' + CONVERT(VARCHAR(25), OBJECT_NAME(@@procid)) +
						',Procedure:' + CONVERT(VARCHAR(25), ERROR_PROCEDURE());  

		THROW 50000,@ErrorMsg,1;

		
	END CATCH

	DROP TABLE IF EXISTS #tbl_SearchResult;
	SET NOCOUNT OFF
END
