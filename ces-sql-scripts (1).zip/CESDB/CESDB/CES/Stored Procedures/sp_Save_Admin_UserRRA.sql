﻿/***************************************************************************************************************************************            
* Name						: sp_Save_Admin_UserRRA            
* Created By				: Cognizant            
* Date Created				: 10-Mar-2021           
* Description				: This stored procedure provides the option to save new or existing user RRA they are assigned.  
* Input Parameters			: JSON      
* Output Parameters			: @OUT_ErrorNo            
* Return Value				: 1 - Success / 0 - Fail            
* Assumptions				: None    
* Execution Statement		: Exec [CES].sp_Save_Admin_UserRRA '{
																	"user_id": 42,		
																	"supplier_id": null,
																	"is_new_user": "N",	
																	"current_user_key":  "9725949A-1EB7-497E-B397-A511422AFAFE",
																	"user_default_rra":			
																	[{		"region_name": "Southern",
																			"route_id": 9,
																			"area_id": 1		
																		}],
																	"user_selected_rra": [		
																		{		
																			"region_name": "Eastern",
																			"route_id": 1,
																			"area_id": 12
																		},
																		{																						
																			"region_name": "Southern",
																			"route_id": 9,
																			"area_id": 2	
																		},
																		{																						
																			"region_name": "Southern",
																			"route_id": 9,
																			"area_id": 1	
																		},
																		{																						
																			"region_name": "Southern",
																			"route_id": 11,
																			"area_id": 4	
																		},
																		{																						
																			"region_name": "Southern",
																			"route_id": 9,
																			"area_id": 3	
																		}
																		
																	]	
																}'

*								
* Modified Date     Modified By   Revision Number  Modifications            

*******************************************************************************************************************************************/ 
 
CREATE PROCEDURE [CES].[sp_Save_Admin_UserRRA]
	@Input_JSON		NVARCHAR(MAX)
AS 
BEGIN
	SET NOCOUNT ON
	
	
	BEGIN TRY
		DECLARE
				@ErrorMsg					VARCHAR(250),
				@ErrorDescription		VARCHAR(4000),
				@result						NVARCHAR(MAX),
				@current_user_key			VARCHAR(64),
				@current_date				DATETIME,
				@supplier_id                DECIMAL(18),
				@supplier_id_old                DECIMAL(18),
				@user_id					DECIMAL(18),
				@is_new_user				VARCHAR(1),
				@user_default_rra			NVARCHAR(MAX),				
				@user_selected_rra			NVARCHAR(MAX),
				@user_previous_rra_count    DECIMAL(18),
				@user_rra_count             DECIMAL(18),
				@current					INT = 0,
				@route_id					DECIMAL(18),
				@area_id					DECIMAL(18),
				@entitlement_id				DECIMAL(18)
				
				DROP TABLE IF EXISTS #tblUserRRA;
				DROP TABLE IF EXISTS #tblUserDefaultRRA;
				DROP TABLE IF EXISTS #tblUserExistingRRA
				
				CREATE TABLE #tblUserRRA
				(
					region_name VARCHAR(64),
					route_id DECIMAL(18),
					area_id DECIMAL(18),
					supplier_id DECIMAL(18),					
					row_id int
				)
				CREATE TABLE #tblUserDefaultRRA
				(
					region_name VARCHAR(64),
					route_id DECIMAL(18),
					area_id DECIMAL(18),
					supplier_id DECIMAL(18),					
					row_id int
				)							

				

				CREATE TABLE #tblUserExistingRRA
				(
					supplier_id_old DECIMAL(18),	
					supplier_id_new DECIMAL(18),
					entitlement_sr_key DECIMAL(18),
					isactive_old BIT,
					isactive_new BIT,
					isdefault_old BIT,
					isdefault_new BIT
				)
				
				

				SELECT 
					@user_id = COALESCE(@user_id,CASE LOWER([key]) WHEN 'user_id' THEN [value] ELSE NULL END),
					@current_user_key = COALESCE(@current_user_key,CASE LOWER([key]) WHEN 'current_user_key' THEN [value] ELSE NULL END),
					@supplier_id = COALESCE(@supplier_id,CASE LOWER([key]) WHEN 'supplier_id' THEN [value] ELSE NULL END),
					@is_new_user = COALESCE(@is_new_user,CASE LOWER([key]) WHEN 'is_new_user' THEN [value] ELSE NULL END),
					@user_default_rra = COALESCE(@user_default_rra,CASE LOWER([key]) WHEN 'user_default_rra' THEN [value] ELSE NULL END),
					@user_selected_rra = COALESCE(@user_selected_rra,CASE LOWER([key]) WHEN 'user_selected_rra' THEN [value] ELSE NULL END)
			
				FROM	OPENJSON(@Input_JSON);

				
		
				IF @user_default_rra IS NOT NULL 
				BEGIN 
					INSERT INTO #tblUserDefaultRRA
					(
						region_name,
						route_id,
						area_id,
						supplier_id,
						row_id 
					)(	
						SELECT region_name,route_id,area_id,@supplier_id  AS supplier_id,ROW_NUMBER() OVER (ORDER BY route_id ASC) AS ROWNUMBER 
						FROM OPENJSON(@user_default_rra)
						 WITH (				
								region_name VARCHAR(64) '$.region_name',
								route_id DECIMAL(18) '$.route_id',
								area_id DECIMAL(18) '$.area_id'				
							  )
					 )
				END
				ELSE 
				BEGIN
					SET @ErrorMsg = 'Default Region, Route, and Area details are missing in input.';
					THROW 50000,@ErrorMsg,1;
				END

				IF @user_selected_rra IS NOT NULL 
				BEGIN 
					INSERT INTO #tblUserRRA
					(
						region_name,
						route_id,
						area_id,
						supplier_id,
						row_id
					)(	
						SELECT region_name,route_id,area_id,@supplier_id  AS supplier_id ,ROW_NUMBER() OVER (ORDER BY route_id ASC) AS ROWNUMBER FROM OPENJSON(@user_selected_rra)
						 WITH (				
								region_name VARCHAR(64) '$.region_name',
								route_id DECIMAL(18) '$.route_id',
								area_id DECIMAL(18) '$.area_id'
							  )
					  )
				 END
				ELSE 
				BEGIN
					SET @ErrorMsg = 'Region, Route, and Area details are missing in input.';
					THROW 50000,@ErrorMsg,1;
				END
				

				IF (@user_id IS NULL)
				BEGIN
					SET @ErrorMsg = 'User Id is blank in input.';
					THROW 50000,@ErrorMsg,1;
				END

				IF (@user_id=0)
				BEGIN
					SET @ErrorMsg = 'User Id is not valid';
					THROW 50000,@ErrorMsg,1;
				END

				IF (@supplier_id IS NOT NULL)				
				BEGIN
					IF NOT EXISTS (SELECT 1 FROM CES.[SUPPLIER] WHERE SUPPLIER_SR_KEY = @supplier_id AND ISACTIVE=1)
					BEGIN
					SET @ErrorMsg = 'The selected Supplier Id is not valid';
					THROW 50000,@ErrorMsg,1;
					END
				END

				IF (@current_user_key IS NULL or LTRIM(RTRIM(@current_user_key)) = '')
				BEGIN
					SET @ErrorMsg = 'Current logged in user key is blank in input';
					THROW 50000,@ErrorMsg,1;
				END

				IF ((SELECT COUNT(1) from #tblUserDefaultRRA) = 0)
				BEGIN
					SET @ErrorMsg = 'Default Region, Route, and Area details are misisng in input';
					THROW 50000,@ErrorMsg,1;
				END
				ELSE IF ((SELECT COUNT(1) from #tblUserDefaultRRA) > 1 )
				BEGIN
					SET @ErrorMsg = 'More than one default Region, Route, and Area details found';
					THROW 50000,@ErrorMsg,1;
				END

				IF ((SELECT COUNT(1) from #tblUserRRA) = 0)
				BEGIN
					SET @ErrorMsg = 'Region, Route, and Area details are misisng in input';
					THROW 50000,@ErrorMsg,1;
				END
				
				--IF ((SELECT COUNT(1) from #tblUserRRA Ur inner join #tblUserDefaultRRA Urd 
				--on Ur.region_name=Urd.region_name and Ur.route_id=Urd.route_id and Ur.area_id=Urd.area_id and Ur.supplier_id=Urd.supplier_id) = 0)
				--BEGIN
				--	SET @ErrorMsg = 'Default RRA details are not present in user selected rra details';
				--	THROW 50000,@ErrorMsg,1;
				--END

				IF ((SELECT COUNT(1) from #tblUserRRA Ur inner join #tblUserDefaultRRA Urd 
				on Ur.region_name=Urd.region_name and Ur.route_id=Urd.route_id and Ur.area_id=Urd.area_id) = 0)
				BEGIN
					SET @ErrorMsg = 'Default RRA details are not present in user selected rra details';
					THROW 50000,@ErrorMsg,1;
				END

				SET @current_date = GETDATE()

				
				SET @user_previous_rra_count=(SELECT COUNT(1) FROM CES.ENTITLEMENT WHERE USER_SR_KEY=@user_id and ISACTIVE=1)
				SET @result = ''
				
				  IF UPPER(@is_new_user) = 'Y'  
					  BEGIN				
						IF @user_previous_rra_count=0 
							BEGIN
								--PRINT 'NEW USER SAVE'
								BEGIN TRAN
									
										INSERT INTO CES.ENTITLEMENT(USER_SR_KEY,ORG_SR_KEY,AREA_SR_KEY,
										SUPPLIER_SR_KEY,ISDEFAULT,CREATED_USER,CREATED_DATE,ISACTIVE)
										SELECT
											@user_id, u.route_id, u.area_id, u.supplier_id,
											CASE WHEN u.region_name = d.region_name AND u.route_id = d.route_id AND ISNULL(u.area_id,0) = ISNULL(d.area_id,0) THEN 1
											ELSE 0 END,@current_user_key,@current_date,1
										FROM #tblUserRRA u
										LEFT JOIN #tblUserDefaultRRA d
										ON u.region_name = d.region_name
										AND u.route_id = d.route_id
										AND ISNULL(u.area_id,0) = ISNULL(d.area_id,0) 
															
								SET @result= (
									SELECT 1 AS save_status,NULL AS error_msg
									FOR JSON PATH,WITHOUT_ARRAY_WRAPPER, INCLUDE_NULL_VALUES
								)
								COMMIT TRAN
							END
						ELSE
							BEGIN
								--PRINT 'NEW USER HAVE RECORDS MESSAGE'
								SET @ErrorMsg = 'The selected user RRA already exist in system';
								SET @result= (
									SELECT 0 AS save_status,@ErrorMsg AS error_msg
									FOR JSON PATH,WITHOUT_ARRAY_WRAPPER, INCLUDE_NULL_VALUES
								)
							END
				     END
				  
				  ELSE
					  BEGIN
									 
									SET @supplier_id_old = (SELECT TOP 1 ISNULL(supplier_sr_key,0) FROM CES.ENTITLEMENT e WHERE e.USER_SR_KEY = @user_id)
									

									IF (@supplier_id_old > 0 AND @supplier_id IS NULL)
									BEGIN
										SET @ErrorMsg = 'Supplier id should not be null';
										THROW 50000,@ErrorMsg,1;
									END
									ELSE IF (@supplier_id_old = 0 AND @supplier_id IS NOT NULL)
									BEGIN
										SET @ErrorMsg = 'This user is not registered as supplier, please delete user and create it as supplier';
										THROW 50000,@ErrorMsg,1;
									END

									INSERT INTO #tblUserExistingRRA
									(
										supplier_id_old,
										supplier_id_new,					
										entitlement_sr_key,
										isactive_old,
										isactive_new,
										isdefault_old,
										isdefault_new
									)
									SELECT
										e.supplier_sr_key,
										u.supplier_id,
										e.entitlement_sr_key,
										e.isactive,
										1,
										e.isdefault,
										case when u.region_name = d.region_name AND u.route_id = d.route_id AND ISNULL(u.area_id,0) = ISNULL(d.area_id,0) THEN 1
										ELSE 0 END
									FROM #tblUserRRA u
									LEFT JOIN #tblUserDefaultRRA d
									ON u.region_name = d.region_name AND u.route_id = d.route_id 
									AND ISNULL(u.area_id,0) = ISNULL(d.area_id,0)
									LEFT JOIN CES.ENTITLEMENT e
									ON u.route_id = e.ORG_SR_KEY
									AND ISNULL(u.area_id,0) = ISNULL(e.AREA_SR_KEY,0)									
									WHERE e.USER_SR_KEY = @user_id

									BEGIN TRAN 

									UPDATE e
									SET 
										supplier_sr_key = supplier_id_new,
										isactive = isactive_new,
										isdefault = isdefault_new,
										UPDATED_USER = @current_user_key,
										UPDATED_DATE = @current_date
									FROM CES.ENTITLEMENT e
									INNER JOIN #tblUserExistingRRA t
									ON e.entitlement_sr_key = t.entitlement_sr_key
									WHERE 
									(supplier_id_old <> supplier_id_new) OR
									 (isactive_old <> isactive_new) 
									OR (isdefault_old <> isdefault_new)

									
									

									IF EXISTS (SELECT 1 FROM #tblUserRRA u
										LEFT JOIN #tblUserDefaultRRA d
										ON u.region_name = d.region_name
										AND u.route_id = d.route_id
										AND ISNULL(u.area_id,0) = ISNULL(d.area_id,0)
										LEFT JOIN CES.ENTITLEMENT e
										ON u.route_id = e.ORG_SR_KEY
										AND ISNULL(u.area_id,0) = ISNULL(e.AREA_SR_KEY,0)
										AND e.USER_SR_KEY = @user_id)
									BEGIN
																														
										INSERT INTO CES.ENTITLEMENT(USER_SR_KEY,ORG_SR_KEY,AREA_SR_KEY,
										SUPPLIER_SR_KEY,ISDEFAULT,CREATED_USER,CREATED_DATE,ISACTIVE)
										SELECT
											@user_id, u.route_id, u.area_id, u.supplier_id,
											CASE WHEN u.region_name = d.region_name AND u.route_id = d.route_id AND ISNULL(u.area_id,0) = ISNULL(d.area_id,0) THEN 1
											ELSE 0 END,@current_user_key,@current_date,1

										FROM #tblUserRRA u
										LEFT JOIN #tblUserDefaultRRA d
										ON u.region_name = d.region_name
										AND u.route_id = d.route_id
										AND ISNULL(u.area_id,0) = ISNULL(d.area_id,0)
										LEFT JOIN CES.ENTITLEMENT e
										ON u.route_id = e.ORG_SR_KEY
										AND ISNULL(u.area_id,0) = ISNULL(e.AREA_SR_KEY,0)
										AND e.USER_SR_KEY = @user_id
										
										WHERE e.ENTITLEMENT_SR_KEY IS NULL
									END

									IF EXISTS (SELECT 1 FROM CES.ENTITLEMENT E
									LEFT JOIN #tblUserRRA u
									ON u.route_id = e.ORG_SR_KEY
									AND ISNULL(u.area_id,0) = ISNULL(e.AREA_SR_KEY,0)
									WHERE E.USER_SR_KEY = @user_id 
									AND u.route_id IS NULL AND u.area_id IS NULL)
									BEGIN
										UPDATE e
										SET										 								
										E.isactive = 0,
										UPDATED_USER = @current_user_key,
										UPDATED_DATE = @current_date									
									FROM CES.ENTITLEMENT E
									LEFT JOIN #tblUserRRA u
									ON u.route_id = e.ORG_SR_KEY
									AND ISNULL(u.area_id,0) = ISNULL(e.AREA_SR_KEY,0)
									WHERE E.USER_SR_KEY = @user_id AND E.isactive = 1
									AND u.route_id IS NULL AND u.area_id IS NULL

									END
									

									SET @result= (
									SELECT 1 AS save_status,NULL AS error_msg
									FOR JSON PATH,WITHOUT_ARRAY_WRAPPER, INCLUDE_NULL_VALUES
									)
										
									COMMIT TRAN	
					END						

	

		 SELECT @result

		 

	END TRY
	BEGIN CATCH
		IF (@@TRANCOUNT >0)
			ROLLBACK TRAN
		IF @ErrorMsg IS NULL
			SET @ErrorMsg = ERROR_MESSAGE() 
		
		SET @ErrorDescription = @ErrorMsg + 
							' Line Num:' + CONVERT(VARCHAR(5), ERROR_LINE()) + 
							',ErrorNum:' + CONVERT(VARCHAR(5), ERROR_NUMBER()) + 
							',Severity:' + CONVERT(VARCHAR(5), ERROR_SEVERITY()) + 
							',State:' + CONVERT(VARCHAR(10), ERROR_STATE()) + 
							',Procedure:' + CONVERT(VARCHAR(25), OBJECT_NAME(@@procid)) +
							',Procedure:' + CONVERT(VARCHAR(25), ERROR_PROCEDURE())

		SET @result= (
						SELECT 0 AS save_status,@ErrorMsg AS error_msg, NULL AS user_id
						FOR JSON PATH,WITHOUT_ARRAY_WRAPPER, INCLUDE_NULL_VALUES
					)
		SELECT @result;

		DROP TABLE IF EXISTS #tblUserRRA;
		DROP TABLE IF EXISTS #tblUserDefaultRRA;
		DROP TABLE IF EXISTS #tblUserExistingRRA;

		THROW 50000,@ErrorMsg,1;

		
	END CATCH

	
	SET NOCOUNT OFF
END