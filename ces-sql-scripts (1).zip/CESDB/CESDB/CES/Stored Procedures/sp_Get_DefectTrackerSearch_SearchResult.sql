﻿
/***************************************************************************************************************************************            
* Name						: sp_Get_DefectTrackerSearch_SearchResult            
* Created By				: Cognizant            
* Date Created				: 27-Dec-2020           
* Description				: This stored procedure provides the search result for defect tracker - asset basic and advanced search.  
* Input Parameters			: JSON      
* Output Parameters			: N/A            
* Return Value				: N/A            
* Assumptions				: None    
* Execution Statement		: Exec [CES].sp_Get_DefectTrackerSearch_SearchResult '{
																					"region_name": "Southern",
																					"route_id": 9,
																					"area_id": 0,
																					"elr_id":[0],	
																					"start_mileage_from": -1,
																					"start_mileage_to": 99999,
																					"railway_id": null,
																					"ast_grp_id": 0,
																					"ast_typ_id": [0],
																					"ownparty_name": null,
																					"mattyp_id": [0],
																					"hceflg_name": "All",
																					"open_defect_from": -1,
																					"open_defect_to" : 99999,
																					"open_defect_score_from": -1,
																					"open_defect_score_to": 99999,
																					"isexporttodoc": "N",
																					"sortcolumn": "MaterialType",
																					"sortorder": "asc",
																					"pageno": 1,
																					"rowsperpage": 25
																				}'
								
																				--"mattyp_id": [397,409],--397,409,416,418,420,431
*																				--"ownparty_name": ["Outside Party","Atkins Rail (FI)", "Network Rail (CE-Struct)"],
* Modified Date     Modified By   Revision Number  Modifications  
* 19-Jul-2021		Cognizant	  2.0			   Release 2 -US# 37567: Change in Open/CLose Defect count logic as per the new column IS_DEFECT_CLOSED in CES.DEFECT table          
  27-Jul-2021		Cognizant	  2.0			   Release 2 -US# 22846: Multi select option enabled for following fields "mattyp_id", "ownparty_name"  
												   
*******************************************************************************************************************************************/ 



CREATE PROCEDURE [CES].[sp_Get_DefectTrackerSearch_SearchResult]
	@Input_JSON		NVARCHAR(MAX)
AS
BEGIN
	SET NOCOUNT ON
	BEGIN TRY
		DECLARE
				@ErrorMsg				VARCHAR(250),
				@result					NVARCHAR(MAX),
				@region_name			VARCHAR(64),
				@route_id				DECIMAL(18),
				@area_id				DECIMAL(18),
				@elr_id					NVARCHAR(MAX),
				@start_mileage_from		DECIMAL(18,4),
				@start_mileage_to		DECIMAL(18,4),
				@railway_id				VARCHAR(64),
				@ast_grp_id				DECIMAL(18),
				@ownparty_name			NVARCHAR(MAX),
				@mattyp_id				NVARCHAR(MAX),
				@hceflg_name			VARCHAR(4),
				@open_defect_from		DECIMAL(18),
				@open_defect_to			DECIMAL(18),
				@open_defect_score_from	DECIMAL(18),
				@open_defect_score_to	DECIMAL(18),
				@isexporttodoc			VARCHAR(1),
				@sortcolumn				VARCHAR(30),
				@sortorder				VARCHAR(5),
				@pageno					DECIMAL(18),
				@rowsperpage			DECIMAL(18),
				@ast_typ_array			NVARCHAR(MAX),
				@isasttypselected		CHAR(1) = 'N',
				@isbasicsearch			CHAR(1) = 'Y',
				@totalresultcnt			INT,
				@iselrselected		CHAR(1) = 'N',
				@ismatselected		CHAR(1) = 'N',
				@isownpartyselected		CHAR(1) = 'N'

		DECLARE @ast_typ TABLE
		(
			ast_typ_id DECIMAL(18)
		)

		CREATE TABLE #tbl_SearchResult
		(
				asset_guid				VARCHAR(32),
				region					VARCHAR(64),
				route					VARCHAR(64),
				area					VARCHAR(64),
				elr						VARCHAR(4),
				struct_no				VARCHAR(64),
				op_status				VARCHAR(100),
				start_mileage			DECIMAL(18,4),
				end_mileage				DECIMAL(18,4),
				asset_group				VARCHAR(64),
				struct_type				VARCHAR(64),
				mat_type				VARCHAR(500),
				owner					VARCHAR(64),
				hce_flag				VARCHAR(4),
				total_defects			DECIMAL(5),
				open_defects			DECIMAL(5),
				highest_open_risk_score	DECIMAL(5)
		)

		DECLARE @elr_id_array TABLE
		(
			elr_id DECIMAL(18)
		)
		
		DECLARE @mat_id_array TABLE
		(
			mat_id DECIMAL(18)
		)

		DECLARE @own_party_array TABLE
		(
			own_party VARCHAR(64)
		)


		
		SELECT 
			@region_name = COALESCE(@region_name,CASE LOWER([key]) WHEN 'region_name' THEN [value] ELSE NULL END),
			@route_id = COALESCE(@route_id,CASE LOWER([key]) WHEN 'route_id' THEN [value] ELSE NULL END),
			@area_id = COALESCE(@area_id,CASE LOWER([key]) WHEN 'area_id' THEN [value] ELSE NULL END),
			@elr_id = COALESCE(@elr_id,CASE LOWER([key]) WHEN 'elr_id' THEN [value] ELSE NULL END),
			@start_mileage_from = COALESCE(@start_mileage_from,CASE LOWER([key]) WHEN 'start_mileage_from' THEN [value] ELSE NULL END),
			@start_mileage_to = COALESCE(@start_mileage_to,CASE LOWER([key]) WHEN 'start_mileage_to' THEN [value] ELSE NULL END),
			@railway_id = COALESCE(@railway_id,CASE LOWER([key]) WHEN 'railway_id' THEN [value] ELSE NULL END),
			@ast_grp_id = COALESCE(@ast_grp_id,CASE LOWER([key]) WHEN 'ast_grp_id' THEN [value] ELSE NULL END),
			@ast_typ_array = COALESCE(@ast_typ_array,CASE LOWER([key]) WHEN 'ast_typ_id' THEN [value] ELSE NULL END),
			@ownparty_name = COALESCE(@ownparty_name,CASE LOWER([key]) WHEN 'ownparty_name' THEN [value] ELSE NULL END),
			@mattyp_id = COALESCE(@mattyp_id,CASE LOWER([key]) WHEN 'mattyp_id' THEN [value] ELSE NULL END),
			@hceflg_name = COALESCE(@hceflg_name,CASE LOWER([key]) WHEN 'hceflg_name' THEN [value] ELSE NULL END),
			@open_defect_from = COALESCE(@open_defect_from,CASE LOWER([key]) WHEN 'open_defect_from' THEN [value] ELSE NULL END),
			@open_defect_to = COALESCE(@open_defect_to,CASE LOWER([key]) WHEN 'open_defect_to' THEN [value] ELSE NULL END),
			@open_defect_score_from = COALESCE(@open_defect_score_from,CASE LOWER([key]) WHEN 'open_defect_score_from' THEN [value] ELSE NULL END),
			@open_defect_score_to = COALESCE(@open_defect_score_to,CASE LOWER([key]) WHEN 'open_defect_score_to' THEN [value] ELSE NULL END),
			@isexporttodoc = COALESCE(@isexporttodoc,CASE LOWER([key]) WHEN 'isexporttodoc' THEN [value] ELSE NULL END),
			@sortcolumn = COALESCE(@sortcolumn,CASE LOWER([key]) WHEN 'sortcolumn' THEN [value] ELSE NULL END),
			@sortorder = COALESCE(@sortorder,CASE LOWER([key]) WHEN 'sortorder' THEN [value] ELSE NULL END),
			@pageno = COALESCE(@pageno,CASE LOWER([key]) WHEN 'pageno' THEN [value] ELSE NULL END),
			@rowsperpage = COALESCE(@rowsperpage,CASE LOWER([key]) WHEN 'rowsperpage' THEN [value] ELSE NULL END)

		FROM	OPENJSON(@Input_JSON);


		IF (@region_name IS NULL)
		BEGIN

			SET @ErrorMsg = 'Region cannot be NULL';
			DROP TABLE IF EXISTS #tbl_SearchResult;
			THROW 50000,@ErrorMsg,1;
		END


		IF @ast_typ_array IS NOT NULL 
		BEGIN
			INSERT INTO @ast_typ (ast_typ_id)
			SELECT[value] FROM OPENJSON(@ast_typ_array);

			IF EXISTS (SELECT 1 FROM @ast_typ WHERE ast_typ_id=0)
				SET @isasttypselected = 'N'
			ELSE
				SET @isasttypselected = 'Y'
		END 

		IF @elr_id IS NOT NULL 
		BEGIN
			INSERT INTO @elr_id_array (elr_id)
			SELECT[value] FROM OPENJSON(@elr_id);

			IF EXISTS (SELECT 1 FROM @elr_id_array WHERE elr_id=0)
				SET @iselrselected = 'N'
			ELSE
				SET @iselrselected = 'Y'
		END 
		

		IF @mattyp_id IS NOT NULL 
		BEGIN
			INSERT INTO @mat_id_array (mat_id)
			SELECT[value] FROM OPENJSON(@mattyp_id);

			IF EXISTS (SELECT 1 FROM @mat_id_array WHERE mat_id=0)
				SET @ismatselected = 'N'
			ELSE
				SET @ismatselected = 'Y'
		END 

		IF @ownparty_name IS NOT NULL 
		BEGIN
			INSERT INTO @own_party_array (own_party)
			SELECT[value] FROM OPENJSON(@ownparty_name);

			IF (SELECT count(own_party) FROM @own_party_array)>0
				SET @isownpartyselected = 'Y'
			ELSE
				SET @isownpartyselected = 'N'
		END 
		

		--IF (@iselrselected = 'N' AND @start_mileage_from = -1 AND @start_mileage_to = 99999 AND @railway_id IS NULL AND @ast_grp_id = 0 AND @isasttypselected = 'N' AND @ownparty_name IS NULL
		--	AND @mattyp_id = 0 AND @hceflg_name = 'All' AND @open_defect_from = -1 AND @open_defect_to = 99999 
		--	AND @open_defect_score_from = -1 AND @open_defect_score_to = 99999)
		IF (@iselrselected = 'N' AND @start_mileage_from = -1 AND @start_mileage_to = 99999 AND @railway_id IS NULL AND @ast_grp_id = 0 AND @isasttypselected = 'N' AND @isownpartyselected = 'N'
			AND @ismatselected = 'N' AND @hceflg_name = 'All' AND @open_defect_from = -1 AND @open_defect_to = 99999 
			AND @open_defect_score_from = -1 AND @open_defect_score_to = 99999)
			
			SET @isbasicsearch = 'Y'
		ELSE
			SET @isbasicsearch = 'N'
		
		IF @isbasicsearch = 'N'		-- Advanced Search
		BEGIN
			

				INSERT INTO #tbl_SearchResult
				(
						asset_guid,
						region,
						route,
						area,
						elr,
						struct_no,
						op_status,
						start_mileage,
						end_mileage,
						asset_group,
						struct_type,
						mat_type,
						owner,
						hce_flag,
						total_defects,
						open_defects,
						highest_open_risk_score
				)
				SELECT 
					ast.ASSET_GUID AS asset_guid,
					o.REGION AS region,
					o.ROUTE AS route,
					a.AREA_NAME AS area,
					elr.ELR_CODE AS elr,
					ast.RAILWAY_ID AS struct_no,
					ops.REF_VALUE AS op_status,
					(ast.START_MILES + ast.START_YARDS/1760) AS start_mileage,
					(ast.END_MILES + ast.END_YARDS/1760) AS end_mileage,
					asg.ASSET_GROUP_DESC AS asset_group,
					asp.ASSET_TYPE_DESC AS struct_type,
					mat.REF_VALUE AS mat_type,
					ast.OWNING_PARTY AS [owner],
					CASE WHEN ast.HCE_FLAG = 'Y' THEN 'Yes' ELSE 'No' END AS hce_flag,
					ISNULL(dtl.total_defects,0),
					ISNULL(dtl.open_defects,0),
					ISNULL(dtl.highest_open_risk_score,0)
												
				FROM [CES].ASSET ast
				INNER JOIN [CES].ORG o
				ON ast.ORG_SR_KEY = o.ORG_SR_KEY
				INNER JOIN [CES].AREA a
				ON a.AREA_SR_KEY = ast.AREA_SR_KEY
				INNER JOIN [CES].ENGINE_LINE_REF elr
				ON elr.ELR_SR_KEY = ast.ENG_LINE_REF
				AND elr.ORG_SR_KEY = ast.ORG_SR_KEY
				AND elr.AREA_SR_KEY = ast.AREA_SR_KEY
				INNER JOIN [CES].ASSET_GROUP asg
				ON asg.ASSET_GROUP_SR_KEY = ast.ASSET_GROUP_SR_KEY
				INNER JOIN [CES].ASSET_TYPE asp
				ON asp.ASSET_TYPE_SR_KEY = ast.ASSET_TYPE_SR_KEY
				LEFT JOIN [CES].REFERENCE_VALUE mat
				ON mat.REF_VAL_SR_KEY = ast.PRIMARY_MATERIAL
				AND mat.ISACTIVE = 1
				LEFT JOIN [CES].REFERENCE_VALUE ops
				ON ops.REF_VAL_SR_KEY = ast.OPERATIONAL_STATUS
				AND ops.ISACTIVE = 1
				LEFT JOIN --OUTER APPLY
					(
						SELECT 
							d.ASSET_GUID,
							COUNT(DISTINCT d.DEFECT_ID) AS total_defects,
							COUNT(DISTINCT CASE WHEN d.IS_DEFECT_CLOSED = 'N' THEN d.DEFECT_ID ELSE NULL END) AS open_defects,  --Release 2 -US# 37567: Modified to make the logic dependent on new column IS_DEFECT_CLOSED
							MAX(CASE WHEN d.IS_DEFECT_CLOSED = 'N' AND d.lst_exam_rnk = 1 THEN IIF(RISK_SCORE='N/A',0,RISK_SCORE) ELSE 0 END) AS highest_open_risk_score --Release 2 -US# 37567: Modified to make the logic dependent on new column IS_DEFECT_CLOSED
						FROM
						(
							SELECT
								df.ASSET_GUID,
								df.DEFECT_ID,
								df.IS_DEFECT_CLOSED,  --Release 2 -US# 37567: Modified to make the logic dependent on new column IS_DEFECT_CLOSED
								df.RISK_SCORE,
								DENSE_RANK() OVER (PARTITION BY df.DEFECT_ID ORDER BY ISNULL(ex.[EXAM_ACTUAL_DATE],df.EXAM_DATE) DESC	) AS lst_exam_rnk
							FROM [CES].DEFECT df
							LEFT JOIN [CES].EXAM AS ex
							ON df.ASSET_GUID = ex.ASSET_GUID
							AND df.EXAM_SR_KEY = ex.EXAM_SR_KEY
							AND ex.ISACTIVE = 1
							WHERE df.ISACTIVE = 1
							
						)d
						GROUP BY d.ASSET_GUID
					)dtl
					ON  dtl.ASSET_GUID = ast.ASSET_GUID
				WHERE
					ast.ISACTIVE= 1
				AND o.ISACTIVE = 1
				AND elr.ISACTIVE = 1
				AND asp.ISACTIVE = 1
				AND o.REGION = @region_name
				AND ( @route_id =0 OR (@route_id <> 0 AND o.ORG_SR_KEY = @route_id))
				AND	( @area_id =0 OR (@area_id <> 0 AND a.AREA_SR_KEY = @area_id))
				AND ( @iselrselected = 'N' OR (@iselrselected = 'Y' AND ast.ENG_LINE_REF IN (SELECT elr_id FROM @elr_id_array)) )
				AND ( (ast.START_MILES + ast.START_YARDS/1760) BETWEEN @start_mileage_from AND @start_mileage_to)
				--AND ( @railway_id IS NULL OR (@railway_id IS NOT NULL AND ast.RAILWAY_ID = @railway_id))
				AND ( @railway_id IS NULL OR (@railway_id IS NOT NULL AND ast.RAILWAY_ID LIKE ('%' + @railway_id + '%')))
				AND ( @ast_grp_id =0 OR (@ast_grp_id <> 0 AND asg.ASSET_GROUP_SR_KEY = @ast_grp_id))
				AND ( @isasttypselected = 'N' OR (@isasttypselected = 'Y' AND asp.ASSET_TYPE_SR_KEY IN (SELECT ast_typ_id FROM @ast_typ)) )
				--AND	( @ownparty_name IS NULL OR (@ownparty_name IS NOT NULL AND ast.OWNING_PARTY = @ownparty_name))
				AND	( @isownpartyselected ='N' OR  (@isownpartyselected = 'Y' AND ast.OWNING_PARTY IN (SELECT own_party FROM @own_party_array)))
				--AND ( @mattyp_id =0 OR (@mattyp_id <> 0 AND mat.REF_VAL_SR_KEY = @mattyp_id))
				AND ( @ismatselected = 'N' OR (@ismatselected = 'Y' AND mat.REF_VAL_SR_KEY IN (SELECT mat_id FROM @mat_id_array)) )
				AND ( @hceflg_name ='All' OR (@hceflg_name = 'Yes' AND ast.HCE_FLAG = 'Y') OR (@hceflg_name = 'No' AND ast.HCE_FLAG = 'N') )
				AND ( ISNULL(dtl.open_defects,0) BETWEEN @open_defect_from AND @open_defect_to)
				AND ( ISNULL(dtl.highest_open_risk_score,0) BETWEEN @open_defect_score_from AND @open_defect_score_to)
				
		END

		ELSE	--Basic search
		BEGIN
		
				INSERT INTO #tbl_SearchResult
				(
						asset_guid,
						region,
						route,
						area,
						elr,
						struct_no,
						op_status,
						start_mileage,
						end_mileage,
						asset_group,
						struct_type,
						mat_type,
						owner,
						hce_flag,
						total_defects,
						open_defects,
						highest_open_risk_score
				)
				SELECT 
					ast.ASSET_GUID AS asset_guid,
					o.REGION AS region,
					o.ROUTE AS route,
					a.AREA_NAME AS area,
					elr.ELR_CODE AS elr,
					ast.RAILWAY_ID AS struct_no,
					ops.REF_VALUE AS op_status,
					(ast.START_MILES + ast.START_YARDS/1760) AS start_mileage,
					(ast.END_MILES + ast.END_YARDS/1760) AS end_mileage,
					asg.ASSET_GROUP_DESC AS asset_group,
					asp.ASSET_TYPE_DESC AS struct_type,
					mat.REF_VALUE AS mat_type,
					ast.OWNING_PARTY AS [owner],
					CASE WHEN ast.HCE_FLAG = 'Y' THEN 'Yes' ELSE 'No' END AS hce_flag,
					ISNULL(dtl.total_defects,0),
					ISNULL(dtl.open_defects,0),
					ISNULL(dtl.highest_open_risk_score,0)
												
				FROM [CES].ASSET ast
				INNER JOIN [CES].ORG o
				ON ast.ORG_SR_KEY = o.ORG_SR_KEY
				INNER JOIN [CES].AREA a
				ON a.AREA_SR_KEY = ast.AREA_SR_KEY
				INNER JOIN [CES].ENGINE_LINE_REF elr
				ON elr.ELR_SR_KEY = ast.ENG_LINE_REF
				INNER JOIN [CES].ASSET_GROUP asg
				ON asg.ASSET_GROUP_SR_KEY = ast.ASSET_GROUP_SR_KEY
				INNER JOIN [CES].ASSET_TYPE asp
				ON asp.ASSET_TYPE_SR_KEY = ast.ASSET_TYPE_SR_KEY
				LEFT JOIN [CES].REFERENCE_VALUE mat
				ON mat.REF_VAL_SR_KEY = ast.PRIMARY_MATERIAL
				AND mat.ISACTIVE = 1
				LEFT JOIN [CES].REFERENCE_VALUE ops
				ON ops.REF_VAL_SR_KEY = ast.OPERATIONAL_STATUS
				AND ops.ISACTIVE = 1
				LEFT JOIN --OUTER APPLY
					(
						SELECT 
							d.ASSET_GUID,
							COUNT(DISTINCT d.DEFECT_ID) AS total_defects,
							COUNT(DISTINCT CASE WHEN d.IS_DEFECT_CLOSED = 'N' THEN d.DEFECT_ID ELSE NULL END) AS open_defects,  --Release 2 -US# 37567: Modified to make the logic dependent on new column IS_DEFECT_CLOSED
							MAX(CASE WHEN d.IS_DEFECT_CLOSED = 'N' AND d.lst_exam_rnk = 1 THEN IIF(RISK_SCORE='N/A',0,RISK_SCORE) ELSE 0 END) AS highest_open_risk_score  --Release 2 -US# 37567: Modified to make the logic dependent on new column IS_DEFECT_CLOSED
						FROM
						(
							SELECT
								df.ASSET_GUID,
								df.DEFECT_ID,
								df.IS_DEFECT_CLOSED,   --Release 2 -US# 37567: Modified to make the logic dependent on new column IS_DEFECT_CLOSED
								df.RISK_SCORE,
								DENSE_RANK() OVER (PARTITION BY df.DEFECT_ID ORDER BY ISNULL(ex.[EXAM_ACTUAL_DATE],df.EXAM_DATE) DESC	) AS lst_exam_rnk
							FROM [CES].DEFECT df
							LEFT JOIN [CES].EXAM AS ex
							ON df.ASSET_GUID = ex.ASSET_GUID
							AND df.EXAM_SR_KEY = ex.EXAM_SR_KEY
							AND ex.ISACTIVE = 1
							WHERE df.ISACTIVE = 1
							
						)d
						GROUP BY d.ASSET_GUID
					)dtl
				ON dtl.ASSET_GUID = ast.ASSET_GUID
				WHERE
					ast.ISACTIVE= 1
				AND o.ISACTIVE = 1
				AND elr.ISACTIVE = 1
				AND asp.ISACTIVE = 1
				AND o.REGION = @region_name
				AND ( @route_id =0 OR (@route_id <> 0 AND o.ORG_SR_KEY = @route_id))
				AND	( @area_id =0 OR (@area_id <> 0 AND a.AREA_SR_KEY = @area_id))

				
		END
		
		--Total count of records
		SELECT @totalresultcnt = COUNT(1) FROM #tbl_SearchResult


		--If no records are returned in search result
		IF  @totalresultcnt=0 
		BEGIN
			SET @result=
					(
						SELECT 
							JSON_QUERY(
										(
											select
												@pageno AS currentpage,
												@totalresultcnt AS totalcount,
												0 AS totalpages
											FOR JSON PATH,WITHOUT_ARRAY_WRAPPER
										)
							) searchdatacount,
							JSON_QUERY('[]') searchresult
						
						FOR JSON PATH,WITHOUT_ARRAY_WRAPPER, INCLUDE_NULL_VALUES
				)
		END	
		--If alt least 1 record is returned in search result
		ELSE
		BEGIN
			IF @isexporttodoc = 'Y' --Export to Excel
			BEGIN
					IF @sortorder = 'asc' 
					BEGIN
				
						SET @result=
						(
							SELECT 
								JSON_QUERY(
											(
												select
													@pageno AS currentpage,
													@totalresultcnt AS totalcount,
													CEILING(@totalresultcnt/@rowsperpage) AS totalpages
												FOR JSON PATH,WITHOUT_ARRAY_WRAPPER
											)
								) searchdatacount,
							(
								SELECT
									asset_guid,
									region,
									route,
									area,
									elr,
									struct_no,
									start_mileage,
									struct_type,
									mat_type,
									owner,
									hce_flag,
									total_defects,
									open_defects,
									highest_open_risk_score,
									op_status,
									end_mileage,
									asset_group
								FROM
								(
									SELECT
											asset_guid,
											region,
											route,
											area,
											elr,
											struct_no,
											start_mileage,
											struct_type,
											mat_type,
											owner,
											hce_flag,
											total_defects,
											open_defects,
											highest_open_risk_score,
											op_status,
											end_mileage,
											asset_group,
											ROW_NUMBER() OVER (ORDER BY 
																		CASE WHEN @sortcolumn = 'AssetGUID' THEN asset_guid ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'Region' THEN region  ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'Route' THEN [route] ELSE NULL END ASC, 
																		CASE WHEN @sortcolumn = 'Area' THEN area ELSE NULL END ASC, 
																		CASE WHEN @sortcolumn = 'ELR' THEN elr ELSE NULL END  ASC, 
																		CASE WHEN @sortcolumn = 'StructureNo' THEN struct_no  ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'StartMileage' THEN start_mileage  ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'StructType' THEN struct_type ELSE NULL END ASC, 
																		CASE WHEN @sortcolumn = 'MaterialType' THEN mat_type ELSE NULL END ASC, 
																		CASE WHEN @sortcolumn = 'OwningParty' THEN [owner] ELSE NULL END ASC, 
																		CASE WHEN @sortcolumn = 'HCE' THEN hce_flag ELSE NULL END ASC, 
																		CASE WHEN @sortcolumn = 'AllDefect' THEN total_defects ELSE NULL END ASC, 
																		CASE WHEN @sortcolumn = 'OpenDefect' THEN open_defects  ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'HighestRiskScore' THEN highest_open_risk_score ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'OperationalStat' THEN op_status ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'EndMileage' THEN end_mileage ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'AssetGrp' THEN asset_group ELSE NULL END ASC
																	
																	) AS ordrnk

									FROM #tbl_SearchResult
								)sr
								ORDER BY ordrnk
								FOR JSON AUTO, INCLUDE_NULL_VALUES
							)searchresult
							FOR JSON PATH,WITHOUT_ARRAY_WRAPPER, INCLUDE_NULL_VALUES
						)
					END
					ELSE IF @sortorder = 'desc' 
					BEGIN
					
						SET @result=
						(
							SELECT 
								JSON_QUERY(
											(
												select
													@pageno AS currentpage,
													@totalresultcnt AS totalcount,
													CEILING(@totalresultcnt/@rowsperpage) AS totalpages
												FOR JSON PATH,WITHOUT_ARRAY_WRAPPER
											)
								) searchdatacount,
							(
								SELECT
									asset_guid,
									region,
									route,
									area,
									elr,
									struct_no,
									start_mileage,
									struct_type,
									mat_type,
									owner,
									hce_flag,
									total_defects,
									open_defects,
									highest_open_risk_score,
									op_status,
									end_mileage,
									asset_group
								FROM
								(
									SELECT
											asset_guid,
											region,
											route,
											area,
											elr,
											struct_no,
											start_mileage,
											struct_type,
											mat_type,
											owner,
											hce_flag,
											total_defects,
											open_defects,
											highest_open_risk_score,
											op_status,
											end_mileage,
											asset_group,
											ROW_NUMBER() OVER (ORDER BY 
																		CASE WHEN @sortcolumn = 'AssetGUID' THEN asset_guid ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'Region' THEN region  ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'Route' THEN [route] ELSE NULL END DESC, 
																		CASE WHEN @sortcolumn = 'Area' THEN area ELSE NULL END DESC, 
																		CASE WHEN @sortcolumn = 'ELR' THEN elr ELSE NULL END DESC, 
																		CASE WHEN @sortcolumn = 'StructureNo' THEN struct_no  ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'StartMileage' THEN start_mileage  ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'StructType' THEN struct_type ELSE NULL END DESC, 
																		CASE WHEN @sortcolumn = 'MaterialType' THEN mat_type ELSE NULL END DESC, 
																		CASE WHEN @sortcolumn = 'OwningParty' THEN [owner] ELSE NULL END DESC, 
																		CASE WHEN @sortcolumn = 'HCE' THEN hce_flag ELSE NULL END DESC, 
																		CASE WHEN @sortcolumn = 'AllDefect' THEN total_defects ELSE NULL END DESC, 
																		CASE WHEN @sortcolumn = 'OpenDefect' THEN open_defects  ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'HighestRiskScore' THEN highest_open_risk_score ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'OperationalStat' THEN op_status ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'EndMileage' THEN end_mileage ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'AssetGrp' THEN asset_group ELSE NULL END DESC
																	
																	) AS ordrnk

									FROM #tbl_SearchResult
								)sr
								ORDER BY ordrnk
								FOR JSON AUTO, INCLUDE_NULL_VALUES
							)searchresult
							FOR JSON PATH,WITHOUT_ARRAY_WRAPPER, INCLUDE_NULL_VALUES
						)
					END
			END
			ELSE IF @isexporttodoc = 'N' --Screen output
			BEGIN
				IF @sortorder = 'asc' 
					BEGIN
			
						SET @result=
						(
							SELECT 
								JSON_QUERY(
											(
												select
													@pageno AS currentpage,
													@totalresultcnt AS totalcount,
													CEILING(@totalresultcnt/@rowsperpage) AS totalpages
												FOR JSON PATH,WITHOUT_ARRAY_WRAPPER
											)
								) searchdatacount,
							(
								SELECT
									asset_guid,
									region,
									route,
									area,
									elr,
									struct_no,
									start_mileage,
									struct_type,
									mat_type,
									owner,
									hce_flag,
									total_defects,
									open_defects,
									highest_open_risk_score,
									op_status,
									end_mileage,
									asset_group
								FROM
								(
									SELECT
											asset_guid,
											region,
											route,
											area,
											elr,
											struct_no,
											start_mileage,
											struct_type,
											mat_type,
											owner,
											hce_flag,
											total_defects,
											open_defects,
											highest_open_risk_score,
											op_status,
											end_mileage,
											asset_group,
											ROW_NUMBER() OVER (ORDER BY 
																		CASE WHEN @sortcolumn = 'AssetGUID' THEN asset_guid ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'Region' THEN region  ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'Route' THEN [route] ELSE NULL END ASC, 
																		CASE WHEN @sortcolumn = 'Area' THEN area ELSE NULL END ASC, 
																		CASE WHEN @sortcolumn = 'ELR' THEN elr ELSE NULL END  ASC, 
																		CASE WHEN @sortcolumn = 'StructureNo' THEN struct_no  ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'StartMileage' THEN start_mileage  ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'StructType' THEN struct_type ELSE NULL END ASC, 
																		CASE WHEN @sortcolumn = 'MaterialType' THEN mat_type ELSE NULL END ASC, 
																		CASE WHEN @sortcolumn = 'OwningParty' THEN [owner] ELSE NULL END ASC, 
																		CASE WHEN @sortcolumn = 'HCE' THEN hce_flag ELSE NULL END ASC, 
																		CASE WHEN @sortcolumn = 'AllDefect' THEN total_defects ELSE NULL END ASC, 
																		CASE WHEN @sortcolumn = 'OpenDefect' THEN open_defects  ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'HighestRiskScore' THEN highest_open_risk_score ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'OperationalStat' THEN op_status ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'EndMileage' THEN end_mileage ELSE NULL END ASC,
																		CASE WHEN @sortcolumn = 'AssetGrp' THEN asset_group ELSE NULL END ASC
																	
																	) AS ordrnk

									FROM #tbl_SearchResult
								)sr
								WHERE sr.ordrnk BETWEEN ((@pageno - 1) * @rowsperpage +1) AND (@pageno * @rowsperpage)
								
								ORDER BY ordrnk
								FOR JSON AUTO, INCLUDE_NULL_VALUES
							)searchresult
							FOR JSON PATH,WITHOUT_ARRAY_WRAPPER, INCLUDE_NULL_VALUES
						)
					END
				
					ELSE IF @sortorder = 'desc' 
					BEGIN
				
						SET @result=
						(
							SELECT 
								JSON_QUERY(
											(
												select
													@pageno AS currentpage,
													@totalresultcnt AS totalcount,
													CEILING(@totalresultcnt/@rowsperpage) AS totalpages
												FOR JSON PATH,WITHOUT_ARRAY_WRAPPER
											)
								) searchdatacount,
							(
								SELECT
									asset_guid,
									region,
									route,
									area,
									elr,
									struct_no,
									start_mileage,
									struct_type,
									mat_type,
									owner,
									hce_flag,
									total_defects,
									open_defects,
									highest_open_risk_score,
									op_status,
									end_mileage,
									asset_group
								FROM
								(
									SELECT
											asset_guid,
											region,
											route,
											area,
											elr,
											struct_no,
											start_mileage,
											struct_type,
											mat_type,
											owner,
											hce_flag,
											total_defects,
											open_defects,
											highest_open_risk_score,
											op_status,
											end_mileage,
											asset_group,
											ROW_NUMBER() OVER (ORDER BY 
																		CASE WHEN @sortcolumn = 'AssetGUID' THEN asset_guid ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'Region' THEN region  ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'Route' THEN [route] ELSE NULL END DESC, 
																		CASE WHEN @sortcolumn = 'Area' THEN area ELSE NULL END DESC, 
																		CASE WHEN @sortcolumn = 'ELR' THEN elr ELSE NULL END DESC, 
																		CASE WHEN @sortcolumn = 'StructureNo' THEN struct_no  ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'StartMileage' THEN start_mileage  ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'StructType' THEN struct_type ELSE NULL END DESC, 
																		CASE WHEN @sortcolumn = 'MaterialType' THEN mat_type ELSE NULL END DESC, 
																		CASE WHEN @sortcolumn = 'OwningParty' THEN [owner] ELSE NULL END DESC, 
																		CASE WHEN @sortcolumn = 'HCE' THEN hce_flag ELSE NULL END DESC, 
																		CASE WHEN @sortcolumn = 'AllDefect' THEN total_defects ELSE NULL END DESC, 
																		CASE WHEN @sortcolumn = 'OpenDefect' THEN open_defects  ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'HighestRiskScore' THEN highest_open_risk_score ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'OperationalStat' THEN op_status ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'EndMileage' THEN end_mileage ELSE NULL END DESC,
																		CASE WHEN @sortcolumn = 'AssetGrp' THEN asset_group ELSE NULL END DESC
																	
																	
																	) AS ordrnk

									FROM #tbl_SearchResult
								)sr
								WHERE sr.ordrnk BETWEEN ((@pageno - 1) * @rowsperpage +1) AND (@pageno * @rowsperpage)
								
								ORDER BY ordrnk
								FOR JSON AUTO, INCLUDE_NULL_VALUES
							)searchresult
							FOR JSON PATH,WITHOUT_ARRAY_WRAPPER, INCLUDE_NULL_VALUES
						)
					END
		
			END
		END
		--PRINT @result
		SELECT @result
	END TRY
	BEGIN CATCH
		SET @ErrorMsg = ERROR_MESSAGE() + 
						' Line Num:' + CONVERT(VARCHAR(5), ERROR_LINE()) + 
						',ErrorNum:' + CONVERT(VARCHAR(5), ERROR_NUMBER()) + 
						',Severity:' + CONVERT(VARCHAR(5), ERROR_SEVERITY()) + 
						',State:' + CONVERT(VARCHAR(10), ERROR_STATE()) + 
						',Procedure:' + CONVERT(VARCHAR(25), OBJECT_NAME(@@procid)) +
						',Procedure:' + CONVERT(VARCHAR(25), ERROR_PROCEDURE());  
		DROP TABLE IF EXISTS #tbl_SearchResult;
		THROW 50000,@ErrorMsg,1;

		
	END CATCH

	DROP TABLE IF EXISTS #tbl_SearchResult;

	SET NOCOUNT OFF
END