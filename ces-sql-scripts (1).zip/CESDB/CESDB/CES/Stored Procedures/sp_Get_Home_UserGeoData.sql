﻿/***************************************************************************************************************************************            
* Name						: sp_Get_Home_UserGeoData            
* Created By				: Cognizant            
* Date Created				: 17-Dec-2020           
* Description				: This stored procedure fetchs the data for default region/route/area for the user.  
* Input Parameters			: N/A      
* Output Parameters			: N/A            
* Return Value				: N/A            
* Assumptions				: None    
* Execution Statement		: Exec [CES].sp_Get_Home_UserGeoData '1'
*								
* Modified Date     Modified By   Revision Number  Modifications            

*******************************************************************************************************************************************/ 



CREATE PROCEDURE [CES].[sp_Get_Home_UserGeoData]
	@User_ID	DECIMAL(18)
AS

BEGIN
	SET NOCOUNT ON
	BEGIN TRY
		DECLARE
				@ErrorMsg	VARCHAR(250)
				
		SELECT
			regions.region_id,
			regions.region AS region_name,
			routes.ORG_SR_KEY AS route_id,
			routes.ROUTE AS route_name,
			areas.AREA_SR_KEY AS area_id,
			areas.AREA_NAME AS area_name
		FROM [CES].ENTITLEMENT e
		INNER JOIN [CES].ORG routes
		ON	e.ORG_SR_KEY = routes.ORG_SR_KEY
		INNER JOIN [CES].AREA areas
		ON	areas.AREA_SR_KEY = e.AREA_SR_KEY
		INNER JOIN
			(
					SELECT 
						ROW_NUMBER() OVER (ORDER BY REGION) region_id,
						REGION 
					FROM
					(
						SELECT DISTINCT REGION 
						FROM [CES].ORG
						WHERE ISACTIVE = 1
					)r
				) regions
		ON regions.REGION  = routes.REGION
		WHERE e.USER_SR_KEY = @User_ID
		AND	e.ISDEFAULT = 1
		AND e.ISACTIVE = 1
		AND routes.ISACTIVE = 1
		AND areas.ISACTIVE = 1
		FOR JSON AUTO,INCLUDE_NULL_VALUES,WITHOUT_ARRAY_WRAPPER


	END TRY

	BEGIN CATCH
		SET @ErrorMsg = ERROR_MESSAGE() + 
						' Line Num:' + CONVERT(VARCHAR(5), ERROR_LINE()) + 
						',ErrorNum:' + CONVERT(VARCHAR(5), ERROR_NUMBER()) + 
						',Severity:' + CONVERT(VARCHAR(5), ERROR_SEVERITY()) + 
						',State:' + CONVERT(VARCHAR(10), ERROR_STATE()) + 
						',Procedure:' + CONVERT(VARCHAR(25), OBJECT_NAME(@@procid)) +
						',Procedure:' + CONVERT(VARCHAR(25), ERROR_PROCEDURE());  

		THROW 50000,@ErrorMsg,1;
	END CATCH
	SET NOCOUNT OFF
END