﻿
/***************************************************************************************************************************************            
* Name						: sp_Get_RiskAssessment_History            
* Created By				: Cognizant            
* Date Created				: 09-Feb-2021           
* Description				: This stored procedure provides the risk assessment history details for given asset and exam type id from compliance screen.  
* Input Parameters			: JSON      
* Output Parameters			: @OUT_ErrorNo            
* Return Value				: N/A            
* Assumptions				: None    
* Execution Statement		: Exec CES.sp_Get_RiskAssessment_History 'A07A9D40-19F0-4DCB-94AE-18D45845E089', 1
							  Exec CES.sp_Get_RiskAssessment_History '3978559E4AD245D9E04400306E4AD01A', 1
							  Exec CES.sp_Get_RiskAssessment_History '3978559C428F45D9E04400306E4AD01A', 1
							  Exec CES.sp_Get_RiskAssessment_History asset_guid,exam_type_id
*								
* Modified Date     Modified By   Revision Number  Modifications            

*******************************************************************************************************************************************/ 



CREATE PROCEDURE [CES].[sp_Get_RiskAssessment_History]
	@Asset_GUID		VARCHAR(64),
	@Exam_Type_Id   DECIMAL(18)

AS 
BEGIN
	SET NOCOUNT ON
	
	
	BEGIN TRY
		DECLARE
				@ErrorMsg						VARCHAR(250),
				@result							NVARCHAR(MAX),
				@totalcount						DECIMAL(18),
				@pageno							DECIMAL(18)		
				
				IF (@Asset_GUID IS NULL or LTRIM(RTRIM(@Asset_GUID)) = '')
				BEGIN
					SET @ErrorMsg = 'Asset guid should not be null or empty';
					THROW 50000,@ErrorMsg,1;
				END

				IF (@Exam_Type_Id IS NULL or ISNULL(@Exam_Type_Id,0) = 0)
				BEGIN
					SET @ErrorMsg = 'Exam type id should not be null or empty';
					THROW 50000,@ErrorMsg,1;
				END
								
				SELECT @totalcount=COUNT(1) FROM CES.RISK_ASSESSMENT WHERE ASSET_GUID =@Asset_GUID AND EXAM_TYPE_SR_KEY=@Exam_Type_Id
											
				IF @totalcount>0 
				BEGIN
					SET @result=
					(
						SELECT 
							@totalcount AS searchdatacount,
							(
								SELECT
									ast.asset_guid,
									elr.ELR_CODE AS elr,
									ast.railway_id,
									(ast.START_MILES + ast.START_YARDS/1760 ) AS start_mileage,
									asg.ASSET_GROUP_DESC AS asset_grp,
									asst.ASSET_TYPE_DESC AS asset_type,
									rv.REF_VALUE AS ops_status,
									ast.owning_party,
									rvp.REF_VALUE AS prim_material
								FROM CES.ASSET ast
								INNER JOIN CES.ENGINE_LINE_REF elr
								ON ast.ENG_LINE_REF = elr.ELR_SR_KEY
								INNER JOIN CES.ASSET_GROUP asg
								ON asg.ASSET_GROUP_SR_KEY = ast.ASSET_GROUP_SR_KEY
								INNER JOIN CES.ASSET_TYPE asst
								ON asst.ASSET_TYPE_SR_KEY = ast.ASSET_TYPE_SR_KEY
								LEFT JOIN CES.REFERENCE_VALUE rv
								ON rv.REF_VAL_SR_KEY = ast.OPERATIONAL_STATUS
								AND rv.ISACTIVE = 1
								LEFT JOIN CES.REFERENCE_VALUE rvp
								ON rvp.REF_VAL_SR_KEY = ast.PRIMARY_MATERIAL
								AND rvp.ISACTIVE = 1
								WHERE 
									ast.ISACTIVE = 1
									AND elr.ISACTIVE = 1
									AND asg.ISACTIVE = 1
									AND asst.ISACTIVE = 1
									AND ast.ASSET_GUID = @Asset_GUID 
								FOR JSON PATH,INCLUDE_NULL_VALUES
							)assetdtls,
							(
								SELECT
								rowrank,
								assessment_date,
								review_date,
								expiry_date,
								risk_score,
								mitigation_comment,
								risk_user,
								question_01,
								question_01_ans,							
								question_01_cmt,
								question_02,
								question_02_ans,
								question_02_cmt,
								question_03,
								question_03_ans,
								question_03_cmt,
								question_04,
								question_04_ans,
								question_04_cmt,
								mitigation_date,
								mitigation_action_01,
								mitigation_action_01_selection,
								mitigation_action_02,
								mitigation_action_02_selection,
								mitigation_action_03,
								mitigation_action_03_selection,
								mitigation_action_04,
								mitigation_action_04_selection,
								mitigation_action_05,
								mitigation_action_05_selection,
								mitigation_action_06,
								mitigation_action_06_selection,
								mitigation_action_07,
								mitigation_action_07_selection
								
								FROM
								(
									SELECT 
									ASSESSMENT_DATE AS assessment_date,
									REVIEW_DATE AS review_date,
									[EXPIRY_DATE] AS expiry_date,
									RISK_SCORE AS risk_score,
									MITIGATION_COMMENT AS mitigation_comment,
									RISK_USER AS risk_user,
									QUESTION_01 AS question_01,
									QUESTION_01_ANS AS question_01_ans,
									QUESTION_01_CMT AS question_01_cmt,
									QUESTION_02 AS question_02,
									QUESTION_02_ANS AS question_02_ans,
									QUESTION_02_CMT AS question_02_cmt,
									QUESTION_03 AS question_03,
									QUESTION_03_ANS AS question_03_ans,
									QUESTION_03_CMT AS question_03_cmt,
									QUESTION_04 AS question_04,
									QUESTION_04_ANS AS question_04_ans,
									QUESTION_04_CMT AS question_04_cmt,
									MITIGATION_DATE AS mitigation_date,
									MITIGATION_ACTION_01 AS mitigation_action_01,
									MITIGATION_ACTION_01_SELECTION AS mitigation_action_01_selection,
									MITIGATION_ACTION_02 AS mitigation_action_02,
									MITIGATION_ACTION_02_SELECTION AS mitigation_action_02_selection,
									MITIGATION_ACTION_03 AS mitigation_action_03,
									MITIGATION_ACTION_03_SELECTION AS mitigation_action_03_selection,
									MITIGATION_ACTION_04 AS mitigation_action_04,
									MITIGATION_ACTION_04_SELECTION AS mitigation_action_04_selection,
									MITIGATION_ACTION_05 AS mitigation_action_05,
									MITIGATION_ACTION_05_SELECTION AS mitigation_action_05_selection,
									MITIGATION_ACTION_06 AS mitigation_action_06,
									MITIGATION_ACTION_06_SELECTION AS mitigation_action_06_selection,
									MITIGATION_ACTION_07 AS mitigation_action_07,
									MITIGATION_ACTION_07_SELECTION AS mitigation_action_07_selection,
									ROW_NUMBER() OVER (ORDER BY ASSESSMENT_DATE DESC,RISK_SR_KEY DESC) AS rowrank
									FROM CES.RISK_ASSESSMENT WHERE ASSET_GUID =@Asset_GUID AND EXAM_TYPE_SR_KEY=@Exam_Type_Id															
								)RES
								ORDER BY rowrank
								FOR JSON AUTO, INCLUDE_NULL_VALUES
							) AS risk_history
							 
						FOR JSON PATH, INCLUDE_NULL_VALUES, WITHOUT_ARRAY_WRAPPER
					) 
					
				END
				ELSE
				BEGIN
					SET @result=
					(
						SELECT 
							@totalcount AS searchdatacount,
							JSON_QUERY('[]') AS assetdtls,
							JSON_QUERY('[]') AS risk_history
						FOR JSON PATH, INCLUDE_NULL_VALUES, WITHOUT_ARRAY_WRAPPER
					)
				END

		SELECT @result
		
	END TRY
	BEGIN CATCH
		SET @ErrorMsg = ERROR_MESSAGE() + 
						' Line Num:' + CONVERT(VARCHAR(5), ERROR_LINE()) + 
						',ErrorNum:' + CONVERT(VARCHAR(5), ERROR_NUMBER()) + 
						',Severity:' + CONVERT(VARCHAR(5), ERROR_SEVERITY()) + 
						',State:' + CONVERT(VARCHAR(10), ERROR_STATE()) + 
						',Procedure:' + CONVERT(VARCHAR(25), ERROR_PROCEDURE());  
		
		
		THROW 50000,@ErrorMsg,1;

		
	END CATCH
	
	SET NOCOUNT OFF
END