﻿


CREATE PROCEDURE [CES].[sp_Upsert_ExamCycle_ADF]
	@Input_JSON		NVARCHAR(MAX)

AS 

BEGIN
	SET NOCOUNT ON
    BEGIN TRY
		DECLARE
				@ErrorMsg			VARCHAR(250),
				@ErrorDescription   VARCHAR(4000),
				@Output				BIT = 0,
				@CurrentDate		DATETIME  = GETDATE(),
				@User				VARCHAR(16) = 'CARRS'
		
		DROP TABLE IF EXISTS #tmpAsExamCycle_ADF

		CREATE TABLE #tmpAsExamCycle_ADF
		(
			ASSET_GUID				 varchar(32),
			CARRS_EXAM_TYPE_CYCLE_ID decimal(18),
			EFFECTIVE_TO_DATE		 date,
			EFFECTIVE_FROM_DATE		 date,
			EXAM_REQUIREMENT         varchar(1000),
			INTERVAL_YEARS			 decimal(5),
			INTERVAL_MONTHS			 decimal(5),
			INTERVAL_DAYS 			 decimal(5),
			BIRTHDAY_MONTH			 decimal(5),
			BIRTHDAY_DAY             decimal(5),
			EXAM_TYPE_SR_KEY	     decimal(18),
			CREATED_DATE             datetime,
			CREATED_USER			 varchar(64),
			UPDATED_DATE			 datetime,
			UPDATED_USER             varchar(64),
			ISACTIVE                 bit
		)
		
		--Parsing the input JSON and gathering the records					
		INSERT INTO #tmpAsExamCycle_ADF
		(
			ASSET_GUID				 ,
			CARRS_EXAM_TYPE_CYCLE_ID ,
			EFFECTIVE_TO_DATE		 ,
			EFFECTIVE_FROM_DATE		 ,
			EXAM_REQUIREMENT         ,
			INTERVAL_YEARS			 ,
			INTERVAL_MONTHS			 ,
			INTERVAL_DAYS 			 ,
			BIRTHDAY_MONTH			 ,
			BIRTHDAY_DAY             ,
			EXAM_TYPE_SR_KEY	     ,
			CREATED_DATE             ,
			CREATED_USER			 ,
			UPDATED_DATE			 ,
			UPDATED_USER             ,
			ISACTIVE                 
		)
		SELECT				
			ast.ASSET_GUID				      ,
			ast.EXAM_GROUP_EXAM_TYPE_CYCLE_ID ,
			ast.EFF_TO_DATE		      		  ,
			ast.EFF_FROM_DATE		          ,
			ast.EXAM_REQUIREMENT              ,
			ast.INTERVAL_YEARS			      ,
			ast.INTERVAL_MONTHS			      ,
			ast.INTERVAL_DAYS 			      ,
			ast.BIRTHDAY_MONTH			      ,
			ast.BIRTHDAY_DAY                  ,
			ast.EXAM_TYPE_SR_KEY	          ,
			ast.CREATED_DATE                  ,
			ast.CREATED_USER			      ,
			ast.UPDATED_DATE			      ,
			ast.UPDATED_USER                  ,
			CASE
			 WHEN ast.DELETED_FLG = 'Y' THEN 0
			 WHEN ast.DELETED_FLG = 'N' THEN 1
			END AS ISACTIVE
		FROM	OPENJSON(@Input_JSON)
		WITH 
			(
			ASSET_GUID					  varchar(32),
			EXAM_GROUP_EXAM_TYPE_CYCLE_ID decimal(18),
			EFF_TO_DATE		              date,
			EFF_FROM_DATE		          date,
			EXAM_REQUIREMENT              varchar(1000),
			INTERVAL_YEARS			      decimal(5),
			INTERVAL_MONTHS			      decimal(5),
			INTERVAL_DAYS 			      decimal(5),
			BIRTHDAY_MONTH			      decimal(5),
			BIRTHDAY_DAY                  decimal(5),
			EXAM_TYPE_SR_KEY	          decimal(18),
			CREATED_DATE                  datetime,
			CREATED_USER			      varchar(64),
			UPDATED_DATE			      datetime,
			UPDATED_USER                  varchar(64),
			DELETED_FLG				      char
			) AS ast

		--- Validation Checks -- Start

		BEGIN TRAN

		MERGE CES.EXAM_CYCLE AS TARGET
		USING #tmpAsExamCycle_ADF As SOURCE
		ON (TARGET.CARRS_EXAM_TYPE_CYCLE_ID  = SOURCE.CARRS_EXAM_TYPE_CYCLE_ID  )
		WHEN MATCHED 
		   THEN UPDATE SET 
		    TARGET.ASSET_GUID	 = SOURCE.ASSET_GUID				,  
			TARGET.EFFECTIVE_TO_DT = SOURCE.EFFECTIVE_TO_DATE	    ,        
			TARGET.EFFECTIVE_FROM_DT = SOURCE.EFFECTIVE_FROM_DATE ,        
			TARGET.EXAM_REQUIREMENT  = SOURCE.EXAM_REQUIREMENT      ,      
			TARGET.INTERVAL_YEARS = SOURCE.INTERVAL_YEARS			,    
			TARGET.INTERVAL_MONTHS = SOURCE.INTERVAL_MONTHS			,    
			TARGET.INTERVAL_DAYS = SOURCE.INTERVAL_DAYS 			,    
			TARGET.BIRTHDAY_MONTH = SOURCE.BIRTHDAY_MONTH			,    
			TARGET.BIRTHDAY_DAY  = SOURCE.BIRTHDAY_DAY              ,  
			TARGET.EXAM_TYPE_SR_KEY = SOURCE.EXAM_TYPE_SR_KEY	    ,    
			TARGET.CREATED_DATE  = SOURCE.CREATED_DATE              ,  
			TARGET.CREATED_USER = SOURCE.CREATED_USER			    ,
		    TARGET.ISACTIVE = SOURCE.ISACTIVE						, 
		    UPDATED_USER = @User									, 
		    UPDATED_DATE = @CurrentDate
		WHEN NOT MATCHED BY TARGET AND (SOURCE.ISACTIVE = 1)
		   THEN INSERT (
		    
		    ASSET_GUID					  ,
			CARRS_EXAM_TYPE_CYCLE_ID      ,
			EFFECTIVE_TO_DT	      ,
			EFFECTIVE_FROM_DT 		  ,
			EXAM_REQUIREMENT              ,
			INTERVAL_YEARS			      ,
			INTERVAL_MONTHS			      ,
			INTERVAL_DAYS 			      ,
			BIRTHDAY_MONTH			      ,
			BIRTHDAY_DAY                  ,
			EXAM_TYPE_SR_KEY	          ,
			CREATED_DATE                  ,
			CREATED_USER			      
			) 
			VALUES(
			   SOURCE.ASSET_GUID		            ,
			   SOURCE.CARRS_EXAM_TYPE_CYCLE_ID      ,
			   SOURCE.EFFECTIVE_TO_DATE		        ,   
			   SOURCE.EFFECTIVE_FROM_DATE	        ,
			   SOURCE.EXAM_REQUIREMENT              ,
			   SOURCE.INTERVAL_YEARS	            , 
			   SOURCE.INTERVAL_MONTHS	            , 
			   SOURCE.INTERVAL_DAYS 	            , 
			   SOURCE.BIRTHDAY_MONTH	            , 
			   SOURCE.BIRTHDAY_DAY                  ,
			   SOURCE.EXAM_TYPE_SR_KEY	            , 			
			   @CurrentDate,
			   @User);		
		COMMIT TRAN
		SET @Output = 1

		 SELECT @Output AS SaveStatus,NULL AS ErrorMsg;
	END TRY

	BEGIN CATCH
		IF (@@TRANCOUNT >0)
			ROLLBACK TRAN
		
		IF @ErrorMsg IS NULL
			SET @ErrorMsg = ERROR_MESSAGE() 
		
		SET @ErrorDescription = @ErrorMsg + 
							' Line Num:' + CONVERT(VARCHAR(5), ERROR_LINE()) + 
							',ErrorNum:' + CONVERT(VARCHAR(5), ERROR_NUMBER()) + 
							',Severity:' + CONVERT(VARCHAR(5), ERROR_SEVERITY()) + 
							',State:' + CONVERT(VARCHAR(10), ERROR_STATE()) + 
							',Procedure:' + CONVERT(VARCHAR(25), OBJECT_NAME(@@procid)) +
							',Procedure:' + CONVERT(VARCHAR(25), ERROR_PROCEDURE())

		SET @Output = 0;
		SELECT @Output AS SaveStatus,@ErrorMsg AS ErrorMsg;

		THROW 50000,@ErrorDescription,1;
	END CATCH

	DROP TABLE IF EXISTS #tmpAsExamCycle_ADF;
	SET NOCOUNT OFF
  END