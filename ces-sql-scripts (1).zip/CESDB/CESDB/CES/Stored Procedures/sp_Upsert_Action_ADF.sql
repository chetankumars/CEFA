﻿


CREATE PROCEDURE [CES].[sp_Upsert_Action_ADF]
	@Input_JSON		NVARCHAR(MAX)

AS 

BEGIN
	SET NOCOUNT ON
    BEGIN TRY
		DECLARE
				@ErrorMsg			VARCHAR(250),
				@ErrorDescription   VARCHAR(4000),
				@Output				BIT = 0,
				@CurrentDate		DATETIME  = GETDATE(),
				@User				VARCHAR(16) = 'CARRS'
		
		DROP TABLE IF EXISTS #tmpAsAction_ADF

		CREATE TABLE #tmpAsAction_ADF
		(
			RECOMMEND_SR_KEY   decimal(18),
			CARRS_ACTION_ID    decimal(18),
			RECOMMEND_NUM	   decimal(18),
			ACTION_NUM         decimal(18),
			DESCRIPTION        varchar(1000),
			PRIORITY_YEAR	   decimal(18),
			LOCATION  		   varchar(128)	,
			ESTIMATED_COST	   decimal(18),
            QUANTITY		   decimal(18),
			QUANTITY_UNIT      varchar(32),
			EXTENT             varchar(12),
			PROBABILITY		   varchar(5),
			SEVERITY		   varchar(5),
			RISK_SCORE		   varchar(5),
			WORK_CATEGORY	   decimal(18),
			WORK_STATUS        decimal(18),
			WORK_TYPE          decimal(18),
			NOTES			   varchar(4000),
			CREATED_DATE       datetime,
			CREATED_USER	   varchar(64),
			UPDATED_DATE	   datetime,
			UPDATED_USER       varchar(64),
			ISACTIVE           bit
		)
		
		--Parsing the input JSON and gathering the records					
		INSERT INTO #tmpAsAction_ADF
		(
			RECOMMEND_SR_KEY  ,
			CARRS_ACTION_ID   ,
			RECOMMEND_NUM	  ,
			ACTION_NUM        ,
			DESCRIPTION       ,
			PRIORITY_YEAR	  ,
			LOCATION  		  ,
			ESTIMATED_COST	  ,
            QUANTITY		  ,
			QUANTITY_UNIT     ,
			EXTENT            ,
			PROBABILITY		  ,
			SEVERITY		  ,
			RISK_SCORE		  ,
			WORK_CATEGORY	  ,
			WORK_STATUS       ,
			WORK_TYPE         ,
			NOTES			  ,
			CREATED_DATE      ,
			CREATED_USER	  ,
			UPDATED_DATE	  ,
			UPDATED_USER      ,
			ISACTIVE 
		)
		SELECT				
			ast.RECOMMEND_SR_KEY  ,
			ast.CARRS_ACTION_ID   ,
			ast.RECOMMEND_NUM	  ,
			ast.ACTION_NUM        ,
			ast.DESCRIPTION       ,
			ast.PRIORITY_YEAR	  ,
			ast.LOCATION  		  ,
			ast.ESTIMATED_COST	  ,
            ast.QUANTITY		  ,
			ast.QUANTITY_UNIT     ,
			ast.EXTENT            ,
			ast.PROBABILITY		  ,
			ast.SEVERITY		  ,
			ast.RISK_SCORE		  ,
			ast.WORK_CATEGORY	  ,
			ast.WORK_STATUS       ,
			ast.WORK_TYPE         ,
			ast.NOTES			  ,
			ast.CREATED_DATE      ,
			ast.CREATED_USER	  ,
			ast.UPDATED_DATE	  ,
			ast.UPDATED_USER      ,
			CASE
			 WHEN ast.DELETED_FLG = 'Y' THEN 0
			 WHEN ast.DELETED_FLG = 'N' THEN 1
			END AS ISACTIVE
		FROM	OPENJSON(@Input_JSON)
		WITH 
			(
			RECOMMEND_SR_KEY   decimal(18),
			CARRS_ACTION_ID    decimal(18),
			RECOMMEND_NUM	   decimal(18),
			ACTION_NUM         decimal(18),
			DESCRIPTION        varchar(1000),
			PRIORITY_YEAR	   decimal(18),
			LOCATION  		   varchar(128)	,
			ESTIMATED_COST	   decimal(18),
            QUANTITY		   decimal(18),
			QUANTITY_UNIT      varchar(32),
			EXTENT             varchar(12),
			PROBABILITY		   varchar(5),
			SEVERITY		   varchar(5),
			RISK_SCORE		   varchar(5),
			WORK_CATEGORY	   decimal(18),
			WORK_STATUS        decimal(18),
			WORK_TYPE          decimal(18),
			NOTES			   varchar(4000),
			CREATED_DATE       datetime,
			CREATED_USER	   varchar(64),
			UPDATED_DATE	   datetime,
			UPDATED_USER       varchar(64),
			DELETED_FLG		   char
			) AS ast

		--- Validation Checks -- Start

		BEGIN TRAN

		MERGE CES.ACTION AS TARGET
		USING #tmpAsAction_ADF As SOURCE
		ON (TARGET.CARRS_ACTION_ID   = SOURCE.CARRS_ACTION_ID)				   
						
		WHEN MATCHED 
		   THEN UPDATE SET 
		    TARGET.RECOMMEND_SR_KEY =  SOURCE.RECOMMEND_SR_KEY ,
            TARGET.CARRS_ACTION_ID =  SOURCE.CARRS_ACTION_ID   ,
            TARGET.RECOMMEND_NUM  =  SOURCE.RECOMMEND_NUM      ,
            TARGET.ACTION_NUM   =  SOURCE.ACTION_NUM           ,
            TARGET.DESCRIPTION   =  SOURCE.DESCRIPTION         ,
            TARGET.PRIORITY_YEAR =  SOURCE.PRIORITY_YEAR       ,
            TARGET.LOCATION  =  SOURCE.LOCATION                ,
            TARGET.ESTIMATED_COST =  SOURCE.ESTIMATED_COST     ,
            TARGET.QUANTITY =  SOURCE.QUANTITY                 ,
            TARGET.QUANTITY_UNIT  =  SOURCE.QUANTITY_UNIT      ,
            TARGET.EXTENT  =  SOURCE.EXTENT                    ,
            TARGET.PROBABILITY =  SOURCE.PROBABILITY           ,
            TARGET.SEVERITY =  SOURCE.SEVERITY                 ,
            TARGET.RISK_SCORE =  SOURCE.RISK_SCORE             ,
            TARGET.WORK_CATEGORY =  SOURCE.WORK_CATEGORY       ,
            TARGET.WORK_STATUS  =  SOURCE.WORK_STATUS          ,
            TARGET.WORK_TYPE   =  SOURCE.WORK_TYPE             ,
            TARGET.NOTES =  SOURCE.NOTES                       ,
            TARGET.CREATED_DATE  =SOURCE.CREATED_DATE          ,
            TARGET.CREATED_USER  =SOURCE.CREATED_USER	  	   ,	
		    UPDATED_USER = @User							   ,	
		    UPDATED_DATE = @CurrentDate
		WHEN NOT MATCHED BY TARGET AND (SOURCE.ISACTIVE = 1)
		   THEN INSERT (
		    RECOMMEND_SR_KEY ,
            CARRS_ACTION_ID  ,
            RECOMMEND_NUM    ,
            ACTION_NUM       ,
            DESCRIPTION      ,
            PRIORITY_YEAR    ,
            LOCATION         ,
            ESTIMATED_COST   ,
            QUANTITY         ,
            QUANTITY_UNIT    ,
            EXTENT           ,
            PROBABILITY      ,
            SEVERITY         ,
            RISK_SCORE       ,
            WORK_CATEGORY    ,
            WORK_STATUS      ,
            WORK_TYPE        ,
            NOTES            ,
            CREATED_DATE     ,
            CREATED_USER     
            ) 
			VALUES(
			  SOURCE.RECOMMEND_SR_KEY ,
              SOURCE.CARRS_ACTION_ID  ,
              SOURCE.RECOMMEND_NUM,
              SOURCE.ACTION_NUM       ,
              SOURCE.DESCRIPTION      ,
              SOURCE.PRIORITY_YEAR,
              SOURCE.LOCATION  ,
              SOURCE.ESTIMATED_COST,
              SOURCE.QUANTITY,
              SOURCE.QUANTITY_UNIT    ,
              SOURCE.EXTENT           ,
              SOURCE.PROBABILITY,
              SOURCE.SEVERITY,
              SOURCE.RISK_SCORE,
              SOURCE.WORK_CATEGORY,
              SOURCE.WORK_STATUS      ,
              SOURCE.WORK_TYPE        ,
              SOURCE.NOTES,
              @CurrentDate,
			  @User);		
		COMMIT TRAN
		SET @Output = 1

		 SELECT @Output AS SaveStatus,NULL AS ErrorMsg;
	END TRY

	BEGIN CATCH
		IF (@@TRANCOUNT >0)
			ROLLBACK TRAN
		
		IF @ErrorMsg IS NULL
			SET @ErrorMsg = ERROR_MESSAGE() 
		
		SET @ErrorDescription = @ErrorMsg + 
							' Line Num:' + CONVERT(VARCHAR(5), ERROR_LINE()) + 
							',ErrorNum:' + CONVERT(VARCHAR(5), ERROR_NUMBER()) + 
							',Severity:' + CONVERT(VARCHAR(5), ERROR_SEVERITY()) + 
							',State:' + CONVERT(VARCHAR(10), ERROR_STATE()) + 
							',Procedure:' + CONVERT(VARCHAR(25), OBJECT_NAME(@@procid)) +
							',Procedure:' + CONVERT(VARCHAR(25), ERROR_PROCEDURE())

		SET @Output = 0;
		SELECT @Output AS SaveStatus,@ErrorMsg AS ErrorMsg;

		THROW 50000,@ErrorDescription,1;
	END CATCH

	DROP TABLE IF EXISTS #tmpAsAction_ADF;
	SET NOCOUNT OFF
  END