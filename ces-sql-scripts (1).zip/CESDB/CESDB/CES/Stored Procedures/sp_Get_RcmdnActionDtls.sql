﻿
/***************************************************************************************************************************************            
* Name						: sp_Get_RcmdnActionDtls            
* Created By				: Cognizant            
* Date Created				: 18-Jan-2021           
* Description				: This stored procedure fetches the Action details for Recommendation Details page.  
* Input Parameters			: Recommendation Key, Asset GUID      
* Output Parameters			: JSON            
* Return Value				: N/A            
* Assumptions				: None    
* Execution Statement		: EXEC [CES].sp_Get_RcmdnActionDtls '264224','3978559C2D9F45D9E04400306E4AD01A'
*								
* Modified Date     Modified By   Revision Number  Modifications            

*******************************************************************************************************************************************/ 



CREATE PROCEDURE [CES].[sp_Get_RcmdnActionDtls] 

    @rcmn_key  DECIMAL(18),
    @Asset_GUID VARCHAR (32)

AS 


BEGIN
	SET NOCOUNT ON
    BEGIN TRY
		DECLARE
				@ErrorMsg	VARCHAR(250),
				@result VARCHAR(MAX),
				@asset_name VARCHAR(128)

		SELECT @asset_name = ASSET_NAME 
		FROM CES.ASSET AS ast
		WHERE ast.asset_guid=@ASSET_GUID
		AND ast.ISACTIVE=1

	

		SELECT
			@asset_name         AS  structure_name,
			ac.[ACTION_NUM]	    AS	action_no,
			wt.REF_VALUE	    AS	work_type,
			wc.REF_VALUE		AS	work_category,
			ac.[LOCATION]	    AS	[location],
			ac.[DESCRIPTION]    AS	prob_statement,
			ws.REF_VALUE	    AS	work_status,
			py.REF_VALUE		AS	priority_year,
			(CAST(r.QUANTITY AS VARCHAR(20)) + ' '+ r.QUANTITY_UNIT) AS quantity,
			ac.SEVERITY         AS  severity,
			ac.PROBABILITY      AS  probability,
			ac.EXTENT           AS  extent,
			ac.RISK_SCORE       AS  risk_score,
			ac.NOTES	        AS	notes

		FROM [CES].[ACTION] AS ac
		INNER JOIN [CES].RECOMMENDATION AS r
		on ac.recommend_sr_key=r.recommend_sr_key
		LEFT JOIN CES.REFERENCE_VALUE wt
		ON wt.REF_VAL_SR_KEY = ac.WORK_TYPE
		LEFT JOIN CES.REFERENCE_VALUE wc
		ON wc.REF_VAL_SR_KEY = ac.WORK_CATEGORY
		LEFT JOIN CES.REFERENCE_VALUE ws
		ON ws.REF_VAL_SR_KEY = ac.WORK_STATUS
		LEFT JOIN CES.REFERENCE_VALUE py
		ON py.REF_VAL_SR_KEY = ac.PRIORITY_YEAR

		WHERE ac.recommend_sr_key = @rcmn_key
		AND ac.ISACTIVE = 1
		AND	r.ISACTIVE = 1
		AND wc.ISACTIVE = 1
		AND ws.ISACTIVE = 1
		
		FOR JSON PATH,INCLUDE_NULL_VALUES,WITHOUT_ARRAY_WRAPPER  

	END TRY

	BEGIN CATCH
		SET @ErrorMsg = ERROR_MESSAGE() + 
						' Line Num:' + CONVERT(VARCHAR(5), ERROR_LINE()) + 
						',ErrorNum:' + CONVERT(VARCHAR(5), ERROR_NUMBER()) + 
						',Severity:' + CONVERT(VARCHAR(5), ERROR_SEVERITY()) + 
						',State:' + CONVERT(VARCHAR(10), ERROR_STATE()) + 
						',Procedure:' + CONVERT(VARCHAR(25), OBJECT_NAME(@@procid)) +
						',Procedure:' + CONVERT(VARCHAR(25), ERROR_PROCEDURE());  

		THROW 50000,@ErrorMsg,1;
	END CATCH

	SET NOCOUNT OFF
  END
