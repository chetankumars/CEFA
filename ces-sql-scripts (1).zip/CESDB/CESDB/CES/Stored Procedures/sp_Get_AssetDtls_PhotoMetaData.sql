﻿

/***************************************************************************************************************************************            
* Name						: sp_Get_AssetDtls_photometadata            
* Created By				: Cognizant            
* Date Created				: 17-Dec-2020           
* Description				: This stored procedure fetches the photo meta data for Asset details.
* Input Parameters			: N/A      
* Output Parameters			: JSON            
* Return Value				: N/A            
* Assumptions				: None    
* Execution Statement		: EXEC [CES].sp_Get_AssetDtls_PhotoMetaData '42E8851DA2312A2FE0440017084CC843'
*								
* Modified Date     Modified By   Revision Number  Modifications            

*******************************************************************************************************************************************/ 



CREATE PROCEDURE [CES].[sp_Get_AssetDtls_PhotoMetaData] 
		@Asset_GUID		VARCHAR(32)
AS 


BEGIN
	SET NOCOUNT ON
    BEGIN TRY
		DECLARE
				@ErrorMsg	VARCHAR(250),
				@result VARCHAR(MAX)

	
		IF EXISTS (SELECT 1 FROM CES.EXAM WHERE ASSET_GUID = @Asset_GUID AND ISACTIVE = 1)

		SELECT 
			ex.[EXAM_ACTUAL_DATE] AS 'defect.exam_date'
			,et.[EXAM_TYPE] AS 'defect.exam_type'
			,ex.[EXAM_ID] AS 'defect.exam_id'
			,(
				SELECT
					im.[IMAGE_INDEX] AS img_index
					,im.[DESCRIPTION] AS img_description
					,im.IMAGE_NAME AS img_name
					,im.IMAGE_LINK AS img_link
					
				FROM [CES].[IMAGE] AS im
				WHERE ex.EXAM_SR_KEY=im.EXAM_SR_KEY
				AND im.ISACTIVE = 1
				ORDER BY im.[IMAGE_INDEX]
				FOR JSON PATH, INCLUDE_NULL_VALUES
			)img
			
		FROM [CES].[EXAM] AS ex
		INNER JOIN [CES].EXAM_TYPE AS et
		ON ex.[EXAM_TYPE_SR_KEY]=et.[EXAM_TYPE_SR_KEY]

		WHERE ex.ASSET_GUID = @Asset_GUID
		AND ex.ISACTIVE = 1
		AND et.ISACTIVE = 1

		ORDER BY ex.[EXAM_ACTUAL_DATE] 
				,et.[EXAM_TYPE] 
				,ex.[EXAM_ID]
				
		FOR JSON PATH, INCLUDE_NULL_VALUES

		ELSE 
			SELECT '[]' image_dtls
  END TRY

	BEGIN CATCH
		SET @ErrorMsg = ERROR_MESSAGE() + 
						' Line Num:' + CONVERT(VARCHAR(5), ERROR_LINE()) + 
						',ErrorNum:' + CONVERT(VARCHAR(5), ERROR_NUMBER()) + 
						',Severity:' + CONVERT(VARCHAR(5), ERROR_SEVERITY()) + 
						',State:' + CONVERT(VARCHAR(10), ERROR_STATE()) + 
						',Procedure:' + CONVERT(VARCHAR(25), OBJECT_NAME(@@procid)) +
						',Procedure:' + CONVERT(VARCHAR(25), ERROR_PROCEDURE());  

		THROW 50000,@ErrorMsg,1;
	END CATCH

	SET NOCOUNT OFF

  END
