﻿CREATE TABLE [CES].[WORK_HIST]
(
	[WORK_HIST_SR_KEY] decimal(18) NOT NULL IDENTITY (1, 1),	-- Work History Surrogate key (PK)
	[WORK_SR_KEY] decimal(18) NULL,
	[WORK_YEAR_KEY] decimal(18) NULL,	-- Financial year
	[WORK_YR_START_DT] date NULL,	-- Financial year start date
	[WORK_YR_END_DT] date NULL,	-- Financial year end date
	[ORG_SR_KEY] decimal(18) NULL,	-- Route information
	[ASSET_GUID] varchar(32) NULL,
	[EXAM_TYPE_SR_KEY] decimal(18) NULL,	-- Exam Type for the assets
	[EXAM_DUE_DATE] date NULL,	-- Exam Due Date - either default as per due date algo or as entered by the AE in Task list request screen or coming from CARRS
	[WORK_STATUS] decimal(18) NULL,
	[SPECIFIC_EXAM_REQ] varchar(1000) NULL,
	[NR_INTERNAL_NOTES] varchar(4000) NULL,	-- NR internal Notes
	[COMMENTS_TO_SEC] varchar(4000) NULL,
	[JOB_NUMBER] varchar(8000) NULL,	-- Job Number associated with examination
	[ISACTIVE] bit NULL,
	[CREATED_USER] varchar(64) NULL,	-- Created By user
	[CREATED_DATE] datetime NULL,	-- Created Date
	[UPDATED_USER] varchar(64) NULL,	-- Updated By user
	[UPDATED_DATE] datetime NULL	-- Updated date
)
GO

/* Create Primary Keys, Indexes, Uniques, Checks */

ALTER TABLE [CES].[WORK_HIST] 
 ADD CONSTRAINT [PK_WORK_HIST]
	PRIMARY KEY CLUSTERED ([WORK_HIST_SR_KEY] ASC)
GO

/* Create Table Comments */

EXEC sp_addextendedproperty 'MS_Description', 'Work History Surrogate key (PK)', 'Schema', [CES], 'table', [WORK_HIST], 'column', [WORK_HIST_SR_KEY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Financial year', 'Schema', [CES], 'table', [WORK_HIST], 'column', [WORK_YEAR_KEY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Financial year start date', 'Schema', [CES], 'table', [WORK_HIST], 'column', [WORK_YR_START_DT]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Financial year end date', 'Schema', [CES], 'table', [WORK_HIST], 'column', [WORK_YR_END_DT]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Route information', 'Schema', [CES], 'table', [WORK_HIST], 'column', [ORG_SR_KEY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Exam Type for the assets', 'Schema', [CES], 'table', [WORK_HIST], 'column', [EXAM_TYPE_SR_KEY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Exam Due Date - either default as per due date algo or as entered by the AE in Task list request screen or coming from CARRS', 'Schema', [CES], 'table', [WORK_HIST], 'column', [EXAM_DUE_DATE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'NR internal Notes', 'Schema', [CES], 'table', [WORK_HIST], 'column', [NR_INTERNAL_NOTES]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Job Number associated with examination', 'Schema', [CES], 'table', [WORK_HIST], 'column', [JOB_NUMBER]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Created By user', 'Schema', [CES], 'table', [WORK_HIST], 'column', [CREATED_USER]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Created Date', 'Schema', [CES], 'table', [WORK_HIST], 'column', [CREATED_DATE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Updated By user', 'Schema', [CES], 'table', [WORK_HIST], 'column', [UPDATED_USER]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Updated date', 'Schema', [CES], 'table', [WORK_HIST], 'column', [UPDATED_DATE]
GO