﻿/* Create Tables */

CREATE TABLE [CES].[COMPLIANCE]
(
	[COMPLIANCE_SR_KEY] decimal(18) NOT NULL IDENTITY (1, 1),	-- Compliance Surrogate key (pk)
	[ASSET_GUID] varchar(32) NOT NULL,	-- Unique asset reference (fk)
	[EXAM_TYPE_SR_KEY] decimal(18) NOT NULL,	-- Exam type surrogate key (Fk)
	[COMP_DATE] date NULL,	-- Compliance due date
	[INTERVAL_DAYS] decimal(3) NULL,	-- Compliance Frequency in days
	[INTERVAL_MONTHS] decimal(3) NULL,	-- Compliance Frequency in months
	[INTERVAL_YEARS] decimal(3) NULL,	-- Compliance Frequency in years
	[EFFECTIVE_FROM_DT] date NOT NULL,	-- Effective From Date
	[EFFECTIVE_TO_DT] date NULL,	-- Effective To Date
	[ISACTIVE] bit NOT NULL DEFAULT 1,	-- Indicates if the user is Active or not - 1 for Active, 0 for Deleted/Inactive
	[CREATED_USER] varchar(64) NOT NULL,	-- Created by user
	[CREATED_DATE] datetime NOT NULL,	-- Created date
	[UPDATED_USER] varchar(64) NULL,	-- Updated by user
	[UPDATED_DATE] datetime NULL	-- Updated date
)
GO

/* Create Primary Keys, Indexes, Uniques, Checks */

ALTER TABLE [CES].[COMPLIANCE] 
 ADD CONSTRAINT [PK_COMPLIANCE]
	PRIMARY KEY CLUSTERED ([COMPLIANCE_SR_KEY] ASC)
GO

CREATE NONCLUSTERED INDEX [IX_COMPLIANCE_ASSETGUID_EXAMTYPESRKEY_ISACTIVE] ON [CES].[COMPLIANCE]
(
	[ASSET_GUID] ASC,
	[EXAM_TYPE_SR_KEY] ASC,
	[ISACTIVE] ASC
)
INCLUDE ( 	[COMP_DATE],
	[EFFECTIVE_FROM_DT],
	[EFFECTIVE_TO_DT])
GO

/* Create Foreign Key Constraints */

ALTER TABLE [CES].[COMPLIANCE] ADD CONSTRAINT [FK_COMPLIANCE_ASSET]
	FOREIGN KEY ([ASSET_GUID]) REFERENCES [CES].[ASSET] ([ASSET_GUID]) ON DELETE No Action ON UPDATE No Action
GO

ALTER TABLE [CES].[COMPLIANCE] ADD CONSTRAINT [FK_COMPLIANCE_EXAM_TYPE]
	FOREIGN KEY ([EXAM_TYPE_SR_KEY]) REFERENCES [CES].[EXAM_TYPE] ([EXAM_TYPE_SR_KEY]) ON DELETE No Action ON UPDATE No Action
GO

/* Create Table Comments */

EXEC sp_addextendedproperty 'MS_Description', 'Compliance Surrogate key (pk)', 'Schema', [CES], 'table', [COMPLIANCE], 'column', [COMPLIANCE_SR_KEY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Unique asset reference (fk)', 'Schema', [CES], 'table', [COMPLIANCE], 'column', [ASSET_GUID]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Exam type surrogate key (Fk)', 'Schema', [CES], 'table', [COMPLIANCE], 'column', [EXAM_TYPE_SR_KEY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Compliance due date', 'Schema', [CES], 'table', [COMPLIANCE], 'column', [COMP_DATE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Compliance Frequency in days', 'Schema', [CES], 'table', [COMPLIANCE], 'column', [INTERVAL_DAYS]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Compliance Frequency in months', 'Schema', [CES], 'table', [COMPLIANCE], 'column', [INTERVAL_MONTHS]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Compliance Frequency in years', 'Schema', [CES], 'table', [COMPLIANCE], 'column', [INTERVAL_YEARS]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Effective From Date', 'Schema', [CES], 'table', [COMPLIANCE], 'column', [EFFECTIVE_FROM_DT]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Effective To Date', 'Schema', [CES], 'table', [COMPLIANCE], 'column', [EFFECTIVE_TO_DT]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Indicates if the user is Active or not - 1 for Active, 0 for Deleted/Inactive', 'Schema', [CES], 'table', [COMPLIANCE], 'column', [ISACTIVE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Created by user', 'Schema', [CES], 'table', [COMPLIANCE], 'column', [CREATED_USER]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Created date', 'Schema', [CES], 'table', [COMPLIANCE], 'column', [CREATED_DATE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Updated by user', 'Schema', [CES], 'table', [COMPLIANCE], 'column', [UPDATED_USER]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Updated date', 'Schema', [CES], 'table', [COMPLIANCE], 'column', [UPDATED_DATE]
GO