﻿CREATE TABLE [CES].[SUPPLIER]
(
	[SUPPLIER_SR_KEY] decimal(18) NOT NULL,	-- Suppliers Surrogate key (PK)
	[SUPPLIER_NAME] varchar(64) NOT NULL,	-- supplier name carrying out the examination
	[ISACTIVE] bit NOT NULL DEFAULT 1,	-- Indicates if the user is Active or not - 1 for Active, 0 for Deleted/Inactive
	[CREATED_USER] varchar(64) NOT NULL,	-- Created by user
	[CREATED_DATE] datetime NOT NULL,	-- Created date
	[UPDATED_USER] varchar(64) NULL,	-- Updated by user
	[UPDATED_DATE] datetime NULL
)
GO

/* Create Primary Keys, Indexes, Uniques, Checks */

ALTER TABLE [CES].[SUPPLIER] 
 ADD CONSTRAINT [PK_SUPPLIER]
	PRIMARY KEY CLUSTERED ([SUPPLIER_SR_KEY] ASC)
GO

/* Create Table Comments */

EXEC sp_addextendedproperty 'MS_Description', 'Suppliers Surrogate key (PK)', 'Schema', [CES], 'table', [SUPPLIER], 'column', [SUPPLIER_SR_KEY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'supplier name carrying out the examination', 'Schema', [CES], 'table', [SUPPLIER], 'column', [SUPPLIER_NAME]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Indicates if the user is Active or not - 1 for Active, 0 for Deleted/Inactive', 'Schema', [CES], 'table', [SUPPLIER], 'column', [ISACTIVE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Created by user', 'Schema', [CES], 'table', [SUPPLIER], 'column', [CREATED_USER]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Created date', 'Schema', [CES], 'table', [SUPPLIER], 'column', [CREATED_DATE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Updated by user', 'Schema', [CES], 'table', [SUPPLIER], 'column', [UPDATED_USER]
GO