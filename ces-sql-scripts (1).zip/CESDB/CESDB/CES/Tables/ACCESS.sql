﻿CREATE TABLE [CES].[ACCESS]
(
	[ACCESS_SR_KEY] decimal(18) NOT NULL IDENTITY (1, 1),	-- Access Surrogate Key (pk)
	[ASSET_GUID] varchar(32) NOT NULL,	-- Unique asset reference (fk)
	[EXAM_TYPE_SR_KEY] decimal(18) NOT NULL,	-- Exam type surrogate key (Fk)
	[POSSESSION] varchar(32) NULL,	-- Posession Critical - supplier data
	[LINE_BLOCK] varchar(32) NULL,	-- Line Block - supplier data
	[TRAFFIC_MNGT] varchar(32) NULL,	-- Traffic management - supplier data
	[RRV] varchar(32) NULL,	-- RRV- supplier data
	[MEWP] varchar(32) NULL,	-- MEWP - supplier data
	[ROPE_ACCESS] varchar(32) NULL,	-- Rope Access - Supplier Data
	[LADDER] varchar(32) NULL,	-- Ladder - Supplier Data
	[SCAFFOLD] varchar(32) NULL,	-- SCAFFOLD - Supplier data
	[CCTV] varchar(32) NULL,	-- CCTV - supplier data
	[CONFINED_SPACE] varchar(32) NULL,	-- Confined space - Supplier data
	[WATER_PERMIT] varchar(32) NULL,	-- Water Permit - supplier data
	[SAFETY_BOAT] varchar(32) NULL,	-- Safety boat - supplier data
	[3RD_PARTY] varchar(32) NULL,	-- 3rd Party - supplier data
	[COMMENTS] varchar(8000) NULL,	-- Comments added by user for Access data on Asset Details page
	[ISACTIVE] bit NOT NULL DEFAULT 1,	-- Indicates if the user is Active or not - 1 for Active, 0 for Deleted/Inactive
	[CREATED_USER] varchar(64) NOT NULL,	-- Created by user
	[CREATED_DATE] datetime NOT NULL,	-- Created date
	[UPDATED_USER] varchar(64) NULL,	-- Updated by user
	[UPDATED_DATE] datetime NULL	-- Updated date
)
GO

/* Create Primary Keys, Indexes, Uniques, Checks */

ALTER TABLE [CES].[ACCESS] 
 ADD CONSTRAINT [PK_ACCESS]
	PRIMARY KEY CLUSTERED ([ACCESS_SR_KEY] ASC)
GO

/* Create Foreign Key Constraints */

ALTER TABLE [CES].[ACCESS] ADD CONSTRAINT [FK_ACCESS_ASSET]
	FOREIGN KEY ([ASSET_GUID]) REFERENCES [CES].[ASSET] ([ASSET_GUID]) ON DELETE No Action ON UPDATE No Action
GO

ALTER TABLE [CES].[ACCESS] ADD CONSTRAINT [FK_ACCESS_EXAM_TYPE]
	FOREIGN KEY ([EXAM_TYPE_SR_KEY]) REFERENCES [CES].[EXAM_TYPE] ([EXAM_TYPE_SR_KEY]) ON DELETE No Action ON UPDATE No Action
GO

/* Create Table Comments */

EXEC sp_addextendedproperty 'MS_Description', 'Access Surrogate Key (pk)', 'Schema', [CES], 'table', [ACCESS], 'column', [ACCESS_SR_KEY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Unique asset reference (fk)', 'Schema', [CES], 'table', [ACCESS], 'column', [ASSET_GUID]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Exam type surrogate key (Fk)', 'Schema', [CES], 'table', [ACCESS], 'column', [EXAM_TYPE_SR_KEY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Posession Critical - supplier data', 'Schema', [CES], 'table', [ACCESS], 'column', [POSSESSION]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Line Block - supplier data', 'Schema', [CES], 'table', [ACCESS], 'column', [LINE_BLOCK]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Traffic management - supplier data', 'Schema', [CES], 'table', [ACCESS], 'column', [TRAFFIC_MNGT]
GO

EXEC sp_addextendedproperty 'MS_Description', 'RRV- supplier data', 'Schema', [CES], 'table', [ACCESS], 'column', [RRV]
GO

EXEC sp_addextendedproperty 'MS_Description', 'MEWP - supplier data', 'Schema', [CES], 'table', [ACCESS], 'column', [MEWP]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Rope Access - Supplier Data', 'Schema', [CES], 'table', [ACCESS], 'column', [ROPE_ACCESS]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Ladder - Supplier Data', 'Schema', [CES], 'table', [ACCESS], 'column', [LADDER]
GO

EXEC sp_addextendedproperty 'MS_Description', 'SCAFFOLD - Supplier data', 'Schema', [CES], 'table', [ACCESS], 'column', [SCAFFOLD]
GO

EXEC sp_addextendedproperty 'MS_Description', 'CCTV - supplier data', 'Schema', [CES], 'table', [ACCESS], 'column', [CCTV]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Confined space - Supplier data', 'Schema', [CES], 'table', [ACCESS], 'column', [CONFINED_SPACE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Water Permit - supplier data', 'Schema', [CES], 'table', [ACCESS], 'column', [WATER_PERMIT]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Safety boat - supplier data', 'Schema', [CES], 'table', [ACCESS], 'column', [SAFETY_BOAT]
GO

EXEC sp_addextendedproperty 'MS_Description', '3rd Party - supplier data', 'Schema', [CES], 'table', [ACCESS], 'column', [3RD_PARTY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Comments added by user for Access data on Asset Details page', 'Schema', [CES], 'table', [ACCESS], 'column', [COMMENTS]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Indicates if the user is Active or not - 1 for Active, 0 for Deleted/Inactive', 'Schema', [CES], 'table', [ACCESS], 'column', [ISACTIVE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Created by user', 'Schema', [CES], 'table', [ACCESS], 'column', [CREATED_USER]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Created date', 'Schema', [CES], 'table', [ACCESS], 'column', [CREATED_DATE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Updated by user', 'Schema', [CES], 'table', [ACCESS], 'column', [UPDATED_USER]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Updated date', 'Schema', [CES], 'table', [ACCESS], 'column', [UPDATED_DATE]
GO