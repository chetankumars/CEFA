﻿CREATE TABLE [CES].[RECOMMENDATION]
(
	[RECOMMEND_SR_KEY] decimal(18) NOT NULL IDENTITY (1, 1),	-- Recommendation Surrogate key (pk)
	[EXAM_SR_KEY] decimal(18) NOT NULL,	-- Exam Surrogate key (fpk)
	[RCMN_NUM] decimal(18) NOT NULL,	-- Recommendation Number
	[RCMN_DATE] date NULL,	-- Recommendation date (Exam submission date)
	[RCMN_SIGNED_DATE] date NULL,	-- date of recommendation signed
	[RCMN_STATUS] decimal(18) NULL,	-- Status- Accepted/Rejected/ Duplicate
	[DESCRIPTION] varchar(1000) NOT NULL,	-- Recommendation Description
	[PRIORITY_YEAR] decimal(18) NULL,	-- Priority year
	[LOCATION] varchar(128) NULL,	-- Recommendation Location
	[WORK_CATEGORY] decimal(18) NULL,	-- Recommendation Work Category
	[RISK_SCORE] varchar(5) NULL,	-- Recommendation Risk Score
	[SEVERITY] varchar(5) NULL,	-- Recommendation Severity
	[PROBABILITY] varchar(5) NULL,	-- Recommendation Probability
	[EXTENT] varchar(12) NULL,	-- Extent
	[QUANTITY] decimal(18,2) NULL,	-- Recommendation Quantity
	[QUANTITY_UNIT] varchar(32) NULL,	-- Recommendation Quantity
	[ESTIMATED_COST] decimal(18,2) NULL,	-- recommendation estimated cost
	[CARRS_RECOMMEND_ID] decimal(18) NULL,	-- Recommendation ID (generated in CARRS) - required for data synchronization
	[ISACTIVE] bit NOT NULL DEFAULT 1,	-- Indicates if the user is Active or not - 1 for Active, 0 for Deleted/Inactive
	[CREATED_USER] varchar(64) NOT NULL,	-- Created by user
	[CREATED_DATE] datetime NOT NULL,	-- Created date
	[UPDATED_USER] varchar(64) NULL,	-- Updated by user
	[UPDATED_DATE] datetime NULL	-- Updated date
)
GO

/* Create Primary Keys, Indexes, Uniques, Checks */

ALTER TABLE [CES].[RECOMMENDATION] 
 ADD CONSTRAINT [PK_RECOMMENDATION]
	PRIMARY KEY CLUSTERED ([RECOMMEND_SR_KEY] ASC)
GO

CREATE NONCLUSTERED INDEX [IX_RECOMMEDATION_EXAM_ISACTIVE] ON [CES].[RECOMMENDATION]
(
	[EXAM_SR_KEY] ASC,
	[ISACTIVE] ASC
)
INCLUDE ( 	[RCMN_NUM],
	[RCMN_STATUS],
	[DESCRIPTION],
	[LOCATION],
	[WORK_CATEGORY],
	[RISK_SCORE],
	[QUANTITY],
	[QUANTITY_UNIT])
GO

/* Create Foreign Key Constraints */

ALTER TABLE [CES].[RECOMMENDATION] ADD CONSTRAINT [FK_RCMN_REF_VAL_PRIORITY_YR]
	FOREIGN KEY ([PRIORITY_YEAR]) REFERENCES [CES].[REFERENCE_VALUE] ([REF_VAL_SR_KEY]) ON DELETE No Action ON UPDATE No Action
GO

ALTER TABLE [CES].[RECOMMENDATION] ADD CONSTRAINT [FK_RCMN_REF_VAL_RCMN_STATUS]
	FOREIGN KEY ([RCMN_STATUS]) REFERENCES [CES].[REFERENCE_VALUE] ([REF_VAL_SR_KEY]) ON DELETE No Action ON UPDATE No Action
GO

ALTER TABLE [CES].[RECOMMENDATION] ADD CONSTRAINT [FK_RCMN_REF_VAL_WORK_CAT]
	FOREIGN KEY ([WORK_CATEGORY]) REFERENCES [CES].[REFERENCE_VALUE] ([REF_VAL_SR_KEY]) ON DELETE No Action ON UPDATE No Action
GO

ALTER TABLE [CES].[RECOMMENDATION] ADD CONSTRAINT [FK_RECOMMENDATION_EXAM]
	FOREIGN KEY ([EXAM_SR_KEY]) REFERENCES [CES].[EXAM] ([EXAM_SR_KEY]) ON DELETE No Action ON UPDATE No Action
GO

/* Create Table Comments */

EXEC sp_addextendedproperty 'MS_Description', 'Recommendation Surrogate key (pk)', 'Schema', [CES], 'table', [RECOMMENDATION], 'column', [RECOMMEND_SR_KEY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Exam Surrogate key (fpk)', 'Schema', [CES], 'table', [RECOMMENDATION], 'column', [EXAM_SR_KEY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Recommendation Number', 'Schema', [CES], 'table', [RECOMMENDATION], 'column', [RCMN_NUM]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Recommendation date (Exam submission date)', 'Schema', [CES], 'table', [RECOMMENDATION], 'column', [RCMN_DATE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'date of recommendation signed', 'Schema', [CES], 'table', [RECOMMENDATION], 'column', [RCMN_SIGNED_DATE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Status- Accepted/Rejected/ Duplicate', 'Schema', [CES], 'table', [RECOMMENDATION], 'column', [RCMN_STATUS]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Recommendation Description', 'Schema', [CES], 'table', [RECOMMENDATION], 'column', [DESCRIPTION]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Priority year', 'Schema', [CES], 'table', [RECOMMENDATION], 'column', [PRIORITY_YEAR]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Recommendation Location', 'Schema', [CES], 'table', [RECOMMENDATION], 'column', [LOCATION]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Recommendation Work Category', 'Schema', [CES], 'table', [RECOMMENDATION], 'column', [WORK_CATEGORY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Recommendation Risk Score', 'Schema', [CES], 'table', [RECOMMENDATION], 'column', [RISK_SCORE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Recommendation Severity', 'Schema', [CES], 'table', [RECOMMENDATION], 'column', [SEVERITY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Recommendation Probability', 'Schema', [CES], 'table', [RECOMMENDATION], 'column', [PROBABILITY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Extent', 'Schema', [CES], 'table', [RECOMMENDATION], 'column', [EXTENT]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Recommendation Quantity', 'Schema', [CES], 'table', [RECOMMENDATION], 'column', [QUANTITY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Recommendation Quantity', 'Schema', [CES], 'table', [RECOMMENDATION], 'column', [QUANTITY_UNIT]
GO

EXEC sp_addextendedproperty 'MS_Description', 'recommendation estimated cost', 'Schema', [CES], 'table', [RECOMMENDATION], 'column', [ESTIMATED_COST]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Recommendation ID (generated in CARRS) - required for data synchronization', 'Schema', [CES], 'table', [RECOMMENDATION], 'column', [CARRS_RECOMMEND_ID]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Indicates if the user is Active or not - 1 for Active, 0 for Deleted/Inactive', 'Schema', [CES], 'table', [RECOMMENDATION], 'column', [ISACTIVE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Created by user', 'Schema', [CES], 'table', [RECOMMENDATION], 'column', [CREATED_USER]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Created date', 'Schema', [CES], 'table', [RECOMMENDATION], 'column', [CREATED_DATE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Updated by user', 'Schema', [CES], 'table', [RECOMMENDATION], 'column', [UPDATED_USER]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Updated date', 'Schema', [CES], 'table', [RECOMMENDATION], 'column', [UPDATED_DATE]
GO