﻿/* Create Tables */

CREATE TABLE [CES].[EXAM_STG]
(
	[EXAM_ID] decimal(18) NOT NULL,	-- CARRS examination ID 
	[ASSET_GUID] varchar(32) NOT NULL,	-- Unique asset reference (fk)
	[WORK_SR_KEY] decimal(18) NULL,	-- WorkBank Surrogate key (fk)
	[EXAM_BASELINE_DATE] date NULL,	-- Examination baseline Planned Date (Supplier)
	[EXAM_PLANNED_DATE] date NULL,	-- Examination Planned Date (Supplier)
	[EXAM_ACTUAL_DATE] date NULL,	-- Examination Actual Date (Supplier)
	[EXAM_REVIEW_DATE] date NULL,	-- Supplier (STE2) review Date
	[EXAM_SUBMISSION_DATE] date NULL,	-- Examination submission Date (Supplier)
	[EXAM_SIGNOFF_DATE] date NULL,	-- Examination signoff Date (Supplier)
	[EXAM_TYPE_SR_KEY] decimal(18) NULL,	-- Exam type surrogate key (Fk)
	[EXAM_REQ_STATUS] decimal(18) NOT NULL,	-- Exam Request Status
	[EXAM_REPORT_STATUS] decimal(18) NULL,	-- examination Status < Received , Under evaluation , Signed off ,Evaluated by ASME , Rejected , Rejected by audit etc….. )
	[EXAM_COMPLETED_IND] varchar(5) NULL,	-- Complete Examination - Yes/No
	[EXAMINER_NAME] varchar(64) NULL,	-- Examiner name
	[EXAMINER_COMMENT] varchar(4000) NULL,	-- Examiner General Comments
	[REVIEWER_NAME] varchar(64) NULL,	-- Examining Engineer name
	[REVIEWER_COMMENT] varchar(4000) NULL,	-- Examining Engineer Comments
	[SUPPLIER_SR_KEY] decimal(18) NULL,	-- Suppliers Surrogate key (FK)
	[SUPPLIER_REPORT_FILENAME] varchar(200) NULL,	-- Examination Report File name
	[SUPPLIER_REPORT_REFERENCE] varchar(500) NULL,	-- Supplier Examination Report Reference
	[SUPPLIER_ZIP_FILENAME] varchar(200) NULL,	-- Examination images File name
	[INSTRUCTION] varchar(128) NULL,	-- Instructions for Tunnel examinations
	[CMI_SCORE] decimal(3) NULL,	-- Condition Marking Index score
	[CMI_DATE] date NULL,	-- Asset Condition Marking Index Date
	[PNE_FLAG] varchar(5) NULL,	-- "Asset" Part not examined - Flag (Yes/No)
	[STRUC_DESCRIPTION] varchar(1000) NULL,	-- Asset structure description
	[AT_OR_BETWEEN_STATIONS] varchar(64) NULL,	-- Asset between stations < Blackfriars and Elephant - Castle ,  Unknown and Unknown , Hounslow And Feltham , London Bridge And New Cross etc >
	[OBSERVED_UNDER_LOAD] bit NULL,	-- Asset observed under load < Yes , No>
	[SPAN_TEXT] varchar(10) NULL,	-- Span text
	[INTERNAL_NOTES] varchar(4000) NULL,	-- NR Internal Notes
	[COMMENT_TO_SEC] varchar(4000) NULL,	-- Comments to Supplier
	[CHANGE_REQ_ID] varchar(20) NULL,	-- Change Request ID for any exam
	[SUPPLIER_COMMENTS] varchar(2000) NULL,	-- Supplier comments as received through Task List Date excel/UI/External API
	[IS_LAST_EXAM] char(1) NOT NULL,	-- Indicates if this is the last exam ID for an asset and exam type (required for compliance calculation) - Y/N
	[EXAM_GROUP_SR_KEY] decimal(18) NULL,	-- Exam Group ID - required for task list
	[EXAM_REQUIREMENT] varchar(1000) NULL,	-- Specific Exam Requirement associated with an Exam in CARRS
	[ISACTIVE] bit NOT NULL DEFAULT 1,	-- Indicates if the user is Active or not - 1 for Active, 0 for Deleted/Inactive
	[CREATED_USER] varchar(64) NOT NULL,	-- Created by user
	[CREATED_DATE] datetime NOT NULL,	-- Created date
	[UPDATED_USER] varchar(64) NULL,	-- Updated by user
	[UPDATED_DATE] datetime NULL	-- Updated date
)
GO

ALTER TABLE [CES].[EXAM_STG] ADD  DEFAULT (NEXT VALUE FOR [CES].[SEQ_WORK_KEY]) FOR [WORK_SR_KEY]
GO


/* Create Table Comments */

EXEC sp_addextendedproperty 'MS_Description', 'CARRS examination ID ', 'Schema', [CES], 'table', [EXAM_STG], 'column', [EXAM_ID]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Unique asset reference (fk)', 'Schema', [CES], 'table', [EXAM_STG], 'column', [ASSET_GUID]
GO

EXEC sp_addextendedproperty 'MS_Description', 'WorkBank Surrogate key (fk)', 'Schema', [CES], 'table', [EXAM_STG], 'column', [WORK_SR_KEY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Examination baseline Planned Date (Supplier)', 'Schema', [CES], 'table', [EXAM_STG], 'column', [EXAM_BASELINE_DATE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Examination Planned Date (Supplier)', 'Schema', [CES], 'table', [EXAM_STG], 'column', [EXAM_PLANNED_DATE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Examination Actual Date (Supplier)', 'Schema', [CES], 'table', [EXAM_STG], 'column', [EXAM_ACTUAL_DATE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Supplier (STE2) review Date', 'Schema', [CES], 'table', [EXAM_STG], 'column', [EXAM_REVIEW_DATE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Examination submission Date (Supplier)', 'Schema', [CES], 'table', [EXAM_STG], 'column', [EXAM_SUBMISSION_DATE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Examination signoff Date (Supplier)', 'Schema', [CES], 'table', [EXAM_STG], 'column', [EXAM_SIGNOFF_DATE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Exam type surrogate key (Fk)', 'Schema', [CES], 'table', [EXAM_STG], 'column', [EXAM_TYPE_SR_KEY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Exam Request Status', 'Schema', [CES], 'table', [EXAM_STG], 'column', [EXAM_REQ_STATUS]
GO

EXEC sp_addextendedproperty 'MS_Description', 'examination Status < Received , Under evaluation , Signed off ,Evaluated by ASME , Rejected , Rejected by audit etc….. )', 'Schema', [CES], 'table', [EXAM_STG], 'column', [EXAM_REPORT_STATUS]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Complete Examination - Yes/No', 'Schema', [CES], 'table', [EXAM_STG], 'column', [EXAM_COMPLETED_IND]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Examiner name', 'Schema', [CES], 'table', [EXAM_STG], 'column', [EXAMINER_NAME]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Examiner General Comments', 'Schema', [CES], 'table', [EXAM_STG], 'column', [EXAMINER_COMMENT]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Examining Engineer name', 'Schema', [CES], 'table', [EXAM_STG], 'column', [REVIEWER_NAME]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Examining Engineer Comments', 'Schema', [CES], 'table', [EXAM_STG], 'column', [REVIEWER_COMMENT]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Suppliers Surrogate key (FK)', 'Schema', [CES], 'table', [EXAM_STG], 'column', [SUPPLIER_SR_KEY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Examination Report File name', 'Schema', [CES], 'table', [EXAM_STG], 'column', [SUPPLIER_REPORT_FILENAME]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Supplier Examination Report Reference', 'Schema', [CES], 'table', [EXAM_STG], 'column', [SUPPLIER_REPORT_REFERENCE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Examination images File name', 'Schema', [CES], 'table', [EXAM_STG], 'column', [SUPPLIER_ZIP_FILENAME]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Instructions for Tunnel examinations', 'Schema', [CES], 'table', [EXAM_STG], 'column', [INSTRUCTION]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Condition Marking Index score', 'Schema', [CES], 'table', [EXAM_STG], 'column', [CMI_SCORE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Asset Condition Marking Index Date', 'Schema', [CES], 'table', [EXAM_STG], 'column', [CMI_DATE]
GO

EXEC sp_addextendedproperty 'MS_Description', '"Asset" Part not examined - Flag (Yes/No)', 'Schema', [CES], 'table', [EXAM_STG], 'column', [PNE_FLAG]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Asset structure description', 'Schema', [CES], 'table', [EXAM_STG], 'column', [STRUC_DESCRIPTION]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Asset between stations < Blackfriars and Elephant - Castle ,  Unknown and Unknown , Hounslow And Feltham , London Bridge And New Cross etc >', 'Schema', [CES], 'table', [EXAM_STG], 'column', [AT_OR_BETWEEN_STATIONS]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Asset observed under load < Yes , No>', 'Schema', [CES], 'table', [EXAM_STG], 'column', [OBSERVED_UNDER_LOAD]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Span text', 'Schema', [CES], 'table', [EXAM_STG], 'column', [SPAN_TEXT]
GO

EXEC sp_addextendedproperty 'MS_Description', 'NR Internal Notes', 'Schema', [CES], 'table', [EXAM_STG], 'column', [INTERNAL_NOTES]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Comments to Supplier', 'Schema', [CES], 'table', [EXAM_STG], 'column', [COMMENT_TO_SEC]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Change Request ID for any exam', 'Schema', [CES], 'table', [EXAM_STG], 'column', [CHANGE_REQ_ID]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Supplier comments as received through Task List Date excel/UI/External API', 'Schema', [CES], 'table', [EXAM_STG], 'column', [SUPPLIER_COMMENTS]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Indicates if this is the last exam ID for an asset and exam type (required for compliance calculation) - Y/N', 'Schema', [CES], 'table', [EXAM_STG], 'column', [IS_LAST_EXAM]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Exam Group ID - required for task list', 'Schema', [CES], 'table', [EXAM_STG], 'column', [EXAM_GROUP_SR_KEY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Specific Exam Requirement associated with an Exam in CARRS', 'Schema', [CES], 'table', [EXAM_STG], 'column', [EXAM_REQUIREMENT]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Indicates if the user is Active or not - 1 for Active, 0 for Deleted/Inactive', 'Schema', [CES], 'table', [EXAM_STG], 'column', [ISACTIVE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Created by user', 'Schema', [CES], 'table', [EXAM_STG], 'column', [CREATED_USER]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Created date', 'Schema', [CES], 'table', [EXAM_STG], 'column', [CREATED_DATE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Updated by user', 'Schema', [CES], 'table', [EXAM_STG], 'column', [UPDATED_USER]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Updated date', 'Schema', [CES], 'table', [EXAM_STG], 'column', [UPDATED_DATE]
GO