﻿CREATE TABLE [CES].[ORG]
(
	[ORG_SR_KEY] decimal(18) NOT NULL,	-- Org Surrogate key (PK)
	[REGION] varchar(64) NOT NULL,	-- REGION Name
	[ROUTE] varchar(64) NOT NULL,	-- Route Name
	[ISACTIVE] bit NOT NULL DEFAULT 1,	-- Indicates if the user is Active or not - 1 for Active, 0 for Deleted/Inactive
	[CREATED_USER] varchar(64) NOT NULL,	-- Created by user
	[CREATED_DATE] datetime NOT NULL,	-- Created date
	[UPDATED_USER] varchar(64) NULL,	-- Updated by user
	[UPDATED_DATE] datetime NULL
)
GO

/* Create Primary Keys, Indexes, Uniques, Checks */

ALTER TABLE [CES].[ORG] 
 ADD CONSTRAINT [PK_ORG]
	PRIMARY KEY CLUSTERED ([ORG_SR_KEY] ASC)
GO

CREATE NONCLUSTERED INDEX [IX_ORG_ISACTIVE_REGION] ON [CES].[ORG]
(
	[ISACTIVE] ASC,
	[REGION] ASC
)
INCLUDE ( 	[ORG_SR_KEY],
	[ROUTE])
GO
/* Create Table Comments */

EXEC sp_addextendedproperty 'MS_Description', 'Org Surrogate key (PK)', 'Schema', [CES], 'table', [ORG], 'column', [ORG_SR_KEY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'REGION Name', 'Schema', [CES], 'table', [ORG], 'column', [REGION]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Route Name', 'Schema', [CES], 'table', [ORG], 'column', [ROUTE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Indicates if the user is Active or not - 1 for Active, 0 for Deleted/Inactive', 'Schema', [CES], 'table', [ORG], 'column', [ISACTIVE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Created by user', 'Schema', [CES], 'table', [ORG], 'column', [CREATED_USER]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Created date', 'Schema', [CES], 'table', [ORG], 'column', [CREATED_DATE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Updated by user', 'Schema', [CES], 'table', [ORG], 'column', [UPDATED_USER]
GO