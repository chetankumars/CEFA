﻿CREATE TABLE [CES].[EXAM_CYCLE]
(
	[EXAM_CYCLE_SR_KEY] decimal(18) NOT NULL IDENTITY (1, 1),	-- Exam cycle surrogate key (pk)
	[ASSET_GUID] varchar(32) NOT NULL,	-- Unique asset reference (fk)
	[EXAM_TYPE_SR_KEY] decimal(18) NOT NULL,	-- Exam type surrogate key (Fk)
	[BIRTHDAY_DAY] decimal(5) NULL,	-- Birthday day
	[BIRTHDAY_MONTH] decimal(5) NULL,	-- Birthday month
	[INTERVAL_DAYS] decimal(5) NULL,	-- Interval days
	[INTERVAL_MONTHS] decimal(5) NULL,	-- Interval months
	[INTERVAL_YEARS] decimal(5) NULL,	-- Interval years
	[WORK_SR_KEY] decimal(18) NULL,	-- WorkBank Surrogate key (fk)
	[NEXT_EXAM_DUE_DATE] date NULL,	-- Next exam due date
	[LAST_EXAM_ID] decimal(18) NULL,	-- Last CARRS examination ID
	[LAST_EXAM_DATE] date NULL,	-- Last Examination Actual Date (Supplier)
	[SUPPLIER_SR_KEY] decimal(18) NULL,	-- Suppliers Surrogate key (FK)
	[EXAM_REQUIREMENT] varchar(1000) NULL,	-- Exam requirement
	[EFFECTIVE_FROM_DT] date NULL,	-- Effective From Date
	[EFFECTIVE_TO_DT] date NULL,	-- Effective To Date
	[CARRS_EXAM_TYPE_CYCLE_ID] decimal(18) NOT NULL,	-- Exam Group Exam Type Cycle ID (PK) in CARRS Exam Group Exam Type Cycle table - required for data synchronization.
	[ISACTIVE] bit NOT NULL DEFAULT 1,	-- Indicates if the user is Active or not - 1 for Active, 0 for Deleted/Inactive
	[CREATED_USER] varchar(64) NOT NULL,	-- Created by user
	[CREATED_DATE] datetime NOT NULL,	-- Created date
	[UPDATED_USER] varchar(64) NULL,	-- Updated by user
	[UPDATED_DATE] datetime NULL	-- Updated date
)
GO

/* Create Primary Keys, Indexes, Uniques, Checks */

ALTER TABLE [CES].[EXAM_CYCLE] 
 ADD CONSTRAINT [PK_EXAM_CYCLE]
	PRIMARY KEY CLUSTERED ([EXAM_CYCLE_SR_KEY] ASC)
GO

/* Create Foreign Key Constraints */

ALTER TABLE [CES].[EXAM_CYCLE] ADD CONSTRAINT [FK_EXAM_CYCLE_ASSET]
	FOREIGN KEY ([ASSET_GUID]) REFERENCES [CES].[ASSET] ([ASSET_GUID]) ON DELETE No Action ON UPDATE No Action
GO

ALTER TABLE [CES].[EXAM_CYCLE] ADD CONSTRAINT [FK_EXAM_CYCLE_EXAM_TYPE]
	FOREIGN KEY ([EXAM_TYPE_SR_KEY]) REFERENCES [CES].[EXAM_TYPE] ([EXAM_TYPE_SR_KEY]) ON DELETE No Action ON UPDATE No Action
GO

ALTER TABLE [CES].[EXAM_CYCLE] ADD CONSTRAINT [FK_EXAM_CYCLE_SUPPLIER]
	FOREIGN KEY ([SUPPLIER_SR_KEY]) REFERENCES [CES].[SUPPLIER] ([SUPPLIER_SR_KEY]) ON DELETE No Action ON UPDATE No Action
GO

/* Create Table Comments */

EXEC sp_addextendedproperty 'MS_Description', 'Exam cycle surrogate key (pk)', 'Schema', [CES], 'table', [EXAM_CYCLE], 'column', [EXAM_CYCLE_SR_KEY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Unique asset reference (fk)', 'Schema', [CES], 'table', [EXAM_CYCLE], 'column', [ASSET_GUID]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Exam type surrogate key (Fk)', 'Schema', [CES], 'table', [EXAM_CYCLE], 'column', [EXAM_TYPE_SR_KEY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Birthday day', 'Schema', [CES], 'table', [EXAM_CYCLE], 'column', [BIRTHDAY_DAY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Birthday month', 'Schema', [CES], 'table', [EXAM_CYCLE], 'column', [BIRTHDAY_MONTH]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Interval days', 'Schema', [CES], 'table', [EXAM_CYCLE], 'column', [INTERVAL_DAYS]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Interval months', 'Schema', [CES], 'table', [EXAM_CYCLE], 'column', [INTERVAL_MONTHS]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Interval years', 'Schema', [CES], 'table', [EXAM_CYCLE], 'column', [INTERVAL_YEARS]
GO

EXEC sp_addextendedproperty 'MS_Description', 'WorkBank Surrogate key (fk)', 'Schema', [CES], 'table', [EXAM_CYCLE], 'column', [WORK_SR_KEY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Next exam due date', 'Schema', [CES], 'table', [EXAM_CYCLE], 'column', [NEXT_EXAM_DUE_DATE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Last CARRS examination ID', 'Schema', [CES], 'table', [EXAM_CYCLE], 'column', [LAST_EXAM_ID]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Last Examination Actual Date (Supplier)', 'Schema', [CES], 'table', [EXAM_CYCLE], 'column', [LAST_EXAM_DATE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Suppliers Surrogate key (FK)', 'Schema', [CES], 'table', [EXAM_CYCLE], 'column', [SUPPLIER_SR_KEY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Exam requirement', 'Schema', [CES], 'table', [EXAM_CYCLE], 'column', [EXAM_REQUIREMENT]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Effective From Date', 'Schema', [CES], 'table', [EXAM_CYCLE], 'column', [EFFECTIVE_FROM_DT]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Effective To Date', 'Schema', [CES], 'table', [EXAM_CYCLE], 'column', [EFFECTIVE_TO_DT]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Exam Group Exam Type Cycle ID (PK) in CARRS Exam Group Exam Type Cycle table - required for data synchronization.', 'Schema', [CES], 'table', [EXAM_CYCLE], 'column', [CARRS_EXAM_TYPE_CYCLE_ID]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Indicates if the user is Active or not - 1 for Active, 0 for Deleted/Inactive', 'Schema', [CES], 'table', [EXAM_CYCLE], 'column', [ISACTIVE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Created by user', 'Schema', [CES], 'table', [EXAM_CYCLE], 'column', [CREATED_USER]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Created date', 'Schema', [CES], 'table', [EXAM_CYCLE], 'column', [CREATED_DATE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Updated by user', 'Schema', [CES], 'table', [EXAM_CYCLE], 'column', [UPDATED_USER]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Updated date', 'Schema', [CES], 'table', [EXAM_CYCLE], 'column', [UPDATED_DATE]
GO