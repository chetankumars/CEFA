﻿CREATE TABLE [CES].[ENTITLEMENT]
(
	[ENTITLEMENT_SR_KEY] decimal(18) NOT NULL IDENTITY (1, 1),	-- Entitlement Surrogate key (PK)
	[USER_SR_KEY] decimal(18) NOT NULL,	-- User ID
	[ORG_SR_KEY] decimal(18) NOT NULL,	-- Org Surrogate key (PK)
	[AREA_SR_KEY] decimal(18) NULL,	-- Area surrogate key (fk)
	[SUPPLIER_SR_KEY] decimal(18) NULL,	-- Suppliers Surrogate key (FK)
	[ISDEFAULT] bit NOT NULL DEFAULT 0,	-- Default indicator to identify the default route/area for the user
	[ISACTIVE] bit NOT NULL DEFAULT 1,	-- Indicates if the user is Active or not - 1 for Active, 0 for Deleted/Inactive
	[CREATED_USER] varchar(64) NOT NULL,	-- Created by user
	[CREATED_DATE] datetime NOT NULL,	-- Created date
	[UPDATED_USER] varchar(64) NULL,	-- Updated by user
	[UPDATED_DATE] datetime NULL	-- Updated date
)
GO

/* Create Primary Keys, Indexes, Uniques, Checks */

ALTER TABLE [CES].[ENTITLEMENT] 
 ADD CONSTRAINT [PK_ENTITLEMENT]
	PRIMARY KEY CLUSTERED ([ENTITLEMENT_SR_KEY] ASC)
GO

/* Create Foreign Key Constraints */

ALTER TABLE [CES].[ENTITLEMENT] ADD CONSTRAINT [FK_ENTITLEMENT_AREA]
	FOREIGN KEY ([AREA_SR_KEY]) REFERENCES [CES].[AREA] ([AREA_SR_KEY]) ON DELETE No Action ON UPDATE No Action
GO

ALTER TABLE [CES].[ENTITLEMENT] ADD CONSTRAINT [FK_ENTITLEMENT_ORG]
	FOREIGN KEY ([ORG_SR_KEY]) REFERENCES [CES].[ORG] ([ORG_SR_KEY]) ON DELETE No Action ON UPDATE No Action
GO

ALTER TABLE [CES].[ENTITLEMENT] ADD CONSTRAINT [FK_ENTITLEMENT_SUPPLIER]
	FOREIGN KEY ([SUPPLIER_SR_KEY]) REFERENCES [CES].[SUPPLIER] ([SUPPLIER_SR_KEY]) ON DELETE No Action ON UPDATE No Action
GO

ALTER TABLE [CES].[ENTITLEMENT] ADD CONSTRAINT [FK_ENTITLEMENT_USER]
	FOREIGN KEY ([USER_SR_KEY]) REFERENCES [RBAC].[USER] ([USER_SR_KEY]) ON DELETE No Action ON UPDATE No Action
GO

/* Create Table Comments */

EXEC sp_addextendedproperty 'MS_Description', 'Entitlement Surrogate key (PK)', 'Schema', [CES], 'table', [ENTITLEMENT], 'column', [ENTITLEMENT_SR_KEY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'User ID', 'Schema', [CES], 'table', [ENTITLEMENT], 'column', [USER_SR_KEY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Org Surrogate key (PK)', 'Schema', [CES], 'table', [ENTITLEMENT], 'column', [ORG_SR_KEY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Area surrogate key (fk)', 'Schema', [CES], 'table', [ENTITLEMENT], 'column', [AREA_SR_KEY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Suppliers Surrogate key (FK)', 'Schema', [CES], 'table', [ENTITLEMENT], 'column', [SUPPLIER_SR_KEY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Default indicator to identify the default route/area for the user', 'Schema', [CES], 'table', [ENTITLEMENT], 'column', [ISDEFAULT]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Indicates if the user is Active or not - 1 for Active, 0 for Deleted/Inactive', 'Schema', [CES], 'table', [ENTITLEMENT], 'column', [ISACTIVE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Created by user', 'Schema', [CES], 'table', [ENTITLEMENT], 'column', [CREATED_USER]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Created date', 'Schema', [CES], 'table', [ENTITLEMENT], 'column', [CREATED_DATE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Updated by user', 'Schema', [CES], 'table', [ENTITLEMENT], 'column', [UPDATED_USER]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Updated date', 'Schema', [CES], 'table', [ENTITLEMENT], 'column', [UPDATED_DATE]
GO