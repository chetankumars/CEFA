﻿/* Create Tables */

CREATE TABLE [CES].[FILE_PROCESS_LOG]
(
	[FILE_PROCESS_LOG_SR_KEY] decimal(18) NOT NULL IDENTITY (1, 1),	-- File process log surrogate key (PK)
	[FILE_TYPE] varchar(50) NOT NULL,	-- File Type for ex. Task List Date Upload, Exam Data Upload etc.
	[FILE_NAME] varchar(500) NOT NULL,	-- Name of the file to be processed
	[SOURCE_FILE_LOCATION] varchar(2000) NULL,	-- Location where source files are stored (RAW layer in datalake)
	[FILE_SUBMISSION_DATE] datetime NOT NULL,	-- File Submission Date
	[FILE_PROCESS_DATE] datetime NULL,	-- File processed date
	[FILE_PROCESS_STATUS] varchar(50) NULL,	-- File processing status. From UI - Submitted, from ADF- Succeeded/Failed/Partially Processed
	[SUPPLIER_SR_KEY] decimal(18) NULL,	-- Supplier information
	[USER_ID] varchar(64) NULL,	-- User Key for the user who has submitted the file
	[ERROR_DESCRIPTION] varchar(4000) NULL,	-- Error description in case the file is failed in validation 
	[ERROR_FILE_LOCATION] varchar(2000) NULL,	-- Error file location
	[OUTBOUND_FILE_NAME] varchar(500) NULL,	-- The Zip file name CES will post to CARRS location for Exam XML data
	[OUTBOUND_FILE_PROCESS_STATUS] varchar(50) NULL,	-- CARRS Outbound file upload status - Succeeded/Failed
	[OUTBOUND_FILE_PROCESS_DATE] datetime NULL,	-- CARRS Outbound file process date
	[OUTBOUND_ERROR_DESCRIPTION] varchar(8000) NULL,	-- CARRS Outbound file upload error if any
	[ISACTIVE] bit NOT NULL DEFAULT 1,
	[CREATED_USER] varchar(64) NOT NULL,	-- Created By user
	[CREATED_DATE] datetime NOT NULL,	-- Created Date
	[UPDATED_USER] varchar(64) NULL,	-- Updated By user
	[UPDATED_DATE] datetime NULL	-- Updated Date
)
GO

/* Create Primary Keys, Indexes, Uniques, Checks */

ALTER TABLE [CES].[FILE_PROCESS_LOG] 
 ADD CONSTRAINT [PK_FILE_PROCESS_LOG]
	PRIMARY KEY CLUSTERED ([FILE_PROCESS_LOG_SR_KEY] ASC)
GO

/* Create Foreign Key Constraints */

ALTER TABLE [CES].[FILE_PROCESS_LOG] ADD CONSTRAINT [FK_FILE_PROCESS_LOG_SUPPLIER]
	FOREIGN KEY ([SUPPLIER_SR_KEY]) REFERENCES [CES].[SUPPLIER] ([SUPPLIER_SR_KEY]) ON DELETE No Action ON UPDATE No Action
GO

/* Create Table Comments */

EXEC sp_addextendedproperty 'MS_Description', 'File process log surrogate key (PK)', 'Schema', [CES], 'table', [FILE_PROCESS_LOG], 'column', [FILE_PROCESS_LOG_SR_KEY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'File Type for ex. Task List Date Upload, Exam Data Upload etc.', 'Schema', [CES], 'table', [FILE_PROCESS_LOG], 'column', [FILE_TYPE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Name of the file to be processed', 'Schema', [CES], 'table', [FILE_PROCESS_LOG], 'column', [FILE_NAME]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Location where source files are stored (RAW layer in datalake)', 'Schema', [CES], 'table', [FILE_PROCESS_LOG], 'column', [SOURCE_FILE_LOCATION]
GO

EXEC sp_addextendedproperty 'MS_Description', 'File Submission Date', 'Schema', [CES], 'table', [FILE_PROCESS_LOG], 'column', [FILE_SUBMISSION_DATE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'File processed date', 'Schema', [CES], 'table', [FILE_PROCESS_LOG], 'column', [FILE_PROCESS_DATE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'File processing status. From UI - Submitted, from ADF- Succeeded/Failed/Partially Processed', 'Schema', [CES], 'table', [FILE_PROCESS_LOG], 'column', [FILE_PROCESS_STATUS]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Supplier information', 'Schema', [CES], 'table', [FILE_PROCESS_LOG], 'column', [SUPPLIER_SR_KEY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'User Key for the user who has submitted the file', 'Schema', [CES], 'table', [FILE_PROCESS_LOG], 'column', [USER_ID]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Error description in case the file is failed in validation ', 'Schema', [CES], 'table', [FILE_PROCESS_LOG], 'column', [ERROR_DESCRIPTION]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Error file location', 'Schema', [CES], 'table', [FILE_PROCESS_LOG], 'column', [ERROR_FILE_LOCATION]
GO

EXEC sp_addextendedproperty 'MS_Description', 'The Zip file name CES will post to CARRS location for Exam XML data', 'Schema', [CES], 'table', [FILE_PROCESS_LOG], 'column', [OUTBOUND_FILE_NAME]
GO

EXEC sp_addextendedproperty 'MS_Description', 'CARRS Outbound file upload status - Succeeded/Failed', 'Schema', [CES], 'table', [FILE_PROCESS_LOG], 'column', [OUTBOUND_FILE_PROCESS_STATUS]
GO

EXEC sp_addextendedproperty 'MS_Description', 'CARRS Outbound file process date', 'Schema', [CES], 'table', [FILE_PROCESS_LOG], 'column', [OUTBOUND_FILE_PROCESS_DATE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'CARRS Outbound file upload error if any', 'Schema', [CES], 'table', [FILE_PROCESS_LOG], 'column', [OUTBOUND_ERROR_DESCRIPTION]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Created By user', 'Schema', [CES], 'table', [FILE_PROCESS_LOG], 'column', [CREATED_USER]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Created Date', 'Schema', [CES], 'table', [FILE_PROCESS_LOG], 'column', [CREATED_DATE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Updated By user', 'Schema', [CES], 'table', [FILE_PROCESS_LOG], 'column', [UPDATED_USER]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Updated Date', 'Schema', [CES], 'table', [FILE_PROCESS_LOG], 'column', [UPDATED_DATE]
GO
