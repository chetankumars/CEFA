﻿CREATE TABLE [CES].[SUP_RELATIONSHIP]
(
	[SUP_RLTNSHP_SR_KEY] decimal(18) NOT NULL,	-- Suppliers relationship Surrogate key (PK)
	[ORG_SR_KEY] decimal(18) NOT NULL,	-- Org Surrogate key (FK)
	[ASSET_GROUP_SR_KEY] decimal(18) NOT NULL,	-- Asset type surrogate key (fk)
	[EXAM_TYPE_SR_KEY] decimal(18) NOT NULL,	-- Exam type surrogate key (Fk)
	[SUPPLIER_SR_KEY] decimal(18) NULL,	-- Suppliers Surrogate key (FK)
	[ISACTIVE] bit NOT NULL DEFAULT 1,	-- Indicates if the user is Active or not - 1 for Active, 0 for Deleted/Inactive
	[CREATED_USER] varchar(64) NOT NULL,	-- Created by user
	[CREATED_DATE] datetime NOT NULL,	-- Created date
	[UPDATED_USER] varchar(64) NULL,	-- Updated by user
	[UPDATED_DATE] datetime NULL	-- Updated date
)
GO

/* Create Primary Keys, Indexes, Uniques, Checks */

ALTER TABLE [CES].[SUP_RELATIONSHIP] 
 ADD CONSTRAINT [PK_SUP_RELATIONSHIP]
	PRIMARY KEY CLUSTERED ([SUP_RLTNSHP_SR_KEY] ASC)
GO

/* Create Foreign Key Constraints */

ALTER TABLE [CES].[SUP_RELATIONSHIP] ADD CONSTRAINT [FK_SUP_RELATIONSHIP_ASSET_GROUP]
	FOREIGN KEY ([ASSET_GROUP_SR_KEY]) REFERENCES [CES].[ASSET_GROUP] ([ASSET_GROUP_SR_KEY]) ON DELETE No Action ON UPDATE No Action
GO

ALTER TABLE [CES].[SUP_RELATIONSHIP] ADD CONSTRAINT [FK_SUP_RELATIONSHIP_EXAM_TYPE]
	FOREIGN KEY ([EXAM_TYPE_SR_KEY]) REFERENCES [CES].[EXAM_TYPE] ([EXAM_TYPE_SR_KEY]) ON DELETE No Action ON UPDATE No Action
GO

ALTER TABLE [CES].[SUP_RELATIONSHIP] ADD CONSTRAINT [FK_SUP_RELATIONSHIP_ORG]
	FOREIGN KEY ([ORG_SR_KEY]) REFERENCES [CES].[ORG] ([ORG_SR_KEY]) ON DELETE No Action ON UPDATE No Action
GO

ALTER TABLE [CES].[SUP_RELATIONSHIP] ADD CONSTRAINT [FK_SUP_RELATIONSHIP_SUPPLIER]
	FOREIGN KEY ([SUPPLIER_SR_KEY]) REFERENCES [CES].[SUPPLIER] ([SUPPLIER_SR_KEY]) ON DELETE No Action ON UPDATE No Action
GO

/* Create Table Comments */

EXEC sp_addextendedproperty 'MS_Description', 'Suppliers relationship Surrogate key (PK)', 'Schema', [CES], 'table', [SUP_RELATIONSHIP], 'column', [SUP_RLTNSHP_SR_KEY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Org Surrogate key (FK)', 'Schema', [CES], 'table', [SUP_RELATIONSHIP], 'column', [ORG_SR_KEY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Asset type surrogate key (fk)', 'Schema', [CES], 'table', [SUP_RELATIONSHIP], 'column', [ASSET_GROUP_SR_KEY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Exam type surrogate key (Fk)', 'Schema', [CES], 'table', [SUP_RELATIONSHIP], 'column', [EXAM_TYPE_SR_KEY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Suppliers Surrogate key (FK)', 'Schema', [CES], 'table', [SUP_RELATIONSHIP], 'column', [SUPPLIER_SR_KEY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Indicates if the user is Active or not - 1 for Active, 0 for Deleted/Inactive', 'Schema', [CES], 'table', [SUP_RELATIONSHIP], 'column', [ISACTIVE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Created by user', 'Schema', [CES], 'table', [SUP_RELATIONSHIP], 'column', [CREATED_USER]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Created date', 'Schema', [CES], 'table', [SUP_RELATIONSHIP], 'column', [CREATED_DATE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Updated by user', 'Schema', [CES], 'table', [SUP_RELATIONSHIP], 'column', [UPDATED_USER]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Updated date', 'Schema', [CES], 'table', [SUP_RELATIONSHIP], 'column', [UPDATED_DATE]
GO