﻿
GO

/* Create Primary Keys, Indexes, Uniques, Checks */


GO

/* Create Foreign Key Constraints */


GO


GO

/* Create Table Comments */


GO


GO


GO


GO


GO


GO


GO


GO


GO