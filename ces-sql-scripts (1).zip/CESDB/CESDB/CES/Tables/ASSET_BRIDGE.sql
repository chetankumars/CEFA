﻿CREATE TABLE [CES].[ASSET_BRIDGE]
(
	[ASSET_GUID] varchar(32) NOT NULL,	-- Asset GUID - Identifier in BRIDGE for asset
	[REGION] varchar(64) NULL,	-- Region of the asset
	[ROUTE] varchar(64) NULL,	-- Route for the asset
	[AREA] varchar(64) NULL,	-- Area for the asset
	[ENGINE_LINE_REF] varchar(4) NULL,	-- ELR Code
	[START_MILEAGE] decimal(18,5) NULL,	-- Start Mileage
	[END_MILEAGE] decimal(18,5) NULL,	-- End Mileage
	[RAILWAY_ID] varchar(64) NULL,	-- Railway ID
	[ASSET_GROUP_CD] varchar(5) NULL,	-- Asset Group Code
	[ASSET_GROUP_DESC] varchar(64) NULL,	-- Asset Group Description
	[ASSET_TYPE] varchar(64) NULL,	-- Asset Type Description
	[ASSET_NAME] varchar(200) NULL,	-- Asset Name/Description
	[PRIMARY_MATERIAL] varchar(100) NULL,	-- Primary Material
	[OS_GRID_REF] varchar(16) NULL,	-- OS GRID Reference
	[HCE_FLAG] varchar(3) NULL,	-- HCE Flag - Yes/No
	[ISACTIVE] bit NOT NULL DEFAULT 1,	-- Indicates if the record is Active or not - 1 for Active, 0 for Deleted/Inactive
	[CREATED_USER] varchar(32) NOT NULL,	-- Created by user
	[CREATED_DATE] datetime NOT NULL,	-- Created Date
	[UPDATED_USER] varchar(32) NULL,	-- Updated By user
	[UPDATED_DATE] datetime NULL	-- Updated Date
)
GO

/* Create Primary Keys, Indexes, Uniques, Checks */

ALTER TABLE [CES].[ASSET_BRIDGE] 
 ADD CONSTRAINT [PK_ASSET_BRIDGE]
	PRIMARY KEY CLUSTERED ([ASSET_GUID] ASC)
GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Updated Date', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'ASSET_BRIDGE', @level2type = N'COLUMN', @level2name = N'UPDATED_DATE';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Updated By user', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'ASSET_BRIDGE', @level2type = N'COLUMN', @level2name = N'UPDATED_USER';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Created Date', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'ASSET_BRIDGE', @level2type = N'COLUMN', @level2name = N'CREATED_DATE';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Created by user', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'ASSET_BRIDGE', @level2type = N'COLUMN', @level2name = N'CREATED_USER';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'HCE Flag - Yes/No', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'ASSET_BRIDGE', @level2type = N'COLUMN', @level2name = N'HCE_FLAG';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'OS GRID Reference', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'ASSET_BRIDGE', @level2type = N'COLUMN', @level2name = N'OS_GRID_REF';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Primary Material', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'ASSET_BRIDGE', @level2type = N'COLUMN', @level2name = N'PRIMARY_MATERIAL';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Asset Name/Description', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'ASSET_BRIDGE', @level2type = N'COLUMN', @level2name = N'ASSET_NAME';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Asset Type Description', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'ASSET_BRIDGE', @level2type = N'COLUMN', @level2name = N'ASSET_TYPE';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Asset Group Description', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'ASSET_BRIDGE', @level2type = N'COLUMN', @level2name = N'ASSET_GROUP_DESC';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Asset Group COde', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'ASSET_BRIDGE', @level2type = N'COLUMN', @level2name = N'ASSET_GROUP_CD';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Railway ID', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'ASSET_BRIDGE', @level2type = N'COLUMN', @level2name = N'RAILWAY_ID';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'End Mileage', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'ASSET_BRIDGE', @level2type = N'COLUMN', @level2name = N'END_MILEAGE';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Start Mileage', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'ASSET_BRIDGE', @level2type = N'COLUMN', @level2name = N'START_MILEAGE';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Area for the asset', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'ASSET_BRIDGE', @level2type = N'COLUMN', @level2name = N'AREA';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Route for the asset', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'ASSET_BRIDGE', @level2type = N'COLUMN', @level2name = N'ROUTE';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Region of the asset', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'ASSET_BRIDGE', @level2type = N'COLUMN', @level2name = N'REGION';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Asset GUID - Identifier in BRIDGE for asset', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'ASSET_BRIDGE', @level2type = N'COLUMN', @level2name = N'ASSET_GUID';

