﻿CREATE TABLE [CES].[EXAM_GROUP]
(
	[EXAM_GROUP_SR_KEY] decimal(18) NOT NULL IDENTITY (1, 1),	-- Exam Group Surrogate Key (PK)
	[CARRS_EXAM_GROUP_ID] decimal(18) NULL,	-- Exam Group ID as mentioned in CARRS
	[LOC_AT_ASSET_GUID] varchar(32) NULL,	-- Primary Asset GUID associated with Exam Group (in case of multiple structures)
	[START_DATE] date NOT NULL,	-- Start Date
	[END_DATE] date NULL,	-- End Date
	[ISACTIVE] bit NOT NULL DEFAULT 1,	-- Indicates if the record is Active or not - 1 for Active, 0 for Deleted/Inactive
	[CREATED_USER] varchar(64) NOT NULL,	-- Created by User
	[CREATED_DATE] datetime NOT NULL,	-- Created Date
	[UPDATED_USER] varchar(64) NULL,	-- Updated by User
	[UPDATED_DATE] datetime NULL
)
GO

/* Create Primary Keys, Indexes, Uniques, Checks */

ALTER TABLE [CES].[EXAM_GROUP] 
 ADD CONSTRAINT [PK_EXAM_GROUP]
	PRIMARY KEY CLUSTERED ([EXAM_GROUP_SR_KEY] ASC)
GO

/* Create Foreign Key Constraints */

ALTER TABLE [CES].[EXAM_GROUP] ADD CONSTRAINT [FK_EXAM_GROUP_ASSET]
	FOREIGN KEY ([LOC_AT_ASSET_GUID]) REFERENCES [CES].[ASSET] ([ASSET_GUID]) ON DELETE No Action ON UPDATE No Action
GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Updated by User', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'EXAM_GROUP', @level2type = N'COLUMN', @level2name = N'UPDATED_USER';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Created Date', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'EXAM_GROUP', @level2type = N'COLUMN', @level2name = N'CREATED_DATE';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Created by User', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'EXAM_GROUP', @level2type = N'COLUMN', @level2name = N'CREATED_USER';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Indicates if the record is Active or not - 1 for Active, 0 for Deleted/Inactive', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'EXAM_GROUP', @level2type = N'COLUMN', @level2name = N'ISACTIVE';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'End Date', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'EXAM_GROUP', @level2type = N'COLUMN', @level2name = N'END_DATE';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Start Date', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'EXAM_GROUP', @level2type = N'COLUMN', @level2name = N'START_DATE';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Primary Asset GUID associated with Exam Group (in case of multiple structures)', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'EXAM_GROUP', @level2type = N'COLUMN', @level2name = N'LOC_AT_ASSET_GUID';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Exam Group ID as mentioned in CARRS', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'EXAM_GROUP', @level2type = N'COLUMN', @level2name = N'CARRS_EXAM_GROUP_ID';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Exam Group Surrogate Key (PK)', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'EXAM_GROUP', @level2type = N'COLUMN', @level2name = N'EXAM_GROUP_SR_KEY';

