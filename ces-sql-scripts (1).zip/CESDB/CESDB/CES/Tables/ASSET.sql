﻿CREATE TABLE [CES].[ASSET]
(
	[ASSET_GUID] varchar(32) NOT NULL,	-- Unique asset reference (pk)
	[PARENT_ASSET_GUID] varchar(32) NULL,	-- Parent asset GUID (fk)
	[ASSET_NAME] varchar(200) NULL,	-- Asset componenet name
	[ASSET_TYPE_SR_KEY] decimal(18) NOT NULL,	-- Asset type surrogate key (fk)
	[ASSET_GROUP_SR_KEY] decimal(18) NOT NULL,	-- Asset group surrogate key (fk)
	[ORG_SR_KEY] decimal(18) NOT NULL,
	[AREA_SR_KEY] decimal(18) NOT NULL,	-- Area
	[ENG_LINE_REF] decimal(18) NOT NULL,	-- The Primary ELR for the Asset  (Engineers Line Reference)
	[RAILWAY_ID] varchar(64) NULL,	--  Railway ID for the Asset ( Assetidentifier)
	[START_MILES] decimal(5) NOT NULL,	-- Start miles
	[START_YARDS] decimal(5) NOT NULL,	-- Start yards
	[END_MILES] decimal(5) NULL,	-- End miles
	[END_YARDS] decimal(5) NULL,	-- End yards
	[PRIMARY_MATERIAL] decimal(18) NULL,	-- Primary Material for the Asset   <RBE - Brick , WALL - Stone , CUL - Brick ,  RBE - Steel ,WALL - Stone  etc >
	[SECONDARY_MATERIAL] decimal(18) NULL,	-- Secondary Material type of the asset
	[OPERATIONAL_STATUS] decimal(18) NULL,	-- Operational Status of the Asset < Functionary , Operational , Removed , duplicate  etc.
	[STRUCTURAL_FORM] decimal(18) NULL,	-- Structural form
	[OWNING_PARTY] varchar(64) NULL,	-- 'Owning Party' for the Asset < NetworkRail (CE-Op Prop), NetworkRail (Signalling), NetworkRail (Drainage) , Highways England etc>
	[OUTSIDE_PARTY] varchar(64) NULL,	-- Outside party name  if the owning party = "Outside party"
	[POSSESSION_CRITICAL] varchar(64) NULL,	-- Possession critical
	[GPS_START_MILEAGE] varchar(64) NULL,	-- Asset with length asset start GPS coordinates (start mileage)
	[GPS_END_MILEAGE] varchar(64) NULL,	-- Asset with length asset end GPS coordinates (end mileage)
	[START_OS_GRID_REF] varchar(16) NULL,	-- Asset with length asset Start OS grid ref 
	[END_OS_GRID_REF] varchar(16) NULL,	-- Asset with length asset End OS grid ref 
	[HCE_FLAG] char(1) NOT NULL DEFAULT 'N',	-- Hidden critical element Yes/No
	[ANY_HIDDEN_PARTS] varchar(5) NULL,	-- Any hidden parts < Yes , No>
	[STRUCTURE_CARRIES] varchar(64) NULL,	-- Structure carries <Foot , Path , Water ,Land , Side Access , Road NP ,Rail etc>
	[STRUCTURE_OVER] varchar(64) NULL,	-- Structures over < Foot ,Yard , Road Pub ,Path ,  Water , Land , Rail , unknown etc >
	[CMI_SCORE] decimal(3) NULL,	-- CMI Score
	[CMI_DATE] date NULL,	-- CMI Date
	[TENANTED_FLG] varchar(1) NULL,	-- Tenanted Arch Flag
	[ASSET_IMAGE_NAME] varchar(200) NULL,	-- Asset Image Name - to be uploaded in Asset Profile
	[ASSET_IMAGE_LINK] varchar(500) NULL,	-- Asset Image link - Data lake path where image will be stored
	[ISACTIVE] bit NOT NULL DEFAULT 1,	-- Indicates if the record is Active or not - 1 for Active, 0 for Deleted/Inactive
	[CREATED_USER] varchar(64) NOT NULL,	-- Created by user
	[CREATED_DATE] datetime NOT NULL,	-- Created date
	[UPDATED_USER] varchar(64) NULL,	-- Updated by user
	[UPDATED_DATE] datetime NULL	-- Updated date
)
GO

/* Create Primary Keys, Indexes, Uniques, Checks */

ALTER TABLE [CES].[ASSET] 
 ADD CONSTRAINT [PK_ASSET]
	PRIMARY KEY CLUSTERED ([ASSET_GUID] ASC)
GO

CREATE NONCLUSTERED INDEX [IX_ASSET_ASSETGRPSRKEY_ISACTIVE] ON [CES].[ASSET]
(
	[ASSET_GROUP_SR_KEY] ASC,
	[ISACTIVE] ASC
)
INCLUDE ( 	[ASSET_NAME],
	[ASSET_TYPE_SR_KEY],
	[ORG_SR_KEY],
	[AREA_SR_KEY],
	[ENG_LINE_REF],
	[RAILWAY_ID],
	[START_MILES],
	[START_YARDS],
	[END_MILES],
	[END_YARDS],
	[PRIMARY_MATERIAL],
	[OPERATIONAL_STATUS],
	[OWNING_PARTY])
GO

CREATE NONCLUSTERED INDEX [IX_ASSET_ELR_ISACTIVE] ON [CES].[ASSET]
(
	[ENG_LINE_REF] ASC,
	[ISACTIVE] ASC
)
INCLUDE ( 	[ASSET_NAME],
	[ASSET_TYPE_SR_KEY],
	[ASSET_GROUP_SR_KEY],
	[ORG_SR_KEY],
	[AREA_SR_KEY],
	[RAILWAY_ID],
	[START_MILES],
	[START_YARDS],
	[END_MILES],
	[END_YARDS],
	[PRIMARY_MATERIAL],
	[OPERATIONAL_STATUS],
	[OWNING_PARTY],
	[HCE_FLAG],
	[STRUCTURE_CARRIES],
	[STRUCTURE_OVER],
	[CMI_SCORE])
GO

CREATE NONCLUSTERED INDEX [IX_ASSET_ORG_ISACTIVE] ON [CES].[ASSET]
(
	[ORG_SR_KEY] ASC,
	[ISACTIVE] ASC
)
INCLUDE ( 	[ENG_LINE_REF],
	[RAILWAY_ID])
GO

/* Create Foreign Key Constraints */

ALTER TABLE [CES].[ASSET] ADD CONSTRAINT [FK_ASSET_AREA]
	FOREIGN KEY ([AREA_SR_KEY]) REFERENCES [CES].[AREA] ([AREA_SR_KEY]) ON DELETE No Action ON UPDATE No Action
GO

ALTER TABLE [CES].[ASSET] ADD CONSTRAINT [FK_ASSET_ASSET_GROUP]
	FOREIGN KEY ([ASSET_GROUP_SR_KEY]) REFERENCES [CES].[ASSET_GROUP] ([ASSET_GROUP_SR_KEY]) ON DELETE No Action ON UPDATE No Action
GO

ALTER TABLE [CES].[ASSET] ADD CONSTRAINT [FK_ASSET_ASSET_TYPE]
	FOREIGN KEY ([ASSET_TYPE_SR_KEY]) REFERENCES [CES].[ASSET_TYPE] ([ASSET_TYPE_SR_KEY]) ON DELETE No Action ON UPDATE No Action
GO

ALTER TABLE [CES].[ASSET] ADD CONSTRAINT [FK_ASSET_ENGINE_LINE_REF]
	FOREIGN KEY ([ENG_LINE_REF]) REFERENCES [CES].[ENGINE_LINE_REF] ([ELR_SR_KEY]) ON DELETE No Action ON UPDATE No Action
GO

ALTER TABLE [CES].[ASSET] ADD CONSTRAINT [FK_ASSET_ORG]
	FOREIGN KEY ([ORG_SR_KEY]) REFERENCES [CES].[ORG] ([ORG_SR_KEY]) ON DELETE No Action ON UPDATE No Action
GO

ALTER TABLE [CES].[ASSET] ADD CONSTRAINT [FK_ASSET_REF_VALUE_OP_STAT]
	FOREIGN KEY ([OPERATIONAL_STATUS]) REFERENCES [CES].[REFERENCE_VALUE] ([REF_VAL_SR_KEY]) ON DELETE No Action ON UPDATE No Action
GO

ALTER TABLE [CES].[ASSET] ADD CONSTRAINT [FK_ASSET_REF_VALUE_PRI_MATR]
	FOREIGN KEY ([PRIMARY_MATERIAL]) REFERENCES [CES].[REFERENCE_VALUE] ([REF_VAL_SR_KEY]) ON DELETE No Action ON UPDATE No Action
GO

ALTER TABLE [CES].[ASSET] ADD CONSTRAINT [FK_ASSET_REF_VALUE_SEC_MATR]
	FOREIGN KEY ([SECONDARY_MATERIAL]) REFERENCES [CES].[REFERENCE_VALUE] ([REF_VAL_SR_KEY]) ON DELETE No Action ON UPDATE No Action
GO

ALTER TABLE [CES].[ASSET] ADD CONSTRAINT [FK_ASSET_REF_VALUE_STRUCT]
	FOREIGN KEY ([STRUCTURAL_FORM]) REFERENCES [CES].[REFERENCE_VALUE] ([REF_VAL_SR_KEY]) ON DELETE No Action ON UPDATE No Action
GO

/* Create Table Comments */

EXEC sp_addextendedproperty 'MS_Description', 'Unique asset reference (pk)', 'Schema', [CES], 'table', [ASSET], 'column', [ASSET_GUID]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Parent asset GUID (fk)', 'Schema', [CES], 'table', [ASSET], 'column', [PARENT_ASSET_GUID]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Asset componenet name', 'Schema', [CES], 'table', [ASSET], 'column', [ASSET_NAME]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Asset type surrogate key (fk)', 'Schema', [CES], 'table', [ASSET], 'column', [ASSET_TYPE_SR_KEY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Asset group surrogate key (fk)', 'Schema', [CES], 'table', [ASSET], 'column', [ASSET_GROUP_SR_KEY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Area', 'Schema', [CES], 'table', [ASSET], 'column', [AREA_SR_KEY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'The Primary ELR for the Asset  (Engineers Line Reference)', 'Schema', [CES], 'table', [ASSET], 'column', [ENG_LINE_REF]
GO

EXEC sp_addextendedproperty 'MS_Description', ' Railway ID for the Asset ( Assetidentifier)', 'Schema', [CES], 'table', [ASSET], 'column', [RAILWAY_ID]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Start miles', 'Schema', [CES], 'table', [ASSET], 'column', [START_MILES]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Start yards', 'Schema', [CES], 'table', [ASSET], 'column', [START_YARDS]
GO

EXEC sp_addextendedproperty 'MS_Description', 'End miles', 'Schema', [CES], 'table', [ASSET], 'column', [END_MILES]
GO

EXEC sp_addextendedproperty 'MS_Description', 'End yards', 'Schema', [CES], 'table', [ASSET], 'column', [END_YARDS]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Primary Material for the Asset   <RBE - Brick , WALL - Stone , CUL - Brick ,  RBE - Steel ,WALL - Stone  etc >', 'Schema', [CES], 'table', [ASSET], 'column', [PRIMARY_MATERIAL]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Secondary Material type of the asset', 'Schema', [CES], 'table', [ASSET], 'column', [SECONDARY_MATERIAL]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Operational Status of the Asset < Functionary , Operational , Removed , duplicate  etc.', 'Schema', [CES], 'table', [ASSET], 'column', [OPERATIONAL_STATUS]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Structural form', 'Schema', [CES], 'table', [ASSET], 'column', [STRUCTURAL_FORM]
GO

EXEC sp_addextendedproperty 'MS_Description', '''Owning Party'' for the Asset < NetworkRail (CE-Op Prop), NetworkRail (Signalling), NetworkRail (Drainage) , Highways England etc>', 'Schema', [CES], 'table', [ASSET], 'column', [OWNING_PARTY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Outside party name  if the owning party = "Outside party"', 'Schema', [CES], 'table', [ASSET], 'column', [OUTSIDE_PARTY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Possession critical', 'Schema', [CES], 'table', [ASSET], 'column', [POSSESSION_CRITICAL]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Asset with length asset start GPS coordinates (start mileage)', 'Schema', [CES], 'table', [ASSET], 'column', [GPS_START_MILEAGE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Asset with length asset end GPS coordinates (end mileage)', 'Schema', [CES], 'table', [ASSET], 'column', [GPS_END_MILEAGE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Asset with length asset Start OS grid ref ', 'Schema', [CES], 'table', [ASSET], 'column', [START_OS_GRID_REF]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Asset with length asset End OS grid ref ', 'Schema', [CES], 'table', [ASSET], 'column', [END_OS_GRID_REF]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Hidden critical element Yes/No', 'Schema', [CES], 'table', [ASSET], 'column', [HCE_FLAG]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Any hidden parts < Yes , No>', 'Schema', [CES], 'table', [ASSET], 'column', [ANY_HIDDEN_PARTS]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Structure carries <Foot , Path , Water ,Land , Side Access , Road NP ,Rail etc>', 'Schema', [CES], 'table', [ASSET], 'column', [STRUCTURE_CARRIES]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Structures over < Foot ,Yard , Road Pub ,Path ,  Water , Land , Rail , unknown etc >', 'Schema', [CES], 'table', [ASSET], 'column', [STRUCTURE_OVER]
GO

EXEC sp_addextendedproperty 'MS_Description', 'CMI Score', 'Schema', [CES], 'table', [ASSET], 'column', [CMI_SCORE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'CMI Date', 'Schema', [CES], 'table', [ASSET], 'column', [CMI_DATE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Tenanted Arch Flag', 'Schema', [CES], 'table', [ASSET], 'column', [TENANTED_FLG]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Indicates if the user is Active or not - 1 for Active, 0 for Deleted/Inactive', 'Schema', [CES], 'table', [ASSET], 'column', [ISACTIVE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Created by user', 'Schema', [CES], 'table', [ASSET], 'column', [CREATED_USER]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Created date', 'Schema', [CES], 'table', [ASSET], 'column', [CREATED_DATE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Updated by user', 'Schema', [CES], 'table', [ASSET], 'column', [UPDATED_USER]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Updated date', 'Schema', [CES], 'table', [ASSET], 'column', [UPDATED_DATE]
GO