﻿CREATE TABLE [CES].[PART_NOT_EXAMINED]
(
	[PNE_SR_KEY] decimal(18) NOT NULL IDENTITY (1, 1),	-- PNE Surrogate key (pk)
	[EXAM_SR_KEY] decimal(18) NOT NULL,	-- Exam Surrogate key (fk)
	[PNE_PART_NAME] varchar(128) NULL,	-- "Asset" Part not examined - Part Name
	[PNE_REASON] varchar(320) NULL,	-- "Asset" Part not examined - Reason not examined
	[ISACTIVE] bit NOT NULL DEFAULT 1,	-- Indicates if the user is Active or not - 1 for Active, 0 for Deleted/Inactive
	[CREATED_USER] varchar(64) NOT NULL,	-- Created by user
	[CREATED_DATE] datetime NOT NULL,	-- Created date
	[UPDATED_USER] varchar(64) NULL,	-- Updated by user
	[UPDATED_DATE] datetime NULL	-- Updated date
)
GO

/* Create Primary Keys, Indexes, Uniques, Checks */

ALTER TABLE [CES].[PART_NOT_EXAMINED] 
 ADD CONSTRAINT [PK_PART_NOT_EXAMINED]
	PRIMARY KEY CLUSTERED ([PNE_SR_KEY] ASC)
GO

/* Create Foreign Key Constraints */

ALTER TABLE [CES].[PART_NOT_EXAMINED] ADD CONSTRAINT [FK_PART_NOT_EXAMINED_EXAM]
	FOREIGN KEY ([EXAM_SR_KEY]) REFERENCES [CES].[EXAM] ([EXAM_SR_KEY]) ON DELETE No Action ON UPDATE No Action
GO

/* Create Table Comments */

EXEC sp_addextendedproperty 'MS_Description', 'PNE Surrogate key (pk)', 'Schema', [CES], 'table', [PART_NOT_EXAMINED], 'column', [PNE_SR_KEY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Exam Surrogate key (fk)', 'Schema', [CES], 'table', [PART_NOT_EXAMINED], 'column', [EXAM_SR_KEY]
GO

EXEC sp_addextendedproperty 'MS_Description', '"Asset" Part not examined - Part Name', 'Schema', [CES], 'table', [PART_NOT_EXAMINED], 'column', [PNE_PART_NAME]
GO

EXEC sp_addextendedproperty 'MS_Description', '"Asset" Part not examined - Reason not examined', 'Schema', [CES], 'table', [PART_NOT_EXAMINED], 'column', [PNE_REASON]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Indicates if the user is Active or not - 1 for Active, 0 for Deleted/Inactive', 'Schema', [CES], 'table', [PART_NOT_EXAMINED], 'column', [ISACTIVE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Created by user', 'Schema', [CES], 'table', [PART_NOT_EXAMINED], 'column', [CREATED_USER]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Created date', 'Schema', [CES], 'table', [PART_NOT_EXAMINED], 'column', [CREATED_DATE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Updated by user', 'Schema', [CES], 'table', [PART_NOT_EXAMINED], 'column', [UPDATED_USER]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Updated date', 'Schema', [CES], 'table', [PART_NOT_EXAMINED], 'column', [UPDATED_DATE]
GO