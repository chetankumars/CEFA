﻿CREATE TABLE [CES].[COMPLIANCE_TOLERANCE]
(
	[COMPL_TOL_SR_KEY] decimal(18) NOT NULL IDENTITY (1, 1),	-- Primary Key (surrogate key)
	[EXAM_TYPE_SR_KEY] decimal(18) NOT NULL,	-- Exam Type
	[FREQ_INTERVAL_MONTHS_FROM] decimal(5) NULL,	-- Exam Frequency Interval From (in months)
	[FREQ_INTERVAL_MONTHS_TO] decimal(5) NULL,	-- Exam Frequency Interval To (in months)
	[SITE_TOLERANCE_WEEKS] decimal(5) NULL,	-- Site Tolerance value (in weeks)
	[REVIEW_TOLERANCE_WEEKS] decimal(5) NULL,	-- Review Tolerance (in weeks)
	[RA_REVIEW_TOLERANCE_MONTHS] decimal(5) NULL,	-- Risk Assessment Review Date Tolerance (in months)
	[RA_EXPIRY_TOLERANCE_MONTHS] decimal(5) NULL,	-- Risk Assessment Expiry Date Tolerance (in months)
	[ISACTIVE] bit NOT NULL DEFAULT 1,	-- Indicates if the user is Active or not - 1 for Active, 0 for Deleted/Inactive
	[CREATED_USER] varchar(64) NOT NULL,	-- Created By User
	[CREATED_DATE] datetime NOT NULL,	-- Created Date
	[UPDATED_USER] varchar(64) NULL,	-- Updated By User
	[UPDATED_DATE] datetime NULL	-- Updated date
)
GO

/* Create Primary Keys, Indexes, Uniques, Checks */

ALTER TABLE [CES].[COMPLIANCE_TOLERANCE] 
 ADD CONSTRAINT [PK_COMPLIANCE_TOLERANCE]
	PRIMARY KEY CLUSTERED ([COMPL_TOL_SR_KEY] ASC)
GO

/* Create Foreign Key Constraints */

ALTER TABLE [CES].[COMPLIANCE_TOLERANCE] ADD CONSTRAINT [FK_COMPLIANCE_TOLERANCE_EXAM_TYPE]
	FOREIGN KEY ([EXAM_TYPE_SR_KEY]) REFERENCES [CES].[EXAM_TYPE] ([EXAM_TYPE_SR_KEY]) ON DELETE No Action ON UPDATE No Action
GO

/* Create Table Comments */

EXEC sp_addextendedproperty 'MS_Description', 'Primary Key (surrogate key)', 'Schema', [CES], 'table', [COMPLIANCE_TOLERANCE], 'column', [COMPL_TOL_SR_KEY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Exam Type', 'Schema', [CES], 'table', [COMPLIANCE_TOLERANCE], 'column', [EXAM_TYPE_SR_KEY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Exam Frequency Interval From (in months)', 'Schema', [CES], 'table', [COMPLIANCE_TOLERANCE], 'column', [FREQ_INTERVAL_MONTHS_FROM]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Exam Frequency Interval To (in months)', 'Schema', [CES], 'table', [COMPLIANCE_TOLERANCE], 'column', [FREQ_INTERVAL_MONTHS_TO]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Site Tolerance value (in weeks)', 'Schema', [CES], 'table', [COMPLIANCE_TOLERANCE], 'column', [SITE_TOLERANCE_WEEKS]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Review Tolerance (in weeks)', 'Schema', [CES], 'table', [COMPLIANCE_TOLERANCE], 'column', [REVIEW_TOLERANCE_WEEKS]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Risk Assessment Review Date Tolerance (in months)', 'Schema', [CES], 'table', [COMPLIANCE_TOLERANCE], 'column', [RA_REVIEW_TOLERANCE_MONTHS]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Risk Assessment Expiry Date Tolerance (in months)', 'Schema', [CES], 'table', [COMPLIANCE_TOLERANCE], 'column', [RA_EXPIRY_TOLERANCE_MONTHS]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Indicates if the user is Active or not - 1 for Active, 0 for Deleted/Inactive', 'Schema', [CES], 'table', [COMPLIANCE_TOLERANCE], 'column', [ISACTIVE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Created By User', 'Schema', [CES], 'table', [COMPLIANCE_TOLERANCE], 'column', [CREATED_USER]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Created Date', 'Schema', [CES], 'table', [COMPLIANCE_TOLERANCE], 'column', [CREATED_DATE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Updated By User', 'Schema', [CES], 'table', [COMPLIANCE_TOLERANCE], 'column', [UPDATED_USER]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Updated date', 'Schema', [CES], 'table', [COMPLIANCE_TOLERANCE], 'column', [UPDATED_DATE]
GO