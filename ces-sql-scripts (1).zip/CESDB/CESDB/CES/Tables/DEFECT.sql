﻿CREATE TABLE [CES].[DEFECT]
(
	[DEFECT_SR_KEY] decimal(18) NOT NULL IDENTITY (1, 1),	-- Defect Surrogate Key(pk)
	[DEFECT_ID] decimal(18) NOT NULL,	-- Defect ID
	[ASSET_GUID] varchar(32) NOT NULL,	-- Unique asset reference (fk)
	[EXAM_SR_KEY] decimal(18) NULL,	-- Exam Surrogate key (fk)
	[EXAM_DATE] date NULL,	-- Exam Date to be marked for Exam Type = Site Visit or NR Inspection
	[EXAM_TYPE_SR_KEY] decimal(18) NULL,	-- Exam Type to be marked for Exam Type = Site Visit or NR Inspection
	[DESCRIPTION] varchar(256) NOT NULL,	-- description of the defect
	[LOCATION] varchar(250) NOT NULL,	-- Defect Location
	[LOCATION_MAJOR] varchar(250) NULL,	-- Location Major
	[LOCATION_MINOR] varchar(250) NULL,	-- Location Minor
	[RISK_SCORE] varchar(10) NULL,	-- Defect Risk Score
	[DETERIORATION] varchar(64) NULL,	-- DETERIORATION
	[ACCESS_GAINED] varchar(5) NULL,	-- ACCESS GAINED
	[ACCESS_REQUIRED] varchar(5) NULL,	-- ACCESS REQUIRED
	[REPAIRED] varchar(5) NULL,	-- REPAIRED
	[RECOMMEND_RAISED] varchar(5) NULL,	-- Recommendation No against defect
	[FLAG_FOR_CLOSURE] char(1) NULL DEFAULT 'N',	-- Flag to indicate the closure status of defect - Y/N
	[ENGINEER_COMMENTS] varchar(1000) NULL,	-- Defect reviewer comments
	[DEFECT_USER] varchar(64) NULL,	-- User created the defect
	[IS_DEFECT_CLOSED] char(1) NOT NULL DEFAULT 'N',	-- Flag to indicate if the defect ID is closed - Y/N
	[DEFECT_CLOSED_BY] varchar(64) NULL,	-- User OID who will be closing the defect
	[DEFECT_CLOSED_DATE] datetime NULL,	-- Date on which defect is closed
	[ISACTIVE] bit NOT NULL DEFAULT 1,	-- Indicates if the user is Active or not - 1 for Active, 0 for Deleted/Inactive
	[CREATED_USER] varchar(64) NOT NULL,	-- Created by user
	[CREATED_DATE] datetime NOT NULL,	-- Created date
	[UPDATED_USER] varchar(64) NULL,	-- Updated by user
	[UPDATED_DATE] datetime NULL	-- Updated date
)
GO

/* Create Primary Keys, Indexes, Uniques, Checks */

ALTER TABLE [CES].[DEFECT] 
 ADD CONSTRAINT [PK_DEFECT]
	PRIMARY KEY CLUSTERED ([DEFECT_SR_KEY] ASC)
GO

CREATE NONCLUSTERED INDEX [IX_DEFECT_ASSETGUID_EXAM_ISACTIVE] ON [CES].[DEFECT]
(
	[ASSET_GUID] ASC,
	[EXAM_SR_KEY] ASC,
	[ISACTIVE] ASC
)
INCLUDE([FLAG_FOR_CLOSURE],[DEFECT_ID],[RISK_SCORE],[EXAM_DATE])
GO

/* Create Foreign Key Constraints */

ALTER TABLE [CES].[DEFECT] ADD CONSTRAINT [FK_DEFECT_ASSET]
	FOREIGN KEY ([ASSET_GUID]) REFERENCES [CES].[ASSET] ([ASSET_GUID]) ON DELETE No Action ON UPDATE No Action
GO

ALTER TABLE [CES].[DEFECT] ADD CONSTRAINT [FK_DEFECT_EXAM]
	FOREIGN KEY ([EXAM_SR_KEY]) REFERENCES [CES].[EXAM] ([EXAM_SR_KEY]) ON DELETE No Action ON UPDATE No Action
GO

ALTER TABLE [CES].[DEFECT] ADD CONSTRAINT [FK_DEFECT_EXAM_TYPE]
	FOREIGN KEY ([EXAM_TYPE_SR_KEY]) REFERENCES [CES].[EXAM_TYPE] ([EXAM_TYPE_SR_KEY]) ON DELETE No Action ON UPDATE No Action
GO

/* Create Table Comments */

EXEC sp_addextendedproperty 'MS_Description', 'Defect Surrogate Key(pk)', 'Schema', [CES], 'table', [DEFECT], 'column', [DEFECT_SR_KEY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Defect ID', 'Schema', [CES], 'table', [DEFECT], 'column', [DEFECT_ID]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Unique asset reference (fk)', 'Schema', [CES], 'table', [DEFECT], 'column', [ASSET_GUID]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Exam Surrogate key (fk)', 'Schema', [CES], 'table', [DEFECT], 'column', [EXAM_SR_KEY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Exam Date to be marked for Exam Type = Site Visit or NR Inspection', 'Schema', [CES], 'table', [DEFECT], 'column', [EXAM_DATE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Exam Type to be marked for Exam Type = Site Visit or NR Inspection', 'Schema', [CES], 'table', [DEFECT], 'column', [EXAM_TYPE_SR_KEY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'description of the defect', 'Schema', [CES], 'table', [DEFECT], 'column', [DESCRIPTION]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Defect Location', 'Schema', [CES], 'table', [DEFECT], 'column', [LOCATION]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Location Major', 'Schema', [CES], 'table', [DEFECT], 'column', [LOCATION_MAJOR]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Location Minor', 'Schema', [CES], 'table', [DEFECT], 'column', [LOCATION_MINOR]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Defect Risk Score', 'Schema', [CES], 'table', [DEFECT], 'column', [RISK_SCORE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'DETERIORATION', 'Schema', [CES], 'table', [DEFECT], 'column', [DETERIORATION]
GO

EXEC sp_addextendedproperty 'MS_Description', 'ACCESS GAINED', 'Schema', [CES], 'table', [DEFECT], 'column', [ACCESS_GAINED]
GO

EXEC sp_addextendedproperty 'MS_Description', 'ACCESS REQUIRED', 'Schema', [CES], 'table', [DEFECT], 'column', [ACCESS_REQUIRED]
GO

EXEC sp_addextendedproperty 'MS_Description', 'REPAIRED', 'Schema', [CES], 'table', [DEFECT], 'column', [REPAIRED]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Recommendation No against defect', 'Schema', [CES], 'table', [DEFECT], 'column', [RECOMMEND_RAISED]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Flag to indicate the closure status of defect - Y/N', 'Schema', [CES], 'table', [DEFECT], 'column', [FLAG_FOR_CLOSURE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Defect reviewer comments', 'Schema', [CES], 'table', [DEFECT], 'column', [ENGINEER_COMMENTS]
GO

EXEC sp_addextendedproperty 'MS_Description', 'User created the defect', 'Schema', [CES], 'table', [DEFECT], 'column', [DEFECT_USER]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Flag to indicate if the defect ID is closed - Y/N', 'Schema', [CES], 'table', [DEFECT], 'column', [IS_DEFECT_CLOSED]
GO

EXEC sp_addextendedproperty 'MS_Description', 'User OID who will be closing the defect', 'Schema', [CES], 'table', [DEFECT], 'column', [DEFECT_CLOSED_BY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Date on which defect is closed', 'Schema', [CES], 'table', [DEFECT], 'column', [DEFECT_CLOSED_DATE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Indicates if the user is Active or not - 1 for Active, 0 for Deleted/Inactive', 'Schema', [CES], 'table', [DEFECT], 'column', [ISACTIVE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Created by user', 'Schema', [CES], 'table', [DEFECT], 'column', [CREATED_USER]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Created date', 'Schema', [CES], 'table', [DEFECT], 'column', [CREATED_DATE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Updated by user', 'Schema', [CES], 'table', [DEFECT], 'column', [UPDATED_USER]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Updated date', 'Schema', [CES], 'table', [DEFECT], 'column', [UPDATED_DATE]
GO