﻿CREATE TABLE [CES].[WORK]
(
	[WORK_SR_KEY] decimal(18) NOT NULL,	-- WorkBank Surrogate key (PK)
	[WORK_YEAR_KEY] decimal(18) NOT NULL,	-- Financial year
	[WORK_YR_START_DT] date NOT NULL,	-- Financial year start date
	[WORK_YR_END_DT] date NOT NULL,	-- Fianancial year end date
	[ORG_SR_KEY] decimal(18) NOT NULL,	-- Route information
	[ASSET_GUID] varchar(32) NOT NULL,	-- Asset GUID for assets selected in Tasklist screen/coming from CARRS
	[EXAM_TYPE_SR_KEY] decimal(18) NOT NULL,	-- Exam Type for the assets
	[EXAM_DUE_DATE] date NULL,	-- Exam Due Date - either default as per due date algo or as entered by the AE in Task list request screen or coming from CARRS
	[WORK_STATUS] decimal(18) NOT NULL,	-- Task List Status
	[SPECIFIC_EXAM_REQ] varchar(1000) NULL,	-- Specific exam requests
	[NR_INTERNAL_NOTES] varchar(4000) NULL,	-- NR internal Notes
	[COMMENTS_TO_SEC] varchar(4000) NULL,	-- Comments to the supplier
	[JOB_NUMBER] varchar(8000) NULL,	-- Job Number associated with examination
	[ISACTIVE] bit NOT NULL DEFAULT 1,	-- Indicates if the user is Active or not - 1 for Active, 0 for Deleted/Inactive
	[CREATED_USER] varchar(64) NOT NULL,	-- Created By user
	[CREATED_DATE] datetime NOT NULL,	-- Created Date
	[UPDATED_USER] varchar(64) NULL,	-- Updated By User
	[UPDATED_DATE] datetime NULL	-- Updated Date
)
GO

/* Create Primary Keys, Indexes, Uniques, Checks */

ALTER TABLE [CES].[WORK] 
 ADD CONSTRAINT [PK_WORK]
	PRIMARY KEY CLUSTERED ([WORK_SR_KEY] ASC)
GO

CREATE NONCLUSTERED INDEX [IX_WORK_ASSET_EXAMTYPE_ISLATEST] ON [CES].[WORK]
(
	[ISACTIVE] ASC,
	[ASSET_GUID] ASC,
	[EXAM_TYPE_SR_KEY] ASC
)
INCLUDE ( 	[WORK_YEAR_KEY],
	[EXAM_DUE_DATE],
	[WORK_STATUS],
	[SPECIFIC_EXAM_REQ],
	[NR_INTERNAL_NOTES],
	[COMMENTS_TO_SEC])
GO
/* Create Foreign Key Constraints */

ALTER TABLE [CES].[WORK] ADD CONSTRAINT [FK_WORK_ASSET]
	FOREIGN KEY ([ASSET_GUID]) REFERENCES [CES].[ASSET] ([ASSET_GUID]) ON DELETE No Action ON UPDATE No Action
GO

ALTER TABLE [CES].[WORK] ADD CONSTRAINT [FK_WORK_EXAM_TYPE]
	FOREIGN KEY ([EXAM_TYPE_SR_KEY]) REFERENCES [CES].[EXAM_TYPE] ([EXAM_TYPE_SR_KEY]) ON DELETE No Action ON UPDATE No Action
GO

ALTER TABLE [CES].[WORK] ADD CONSTRAINT [FK_WORK_REF_VAL_WORK_YR]
	FOREIGN KEY ([WORK_YEAR_KEY]) REFERENCES [CES].[REFERENCE_VALUE] ([REF_VAL_SR_KEY]) ON DELETE No Action ON UPDATE No Action
GO

ALTER TABLE [CES].[WORK] ADD CONSTRAINT [FK_WORK_ORG]
	FOREIGN KEY ([ORG_SR_KEY]) REFERENCES [CES].[ORG] ([ORG_SR_KEY]) ON DELETE No Action ON UPDATE No Action
GO

ALTER TABLE [CES].[WORK] ADD CONSTRAINT [FK_WORK_REF_VAL_WORK_STAT]
	FOREIGN KEY ([WORK_STATUS]) REFERENCES [CES].[REFERENCE_VALUE] ([REF_VAL_SR_KEY]) ON DELETE No Action ON UPDATE No Action
GO

/* Create Table Comments */

EXEC sp_addextendedproperty 'MS_Description', 'WorkBank Surrogate key (PK)', 'Schema', [CES], 'table', [WORK], 'column', [WORK_SR_KEY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Financial year', 'Schema', [CES], 'table', [WORK], 'column', [WORK_YEAR_KEY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Financial year start date', 'Schema', [CES], 'table', [WORK], 'column', [WORK_YR_START_DT]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Fianancial year end date', 'Schema', [CES], 'table', [WORK], 'column', [WORK_YR_END_DT]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Route information', 'Schema', [CES], 'table', [WORK], 'column', [ORG_SR_KEY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Asset GUID for assets selected in Tasklist screen/coming from CARRS', 'Schema', [CES], 'table', [WORK], 'column', [ASSET_GUID]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Exam Type for the assets', 'Schema', [CES], 'table', [WORK], 'column', [EXAM_TYPE_SR_KEY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Exam Due Date - either default as per due date algo or as entered by the AE in Task list request screen or coming from CARRS', 'Schema', [CES], 'table', [WORK], 'column', [EXAM_DUE_DATE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Task List Status', 'Schema', [CES], 'table', [WORK], 'column', [WORK_STATUS]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Specific exam requests', 'Schema', [CES], 'table', [WORK], 'column', [SPECIFIC_EXAM_REQ]
GO

EXEC sp_addextendedproperty 'MS_Description', 'NR internal Notes', 'Schema', [CES], 'table', [WORK], 'column', [NR_INTERNAL_NOTES]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Comments to the supplier', 'Schema', [CES], 'table', [WORK], 'column', [COMMENTS_TO_SEC]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Job Number associated with examination', 'Schema', [CES], 'table', [WORK], 'column', [JOB_NUMBER]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Indicates if the user is Active or not - 1 for Active, 0 for Deleted/Inactive', 'Schema', [CES], 'table', [WORK], 'column', [ISACTIVE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Created By user', 'Schema', [CES], 'table', [WORK], 'column', [CREATED_USER]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Created Date', 'Schema', [CES], 'table', [WORK], 'column', [CREATED_DATE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Updated By User', 'Schema', [CES], 'table', [WORK], 'column', [UPDATED_USER]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Updated Date', 'Schema', [CES], 'table', [WORK], 'column', [UPDATED_DATE]
GO