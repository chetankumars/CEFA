﻿CREATE TABLE [CES].[ACTION]
(
	[ACTION_SR_KEY] decimal(18) NOT NULL IDENTITY (1, 1),	-- Action Surrogate Key
	[RECOMMEND_SR_KEY] decimal(18) NOT NULL,	-- Recommendation key (FK)
	[ACTION_NUM] decimal(18) NOT NULL,	-- Action Number
	[RECOMMEND_NUM] decimal(18) NULL,	-- Recommendation Number
	[DESCRIPTION] varchar(1000) NOT NULL,	-- Description of Action
	[LOCATION] varchar(100) NULL,	-- Location details
	[WORK_TYPE] decimal(18) NULL,	-- Work Type
	[WORK_CATEGORY] decimal(18) NULL,	-- Work Category
	[WORK_STATUS] decimal(18) NULL,	-- Work Status
	[PRIORITY_YEAR] decimal(18) NULL,	-- Priority Year (Financial Year)
	[QUANTITY] decimal(18,2) NULL,	-- Quantity
	[QUANTITY_UNIT] varchar(32) NULL,	-- Units measured for quantity
	[RISK_SCORE] varchar(5) NULL,	-- Risk Score
	[SEVERITY] varchar(5) NULL,	-- Severity
	[PROBABILITY] varchar(5) NULL,	-- Probability
	[EXTENT] varchar(12) NULL,	-- Extent
	[ESTIMATED_COST] decimal(18,2) NULL,	-- Estimated Cost
	[NOTES] varchar(4000) NULL,	-- Notes
	[CARRS_ACTION_ID] decimal(18) NULL,	-- Action ID (generated in CARRS) - required for data synchronization
	[ISACTIVE] bit NOT NULL DEFAULT 1,	-- Indicates whether the record is active or not
	[CREATED_USER] varchar(64) NOT NULL,	-- Created by user
	[CREATED_DATE] datetime NOT NULL,	-- Created Date
	[UPDATED_USER] varchar(64) NULL,	-- Updated by User
	[UPDATED_DATE] datetime NULL	-- Updated Date
)
GO

/* Create Primary Keys, Indexes, Uniques, Checks */

ALTER TABLE [CES].[ACTION] 
 ADD CONSTRAINT [PK_ACTION]
	PRIMARY KEY CLUSTERED ([ACTION_SR_KEY] ASC)
GO

CREATE NONCLUSTERED INDEX [IX_ACTION_RECMND_ISACTIVE] ON [CES].[ACTION]
(
	[RECOMMEND_SR_KEY] ASC,
	[ISACTIVE] ASC
)
INCLUDE ( 	[ACTION_NUM],
	[WORK_STATUS],
	[PRIORITY_YEAR],
	[RISK_SCORE],
	[NOTES])
GO

/* Create Foreign Key Constraints */

ALTER TABLE [CES].[ACTION] ADD CONSTRAINT [FK_ACTION_RECOMMENDATION]
	FOREIGN KEY ([RECOMMEND_SR_KEY]) REFERENCES [CES].[RECOMMENDATION] ([RECOMMEND_SR_KEY]) ON DELETE No Action ON UPDATE No Action
GO

ALTER TABLE [CES].[ACTION] ADD CONSTRAINT [FK_ACTION_REF_VAL_PRIO_YR]
	FOREIGN KEY ([PRIORITY_YEAR]) REFERENCES [CES].[REFERENCE_VALUE] ([REF_VAL_SR_KEY]) ON DELETE No Action ON UPDATE No Action
GO

ALTER TABLE [CES].[ACTION] ADD CONSTRAINT [FK_ACTION_REF_VAL_WRK_CAT]
	FOREIGN KEY ([WORK_CATEGORY]) REFERENCES [CES].[REFERENCE_VALUE] ([REF_VAL_SR_KEY]) ON DELETE No Action ON UPDATE No Action
GO

ALTER TABLE [CES].[ACTION] ADD CONSTRAINT [FK_ACTION_REF_VAL_WRK_TYP]
	FOREIGN KEY ([WORK_TYPE]) REFERENCES [CES].[REFERENCE_VALUE] ([REF_VAL_SR_KEY]) ON DELETE No Action ON UPDATE No Action
GO

ALTER TABLE [CES].[ACTION] ADD CONSTRAINT [FK_ACTION_REF_VAL_WRL_STATS]
	FOREIGN KEY ([WORK_STATUS]) REFERENCES [CES].[REFERENCE_VALUE] ([REF_VAL_SR_KEY]) ON DELETE No Action ON UPDATE No Action
GO

/* Create Table Comments */

EXEC sp_addextendedproperty 'MS_Description', 'Action Surrogate Key', 'Schema', [CES], 'table', [ACTION], 'column', [ACTION_SR_KEY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Recommendation key (FK)', 'Schema', [CES], 'table', [ACTION], 'column', [RECOMMEND_SR_KEY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Action Number', 'Schema', [CES], 'table', [ACTION], 'column', [ACTION_NUM]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Recommendation Number', 'Schema', [CES], 'table', [ACTION], 'column', [RECOMMEND_NUM]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Description of Action', 'Schema', [CES], 'table', [ACTION], 'column', [DESCRIPTION]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Location details', 'Schema', [CES], 'table', [ACTION], 'column', [LOCATION]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Work Type', 'Schema', [CES], 'table', [ACTION], 'column', [WORK_TYPE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Work Category', 'Schema', [CES], 'table', [ACTION], 'column', [WORK_CATEGORY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Work Status', 'Schema', [CES], 'table', [ACTION], 'column', [WORK_STATUS]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Priority Year (Financial Year)', 'Schema', [CES], 'table', [ACTION], 'column', [PRIORITY_YEAR]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Quantity', 'Schema', [CES], 'table', [ACTION], 'column', [QUANTITY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Units measured for quantity', 'Schema', [CES], 'table', [ACTION], 'column', [QUANTITY_UNIT]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Risk Score', 'Schema', [CES], 'table', [ACTION], 'column', [RISK_SCORE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Severity', 'Schema', [CES], 'table', [ACTION], 'column', [SEVERITY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Probability', 'Schema', [CES], 'table', [ACTION], 'column', [PROBABILITY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Extent', 'Schema', [CES], 'table', [ACTION], 'column', [EXTENT]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Estimated Cost', 'Schema', [CES], 'table', [ACTION], 'column', [ESTIMATED_COST]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Notes', 'Schema', [CES], 'table', [ACTION], 'column', [NOTES]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Action ID (generated in CARRS) - required for data synchronization', 'Schema', [CES], 'table', [ACTION], 'column', [CARRS_ACTION_ID]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Indicates whether the record is active or not', 'Schema', [CES], 'table', [ACTION], 'column', [ISACTIVE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Created by user', 'Schema', [CES], 'table', [ACTION], 'column', [CREATED_USER]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Created Date', 'Schema', [CES], 'table', [ACTION], 'column', [CREATED_DATE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Updated by User', 'Schema', [CES], 'table', [ACTION], 'column', [UPDATED_USER]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Updated Date', 'Schema', [CES], 'table', [ACTION], 'column', [UPDATED_DATE]
GO