﻿CREATE TABLE [CES].[EXAM_GROUP_ASSET_MAP]
(
	[EXAM_GROUP_ASSET_MAP_SR_KEY] decimal(18) NOT NULL IDENTITY (1, 1),	-- ExamGroup Asset Map surrogate key (PK)
	[EXAM_GROUP_SR_KEY] decimal(18) NOT NULL,	-- Exam Group Key
	[ASSET_GUID] varchar(32) NOT NULL,	-- Asset GUID mapped with Exam Group
	[ISACTIVE] bit NOT NULL DEFAULT 1,	-- Indicates if the record is Active or not - 1 for Active, 0 for Deleted/Inactive
	[CREATED_USER] varchar(64) NOT NULL,	-- Created by User
	[CREATED_DATE] datetime NOT NULL,	-- Created Date
	[UPDATED_USER] varchar(64) NULL,	-- Updated by user
	[UPDATED_DATE] datetime NULL
)
GO

/* Create Primary Keys, Indexes, Uniques, Checks */

ALTER TABLE [CES].[EXAM_GROUP_ASSET_MAP] 
 ADD CONSTRAINT [PK_EXAM_GROUP_ASSET_MAP]
	PRIMARY KEY CLUSTERED ([EXAM_GROUP_ASSET_MAP_SR_KEY] ASC)
GO

/* Create Foreign Key Constraints */

ALTER TABLE [CES].[EXAM_GROUP_ASSET_MAP] ADD CONSTRAINT [FK_EXAM_GROUP_ASSET_MAP_ASSET]
	FOREIGN KEY ([ASSET_GUID]) REFERENCES [CES].[ASSET] ([ASSET_GUID]) ON DELETE No Action ON UPDATE No Action
GO

ALTER TABLE [CES].[EXAM_GROUP_ASSET_MAP] ADD CONSTRAINT [FK_EXAM_GROUP_ASSET_MAP_EXAM_GROUP]
	FOREIGN KEY ([EXAM_GROUP_SR_KEY]) REFERENCES [CES].[EXAM_GROUP] ([EXAM_GROUP_SR_KEY]) ON DELETE No Action ON UPDATE No Action
GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Updated by user', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'EXAM_GROUP_ASSET_MAP', @level2type = N'COLUMN', @level2name = N'UPDATED_USER';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Created Date', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'EXAM_GROUP_ASSET_MAP', @level2type = N'COLUMN', @level2name = N'CREATED_DATE';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Created by User', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'EXAM_GROUP_ASSET_MAP', @level2type = N'COLUMN', @level2name = N'CREATED_USER';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Indicates if the record is Active or not - 1 for Active, 0 for Deleted/Inactive', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'EXAM_GROUP_ASSET_MAP', @level2type = N'COLUMN', @level2name = N'ISACTIVE';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Asset GUID mapped with Exam Group', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'EXAM_GROUP_ASSET_MAP', @level2type = N'COLUMN', @level2name = N'ASSET_GUID';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Exam Group Key', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'EXAM_GROUP_ASSET_MAP', @level2type = N'COLUMN', @level2name = N'EXAM_GROUP_SR_KEY';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'ExamGroup Asset Map surrogate key (PK)', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'EXAM_GROUP_ASSET_MAP', @level2type = N'COLUMN', @level2name = N'EXAM_GROUP_ASSET_MAP_SR_KEY';

