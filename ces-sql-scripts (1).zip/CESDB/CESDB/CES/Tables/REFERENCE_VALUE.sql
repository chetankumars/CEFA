﻿CREATE TABLE [CES].[REFERENCE_VALUE]
(
	[REF_VAL_SR_KEY] decimal(18) NOT NULL IDENTITY (1, 1),	-- Reference Value Surrogate Key
	[REF_TYP_SR_KEY] decimal(18) NOT NULL,	-- Reference Type Id (Fk)
	[REF_VALUE] varchar(500) NOT NULL,	-- Reference Value 
	[ISACTIVE] bit NOT NULL DEFAULT 1,	-- Indicates if the user is Active or not - 1 for Active, 0 for Deleted/Inactive
	[CREATED_USER] varchar(64) NOT NULL,	-- Created By User
	[CREATED_DATE] datetime NOT NULL,	-- Created Date
	[UPDATED_USER] varchar(64) NULL,	-- Modified By User
	[UPDATED_DATE] datetime NULL	-- Modified Date
)
GO

/* Create Primary Keys, Indexes, Uniques, Checks */

ALTER TABLE [CES].[REFERENCE_VALUE] 
 ADD CONSTRAINT [PK_REFERENCE_VALUE]
	PRIMARY KEY CLUSTERED ([REF_VAL_SR_KEY] ASC)
GO

/* Create Foreign Key Constraints */

ALTER TABLE [CES].[REFERENCE_VALUE] ADD CONSTRAINT [FK_REFERENCE_VALUE_REFERENCE_TYPE]
	FOREIGN KEY ([REF_TYP_SR_KEY]) REFERENCES [CES].[REFERENCE_TYPE] ([REF_TYP_SR_KEY]) ON DELETE No Action ON UPDATE No Action
GO

/* Create Table Comments */

EXEC sp_addextendedproperty 'MS_Description', 'Reference Value Surrogate Key', 'Schema', [CES], 'table', [REFERENCE_VALUE], 'column', [REF_VAL_SR_KEY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Reference Type Id (Fk)', 'Schema', [CES], 'table', [REFERENCE_VALUE], 'column', [REF_TYP_SR_KEY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Reference Value ', 'Schema', [CES], 'table', [REFERENCE_VALUE], 'column', [REF_VALUE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Indicates if the user is Active or not - 1 for Active, 0 for Deleted/Inactive', 'Schema', [CES], 'table', [REFERENCE_VALUE], 'column', [ISACTIVE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Created By User', 'Schema', [CES], 'table', [REFERENCE_VALUE], 'column', [CREATED_USER]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Created Date', 'Schema', [CES], 'table', [REFERENCE_VALUE], 'column', [CREATED_DATE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Modified By User', 'Schema', [CES], 'table', [REFERENCE_VALUE], 'column', [UPDATED_USER]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Modified Date', 'Schema', [CES], 'table', [REFERENCE_VALUE], 'column', [UPDATED_DATE]
GO