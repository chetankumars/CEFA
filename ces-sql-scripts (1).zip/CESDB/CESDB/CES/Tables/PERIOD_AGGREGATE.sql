﻿CREATE TABLE [CES].[PERIOD_AGGREGATE] (
    [PERIOD_AGGR_SR_KEY]   DECIMAL (18) IDENTITY (1, 1) NOT NULL,
    [CONTRACT_YEAR]        VARCHAR (10) NULL,
    [PERIOD_KEY]           DECIMAL (3)  NULL,
    [ORG_SR_KEY]           DECIMAL (18) NULL,
    [SUPPLIER_SR_KEY]      DECIMAL (18) NULL,
    [EXAM_TYPE_SR_KEY]     DECIMAL (18) NULL,
    [TOTAL_ASSET_CNT]      DECIMAL (38) NULL,
    [TOTAL_NON_COMPL_CNT]  DECIMAL (38) NULL,
    [0TO1_NON_COMPL_CNT]   DECIMAL (38) NULL,
    [1TO3_NON_COMPL_CNT]   DECIMAL (38) NULL,
    [3TO6_NON_COMPL_CNT]   DECIMAL (38) NULL,
    [6TO12_NON_COMPL_CNT]  DECIMAL (38) NULL,
    [GRT12_NON_COMPL_CNT]  DECIMAL (38) NULL,
    [RISK_ASSESSED_CNT]    DECIMAL (38) NULL,
    [TOTAL_SUB_NCOMPL_CNT] DECIMAL (38) NULL,
    [TOTAL_SGN_NCOMPL_CNT] DECIMAL (38) NULL,
    [ISACTIVE]             BIT          DEFAULT ((1)) NOT NULL,
    [CREATED_USER]         VARCHAR (64) NOT NULL,
    [CREATED_DATE]         DATETIME     NOT NULL,
    [UPDATED_USER]         VARCHAR (64) NULL,
    [UPDATED_DATE]         DATETIME     NULL,
    CONSTRAINT [PK_PERIOD_AGGREGATE] PRIMARY KEY CLUSTERED ([PERIOD_AGGR_SR_KEY] ASC, [CREATED_USER] ASC, [CREATED_DATE] ASC),
    CONSTRAINT [FK_PERIOD_AGGREGATE_EXAM_TYPE] FOREIGN KEY ([EXAM_TYPE_SR_KEY]) REFERENCES [CES].[EXAM_TYPE] ([EXAM_TYPE_SR_KEY]),
    CONSTRAINT [FK_PERIOD_AGGREGATE_ORG] FOREIGN KEY ([ORG_SR_KEY]) REFERENCES [CES].[ORG] ([ORG_SR_KEY]),
    CONSTRAINT [FK_PERIOD_AGGREGATE_SUPPLIER] FOREIGN KEY ([SUPPLIER_SR_KEY]) REFERENCES [CES].[SUPPLIER] ([SUPPLIER_SR_KEY])
);


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Updated date', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'PERIOD_AGGREGATE', @level2type = N'COLUMN', @level2name = N'UPDATED_DATE';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Updated by user', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'PERIOD_AGGREGATE', @level2type = N'COLUMN', @level2name = N'UPDATED_USER';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Created date', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'PERIOD_AGGREGATE', @level2type = N'COLUMN', @level2name = N'CREATED_DATE';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Created by user', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'PERIOD_AGGREGATE', @level2type = N'COLUMN', @level2name = N'CREATED_USER';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Indicates if the user is Active or not - 1 for Active, 0 for Deleted/Inactive', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'PERIOD_AGGREGATE', @level2type = N'COLUMN', @level2name = N'ISACTIVE';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Total no of exams signoff non compliant', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'PERIOD_AGGREGATE', @level2type = N'COLUMN', @level2name = N'TOTAL_SGN_NCOMPL_CNT';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Total no of exams submission non compliant', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'PERIOD_AGGREGATE', @level2type = N'COLUMN', @level2name = N'TOTAL_SUB_NCOMPL_CNT';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Total no of exams non compliant and risk assessed', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'PERIOD_AGGREGATE', @level2type = N'COLUMN', @level2name = N'RISK_ASSESSED_CNT';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Total no of exams non compliant greater than 12 months', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'PERIOD_AGGREGATE', @level2type = N'COLUMN', @level2name = N'GRT12_NON_COMPL_CNT';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Total no of exams non compliant for 6 to 12 months', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'PERIOD_AGGREGATE', @level2type = N'COLUMN', @level2name = N'6TO12_NON_COMPL_CNT';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Total no of exams non compliant for 3 to 6 months', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'PERIOD_AGGREGATE', @level2type = N'COLUMN', @level2name = N'3TO6_NON_COMPL_CNT';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Total no of exams non compliant for 1 to 3 months', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'PERIOD_AGGREGATE', @level2type = N'COLUMN', @level2name = N'1TO3_NON_COMPL_CNT';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Total no of exams non compliant for 0 to 1 month', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'PERIOD_AGGREGATE', @level2type = N'COLUMN', @level2name = N'0TO1_NON_COMPL_CNT';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Total no of exams non compliant', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'PERIOD_AGGREGATE', @level2type = N'COLUMN', @level2name = N'TOTAL_NON_COMPL_CNT';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Total no of assets', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'PERIOD_AGGREGATE', @level2type = N'COLUMN', @level2name = N'TOTAL_ASSET_CNT';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Exam type surrogate key (Fk)', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'PERIOD_AGGREGATE', @level2type = N'COLUMN', @level2name = N'EXAM_TYPE_SR_KEY';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Suppliers Surrogate key (FK)', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'PERIOD_AGGREGATE', @level2type = N'COLUMN', @level2name = N'SUPPLIER_SR_KEY';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Org Surrogate key (FK)', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'PERIOD_AGGREGATE', @level2type = N'COLUMN', @level2name = N'ORG_SR_KEY';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Period key', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'PERIOD_AGGREGATE', @level2type = N'COLUMN', @level2name = N'PERIOD_KEY';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Contract year (2019/2020)', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'PERIOD_AGGREGATE', @level2type = N'COLUMN', @level2name = N'CONTRACT_YEAR';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Period aggregate fact key (pk)', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'PERIOD_AGGREGATE', @level2type = N'COLUMN', @level2name = N'PERIOD_AGGR_SR_KEY';

