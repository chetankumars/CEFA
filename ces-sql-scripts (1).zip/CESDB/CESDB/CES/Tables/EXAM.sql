﻿CREATE TABLE [CES].[EXAM]
(
	[EXAM_SR_KEY] decimal(18) NOT NULL IDENTITY (1, 1),	-- Exam Surrogate key (pk)
	[EXAM_ID] decimal(18) NULL,	-- CARRS examination ID 
	[ASSET_GUID] varchar(32) NOT NULL,	-- Unique asset reference (fk)
	[WORK_SR_KEY] decimal(18) NULL,	-- WorkBank Surrogate key (fk)
	[EXAM_BASELINE_DATE] date NULL,	-- Examination baseline Planned Date (Supplier)
	[EXAM_PLANNED_DATE] date NULL,	-- Examination Planned Date (Supplier)
	[EXAM_ACTUAL_DATE] date NULL,	-- Examination Actual Date (Supplier)
	[EXAM_REVIEW_DATE] date NULL,	-- Supplier (STE2) review Date
	[EXAM_SUBMISSION_DATE] date NULL,	-- Examination submission Date (Supplier)
	[EXAM_SIGNOFF_DATE] date NULL,	-- Examination signoff Date (Supplier)
	[EXAM_TYPE_SR_KEY] decimal(18) NULL,	-- Exam type surrogate key (Fk)
	[EXAM_REQ_STATUS] decimal(18) NOT NULL,	-- Exam Request Status
	[EXAM_REPORT_STATUS] decimal(18) NULL,	-- examination Status < Received , Under evaluation , Signed off ,Evaluated by ASME , Rejected , Rejected by audit etc….. )
	[EXAM_COMPLETED_IND] varchar(5) NULL,	-- Complete Examination - Yes/No
	[EXAMINER_NAME] varchar(64) NULL,	-- Examiner name
	[EXAMINER_COMMENT] varchar(4000) NULL,	-- Examiner General Comments
	[REVIEWER_NAME] varchar(64) NULL,	-- Examining Engineer name
	[REVIEWER_COMMENT] varchar(4000) NULL,	-- Examining Engineer Comments
	[SUPPLIER_SR_KEY] decimal(18) NULL,	-- Suppliers Surrogate key (FK)
	[SUPPLIER_REPORT_FILENAME] varchar(200) NULL,	-- Examination Report File name
	[SUPPLIER_REPORT_REFERENCE] varchar(500) NULL,	-- Supplier Examination Report Reference
	[SUPPLIER_ZIP_FILENAME] varchar(200) NULL,	-- Examination images File name
	[INSTRUCTION] varchar(128) NULL,	-- Instructions for Tunnel examinations
	[CMI_SCORE] decimal(3) NULL,	-- Condition Marking Index score
	[CMI_DATE] date NULL,	-- Asset Condition Marking Index Date
	[PNE_FLAG] varchar(5) NULL,	-- "Asset" Part not examined - Flag (Yes/No)
	[STRUC_DESCRIPTION] varchar(1000) NULL,	-- Asset structure description
	[AT_OR_BETWEEN_STATIONS] varchar(64) NULL,	-- Asset between stations < Blackfriars and Elephant - Castle ,  Unknown and Unknown , Hounslow And Feltham , London Bridge And New Cross etc >
	[OBSERVED_UNDER_LOAD] bit NULL,	-- Asset observed under load < Yes , No>
	[SPAN_TEXT] varchar(10) NULL,	-- Span text
	[INTERNAL_NOTES] varchar(4000) NULL,	-- NR Internal Notes
	[COMMENT_TO_SEC] varchar(4000) NULL,	-- Comments to Supplier
	[CHANGE_REQ_ID] varchar(20) NULL,	-- Change Request ID for any exam
	[SUPPLIER_COMMENTS] varchar(2000) NULL,	-- Supplier comments as received through Task List Date excel/UI/External API
	[IS_LAST_EXAM] char(1) NOT NULL,	-- Indicates if this is the last exam ID for an asset and exam type (required for compliance calculation) - Y/N
	[EXAM_GROUP_SR_KEY] decimal(18) NULL,	-- Exam Group ID - required for task list
	[EXAM_REQUIREMENT] varchar(1000) NULL,	-- Specific Exam Requirement associated with an Exam in CARRS
	[ISACTIVE] bit NOT NULL DEFAULT 1,	-- Indicates if the user is Active or not - 1 for Active, 0 for Deleted/Inactive
	[CREATED_USER] varchar(64) NOT NULL,	-- Created by user
	[CREATED_DATE] datetime NOT NULL,	-- Created date
	[UPDATED_USER] varchar(64) NULL,	-- Updated by user
	[UPDATED_DATE] datetime NULL	-- Updated date
)
GO

/* Create Primary Keys, Indexes, Uniques, Checks */

ALTER TABLE [CES].[EXAM] 
 ADD CONSTRAINT [PK_EXAM]
	PRIMARY KEY CLUSTERED ([EXAM_SR_KEY] ASC)
GO

CREATE NONCLUSTERED INDEX [IX_EXAM_ASSET_EXAMTYPE_ISLAST_ISACTIVE] ON [CES].[EXAM]
(
	[ASSET_GUID] ASC,
	[EXAM_TYPE_SR_KEY] ASC,
	[ISACTIVE] ASC,
	[IS_LAST_EXAM] ASC
)
INCLUDE ( 	[EXAM_ACTUAL_DATE])
GO

CREATE NONCLUSTERED INDEX [IX_EXAM_EXAMREQSTATUS_ISACTIVE] ON [CES].[EXAM]
(
	[EXAM_REQ_STATUS] ASC,
	[ISACTIVE] ASC
)
INCLUDE ( 	[ASSET_GUID],
	[EXAM_PLANNED_DATE],
	[EXAM_ACTUAL_DATE],
	[EXAM_SUBMISSION_DATE],
	[EXAM_SIGNOFF_DATE],
	[EXAM_REPORT_STATUS],
	[IS_LAST_EXAM])
GO

CREATE NONCLUSTERED INDEX [IX_EXAM_ISACTIVE_ASSETGUID_EXAMTYPE] ON [CES].[EXAM]
(
	[ISACTIVE] ASC,
	[ASSET_GUID] ASC,
	[EXAM_TYPE_SR_KEY] ASC
)
INCLUDE ( 	[EXAM_ID],
	[EXAM_ACTUAL_DATE],
	[EXAM_PLANNED_DATE],
	[EXAM_REPORT_STATUS],
	[EXAM_SIGNOFF_DATE],
	[EXAM_SUBMISSION_DATE],
	[EXAM_BASELINE_DATE],
	[EXAM_REQ_STATUS],
	[SUPPLIER_SR_KEY],
	[IS_LAST_EXAM],
	[WORK_SR_KEY],
	[INTERNAL_NOTES],
	[COMMENT_TO_SEC],
	[CHANGE_REQ_ID],
	[SUPPLIER_COMMENTS])
GO

CREATE NONCLUSTERED INDEX [IX_EXAM_WORKKEY_SUPPLIER_ISACTIVE] ON [CES].[EXAM]
(
	[WORK_SR_KEY] ASC,
	[SUPPLIER_SR_KEY] ASC,
	[ISACTIVE] ASC
)
INCLUDE ( 	[EXAM_ID],
	[ASSET_GUID],
	[EXAM_BASELINE_DATE],
	[EXAM_PLANNED_DATE],
	[EXAM_ACTUAL_DATE],
	[EXAM_SUBMISSION_DATE],
	[EXAM_SIGNOFF_DATE],
	[EXAM_TYPE_SR_KEY],
	[EXAM_REQ_STATUS],
	[EXAM_REPORT_STATUS],
	[INTERNAL_NOTES],
	[COMMENT_TO_SEC],
	[CHANGE_REQ_ID],
	[SUPPLIER_COMMENTS],
	[EXAM_GROUP_SR_KEY])
GO

/* Create Foreign Key Constraints */

ALTER TABLE [CES].[EXAM] ADD CONSTRAINT [FK_EXAM_ASSET]
	FOREIGN KEY ([ASSET_GUID]) REFERENCES [CES].[ASSET] ([ASSET_GUID]) ON DELETE No Action ON UPDATE No Action
GO

ALTER TABLE [CES].[EXAM] ADD CONSTRAINT [FK_EXAM_EXAM_GROUP]
	FOREIGN KEY ([EXAM_GROUP_SR_KEY]) REFERENCES [CES].[EXAM_GROUP] ([EXAM_GROUP_SR_KEY]) ON DELETE No Action ON UPDATE No Action
GO

ALTER TABLE [CES].[EXAM] ADD CONSTRAINT [FK_EXAM_EXAM_TYPE]
	FOREIGN KEY ([EXAM_TYPE_SR_KEY]) REFERENCES [CES].[EXAM_TYPE] ([EXAM_TYPE_SR_KEY]) ON DELETE No Action ON UPDATE No Action
GO

ALTER TABLE [CES].[EXAM] ADD CONSTRAINT [FK_EXAM_REF_VALUE_EXM_REQ_STAT]
	FOREIGN KEY ([EXAM_REQ_STATUS]) REFERENCES [CES].[REFERENCE_VALUE] ([REF_VAL_SR_KEY]) ON DELETE No Action ON UPDATE No Action
GO

ALTER TABLE [CES].[EXAM] ADD CONSTRAINT [FK_EXAM_REF_VALUE_EXM_RPT_STAT]
	FOREIGN KEY ([EXAM_REPORT_STATUS]) REFERENCES [CES].[REFERENCE_VALUE] ([REF_VAL_SR_KEY]) ON DELETE No Action ON UPDATE No Action
GO

ALTER TABLE [CES].[EXAM] ADD CONSTRAINT [FK_EXAM_SUPPLIER]
	FOREIGN KEY ([SUPPLIER_SR_KEY]) REFERENCES [CES].[SUPPLIER] ([SUPPLIER_SR_KEY]) ON DELETE No Action ON UPDATE No Action
GO

ALTER TABLE [CES].[EXAM] ADD CONSTRAINT [FK_EXAM_WORK]
	FOREIGN KEY ([WORK_SR_KEY]) REFERENCES [CES].[WORK] ([WORK_SR_KEY]) ON DELETE No Action ON UPDATE No Action
GO

/* Create Table Comments */

EXEC sp_addextendedproperty 'MS_Description', 'Exam Surrogate key (pk)', 'Schema', [CES], 'table', [EXAM], 'column', [EXAM_SR_KEY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'CARRS examination ID ', 'Schema', [CES], 'table', [EXAM], 'column', [EXAM_ID]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Unique asset reference (fk)', 'Schema', [CES], 'table', [EXAM], 'column', [ASSET_GUID]
GO

EXEC sp_addextendedproperty 'MS_Description', 'WorkBank Surrogate key (fk)', 'Schema', [CES], 'table', [EXAM], 'column', [WORK_SR_KEY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Examination baseline Planned Date (Supplier)', 'Schema', [CES], 'table', [EXAM], 'column', [EXAM_BASELINE_DATE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Examination Planned Date (Supplier)', 'Schema', [CES], 'table', [EXAM], 'column', [EXAM_PLANNED_DATE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Examination Actual Date (Supplier)', 'Schema', [CES], 'table', [EXAM], 'column', [EXAM_ACTUAL_DATE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Supplier (STE2) review Date', 'Schema', [CES], 'table', [EXAM], 'column', [EXAM_REVIEW_DATE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Examination submission Date (Supplier)', 'Schema', [CES], 'table', [EXAM], 'column', [EXAM_SUBMISSION_DATE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Examination signoff Date (Supplier)', 'Schema', [CES], 'table', [EXAM], 'column', [EXAM_SIGNOFF_DATE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Exam type surrogate key (Fk)', 'Schema', [CES], 'table', [EXAM], 'column', [EXAM_TYPE_SR_KEY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Exam Request Status', 'Schema', [CES], 'table', [EXAM], 'column', [EXAM_REQ_STATUS]
GO

EXEC sp_addextendedproperty 'MS_Description', 'examination Status < Received , Under evaluation , Signed off ,Evaluated by ASME , Rejected , Rejected by audit etc….. )', 'Schema', [CES], 'table', [EXAM], 'column', [EXAM_REPORT_STATUS]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Complete Examination - Yes/No', 'Schema', [CES], 'table', [EXAM], 'column', [EXAM_COMPLETED_IND]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Examiner name', 'Schema', [CES], 'table', [EXAM], 'column', [EXAMINER_NAME]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Examiner General Comments', 'Schema', [CES], 'table', [EXAM], 'column', [EXAMINER_COMMENT]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Examining Engineer name', 'Schema', [CES], 'table', [EXAM], 'column', [REVIEWER_NAME]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Examining Engineer Comments', 'Schema', [CES], 'table', [EXAM], 'column', [REVIEWER_COMMENT]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Suppliers Surrogate key (FK)', 'Schema', [CES], 'table', [EXAM], 'column', [SUPPLIER_SR_KEY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Examination Report File name', 'Schema', [CES], 'table', [EXAM], 'column', [SUPPLIER_REPORT_FILENAME]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Supplier Examination Report Reference', 'Schema', [CES], 'table', [EXAM], 'column', [SUPPLIER_REPORT_REFERENCE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Examination images File name', 'Schema', [CES], 'table', [EXAM], 'column', [SUPPLIER_ZIP_FILENAME]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Instructions for Tunnel examinations', 'Schema', [CES], 'table', [EXAM], 'column', [INSTRUCTION]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Condition Marking Index score', 'Schema', [CES], 'table', [EXAM], 'column', [CMI_SCORE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Asset Condition Marking Index Date', 'Schema', [CES], 'table', [EXAM], 'column', [CMI_DATE]
GO

EXEC sp_addextendedproperty 'MS_Description', '"Asset" Part not examined - Flag (Yes/No)', 'Schema', [CES], 'table', [EXAM], 'column', [PNE_FLAG]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Asset structure description', 'Schema', [CES], 'table', [EXAM], 'column', [STRUC_DESCRIPTION]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Asset between stations < Blackfriars and Elephant - Castle ,  Unknown and Unknown , Hounslow And Feltham , London Bridge And New Cross etc >', 'Schema', [CES], 'table', [EXAM], 'column', [AT_OR_BETWEEN_STATIONS]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Asset observed under load < Yes , No>', 'Schema', [CES], 'table', [EXAM], 'column', [OBSERVED_UNDER_LOAD]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Span text', 'Schema', [CES], 'table', [EXAM], 'column', [SPAN_TEXT]
GO

EXEC sp_addextendedproperty 'MS_Description', 'NR Internal Notes', 'Schema', [CES], 'table', [EXAM], 'column', [INTERNAL_NOTES]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Comments to Supplier', 'Schema', [CES], 'table', [EXAM], 'column', [COMMENT_TO_SEC]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Change Request ID for any exam', 'Schema', [CES], 'table', [EXAM], 'column', [CHANGE_REQ_ID]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Supplier comments as received through Task List Date excel/UI/External API', 'Schema', [CES], 'table', [EXAM], 'column', [SUPPLIER_COMMENTS]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Indicates if this is the last exam ID for an asset and exam type (required for compliance calculation) - Y/N', 'Schema', [CES], 'table', [EXAM], 'column', [IS_LAST_EXAM]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Exam Group ID - required for task list', 'Schema', [CES], 'table', [EXAM], 'column', [EXAM_GROUP_SR_KEY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Specific Exam Requirement associated with an Exam in CARRS', 'Schema', [CES], 'table', [EXAM], 'column', [EXAM_REQUIREMENT]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Indicates if the user is Active or not - 1 for Active, 0 for Deleted/Inactive', 'Schema', [CES], 'table', [EXAM], 'column', [ISACTIVE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Created by user', 'Schema', [CES], 'table', [EXAM], 'column', [CREATED_USER]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Created date', 'Schema', [CES], 'table', [EXAM], 'column', [CREATED_DATE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Updated by user', 'Schema', [CES], 'table', [EXAM], 'column', [UPDATED_USER]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Updated date', 'Schema', [CES], 'table', [EXAM], 'column', [UPDATED_DATE]
GO