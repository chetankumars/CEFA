﻿CREATE TABLE [CES].[ENGINE_LINE_REF]
(
	[ELR_SR_KEY] decimal(18) NOT NULL IDENTITY (1, 1),	-- ELR Surrogate Key
	[ELR_CODE] varchar(4) NOT NULL,	-- ELR Code
	[ELR_NAME] varchar(100) NOT NULL,	-- ELR Name
	[ORG_SR_KEY] decimal(18) NULL,	-- Route associated with ELR
	[AREA_SR_KEY] decimal(18) NULL,	-- Area associated with ELR
	[ISACTIVE] bit NOT NULL DEFAULT 1,	-- Indicates if the user is Active or not - 1 for Active, 0 for Deleted/Inactive
	[CREATED_USER] varchar(64) NOT NULL,	-- Created By User
	[CREATED_DATE] datetime NOT NULL,	-- Created Date
	[UPDATED_USER] varchar(64) NULL,	-- Updated By User
	[UPDATED_DATE] datetime NULL	-- Updated Date
)
GO

/* Create Primary Keys, Indexes, Uniques, Checks */

ALTER TABLE [CES].[ENGINE_LINE_REF] 
 ADD CONSTRAINT [PK_ELR]
	PRIMARY KEY CLUSTERED ([ELR_SR_KEY] ASC)
GO

CREATE NONCLUSTERED INDEX [IX_ENGINELINEREF_ISACTIVE_ELRCODE] ON [CES].[ENGINE_LINE_REF]
(
	[ISACTIVE] ASC,
	[ELR_CODE] ASC
)
INCLUDE ( 	[ELR_SR_KEY])
GO

/* Create Foreign Key Constraints */

ALTER TABLE [CES].[ENGINE_LINE_REF] ADD CONSTRAINT [FK_ENGINE_LINE_REF_AREA]
	FOREIGN KEY ([AREA_SR_KEY]) REFERENCES [CES].[AREA] ([AREA_SR_KEY]) ON DELETE No Action ON UPDATE No Action
GO

ALTER TABLE [CES].[ENGINE_LINE_REF] ADD CONSTRAINT [FK_ENGINE_LINE_REF_ORG]
	FOREIGN KEY ([ORG_SR_KEY]) REFERENCES [CES].[ORG] ([ORG_SR_KEY]) ON DELETE No Action ON UPDATE No Action
GO

/* Create Table Comments */

EXEC sp_addextendedproperty 'MS_Description', 'ELR Surrogate Key', 'Schema', [CES], 'table', [ENGINE_LINE_REF], 'column', [ELR_SR_KEY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'ELR Code', 'Schema', [CES], 'table', [ENGINE_LINE_REF], 'column', [ELR_CODE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'ELR Name', 'Schema', [CES], 'table', [ENGINE_LINE_REF], 'column', [ELR_NAME]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Route associated with ELR', 'Schema', [CES], 'table', [ENGINE_LINE_REF], 'column', [ORG_SR_KEY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Area associated with ELR', 'Schema', [CES], 'table', [ENGINE_LINE_REF], 'column', [AREA_SR_KEY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Indicates if the user is Active or not - 1 for Active, 0 for Deleted/Inactive', 'Schema', [CES], 'table', [ENGINE_LINE_REF], 'column', [ISACTIVE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Created By User', 'Schema', [CES], 'table', [ENGINE_LINE_REF], 'column', [CREATED_USER]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Created Date', 'Schema', [CES], 'table', [ENGINE_LINE_REF], 'column', [CREATED_DATE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Updated By User', 'Schema', [CES], 'table', [ENGINE_LINE_REF], 'column', [UPDATED_USER]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Updated Date', 'Schema', [CES], 'table', [ENGINE_LINE_REF], 'column', [UPDATED_DATE]
GO