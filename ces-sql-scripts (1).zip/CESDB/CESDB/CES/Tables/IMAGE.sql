﻿CREATE TABLE [CES].[IMAGE]
(
	[IMAGE_SR_KEY] decimal(18) NOT NULL IDENTITY (1, 1),	-- Image Surrogate key (pk)
	[EXAM_SR_KEY] decimal(18) NOT NULL,	-- Exam Surrogate key (fk)
	[DESCRIPTION] varchar(128) NULL,	-- description of the Image
	[IMAGE_INDEX] decimal(3) NULL,	-- Photo Index
	[IMAGE_TYPE] varchar(50) NULL,	-- Image Type
	[IMAGE_NAME] varchar(200) NULL,	-- Image Name
	[IMAGE_LINK] varchar(500) NULL,	-- Link to image location
	[ISACTIVE] bit NOT NULL DEFAULT 1,	-- Indicates if the user is Active or not - 1 for Active, 0 for Deleted/Inactive
	[CREATED_USER] varchar(64) NOT NULL,	-- Created by user
	[CREATED_DATE] datetime NOT NULL,	-- Created date
	[UPDATED_USER] varchar(64) NULL,	-- Updated by user
	[UPDATED_DATE] datetime NULL	-- Updated date
)
GO

/* Create Primary Keys, Indexes, Uniques, Checks */

ALTER TABLE [CES].[IMAGE] 
 ADD CONSTRAINT [PK_IMAGE]
	PRIMARY KEY CLUSTERED ([IMAGE_SR_KEY] ASC)
GO

/* Create Foreign Key Constraints */

ALTER TABLE [CES].[IMAGE] ADD CONSTRAINT [FK_IMAGE_EXAM]
	FOREIGN KEY ([EXAM_SR_KEY]) REFERENCES [CES].[EXAM] ([EXAM_SR_KEY]) ON DELETE No Action ON UPDATE No Action
GO

/* Create Table Comments */

EXEC sp_addextendedproperty 'MS_Description', 'Image Surrogate key (pk)', 'Schema', [CES], 'table', [IMAGE], 'column', [IMAGE_SR_KEY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Exam Surrogate key (fk)', 'Schema', [CES], 'table', [IMAGE], 'column', [EXAM_SR_KEY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'description of the Image', 'Schema', [CES], 'table', [IMAGE], 'column', [DESCRIPTION]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Photo Index', 'Schema', [CES], 'table', [IMAGE], 'column', [IMAGE_INDEX]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Image Type', 'Schema', [CES], 'table', [IMAGE], 'column', [IMAGE_TYPE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Image Name', 'Schema', [CES], 'table', [IMAGE], 'column', [IMAGE_NAME]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Link to image location', 'Schema', [CES], 'table', [IMAGE], 'column', [IMAGE_LINK]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Indicates if the user is Active or not - 1 for Active, 0 for Deleted/Inactive', 'Schema', [CES], 'table', [IMAGE], 'column', [ISACTIVE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Created by user', 'Schema', [CES], 'table', [IMAGE], 'column', [CREATED_USER]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Created date', 'Schema', [CES], 'table', [IMAGE], 'column', [CREATED_DATE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Updated by user', 'Schema', [CES], 'table', [IMAGE], 'column', [UPDATED_USER]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Updated date', 'Schema', [CES], 'table', [IMAGE], 'column', [UPDATED_DATE]
GO