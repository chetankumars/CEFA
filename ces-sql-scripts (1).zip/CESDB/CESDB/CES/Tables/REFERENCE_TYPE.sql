﻿CREATE TABLE [CES].[REFERENCE_TYPE]
(
	[REF_TYP_SR_KEY] decimal(18) NOT NULL,	-- Reference Type surrogate Key
	[REF_TYP_CODE] varchar(5) NOT NULL,	-- Reference Type Code
	[REF_TYP_NAME] varchar(50) NOT NULL,	-- Reference Type Name
	[SOURCE] varchar(10) NOT NULL,	-- Source of Reference Type - CARRS/CES etc (required for ADF refresh and syncup)
	[ISACTIVE] bit NOT NULL DEFAULT 1,
	[CREATED_USER] varchar(64) NOT NULL,	-- Created by user
	[CREATED_DATE] datetime NOT NULL,	-- Created Date
	[UPDATED_USER] varchar(64) NULL,	-- Updated by user
	[UPDATED_DATE] datetime NULL
)
GO

/* Create Primary Keys, Indexes, Uniques, Checks */

ALTER TABLE [CES].[REFERENCE_TYPE] 
 ADD CONSTRAINT [PK_REFERENCE_TYPE]
	PRIMARY KEY CLUSTERED ([REF_TYP_SR_KEY] ASC)
GO

/* Create Table Comments */

EXEC sp_addextendedproperty 'MS_Description', 'Reference Type surrogate Key', 'Schema', [CES], 'table', [REFERENCE_TYPE], 'column', [REF_TYP_SR_KEY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Reference Type Code', 'Schema', [CES], 'table', [REFERENCE_TYPE], 'column', [REF_TYP_CODE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Reference Type Name', 'Schema', [CES], 'table', [REFERENCE_TYPE], 'column', [REF_TYP_NAME]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Source of Reference Type - CARRS/CES etc (required for ADF refresh and syncup)', 'Schema', [CES], 'table', [REFERENCE_TYPE], 'column', [SOURCE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Created by user', 'Schema', [CES], 'table', [REFERENCE_TYPE], 'column', [CREATED_USER]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Created Date', 'Schema', [CES], 'table', [REFERENCE_TYPE], 'column', [CREATED_DATE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Updated by user', 'Schema', [CES], 'table', [REFERENCE_TYPE], 'column', [UPDATED_USER]
GO