﻿CREATE TABLE [CES].[RISK_ASSESSMENT]
(
	[RISK_SR_KEY] decimal(18) NOT NULL IDENTITY (1, 1),	-- Risk Surrogate Key (pk)
	[ASSET_GUID] varchar(32) NOT NULL,	-- Unique asset reference (fk)
	[EXAM_TYPE_SR_KEY] decimal(18) NOT NULL,	-- Exam type surrogate key (Fk)
	[ASSESSMENT_DATE] date NULL,	-- Risk Assessment Date
	[REVIEW_DATE] date NULL,	-- Review date
	[EXPIRY_DATE] date NULL,	-- Risk Assessment expiry Date
	[RISK_SCORE] varchar(10) NULL,	-- Non compliant Risk Score
	[RISK_ASSESS_STATUS] decimal(18) NULL,	-- Risk Assessment Status
	[RISK_USER] varchar(64) NULL,	-- Risk Created user
	[QUESTION_01] varchar(256) NULL,	-- Question asked on Risk Assessment form
	[QUESTION_01_ANS] varchar(1) NULL,	-- Answer to the question (Yes/No)
	[QUESTION_01_CMT] varchar(1000) NULL,	-- Rationale comment
	[QUESTION_02] varchar(256) NULL,	-- Question asked on Risk Assessment form
	[QUESTION_02_ANS] varchar(1) NULL,	-- Answer to the question (Yes/No)
	[QUESTION_02_CMT] varchar(1000) NULL,	-- Rationale comment
	[QUESTION_03] varchar(256) NULL,	-- Question asked on Risk Assessment form
	[QUESTION_03_ANS] varchar(1) NULL,	-- Answer to the question (Yes/No)
	[QUESTION_03_CMT] varchar(1000) NULL,	-- Rationale comment
	[QUESTION_04] varchar(256) NULL,	-- Question asked on Risk Assessment form
	[QUESTION_04_ANS] varchar(1) NULL,	-- Answer to the question (Yes/No)
	[QUESTION_04_CMT] varchar(1000) NULL,	-- Rationale comment
	[MITIGATION_ACTION_01] varchar(100) NULL,	-- Mitigation Action 1 on Risk Assessment Form for risk score as Higher 
	[MITIGATION_ACTION_01_SELECTION] varchar(1) NULL,	-- Indicates if the Mitigation Action 1 is selected or not - Y/N
	[MITIGATION_ACTION_02] varchar(100) NULL,	-- Mitigation Action 2 on Risk Assessment Form for risk score as Higher
	[MITIGATION_ACTION_02_SELECTION] varchar(1) NULL,	-- Indicates if the Mitigation Action 2 is selected or not - Y/N
	[MITIGATION_ACTION_03] varchar(100) NULL,	-- Mitigation Action 3 on Risk Assessment Form for risk score as Higher
	[MITIGATION_ACTION_03_SELECTION] varchar(1) NULL,	-- Indicates if the Mitigation Action 3 is selected or not - Y/N
	[MITIGATION_ACTION_04] varchar(100) NULL,	-- Mitigation Action 4 on Risk Assessment Form for risk score as Higher
	[MITIGATION_ACTION_04_SELECTION] varchar(1) NULL,	-- Indicates if the Mitigation Action 4 is selected or not - Y/N
	[MITIGATION_ACTION_05] varchar(100) NULL,	-- Mitigation Action 5 on Risk Assessment Form for risk score as Higher
	[MITIGATION_ACTION_05_SELECTION] varchar(1) NULL,	-- Indicates if the Mitigation Action 5 is selected or not - Y/N
	[MITIGATION_ACTION_06] varchar(100) NULL,	-- Mitigation Action 6 on Risk Assessment Form for risk score as Higher
	[MITIGATION_ACTION_06_SELECTION] varchar(1) NULL,	-- Indicates if the Mitigation Action 6 is selected or not - Y/N
	[MITIGATION_ACTION_07] varchar(100) NULL,	-- Mitigation Action 7 on Risk Assessment Form for risk score as Higher
	[MITIGATION_ACTION_07_SELECTION] varchar(1) NULL,	-- Indicates if the Mitigation Action 7 is selected or not - Y/N
	[MITIGATION_DATE] date NULL,	-- Mitigation Date
	[MITIGATION_COMMENT] varchar(1000) NULL,	-- Mitigation rationale/comment
	[ISLATEST] char(1) NOT NULL,	-- Indicates whether the record is the latest risk assessment record for the asset and exam type - Y/N
	[BRIDGE_RA_ID] decimal(18) NULL,	-- RA ID column from Bridge application - required for migration track
	[ISACTIVE] bit NOT NULL DEFAULT 1,	-- Indicates if the user is Active or not - 1 for Active, 0 for Deleted/Inactive
	[CREATED_USER] varchar(64) NOT NULL,	-- Created by user
	[CREATED_DATE] datetime NOT NULL,	-- Created date
	[UPDATED_USER] varchar(64) NULL,	-- Updated by user
	[UPDATED_DATE] datetime NULL	-- Updated date
)
GO

/* Create Primary Keys, Indexes, Uniques, Checks */

ALTER TABLE [CES].[RISK_ASSESSMENT] 
 ADD CONSTRAINT [PK_RISK_ASSESSMENT]
	PRIMARY KEY CLUSTERED ([RISK_SR_KEY] ASC)
GO

CREATE NONCLUSTERED INDEX [IX_RISK_ASSESSMENT_ISACTIVE_ASSETGUID_EXAMTYPE] ON [CES].[RISK_ASSESSMENT]
(
	[ISACTIVE] ASC,
	[ASSET_GUID] ASC,
	[EXAM_TYPE_SR_KEY] ASC
)
INCLUDE ( 	[REVIEW_DATE],
	[EXPIRY_DATE],
	[RISK_SCORE],
	[RISK_ASSESS_STATUS],
	[ISLATEST])
GO

/* Create Foreign Key Constraints */

ALTER TABLE [CES].[RISK_ASSESSMENT] ADD CONSTRAINT [FK_RISK_ASSESS_REF_VAL_RSK_STAT]
	FOREIGN KEY ([RISK_ASSESS_STATUS]) REFERENCES [CES].[REFERENCE_VALUE] ([REF_VAL_SR_KEY]) ON DELETE No Action ON UPDATE No Action
GO

ALTER TABLE [CES].[RISK_ASSESSMENT] ADD CONSTRAINT [FK_RISK_ASSESSMENT_ASSET]
	FOREIGN KEY ([ASSET_GUID]) REFERENCES [CES].[ASSET] ([ASSET_GUID]) ON DELETE No Action ON UPDATE No Action
GO

ALTER TABLE [CES].[RISK_ASSESSMENT] ADD CONSTRAINT [FK_RISK_ASSESSMENT_EXAM_TYPE]
	FOREIGN KEY ([EXAM_TYPE_SR_KEY]) REFERENCES [CES].[EXAM_TYPE] ([EXAM_TYPE_SR_KEY]) ON DELETE No Action ON UPDATE No Action
GO

/* Create Table Comments */

EXEC sp_addextendedproperty 'MS_Description', 'Risk Surrogate Key (pk)', 'Schema', [CES], 'table', [RISK_ASSESSMENT], 'column', [RISK_SR_KEY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Unique asset reference (fk)', 'Schema', [CES], 'table', [RISK_ASSESSMENT], 'column', [ASSET_GUID]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Exam type surrogate key (Fk)', 'Schema', [CES], 'table', [RISK_ASSESSMENT], 'column', [EXAM_TYPE_SR_KEY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Risk Assessment Date', 'Schema', [CES], 'table', [RISK_ASSESSMENT], 'column', [ASSESSMENT_DATE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Review date', 'Schema', [CES], 'table', [RISK_ASSESSMENT], 'column', [REVIEW_DATE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Risk Assessment expiry Date', 'Schema', [CES], 'table', [RISK_ASSESSMENT], 'column', [EXPIRY_DATE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Non compliant Risk Score', 'Schema', [CES], 'table', [RISK_ASSESSMENT], 'column', [RISK_SCORE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Risk Assessment Status', 'Schema', [CES], 'table', [RISK_ASSESSMENT], 'column', [RISK_ASSESS_STATUS]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Risk Created user', 'Schema', [CES], 'table', [RISK_ASSESSMENT], 'column', [RISK_USER]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Question asked on Risk Assessment form', 'Schema', [CES], 'table', [RISK_ASSESSMENT], 'column', [QUESTION_01]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Answer to the question (Yes/No)', 'Schema', [CES], 'table', [RISK_ASSESSMENT], 'column', [QUESTION_01_ANS]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Rationale comment', 'Schema', [CES], 'table', [RISK_ASSESSMENT], 'column', [QUESTION_01_CMT]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Question asked on Risk Assessment form', 'Schema', [CES], 'table', [RISK_ASSESSMENT], 'column', [QUESTION_02]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Answer to the question (Yes/No)', 'Schema', [CES], 'table', [RISK_ASSESSMENT], 'column', [QUESTION_02_ANS]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Rationale comment', 'Schema', [CES], 'table', [RISK_ASSESSMENT], 'column', [QUESTION_02_CMT]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Question asked on Risk Assessment form', 'Schema', [CES], 'table', [RISK_ASSESSMENT], 'column', [QUESTION_03]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Answer to the question (Yes/No)', 'Schema', [CES], 'table', [RISK_ASSESSMENT], 'column', [QUESTION_03_ANS]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Rationale comment', 'Schema', [CES], 'table', [RISK_ASSESSMENT], 'column', [QUESTION_03_CMT]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Question asked on Risk Assessment form', 'Schema', [CES], 'table', [RISK_ASSESSMENT], 'column', [QUESTION_04]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Answer to the question (Yes/No)', 'Schema', [CES], 'table', [RISK_ASSESSMENT], 'column', [QUESTION_04_ANS]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Rationale comment', 'Schema', [CES], 'table', [RISK_ASSESSMENT], 'column', [QUESTION_04_CMT]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Mitigation Action 1 on Risk Assessment Form for risk score as Higher ', 'Schema', [CES], 'table', [RISK_ASSESSMENT], 'column', [MITIGATION_ACTION_01]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Indicates if the Mitigation Action 1 is selected or not - Y/N', 'Schema', [CES], 'table', [RISK_ASSESSMENT], 'column', [MITIGATION_ACTION_01_SELECTION]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Mitigation Action 2 on Risk Assessment Form for risk score as Higher', 'Schema', [CES], 'table', [RISK_ASSESSMENT], 'column', [MITIGATION_ACTION_02]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Indicates if the Mitigation Action 2 is selected or not - Y/N', 'Schema', [CES], 'table', [RISK_ASSESSMENT], 'column', [MITIGATION_ACTION_02_SELECTION]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Mitigation Action 3 on Risk Assessment Form for risk score as Higher', 'Schema', [CES], 'table', [RISK_ASSESSMENT], 'column', [MITIGATION_ACTION_03]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Indicates if the Mitigation Action 3 is selected or not - Y/N', 'Schema', [CES], 'table', [RISK_ASSESSMENT], 'column', [MITIGATION_ACTION_03_SELECTION]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Mitigation Action 4 on Risk Assessment Form for risk score as Higher', 'Schema', [CES], 'table', [RISK_ASSESSMENT], 'column', [MITIGATION_ACTION_04]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Indicates if the Mitigation Action 4 is selected or not - Y/N', 'Schema', [CES], 'table', [RISK_ASSESSMENT], 'column', [MITIGATION_ACTION_04_SELECTION]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Mitigation Action 5 on Risk Assessment Form for risk score as Higher', 'Schema', [CES], 'table', [RISK_ASSESSMENT], 'column', [MITIGATION_ACTION_05]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Indicates if the Mitigation Action 5 is selected or not - Y/N', 'Schema', [CES], 'table', [RISK_ASSESSMENT], 'column', [MITIGATION_ACTION_05_SELECTION]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Mitigation Action 6 on Risk Assessment Form for risk score as Higher', 'Schema', [CES], 'table', [RISK_ASSESSMENT], 'column', [MITIGATION_ACTION_06]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Indicates if the Mitigation Action 6 is selected or not - Y/N', 'Schema', [CES], 'table', [RISK_ASSESSMENT], 'column', [MITIGATION_ACTION_06_SELECTION]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Mitigation Action 7 on Risk Assessment Form for risk score as Higher', 'Schema', [CES], 'table', [RISK_ASSESSMENT], 'column', [MITIGATION_ACTION_07]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Indicates if the Mitigation Action 7 is selected or not - Y/N', 'Schema', [CES], 'table', [RISK_ASSESSMENT], 'column', [MITIGATION_ACTION_07_SELECTION]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Mitigation Date', 'Schema', [CES], 'table', [RISK_ASSESSMENT], 'column', [MITIGATION_DATE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Mitigation rationale/comment', 'Schema', [CES], 'table', [RISK_ASSESSMENT], 'column', [MITIGATION_COMMENT]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Indicates whether the record is the latest risk assessment record for the asset and exam type - Y/N', 'Schema', [CES], 'table', [RISK_ASSESSMENT], 'column', [ISLATEST]
GO

EXEC sp_addextendedproperty 'MS_Description', 'RA ID column from Bridge application - required for migration track', 'Schema', [CES], 'table', [RISK_ASSESSMENT], 'column', [BRIDGE_RA_ID]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Indicates if the user is Active or not - 1 for Active, 0 for Deleted/Inactive', 'Schema', [CES], 'table', [RISK_ASSESSMENT], 'column', [ISACTIVE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Created by user', 'Schema', [CES], 'table', [RISK_ASSESSMENT], 'column', [CREATED_USER]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Created date', 'Schema', [CES], 'table', [RISK_ASSESSMENT], 'column', [CREATED_DATE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Updated by user', 'Schema', [CES], 'table', [RISK_ASSESSMENT], 'column', [UPDATED_USER]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Updated date', 'Schema', [CES], 'table', [RISK_ASSESSMENT], 'column', [UPDATED_DATE]
GO