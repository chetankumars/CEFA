﻿CREATE TABLE [CES].[EXAM_UPDATE_STG] (
    [EXAM_ID]            DECIMAL (18)   NOT NULL,
    [ASSET_GUID]         VARCHAR (32)   NOT NULL,
    [EXAM_PLANNED_DATE]  DATE           NULL,
    [EXAM_REVIEW_DATE]   DATE           NULL,
    [EXAM_SIGNOFF_DATE]  DATE           NULL,
    [EXAM_TYPE_SR_KEY]   DECIMAL (18)   NULL,
    [EXAM_REQ_STATUS]    DECIMAL (18)   NOT NULL,
    [EXAM_REPORT_STATUS] DECIMAL (18)   NULL,
    [EXAM_GROUP_SR_KEY]  DECIMAL (18)   NULL,
    [EXAM_REQUIREMENT]   VARCHAR (1000) NULL,
    [SUPPLIER_SR_KEY]    DECIMAL(18)    NULL,	
	[INTERNAL_NOTES]     VARCHAR(4000)  NULL,	
	[COMMENT_TO_SEC]     VARCHAR(50)    NULL,	
	[DELETED_FLG]        VARCHAR (1)    NULL,
    [ISACTIVE]           BIT            DEFAULT ((1)) NOT NULL,
    [CREATED_USER]       VARCHAR (64)   DEFAULT ('CARRS') NOT NULL,
    [CREATED_DATE]       DATETIME       DEFAULT (getdate()) NOT NULL,
    [UPDATED_USER]       VARCHAR (64)   NULL,
    [UPDATED_DATE]       DATETIME       NULL
);


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Updated date', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'EXAM_UPDATE_STG', @level2type = N'COLUMN', @level2name = N'UPDATED_DATE';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Updated by user', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'EXAM_UPDATE_STG', @level2type = N'COLUMN', @level2name = N'UPDATED_USER';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Created date', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'EXAM_UPDATE_STG', @level2type = N'COLUMN', @level2name = N'CREATED_DATE';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Created by user', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'EXAM_UPDATE_STG', @level2type = N'COLUMN', @level2name = N'CREATED_USER';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Indicates if the user is Active or not - 1 for Active, 0 for Deleted/Inactive', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'EXAM_UPDATE_STG', @level2type = N'COLUMN', @level2name = N'ISACTIVE';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Deleted Flag - appearing from CARRS to indicate the active/deleted record in sync process', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'EXAM_UPDATE_STG', @level2type = N'COLUMN', @level2name = N'DELETED_FLG';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Specific Exam Requirement associated with an Exam in CARRS', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'EXAM_UPDATE_STG', @level2type = N'COLUMN', @level2name = N'EXAM_REQUIREMENT';


GO
EXEC sp_addextendedproperty 'MS_Description', 'Suppliers Surrogate key (FK)', 'Schema', [CES], 'table', [EXAM_UPDATE_STG], 'column', [SUPPLIER_SR_KEY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'NR Internal Notes', 'Schema', [CES], 'table', [EXAM_UPDATE_STG], 'column', [INTERNAL_NOTES]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Comments to Supplier', 'Schema', [CES], 'table', [EXAM_UPDATE_STG], 'column', [COMMENT_TO_SEC]
GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Exam Group ID - required for task list', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'EXAM_UPDATE_STG', @level2type = N'COLUMN', @level2name = N'EXAM_GROUP_SR_KEY';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'examination Status < Received , Under evaluation , Signed off ,Evaluated by ASME , Rejected , Rejected by audit etc….. )', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'EXAM_UPDATE_STG', @level2type = N'COLUMN', @level2name = N'EXAM_REPORT_STATUS';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Exam Request Status', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'EXAM_UPDATE_STG', @level2type = N'COLUMN', @level2name = N'EXAM_REQ_STATUS';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Exam type surrogate key (Fk)', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'EXAM_UPDATE_STG', @level2type = N'COLUMN', @level2name = N'EXAM_TYPE_SR_KEY';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Examination signoff Date (Supplier)', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'EXAM_UPDATE_STG', @level2type = N'COLUMN', @level2name = N'EXAM_SIGNOFF_DATE';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Supplier (STE2) review Date', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'EXAM_UPDATE_STG', @level2type = N'COLUMN', @level2name = N'EXAM_REVIEW_DATE';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Examination Planned Date (Supplier)', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'EXAM_UPDATE_STG', @level2type = N'COLUMN', @level2name = N'EXAM_PLANNED_DATE';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Unique asset reference (fk)', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'EXAM_UPDATE_STG', @level2type = N'COLUMN', @level2name = N'ASSET_GUID';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'CARRS examination ID ', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'EXAM_UPDATE_STG', @level2type = N'COLUMN', @level2name = N'EXAM_ID';

