﻿CREATE TABLE [CES].[AREA]
(
	[AREA_SR_KEY] decimal(18) NOT NULL,	-- Area Surrogate key (pk)
	[ORG_SR_KEY] decimal(18) NOT NULL,	-- Route associated with Area
	[AREA_NAME] varchar(64) NOT NULL,	-- Area Name
	[ISACTIVE] bit NOT NULL DEFAULT 1,
	[CREATED_USER] varchar(64) NOT NULL,	-- Created User
	[CREATED_DATE] datetime NOT NULL,	-- Created Date
	[UPDATED_USER] varchar(64) NULL,	-- Updated User
	[UPDATED_DATE] datetime NULL	-- Updated Date
)
GO

/* Create Primary Keys, Indexes, Uniques, Checks */

ALTER TABLE [CES].[AREA] 
 ADD CONSTRAINT [PK_AREA]
	PRIMARY KEY CLUSTERED ([AREA_SR_KEY] ASC)
GO

/* Create Foreign Key Constraints */

ALTER TABLE [CES].[AREA] ADD CONSTRAINT [FK_AREA_ORG]
	FOREIGN KEY ([ORG_SR_KEY]) REFERENCES [CES].[ORG] ([ORG_SR_KEY]) ON DELETE No Action ON UPDATE No Action
GO

/* Create Table Comments */

EXEC sp_addextendedproperty 'MS_Description', 'Area Surrogate key (pk)', 'Schema', [CES], 'table', [AREA], 'column', [AREA_SR_KEY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Route associated with Area', 'Schema', [CES], 'table', [AREA], 'column', [ORG_SR_KEY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Area Name', 'Schema', [CES], 'table', [AREA], 'column', [AREA_NAME]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Created User', 'Schema', [CES], 'table', [AREA], 'column', [CREATED_USER]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Created Date', 'Schema', [CES], 'table', [AREA], 'column', [CREATED_DATE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Updated User', 'Schema', [CES], 'table', [AREA], 'column', [UPDATED_USER]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Updated Date', 'Schema', [CES], 'table', [AREA], 'column', [UPDATED_DATE]
GO