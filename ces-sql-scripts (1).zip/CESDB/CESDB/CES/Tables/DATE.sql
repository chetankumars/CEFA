﻿CREATE TABLE [CES].[DATE]
(
	[DATE] date NOT NULL,	-- Date (pk)
	[DAY_OF_WEEK] varchar(32) NOT NULL,	-- DayofWeek < Monday , Tuesday , Wednesday etc ..>
	[WEEK_NUM] decimal(3) NOT NULL,	-- Week number for the date
	[CONTRACT_YEAR] varchar(10) NOT NULL,	-- Contract year (2019/2020)
	[PERIOD_KEY] decimal(3) NOT NULL,	-- Period key (01,02..)
	[CONTRACT_PERIOD] varchar(10) NOT NULL,	-- Contract period (CP6)
	[ISACTIVE] bit NOT NULL DEFAULT 1,	-- Indicates if the user is Active or not - 1 for Active, 0 for Deleted/Inactive
	[CREATED_USER] varchar(64) NOT NULL,	-- Created by user
	[CREATED_DATE] datetime NOT NULL,	-- Created date
	[UPDATED_USER] varchar(64) NULL,	-- Updated by user
	[UPDATED_DATE] datetime NULL	-- Updated date
)
GO

/* Create Primary Keys, Indexes, Uniques, Checks */

ALTER TABLE [CES].[DATE] 
 ADD CONSTRAINT [PK_DATE]
	PRIMARY KEY CLUSTERED ([DATE] ASC)
GO

/* Create Table Comments */

EXEC sp_addextendedproperty 'MS_Description', 'Date (pk)', 'Schema', [CES], 'table', [DATE], 'column', [DATE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'DayofWeek < Monday , Tuesday , Wednesday etc ..>', 'Schema', [CES], 'table', [DATE], 'column', [DAY_OF_WEEK]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Week number for the date', 'Schema', [CES], 'table', [DATE], 'column', [WEEK_NUM]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Contract year (2019/2020)', 'Schema', [CES], 'table', [DATE], 'column', [CONTRACT_YEAR]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Period key (01,02..)', 'Schema', [CES], 'table', [DATE], 'column', [PERIOD_KEY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Contract period (CP6)', 'Schema', [CES], 'table', [DATE], 'column', [CONTRACT_PERIOD]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Indicates if the user is Active or not - 1 for Active, 0 for Deleted/Inactive', 'Schema', [CES], 'table', [DATE], 'column', [ISACTIVE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Created by user', 'Schema', [CES], 'table', [DATE], 'column', [CREATED_USER]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Created date', 'Schema', [CES], 'table', [DATE], 'column', [CREATED_DATE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Updated by user', 'Schema', [CES], 'table', [DATE], 'column', [UPDATED_USER]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Updated date', 'Schema', [CES], 'table', [DATE], 'column', [UPDATED_DATE]
GO