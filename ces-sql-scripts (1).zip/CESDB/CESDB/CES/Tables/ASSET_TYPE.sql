﻿CREATE TABLE [CES].[ASSET_TYPE]
(
	[ASSET_TYPE_SR_KEY] decimal(18) NOT NULL,	-- Asset type surrogate key (pk)
	[ASSET_GROUP_SR_KEY] decimal(18) NOT NULL,	-- Asset Group Surrogate Key (Fk)
	[ASSET_TYPE] varchar(5) NOT NULL,	-- Asset Type the asset belongs to ( example culvert , footbridge , overline bridge , retaining wall etc)
	[ASSET_TYPE_DESC] varchar(64) NOT NULL,	-- Asset type description
	[ISACTIVE] bit NOT NULL DEFAULT 1,	-- Indicates if the user is Active or not - 1 for Active, 0 for Deleted/Inactive
	[CREATED_USER] varchar(64) NOT NULL,	-- Created by user
	[CREATED_DATE] datetime NOT NULL,	-- Created date
	[UPDATED_USER] varchar(64) NULL,	-- Updated by user
	[UPDATED_DATE] datetime NULL	-- Updated date
)
GO

/* Create Primary Keys, Indexes, Uniques, Checks */

ALTER TABLE [CES].[ASSET_TYPE] 
 ADD CONSTRAINT [PK_ASSET_TYPE]
	PRIMARY KEY CLUSTERED ([ASSET_TYPE_SR_KEY] ASC)
GO

/* Create Foreign Key Constraints */

ALTER TABLE [CES].[ASSET_TYPE] ADD CONSTRAINT [FK_ASSET_TYPE_ASSET_GROUP]
	FOREIGN KEY ([ASSET_GROUP_SR_KEY]) REFERENCES [CES].[ASSET_GROUP] ([ASSET_GROUP_SR_KEY]) ON DELETE No Action ON UPDATE No Action
GO

/* Create Table Comments */

EXEC sp_addextendedproperty 'MS_Description', 'Asset type surrogate key (pk)', 'Schema', [CES], 'table', [ASSET_TYPE], 'column', [ASSET_TYPE_SR_KEY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Asset Group Surrogate Key (Fk)', 'Schema', [CES], 'table', [ASSET_TYPE], 'column', [ASSET_GROUP_SR_KEY]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Asset Type the asset belongs to ( example culvert , footbridge , overline bridge , retaining wall etc)', 'Schema', [CES], 'table', [ASSET_TYPE], 'column', [ASSET_TYPE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Asset type description', 'Schema', [CES], 'table', [ASSET_TYPE], 'column', [ASSET_TYPE_DESC]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Indicates if the user is Active or not - 1 for Active, 0 for Deleted/Inactive', 'Schema', [CES], 'table', [ASSET_TYPE], 'column', [ISACTIVE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Created by user', 'Schema', [CES], 'table', [ASSET_TYPE], 'column', [CREATED_USER]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Created date', 'Schema', [CES], 'table', [ASSET_TYPE], 'column', [CREATED_DATE]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Updated by user', 'Schema', [CES], 'table', [ASSET_TYPE], 'column', [UPDATED_USER]
GO

EXEC sp_addextendedproperty 'MS_Description', 'Updated date', 'Schema', [CES], 'table', [ASSET_TYPE], 'column', [UPDATED_DATE]
GO