﻿CREATE TABLE [CES].[COMPLIANCE_STG] (
    [ASSET_GUID]        VARCHAR (32) NOT NULL,
    [EXAM_TYPE_SR_KEY]  DECIMAL (18) NOT NULL,
    [COMP_DATE]         DATE         NULL,
    [INTERVAL_DAYS]     DECIMAL (3)  NULL,
    [INTERVAL_MONTHS]   DECIMAL (3)  NULL,
    [INTERVAL_YEARS]    DECIMAL (3)  NULL,
    [EFFECTIVE_FROM_DT] DATE         NOT NULL,
    [EFFECTIVE_TO_DT]   DATE         NULL,
    [ISACTIVE]          BIT          DEFAULT ((1)) NOT NULL,
    [CREATED_USER]      VARCHAR (64) NOT NULL,
    [CREATED_DATE]      DATETIME     NOT NULL,
    [UPDATED_USER]      VARCHAR (64) NULL,
    [UPDATED_DATE]      DATETIME     NULL
);


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Updated date', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'COMPLIANCE_STG', @level2type = N'COLUMN', @level2name = N'UPDATED_DATE';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Updated by user', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'COMPLIANCE_STG', @level2type = N'COLUMN', @level2name = N'UPDATED_USER';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Created date', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'COMPLIANCE_STG', @level2type = N'COLUMN', @level2name = N'CREATED_DATE';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Created by user', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'COMPLIANCE_STG', @level2type = N'COLUMN', @level2name = N'CREATED_USER';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Indicates if the user is Active or not - 1 for Active, 0 for Deleted/Inactive', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'COMPLIANCE_STG', @level2type = N'COLUMN', @level2name = N'ISACTIVE';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Effective To Date', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'COMPLIANCE_STG', @level2type = N'COLUMN', @level2name = N'EFFECTIVE_TO_DT';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Effective From Date', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'COMPLIANCE_STG', @level2type = N'COLUMN', @level2name = N'EFFECTIVE_FROM_DT';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Compliance Frequency in years', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'COMPLIANCE_STG', @level2type = N'COLUMN', @level2name = N'INTERVAL_YEARS';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Compliance Frequency in months', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'COMPLIANCE_STG', @level2type = N'COLUMN', @level2name = N'INTERVAL_MONTHS';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Compliance Frequency in days', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'COMPLIANCE_STG', @level2type = N'COLUMN', @level2name = N'INTERVAL_DAYS';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Compliance due date', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'COMPLIANCE_STG', @level2type = N'COLUMN', @level2name = N'COMP_DATE';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Exam type surrogate key (Fk)', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'COMPLIANCE_STG', @level2type = N'COLUMN', @level2name = N'EXAM_TYPE_SR_KEY';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = 'Unique asset reference (fk)', @level0type = N'SCHEMA', @level0name = N'CES', @level1type = N'TABLE', @level1name = N'COMPLIANCE_STG', @level2type = N'COLUMN', @level2name = N'ASSET_GUID';

